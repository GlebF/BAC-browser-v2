﻿Public Class MBMD_Search

    Private Sub Algorithm_1()
        Dim WordLength As Integer = WordLTextBox.Text
        Dim TotalWordList As New List(Of K_Word_PWM)
        Dim PrimeMatchScore As Single = PrimeMatchTextBox.Text
        Dim PrimeMismatchScore As Single = PrimeMismatchTextBox.Text
        Dim InputSequences As New List(Of String)
        Dim InputHeaders As New List(Of String)

        If Not SeqFileTextBox.Text = "" Then

            Dim RS As New IO.FileStream(SeqFileTextBox.Text, IO.FileMode.Open)
            Dim Reader As New IO.StreamReader(RS)
            Dim CurrentLine As String = ""
            Dim CurrentHeader As String = ""

            While Reader.Peek > -1
                CurrentLine = Reader.ReadLine
                If CurrentLine.StartsWith(">") Then 'This is fasta header
                    CurrentHeader = CurrentLine.Substring(1)
                    InputHeaders.Add(CurrentHeader)
                Else 'This is sequence
                    InputSequences.Add(CurrentLine)
                    For i = 0 To CurrentLine.Length - WordLength
                        Dim KWord As New K_Word_PWM
                        KWord.Word_Position = i
                        KWord.Word_Text = CurrentLine.Substring(i, WordLength)
                        KWord.Seq_ID = CurrentHeader
                        KWord.Match_Score = PrimeMatchScore
                        KWord.Mismatch_Score = PrimeMismatchScore
                        TotalWordList.Add(KWord)
                    Next

                End If
            End While

            Reader.Close()
            RS.Close()
            Reader.Dispose()
            RS.Dispose()

        ElseIf Not SeqTextBox.Text = "" Then


            ' SeqTextBox.Text = SeqTextBox.Text.ToUpper()
            Dim Sequences As New List(Of Char())
            Dim SeqArr As String() = SeqTextBox.Text.Split(vbNewLine)
            Dim CurrentLine As String = ""
            Dim CurrentHeader As String = ""
            Dim HeaderIncrement As Integer = 0
            Dim TmpHeader As String = ""

            For Each Seq As String In SeqArr
                CurrentLine = Seq
                CurrentLine = CurrentLine.Replace(Chr(10), "")
                CurrentLine = CurrentLine.Replace(Chr(13), "")
                If Not CurrentLine = "" Then
                    If CurrentLine.StartsWith(">") Then
                        CurrentHeader = CurrentLine.Substring(1)
                        InputHeaders.Add(CurrentHeader)
                    Else

                        CurrentLine = CurrentLine.ToUpper

                        InputSequences.Add(CurrentLine)

                        If CurrentHeader = "" Then
                            TmpHeader = "Seq" & HeaderIncrement
                            InputHeaders.Add(TmpHeader)
                            HeaderIncrement += 1
                        End If

                        For i = 0 To CurrentLine.Length - WordLength
                            Dim KWord As New K_Word_PWM
                            KWord.Word_Position = i
                            KWord.Word_Text = CurrentLine.Substring(i, WordLength)
                            If CurrentHeader = "" Then
                                KWord.Seq_ID = TmpHeader
                            Else
                                KWord.Seq_ID = CurrentHeader
                            End If

                            KWord.Match_Score = PrimeMatchScore
                            KWord.Mismatch_Score = PrimeMismatchScore
                            TotalWordList.Add(KWord)
                        Next
                    End If

                End If
            Next

        Else
            Exit Sub
        End If



        Dim A_P As Single = 0
        Dim T_P As Single = 0
        Dim G_P As Single = 0
        Dim C_P As Single = 0

        If AutoPButton.Checked Then
            'Make correction for nucleotide distribution in a sample
            Dim A_counter As Integer = 0
            Dim T_counter As Integer = 0
            Dim G_counter As Integer = 0
            Dim C_counter As Integer = 0
            Dim Total_counter As Integer = 0
            For Each Word As K_Word_PWM In TotalWordList
                For i = 0 To Word.Word_Text.Length - 1
                    Select Case Word.Word_Text(i)
                        Case "A"
                            A_counter += 1
                        Case "T"
                            T_counter += 1
                        Case "G"
                            G_counter += 1
                        Case "C"
                            C_counter += 1
                    End Select
                Next
            Next
            Total_counter = A_counter + T_counter + G_counter + C_counter
            A_P = A_counter / Total_counter
            T_P = T_counter / Total_counter
            G_P = G_counter / Total_counter
            C_P = C_counter / Total_counter

            TextBox_AP.Text = A_P
            TextBox_TP.Text = T_P
            TextBox_GP.Text = G_P
            TextBox_CP.Text = C_P

        ElseIf GCButton.Checked Then
            Dim GC As Single = GCTextBox.Text
            A_P = (1 - GC) / 2
            T_P = A_P
            G_P = GC / 2
            C_P = G_P
        ElseIf ManualPButton.Checked Then
            A_P = TextBox_AP.Text
            T_P = TextBox_TP.Text
            G_P = TextBox_GP.Text
            C_P = TextBox_CP.Text

            If A_P + T_P + G_P + C_P <> 1 Then
                MsgBox("Nucleotide frequencies sum must be 1 (100%)!")
                Exit Sub
            End If

        Else
            Exit Sub
        End If

        'Discover motifs
        Dim Motifs As New List(Of MBMD_Result)
        Dim PrimePWMCutoff As Single = PrimeCutoffTextBox.Text
        Dim ExtensionPWMCutoff As Single = ExtCutoffTextBox.Text
        Dim MinPWMRange As Single = WordLength * PWMSelTextBox.Text

        Motifs = Bioinformatics.DiscoverMotifs(TotalWordList, A_P, T_P, G_P, C_P, PrimePWMCutoff, ExtensionPWMCutoff, MinPWMRange)

        'Trim motifs and remove bad motifs
        If TrimCheckBox.Checked And Motifs.Count > 0 Then
            'Change to trim copy of motifs array!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            Motifs = Bioinformatics.TrimMotifs(Motifs, TrimThresholdTextBox.Text, MinLTextBox.Text)
        End If

        'Align and combine similar motifs
        If CombineMotifsCheckBox.Checked And Motifs.Count > 0 Then
            Motifs = Bioinformatics.CombineMotifs(Motifs, DistanceTextBox.Text, MinLTextBox.Text)
        End If

        If TrimCheckBox.Checked Or CombineMotifsCheckBox.Checked Then
            'Recalc weights
            Dim SeqList As New List(Of Char())

            For Each Motif As MBMD_Result In Motifs
                SeqList.Clear()
                For Each Hit As K_Word_PWM_Hit In Motif.Motif_Hits
                    SeqList.Add(Hit.Word_Text.ToCharArray)
                Next
                Motif.Original_PWM = Bioinformatics.CalculatePWM(SeqList, A_P, T_P, G_P, C_P, True)
                Motif.Weight = Motif.Original_PWM.GetMaxWeight - Motif.Original_PWM.GetMinWeight
            Next
        End If

        'Draw motifs
        ReportPanel.Controls.Clear()
        Dim counter As Integer = Motifs.Count
        Dim CurrentY As Integer = 0

        For i = Motifs.Count - 1 To 0 Step -1

            Dim NewResultGraphics As New MBMD_Graphics
            NewResultGraphics.Dock = DockStyle.Top

            NewResultGraphics.SearchResult = Motifs(i)
            For Each Seq As K_Word_PWM_Hit In Motifs(i).Motif_Hits
                NewResultGraphics.MBMD_LOGO.Sequences_List.Add(Seq.Word_Text)
            Next
            NewResultGraphics.MBMD_LOGO.CalculateInformationContent(True)
            NewResultGraphics.MBMD_LOGO.Size = New Size(30 * WordLength, 100)
            NewResultGraphics.MBMD_LOGO.InverseX = InvertXCheckBox.Checked
            NewResultGraphics.ReportTextBox.Text = "Motif-" & counter & ", Hits: " & Motifs(i).Motif_Hits.Count & ", Score (selectivity):" & Motifs(i).Weight
            NewResultGraphics.DistributionPlot.CalculatePositions(Motifs(i).Motif_Hits, InputSequences, InputHeaders)
            NewResultGraphics.DistributionPlot.AlignToRight = RightAlignCheckBox.Checked
            NewResultGraphics.DistributionPlot.GetSize()

            'NewResultGraphics.Location = New Point(0, CurrentY)
            ReportPanel.Controls.Add(NewResultGraphics)
            'NewResultGraphics.BringToFront()

            counter -= 1
            CurrentY += NewResultGraphics.Height
        Next
    End Sub

    Private Sub Algorithm_2()
        Dim WordLength As Integer = WordLTextBox.Text
        Dim PrimeMatchScore As Single = PrimeMatchTextBox.Text
        Dim PrimeMismatchScore As Single = PrimeMismatchTextBox.Text
        Dim InputSequences As New List(Of String)
        Dim InputHeaders As New List(Of String)

        Dim PrimePWMs As New List(Of PWM)
        Dim SeqWords As New List(Of List(Of K_Word_MBMD))

        If Not SeqFileTextBox.Text = "" Then

            Dim RS As New IO.FileStream(SeqFileTextBox.Text, IO.FileMode.Open)
            Dim Reader As New IO.StreamReader(RS)
            Dim CurrentLine As String = ""
            Dim CurrentHeader As String = ""

            While Reader.Peek > -1
                CurrentLine = Reader.ReadLine
                If CurrentLine.StartsWith(">") Then 'This is fasta header
                    CurrentHeader = CurrentLine.Substring(1)
                    InputHeaders.Add(CurrentHeader)
                Else 'This is sequence
                    CurrentLine = CurrentLine.ToUpper
                    InputSequences.Add(CurrentLine)
                    Dim NewWordList As New List(Of K_Word_MBMD)
                    For i = 0 To CurrentLine.Length - WordLength
                        Dim KWord As New K_Word_MBMD
                        KWord.Relative_Position = i
                        KWord.Word_Text = CurrentLine.Substring(i, WordLength)
                        KWord.Seq_ID = CurrentHeader
                        NewWordList.Add(KWord)
                    Next
                    SeqWords.Add(NewWordList)
                End If
            End While

            Reader.Close()
            RS.Close()
            Reader.Dispose()
            RS.Dispose()

        ElseIf Not SeqTextBox.Text = "" Then


            ' SeqTextBox.Text = SeqTextBox.Text.ToUpper()
            Dim Sequences As New List(Of Char())
            Dim SeqArr As String() = SeqTextBox.Text.Split(vbNewLine)
            Dim CurrentLine As String = ""
            Dim CurrentHeader As String = ""
            Dim HeaderIncrement As Integer = 0
            Dim TmpHeader As String = ""

            For Each Seq As String In SeqArr
                CurrentLine = Seq
                CurrentLine = CurrentLine.Replace(Chr(10), "")
                CurrentLine = CurrentLine.Replace(Chr(13), "")
                If Not CurrentLine = "" Then
                    If CurrentLine.StartsWith(">") Then
                        CurrentHeader = CurrentLine.Substring(1)
                        InputHeaders.Add(CurrentHeader)
                    Else

                        CurrentLine = CurrentLine.ToUpper

                        InputSequences.Add(CurrentLine)
                        Dim NewWordList As New List(Of K_Word_MBMD)

                        If CurrentHeader = "" Then
                            TmpHeader = "Seq" & HeaderIncrement
                            InputHeaders.Add(TmpHeader)
                            HeaderIncrement += 1
                        End If

                        For i = 0 To CurrentLine.Length - WordLength
                            Dim KWord As New K_Word_MBMD
                            KWord.Relative_Position = i
                            KWord.Word_Text = CurrentLine.Substring(i, WordLength)
                            If CurrentHeader = "" Then
                                KWord.Seq_ID = TmpHeader
                            Else
                                KWord.Seq_ID = CurrentHeader
                            End If

                            NewWordList.Add(KWord)
                        Next

                        SeqWords.Add(NewWordList)

                    End If

                End If
            Next

        Else
            Exit Sub
        End If

        'Make unique list of prime words to make prime PWMs
        Dim QniquePrimeWords As New List(Of K_Word_MBMD)
        Dim Found As Boolean = False
        For Each Seq As List(Of K_Word_MBMD) In SeqWords
            For Each Word As K_Word_MBMD In Seq
                Found = False
                For Each QniqueWord As K_Word_MBMD In QniquePrimeWords
                    If Word.Word_Text = QniqueWord.Word_Text Then
                        Found = True
                    End If
                Next
                If Not Found Then
                    QniquePrimeWords.Add(Word)
                End If
            Next
        Next Seq


        Dim A_P As Single = 0
        Dim T_P As Single = 0
        Dim G_P As Single = 0
        Dim C_P As Single = 0

        If AutoPButton.Checked Then
            'Make correction for nucleotide distribution in a sample
            Dim A_counter As Integer = 0
            Dim T_counter As Integer = 0
            Dim G_counter As Integer = 0
            Dim C_counter As Integer = 0
            Dim Total_counter As Integer = 0
            For Each Seq As List(Of K_Word_MBMD) In SeqWords
                For Each Word As K_Word_MBMD In Seq
                    For i = 0 To Word.Word_Text.Length - 1
                        Select Case Word.Word_Text(i)
                            Case "A"
                                A_counter += 1
                            Case "T"
                                T_counter += 1
                            Case "G"
                                G_counter += 1
                            Case "C"
                                C_counter += 1
                        End Select
                    Next i
                Next Word
            Next Seq

            Total_counter = A_counter + T_counter + G_counter + C_counter
            A_P = A_counter / Total_counter
            T_P = T_counter / Total_counter
            G_P = G_counter / Total_counter
            C_P = C_counter / Total_counter

            TextBox_AP.Text = A_P
            TextBox_TP.Text = T_P
            TextBox_GP.Text = G_P
            TextBox_CP.Text = C_P

        ElseIf GCButton.Checked Then
            Dim GC As Single = GCTextBox.Text
            A_P = (1 - GC) / 2
            T_P = A_P
            G_P = GC / 2
            C_P = G_P
        ElseIf ManualPButton.Checked Then
            A_P = TextBox_AP.Text
            T_P = TextBox_TP.Text
            G_P = TextBox_GP.Text
            C_P = TextBox_CP.Text

            If A_P + T_P + G_P + C_P <> 1 Then
                MsgBox("Nucleotide frequencies sum must be 1 (100%)!")
                Exit Sub
            End If

        Else
            Exit Sub
        End If


        For Each QniqueWord As K_Word_MBMD In QniquePrimeWords
            PrimePWMs.Add(Bioinformatics.PrimePWM(QniqueWord.Word_Text, PrimeMatchScore, PrimeMismatchScore, A_P, T_P, G_P, C_P))
        Next
        QniquePrimeWords.Clear()

        'Discover motifs
        Dim Motifs As New List(Of MBMD_Result)
        Dim PrimePWMCutoff As Single = PrimeCutoffTextBox.Text
        Dim ExtensionPWMCutoff As Single = ExtCutoffTextBox.Text
        Dim MinPWMRange As Single = WordLength * PWMSelTextBox.Text

        Motifs = Bioinformatics.DiscoverMotifsByBestOccurence(PrimePWMs, SeqWords, A_P, T_P, G_P, C_P, PrimePWMCutoff, ExtensionPWMCutoff, MinPWMRange, 2)

        'Trim motifs and remove bad motifs
        If TrimCheckBox.Checked And Motifs.Count > 0 Then
            'Change to trim copy of motifs array!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            Motifs = Bioinformatics.TrimMotifs(Motifs, TrimThresholdTextBox.Text, MinLTextBox.Text)
        End If

        'Align and combine similar motifs
        If CombineMotifsCheckBox.Checked And Motifs.Count > 0 Then
            Motifs = Bioinformatics.CombineMotifs(Motifs, DistanceTextBox.Text, MinLTextBox.Text)
        End If

        If TrimCheckBox.Checked Or CombineMotifsCheckBox.Checked Then
            'Recalc weights
            Dim SeqList As New List(Of Char())

            For Each Motif As MBMD_Result In Motifs
                SeqList.Clear()
                For Each Hit As K_Word_PWM_Hit In Motif.Motif_Hits
                    SeqList.Add(Hit.Word_Text.ToCharArray)
                Next
                Motif.Original_PWM = Bioinformatics.CalculatePWM(SeqList, A_P, T_P, G_P, C_P, True)
                Motif.Weight = Motif.Original_PWM.GetMaxWeight - Motif.Original_PWM.GetMinWeight
            Next
        End If

        'Draw motifs
        ReportPanel.Controls.Clear()
        Dim counter As Integer = Motifs.Count
        Dim CurrentY As Integer = 0

        For i = Motifs.Count - 1 To 0 Step -1

            Dim NewResultGraphics As New MBMD_Graphics
            NewResultGraphics.Dock = DockStyle.Top

            NewResultGraphics.SearchResult = Motifs(i)
            For Each Seq As K_Word_PWM_Hit In Motifs(i).Motif_Hits
                NewResultGraphics.MBMD_LOGO.Sequences_List.Add(Seq.Word_Text)
            Next
            NewResultGraphics.MBMD_LOGO.CalculateInformationContent(True)
            NewResultGraphics.MBMD_LOGO.Size = New Size(30 * WordLength, 100)
            NewResultGraphics.MBMD_LOGO.InverseX = InvertXCheckBox.Checked
            NewResultGraphics.ReportTextBox.Text = "Motif-" & counter & ", Hits: " & Motifs(i).Motif_Hits.Count & ", Score (selectivity):" & Motifs(i).Weight
            NewResultGraphics.DistributionPlot.CalculatePositions(Motifs(i).Motif_Hits, InputSequences, InputHeaders)
            NewResultGraphics.DistributionPlot.AlignToRight = RightAlignCheckBox.Checked
            NewResultGraphics.DistributionPlot.GetSize()

            'NewResultGraphics.Location = New Point(0, CurrentY)
            ReportPanel.Controls.Add(NewResultGraphics)
            'NewResultGraphics.BringToFront()

            counter -= 1
            CurrentY += NewResultGraphics.Height
        Next
    End Sub

    Private Sub GoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoButton.Click
       
        Algorithm_2()

    End Sub

    Private Sub OpenButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenButton.Click
        If Master.OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            SeqFileTextBox.Text = Master.OpenFileDialog.FileName
        End If

    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        SeqFileTextBox.Text = ""
        SeqTextBox.Text = ""

    End Sub

    Private Sub RightAlignCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RightAlignCheckBox.CheckedChanged
        Dim CurrentGraphics As MBMD_Graphics = Nothing
        For Each TargetControl As Control In ReportPanel.Controls
            CurrentGraphics = TargetControl
            CurrentGraphics.DistributionPlot.AlignToRight = RightAlignCheckBox.Checked
            CurrentGraphics.DistributionPlot.Invalidate()
        Next

    End Sub

    Private Sub InvertXCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InvertXCheckBox.CheckedChanged
        Dim CurrentGraphics As MBMD_Graphics = Nothing
        For Each TargetControl As Control In ReportPanel.Controls
            CurrentGraphics = TargetControl
            CurrentGraphics.MBMD_LOGO.InverseX = InvertXCheckBox.Checked
            CurrentGraphics.MBMD_LOGO.Invalidate()
        Next
    End Sub

   
End Class