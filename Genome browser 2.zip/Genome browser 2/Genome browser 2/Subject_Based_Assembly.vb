﻿Public Class Subject_Based_Assembly

    Private SubjectPositions As New List(Of K_Word_Hashed)
    Private QueryPositions As New List(Of Integer)
    Private intScore As Integer

    Public Property Subject_Positions() As List(Of K_Word_Hashed)
        Get
            Subject_Positions = SubjectPositions
        End Get
        Set(ByVal value As List(Of K_Word_Hashed))
            SubjectPositions = value
        End Set
    End Property

    Public Property Query_Positions() As List(Of Integer)
        Get
            Query_Positions = QueryPositions
        End Get
        Set(ByVal value As List(Of Integer))
            QueryPositions = value
        End Set
    End Property

    Public Property Score() As Integer
        Get
            Score = intScore
        End Get
        Set(ByVal value As Integer)
            intScore = value
        End Set
    End Property

End Class
