﻿Public Class GB_Importer
    Private DialogValue As Boolean = False

    Public Function DialogReturn()
        Me.ShowDialog()
        Return DialogValue
    End Function

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        If MegreGenesAndCDSsCheckBox.Checked Then
            DialogValue = True
        Else
            DialogValue = False
        End If

        Me.Close()
    End Sub

End Class