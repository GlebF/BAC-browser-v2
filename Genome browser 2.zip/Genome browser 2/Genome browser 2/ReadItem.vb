﻿Public Class ReadItem
    Private intReadAbsoluteStart As Integer
    Private intReadAbsoluteEnd As Integer
    Private intReadProjectionStart As Integer
    Private intReadProjectionEnd As Integer

    Public Property ReadAbsoluteStart() As Integer
        Get
            ReadAbsoluteStart = intReadAbsoluteStart
        End Get
        Set(ByVal value As Integer)
            intReadAbsoluteStart = value
        End Set
    End Property

    Public Property ReadAbsoluteEnd() As Integer
        Get
            ReadAbsoluteEnd = intReadAbsoluteEnd
        End Get
        Set(ByVal value As Integer)
            intReadAbsoluteEnd = value
        End Set
    End Property

    Public Property ReadProjectionStart() As Integer
        Get
            ReadProjectionStart = intReadProjectionStart
        End Get
        Set(ByVal value As Integer)
            intReadProjectionStart = value
        End Set
    End Property

    Public Property ReadProjectionEnd() As Integer
        Get
            ReadProjectionEnd = intReadProjectionEnd
        End Get
        Set(ByVal value As Integer)
            intReadProjectionEnd = value
        End Set
    End Property

    Public Sub New(ByVal RStart As Integer, ByVal REnd As Integer)
        intReadAbsoluteStart = RStart
        intReadAbsoluteEnd = REnd
    End Sub

End Class
