﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MBMD_Graphics
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MBMD_Graphics))
        Me.ReportTextBox = New System.Windows.Forms.TextBox
        Me.ExpandButton = New System.Windows.Forms.Button
        Me.ControlPanel = New System.Windows.Forms.Panel
        Me.SavePWMButton = New System.Windows.Forms.Button
        Me.SeqButton = New System.Windows.Forms.Button
        Me.ControlPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'ReportTextBox
        '
        Me.ReportTextBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.ReportTextBox.Enabled = False
        Me.ReportTextBox.Location = New System.Drawing.Point(113, 0)
        Me.ReportTextBox.Multiline = True
        Me.ReportTextBox.Name = "ReportTextBox"
        Me.ReportTextBox.Size = New System.Drawing.Size(567, 20)
        Me.ReportTextBox.TabIndex = 0
        '
        'ExpandButton
        '
        Me.ExpandButton.Dock = System.Windows.Forms.DockStyle.Left
        Me.ExpandButton.Image = CType(resources.GetObject("ExpandButton.Image"), System.Drawing.Image)
        Me.ExpandButton.Location = New System.Drawing.Point(0, 0)
        Me.ExpandButton.Name = "ExpandButton"
        Me.ExpandButton.Size = New System.Drawing.Size(23, 22)
        Me.ExpandButton.TabIndex = 1
        Me.ExpandButton.UseVisualStyleBackColor = True
        '
        'ControlPanel
        '
        Me.ControlPanel.Controls.Add(Me.ReportTextBox)
        Me.ControlPanel.Controls.Add(Me.SavePWMButton)
        Me.ControlPanel.Controls.Add(Me.SeqButton)
        Me.ControlPanel.Controls.Add(Me.ExpandButton)
        Me.ControlPanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.ControlPanel.Location = New System.Drawing.Point(0, 0)
        Me.ControlPanel.Name = "ControlPanel"
        Me.ControlPanel.Size = New System.Drawing.Size(680, 22)
        Me.ControlPanel.TabIndex = 2
        '
        'SavePWMButton
        '
        Me.SavePWMButton.Dock = System.Windows.Forms.DockStyle.Left
        Me.SavePWMButton.Location = New System.Drawing.Point(68, 0)
        Me.SavePWMButton.Name = "SavePWMButton"
        Me.SavePWMButton.Size = New System.Drawing.Size(45, 22)
        Me.SavePWMButton.TabIndex = 2
        Me.SavePWMButton.Text = "PWM"
        Me.SavePWMButton.UseVisualStyleBackColor = True
        '
        'SeqButton
        '
        Me.SeqButton.Dock = System.Windows.Forms.DockStyle.Left
        Me.SeqButton.Location = New System.Drawing.Point(23, 0)
        Me.SeqButton.Name = "SeqButton"
        Me.SeqButton.Size = New System.Drawing.Size(45, 22)
        Me.SeqButton.TabIndex = 3
        Me.SeqButton.Text = "Seq's"
        Me.SeqButton.UseVisualStyleBackColor = True
        '
        'MBMD_Graphics
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.Controls.Add(Me.ControlPanel)
        Me.Name = "MBMD_Graphics"
        Me.Size = New System.Drawing.Size(680, 122)
        Me.ControlPanel.ResumeLayout(False)
        Me.ControlPanel.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ReportTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ExpandButton As System.Windows.Forms.Button
    Friend WithEvents ControlPanel As System.Windows.Forms.Panel
    Friend WithEvents SavePWMButton As System.Windows.Forms.Button
    Friend WithEvents SeqButton As System.Windows.Forms.Button

End Class
