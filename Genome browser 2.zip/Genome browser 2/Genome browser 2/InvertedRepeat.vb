﻿Public Class InvertedRepeat
    Private strLeftStem As String = ""
    Private strRightStem As String = ""
    Private strIRLoop As String = ""
    Private intStart As Integer
    Private intEnd As Integer

    Public Property LeftStem() As String
        Get
            LeftStem = strLeftStem
        End Get
        Set(ByVal value As String)
            strLeftStem = value
        End Set
    End Property

    Public Property RightStem() As String
        Get
            RightStem = strRightStem
        End Get
        Set(ByVal value As String)
            strRightStem = value
        End Set
    End Property

    Public Property IRLoop() As String
        Get
            IRLoop = strIRLoop
        End Get
        Set(ByVal value As String)
            strIRLoop = value
        End Set
    End Property

    Public Property IRStart() As Integer
        Get
            IRStart = intStart
        End Get
        Set(ByVal value As Integer)
            intStart = value
        End Set
    End Property

    Public Property IREnd() As Integer
        Get
            IREnd = intEnd
        End Get
        Set(ByVal value As Integer)
            intEnd = value
        End Set
    End Property

End Class
