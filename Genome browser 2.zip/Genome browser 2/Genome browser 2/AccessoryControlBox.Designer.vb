﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AccessoryControlBox
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AccessoryControlBox))
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.AccessoryMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ViewThisFeatureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AccessoryControlToolStrip = New System.Windows.Forms.ToolStrip
        Me.ClearToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.CheckStateButton = New System.Windows.Forms.ToolStripButton
        Me.UpdateToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.ViewToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.AddToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.DeleteFeatureButton = New System.Windows.Forms.ToolStripButton
        Me.AccessoryGridView = New System.Windows.Forms.DataGridView
        Me.ShowCol = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.IDCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.NameCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.StartCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.EndCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DirCol = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.TypeCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.SequenceCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.AccessoryMenu.SuspendLayout()
        Me.AccessoryControlToolStrip.SuspendLayout()
        CType(Me.AccessoryGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'AccessoryMenu
        '
        Me.AccessoryMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewThisFeatureToolStripMenuItem, Me.DeleteToolStripMenuItem})
        Me.AccessoryMenu.Name = "AccessoryMenu"
        Me.AccessoryMenu.Size = New System.Drawing.Size(162, 48)
        '
        'ViewThisFeatureToolStripMenuItem
        '
        Me.ViewThisFeatureToolStripMenuItem.Image = CType(resources.GetObject("ViewThisFeatureToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ViewThisFeatureToolStripMenuItem.Name = "ViewThisFeatureToolStripMenuItem"
        Me.ViewThisFeatureToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.ViewThisFeatureToolStripMenuItem.Text = "View this feature"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.Image = CType(resources.GetObject("DeleteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.DeleteToolStripMenuItem.Text = "Delete"
        '
        'AccessoryControlToolStrip
        '
        Me.AccessoryControlToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClearToolStripButton, Me.ToolStripSeparator1, Me.CheckStateButton, Me.UpdateToolStripButton, Me.ViewToolStripButton, Me.ToolStripSeparator2, Me.AddToolStripButton, Me.DeleteFeatureButton})
        Me.AccessoryControlToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.AccessoryControlToolStrip.Name = "AccessoryControlToolStrip"
        Me.AccessoryControlToolStrip.Size = New System.Drawing.Size(791, 25)
        Me.AccessoryControlToolStrip.TabIndex = 6
        Me.AccessoryControlToolStrip.Text = "ToolStrip1"
        '
        'ClearToolStripButton
        '
        Me.ClearToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ClearToolStripButton.Image = CType(resources.GetObject("ClearToolStripButton.Image"), System.Drawing.Image)
        Me.ClearToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ClearToolStripButton.Name = "ClearToolStripButton"
        Me.ClearToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.ClearToolStripButton.Text = "Clear all items"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'CheckStateButton
        '
        Me.CheckStateButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CheckStateButton.Image = CType(resources.GetObject("CheckStateButton.Image"), System.Drawing.Image)
        Me.CheckStateButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CheckStateButton.Name = "CheckStateButton"
        Me.CheckStateButton.Size = New System.Drawing.Size(23, 22)
        Me.CheckStateButton.Text = "Check all"
        '
        'UpdateToolStripButton
        '
        Me.UpdateToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.UpdateToolStripButton.Image = CType(resources.GetObject("UpdateToolStripButton.Image"), System.Drawing.Image)
        Me.UpdateToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.UpdateToolStripButton.Name = "UpdateToolStripButton"
        Me.UpdateToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.UpdateToolStripButton.Text = "Update view"
        '
        'ViewToolStripButton
        '
        Me.ViewToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ViewToolStripButton.Image = CType(resources.GetObject("ViewToolStripButton.Image"), System.Drawing.Image)
        Me.ViewToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ViewToolStripButton.Name = "ViewToolStripButton"
        Me.ViewToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.ViewToolStripButton.Text = "Center view"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'AddToolStripButton
        '
        Me.AddToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AddToolStripButton.Image = CType(resources.GetObject("AddToolStripButton.Image"), System.Drawing.Image)
        Me.AddToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AddToolStripButton.Name = "AddToolStripButton"
        Me.AddToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.AddToolStripButton.Text = "Add user feature"
        '
        'DeleteFeatureButton
        '
        Me.DeleteFeatureButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DeleteFeatureButton.Enabled = False
        Me.DeleteFeatureButton.Image = CType(resources.GetObject("DeleteFeatureButton.Image"), System.Drawing.Image)
        Me.DeleteFeatureButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DeleteFeatureButton.Name = "DeleteFeatureButton"
        Me.DeleteFeatureButton.Size = New System.Drawing.Size(23, 22)
        Me.DeleteFeatureButton.Text = "Delete current feature"
        '
        'AccessoryGridView
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.AccessoryGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.AccessoryGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.AccessoryGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ShowCol, Me.IDCol, Me.NameCol, Me.StartCol, Me.EndCol, Me.DirCol, Me.TypeCol, Me.SequenceCol})
        Me.AccessoryGridView.ContextMenuStrip = Me.AccessoryMenu
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.AccessoryGridView.DefaultCellStyle = DataGridViewCellStyle5
        Me.AccessoryGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.AccessoryGridView.Location = New System.Drawing.Point(0, 25)
        Me.AccessoryGridView.Name = "AccessoryGridView"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.AccessoryGridView.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.AccessoryGridView.Size = New System.Drawing.Size(791, 175)
        Me.AccessoryGridView.TabIndex = 7
        '
        'ShowCol
        '
        Me.ShowCol.HeaderText = "Show"
        Me.ShowCol.Name = "ShowCol"
        Me.ShowCol.Width = 40
        '
        'IDCol
        '
        Me.IDCol.HeaderText = "ID"
        Me.IDCol.Name = "IDCol"
        Me.IDCol.Visible = False
        Me.IDCol.Width = 80
        '
        'NameCol
        '
        Me.NameCol.HeaderText = "Name"
        Me.NameCol.Name = "NameCol"
        Me.NameCol.Width = 80
        '
        'StartCol
        '
        Me.StartCol.HeaderText = "Start"
        Me.StartCol.Name = "StartCol"
        Me.StartCol.Width = 80
        '
        'EndCol
        '
        Me.EndCol.HeaderText = "End"
        Me.EndCol.Name = "EndCol"
        Me.EndCol.Width = 80
        '
        'DirCol
        '
        Me.DirCol.HeaderText = "Direction"
        Me.DirCol.Items.AddRange(New Object() {"None", "Plus", "Minus"})
        Me.DirCol.Name = "DirCol"
        Me.DirCol.Width = 80
        '
        'TypeCol
        '
        Me.TypeCol.HeaderText = "Type"
        Me.TypeCol.Name = "TypeCol"
        Me.TypeCol.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.TypeCol.Width = 60
        '
        'SequenceCol
        '
        Me.SequenceCol.HeaderText = "Sequence"
        Me.SequenceCol.Name = "SequenceCol"
        Me.SequenceCol.Width = 200
        '
        'AccessoryControlBox
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.AccessoryGridView)
        Me.Controls.Add(Me.AccessoryControlToolStrip)
        Me.Name = "AccessoryControlBox"
        Me.Size = New System.Drawing.Size(791, 200)
        Me.AccessoryMenu.ResumeLayout(False)
        Me.AccessoryControlToolStrip.ResumeLayout(False)
        Me.AccessoryControlToolStrip.PerformLayout()
        CType(Me.AccessoryGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents AccessoryMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ViewThisFeatureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AccessoryControlToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents ClearToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CheckStateButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents UpdateToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ViewToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AddToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents DeleteFeatureButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents AccessoryGridView As System.Windows.Forms.DataGridView
    Friend WithEvents ShowCol As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents IDCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NameCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StartCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EndCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DirCol As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents TypeCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SequenceCol As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
