﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HitPlot
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(HitPlot))
        Me.HitPlotToolStrip = New System.Windows.Forms.ToolStrip
        Me.SeqTextBox = New System.Windows.Forms.TextBox
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.RefreshPlotButton = New System.Windows.Forms.ToolStripButton
        Me.WLTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel
        Me.HitPlotToolStrip.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SuspendLayout()
        '
        'HitPlotToolStrip
        '
        Me.HitPlotToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel1, Me.WLTextBox, Me.RefreshPlotButton})
        Me.HitPlotToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.HitPlotToolStrip.Name = "HitPlotToolStrip"
        Me.HitPlotToolStrip.Size = New System.Drawing.Size(365, 25)
        Me.HitPlotToolStrip.TabIndex = 8
        Me.HitPlotToolStrip.Text = "ToolStrip1"
        '
        'SeqTextBox
        '
        Me.SeqTextBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SeqTextBox.Location = New System.Drawing.Point(0, 0)
        Me.SeqTextBox.Multiline = True
        Me.SeqTextBox.Name = "SeqTextBox"
        Me.SeqTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.SeqTextBox.Size = New System.Drawing.Size(365, 95)
        Me.SeqTextBox.TabIndex = 9
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 25)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SeqTextBox)
        Me.SplitContainer1.Size = New System.Drawing.Size(365, 378)
        Me.SplitContainer1.SplitterDistance = 279
        Me.SplitContainer1.TabIndex = 10
        '
        'RefreshPlotButton
        '
        Me.RefreshPlotButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.RefreshPlotButton.Image = CType(resources.GetObject("RefreshPlotButton.Image"), System.Drawing.Image)
        Me.RefreshPlotButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.RefreshPlotButton.Name = "RefreshPlotButton"
        Me.RefreshPlotButton.Size = New System.Drawing.Size(23, 22)
        Me.RefreshPlotButton.Text = "ToolStripButton1"
        '
        'WLTextBox
        '
        Me.WLTextBox.Name = "WLTextBox"
        Me.WLTextBox.Size = New System.Drawing.Size(30, 25)
        Me.WLTextBox.Text = "10"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(76, 22)
        Me.ToolStripLabel1.Text = "Word length:"
        '
        'HitPlot
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(365, 403)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.HitPlotToolStrip)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "HitPlot"
        Me.Text = "Hit plot"
        Me.HitPlotToolStrip.ResumeLayout(False)
        Me.HitPlotToolStrip.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.Panel2.PerformLayout()
        Me.SplitContainer1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents HitPlotToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents SeqTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents RefreshPlotButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents WLTextBox As System.Windows.Forms.ToolStripTextBox
End Class
