﻿Public Class K_Word_Hashed
    Inherits K_Word

    Private intHash As Int32

    Public Property Hash() As Int32
        Get
            Hash = intHash
        End Get
        Set(ByVal value As Int32)
            intHash = value
        End Set
    End Property

End Class
