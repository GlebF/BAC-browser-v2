﻿Public Class Translation_Viewer

    'Data
    Private strNNseq As String = ""
    Private strAASeq As String = ""
    Private shGeneticCode As Short = 1

    'Graphics
    Private NNLane As New List(Of GraphicalElement)
    Private AALane As New List(Of GraphicalElement)
    Private NNBox As Integer = 8
    Private AABox As Integer = 12
    Private InterStringInterval As Integer = 40 '32
    Private TextBrush As Brush = Brushes.Black
    Private NNFont As New Font("Microsoft Sans Serif", 6, FontStyle.Bold)
    Private AAFont As New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
    Private DrawingSpaceVOffset As Integer = 24
    Private DrawingSpaceHOffset As Integer = 12
    Private AADrawHOffset As Integer = 6
    Private AALaneVOffset As Integer = 10
    Private StringLength As Integer
    Private StringsNumber As Integer
    Private DisplayedStringsNumber As Integer
    Private VerticalScrollOffset As Integer = 0

    'Hand tool
    Private SelectionLocked As Boolean = False
    Private ElementsSelected As Boolean = False
    Private MinMouseStep As Integer = 5 'After this change mouse move event redraw image
    Private SelectionStarted As Boolean = False
    Private MouseMoved As Boolean = False
    Private initX As Integer
    Private initY As Integer
    Private initType As Short 'NN or AA was selected
    Private initIndex As Integer 'Which element was selected
    Private lastIndex As Integer 'Which element was selected on mouse up

    Private CursorIndex As Integer = 0
    Private CursorPen As New Pen(Color.Red, 1)

    Public Property NucleotideSequence() As String
        Get
            NucleotideSequence = strNNseq
        End Get
        Set(ByVal value As String)
            Dim TranslationTable As DataTable
            TranslationTable = Bioinformatics.GetTranslationTable(shGeneticCode)
            strNNseq = value
            strAASeq = Bioinformatics.Translate(strNNseq, TranslationTable)

            ArrangeLayout()



            Invalidate()

        End Set
    End Property

    Public Property GeneticCode() As Short
        Get
            GeneticCode = shGeneticCode
        End Get
        Set(ByVal value As Short)
            shGeneticCode = value
        End Set
    End Property

    Public ReadOnly Property AminoacidSequence() As String
        Get
            AminoacidSequence = strAASeq
        End Get
    End Property


    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        If strNNseq = "" Then
            VerticalScrollBar.Maximum = 0
        End If

    End Sub

    Private Sub ArrangeLayout()

        Dim DrawingWidth As Integer = Me.Width - VerticalScrollBar.Width - DrawingSpaceHOffset * 2
        StringLength = Math.Truncate(Math.Truncate(DrawingWidth / NNBox) / 3) * 3
        StringsNumber = Math.Truncate(strNNseq.Length / StringLength)


        Dim DrawingHeight As Integer = Me.Height - DrawingSpaceVOffset * 2
        DisplayedStringsNumber = Math.Truncate(DrawingHeight / InterStringInterval)

        Dim HiddenStringsNumber As Integer = StringsNumber - DisplayedStringsNumber

        VerticalScrollBar.Maximum = HiddenStringsNumber

        VerticalScrollBar.Minimum = 0

        If strNNseq = "" Then
            VerticalScrollBar.Maximum = 0
            VerticalScrollBar.Value = 0
        End If

        If VerticalScrollBar.Value > VerticalScrollBar.Maximum Then
            VerticalScrollBar.Value = VerticalScrollBar.Maximum
        End If

        GetSequenceGraphics()

        ' SequenceDisplay.TestTextBox.Text = VerticalScrollBar.Maximum

       
    End Sub

    Private Sub GetSequenceGraphics()
        NNLane.Clear()
        AALane.Clear()

        If strNNseq = "" Then
            Exit Sub
        End If


        Dim NNCounter As Integer = 0

        Dim MaxNNindex As Integer = strNNseq.Length - 1
        Dim MaxAAindex As Integer = strAASeq.Length - 1

        Dim AACounter As Integer = 0
        Dim AACycler As Integer = 0

        Dim Current_X As Integer = DrawingSpaceHOffset
        Dim Current_Y As Integer = DrawingSpaceVOffset
        Dim CurrentAA_X As Integer = DrawingSpaceHOffset
        Dim CurrentAA_Y As Integer = DrawingSpaceVOffset + AALaneVOffset

        Dim YStepOffset As Integer = InterStringInterval

        Dim XStepAAOffset As Integer = NNBox * 3

        For StringsCounter = 0 To StringsNumber

            Current_X = DrawingSpaceHOffset


            For i = 0 To StringLength - 1


                If NNCounter > MaxNNindex Then
                    Exit For
                End If


                Dim NewNNBox As GraphicalElement = New GraphicalElement(Current_X, Current_Y, NNBox, NNBox, strNNseq(NNCounter))
                NNLane.Add(NewNNBox)

                NNCounter += 1



                If AACycler = 0 Then

                    If AACounter <= MaxAAindex Then

                        Dim NewAABox As GraphicalElement = New GraphicalElement(Current_X, CurrentAA_Y, XStepAAOffset, AABox, strAASeq(AACounter))

                        Select Case NewAABox.Text
                            Case "*"
                                NewAABox.FillBrush = New SolidBrush(Color.Red)
                                NewAABox.FillRect = True
                            Case "M"
                                NewAABox.FillBrush = New SolidBrush(Color.LimeGreen)
                                NewAABox.FillRect = True
                        End Select

                        AALane.Add(NewAABox)

                    End If 'AACounter <= MaxAAindex

                    AACounter += 1
                End If 'AACycler = 0

                AACycler += 1
                If AACycler = 3 Then
                    AACycler = 0
                End If

                Current_X += NNBox
                CurrentAA_X += XStepAAOffset



            Next i

            Current_Y += YStepOffset
            CurrentAA_Y += YStepOffset
        Next StringsCounter

    End Sub

    Private Sub DrawSeq(ByVal e As PaintEventArgs)

        Dim RullerCounter As Integer = 0
        Dim RullerEnumerator As Integer = 0
        Dim RulerPoint As Integer = 30
        Dim RullerX As Integer = 0

        Dim BoxScrollY As Integer = 0



        For Each Box As GraphicalElement In AALane
            BoxScrollY = Box.Abs_Y - VerticalScrollOffset

            If Box.FillRect Then
                Dim FillRect As New Rectangle(Box.Abs_X, BoxScrollY, Box.Abs_W, Box.Abs_H)
                e.Graphics.FillRectangle(Box.FillBrush, FillRect)
            End If

            If Box.IsSelected Then
                Dim SelRect As New Rectangle(Box.Abs_X, BoxScrollY - NNBox - 2, Box.Abs_W, Box.Abs_H + NNBox + 2)
                e.Graphics.FillRectangle(Brushes.Aqua, SelRect)
            End If


            e.Graphics.DrawString(Box.Text, AAFont, TextBrush, Box.Abs_X + AADrawHOffset, BoxScrollY)

        Next Box


        For Each Box As GraphicalElement In NNLane
            BoxScrollY = Box.Abs_Y - VerticalScrollOffset

            If Box.IsSelected Then
                Dim SelRect As New Rectangle(Box.Abs_X, BoxScrollY, Box.Abs_W, Box.Abs_H)
                e.Graphics.FillRectangle(Brushes.Aqua, SelRect)
            End If


            e.Graphics.DrawString(Box.Text, NNFont, TextBrush, Box.Abs_X, BoxScrollY)
            RullerCounter += 1

            If RullerCounter = RulerPoint Then
                RullerCounter = 0
                RullerEnumerator += 10
                RullerX = Box.Abs_X + Box.Abs_W
                e.Graphics.DrawLine(Pens.Black, RullerX, BoxScrollY, RullerX, BoxScrollY - 6)
                e.Graphics.DrawString(RullerEnumerator, NNFont, TextBrush, RullerX + 2, BoxScrollY - 12)
            End If

        Next Box

        'Draw cursor
        Dim Cursor_X As Integer = 0
        Dim Cursor_Y As Integer = 0

        Try


            If CursorIndex = 0 Then
                Cursor_X = NNLane(0).Abs_X - 1
                Cursor_Y = NNLane(0).Abs_Y - VerticalScrollOffset
            Else
                Cursor_X = NNLane(CursorIndex - 1).Abs_X + NNLane(CursorIndex - 1).Abs_W - 1
                Cursor_Y = NNLane(CursorIndex - 1).Abs_Y - VerticalScrollOffset
            End If
        Catch ex As Exception

        End Try

        e.Graphics.DrawLine(CursorPen, Cursor_X, Cursor_Y - 2, Cursor_X, Cursor_Y + NNBox + 2)


    End Sub

    Private Sub Translation_Viewer_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint

        If strNNseq = "" Then
            Exit Sub
        End If

        DrawSeq(e)

    End Sub

    Private Sub RedrawSelection()
        Select Case initType
            Case 0

                For Each Box As GraphicalElement In NNLane
                    Box.IsSelected = False
                Next Box

                If initIndex < lastIndex Then
                    For i = initIndex To lastIndex
                        NNLane(i).IsSelected = True
                    Next i
                Else
                    For i = lastIndex To initIndex
                        NNLane(i).IsSelected = True
                    Next i
                End If


            Case 1

                For Each Box As GraphicalElement In AALane
                    Box.IsSelected = False
                Next Box

                If initIndex < lastIndex Then
                    For i = initIndex To lastIndex
                        AALane(i).IsSelected = True
                    Next i
                Else
                    For i = lastIndex To initIndex
                        AALane(i).IsSelected = True
                    Next i
                End If


        End Select
    End Sub

    Private Sub Translation_Viewer_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        'Identify which NN or AA is clicked and mark start position

        If SelectionLocked Then
            Exit Sub
        End If



        If e.Button = Windows.Forms.MouseButtons.Left Then

            ElementsSelected = False

            For Each Box As GraphicalElement In NNLane
                Box.IsSelected = False
            Next Box

            For Each Box As GraphicalElement In AALane
                Box.IsSelected = False
            Next Box

            Dim counter As Integer = 0

            If Not SelectionStarted Then
                Dim HalfBoxWidth As Integer = NNBox / 2
               
                For Each Box As GraphicalElement In NNLane

                    'Find first box for selection
                    If e.X >= Box.Abs_X And e.X <= Box.Abs_X + Box.Abs_W And e.Y >= Box.Abs_Y - VerticalScrollOffset And e.Y <= Box.Abs_Y - VerticalScrollOffset + Box.Abs_H Then

                        initType = 0
                        initIndex = counter
                        lastIndex = counter
                        initX = e.X
                        initY = e.Y
                        ' Box.IsSelected = True
                        SelectionStarted = True
                        ElementsSelected = True


                        If e.X >= Box.Abs_X + HalfBoxWidth And e.X <= Box.Abs_X + Box.Abs_W And e.Y >= Box.Abs_Y - VerticalScrollOffset And e.Y <= Box.Abs_Y - VerticalScrollOffset + Box.Abs_H Then
                            'Rigth half
                            CursorIndex = initIndex + 1
                            Exit For
                        ElseIf e.X >= Box.Abs_X And e.X <= Box.Abs_X + HalfBoxWidth And e.Y >= Box.Abs_Y - VerticalScrollOffset And e.Y <= Box.Abs_Y - VerticalScrollOffset + Box.Abs_H Then
                            'Left half
                            CursorIndex = initIndex
                            Exit For
                        End If


                        Exit For
                    End If




                    counter += 1
                Next Box

            End If



            If Not SelectionStarted Then
                counter = 0

                For Each Box As GraphicalElement In AALane
                    If e.X > Box.Abs_X And e.X < Box.Abs_X + Box.Abs_W And e.Y > Box.Abs_Y - VerticalScrollOffset And e.Y < Box.Abs_Y - VerticalScrollOffset + Box.Abs_H Then
                        initType = 1
                        initIndex = counter
                        lastIndex = counter
                        initX = e.X
                        initY = e.Y
                        Box.IsSelected = True
                        SelectionStarted = True
                        ElementsSelected = True
                        Exit For
                        Exit For
                    End If
                    counter += 1
                Next Box
            End If

        End If

        Invalidate()

    End Sub

    Private Sub Translation_Viewer_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
        If SelectionStarted Then

            Dim counter As Integer = 0

            Select Case initType
                Case 0
                    For Each Box As GraphicalElement In NNLane
                        If e.X > Box.Abs_X And e.X < Box.Abs_X + Box.Abs_W And e.Y > Box.Abs_Y - VerticalScrollOffset And e.Y < Box.Abs_Y - VerticalScrollOffset + Box.Abs_H Then
                            'Identify current index and select all previous elements

                            lastIndex = counter

                            Exit For
                        End If
                        counter += 1
                    Next Box

                Case 1
                    For Each Box As GraphicalElement In AALane
                        If e.X > Box.Abs_X And e.X < Box.Abs_X + Box.Abs_W And e.Y > Box.Abs_Y - VerticalScrollOffset And e.Y < Box.Abs_Y - VerticalScrollOffset + Box.Abs_H Then
                            'Identify current index and select all previous elements

                            lastIndex = counter

                            Exit For
                        End If
                        counter += 1
                    Next Box

            End Select



            If Math.Abs(initX - e.X) > MinMouseStep Or Math.Abs(initY - e.Y) > MinMouseStep Then

                MouseMoved = True

                RedrawSelection()

                Invalidate()


            End If 'Coordinate changed significantly


        End If 'Selection started
    End Sub

    Private Sub Translation_Viewer_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseUp

        If SelectionStarted Then

            Select Case initType
                Case 0

                    If MouseMoved Then
                        RedrawSelection()
                        Invalidate()
                    End If

                Case 1
                    RedrawSelection()
                    Invalidate()

            End Select

        End If

        MouseMoved = False
        SelectionStarted = False

    End Sub

    Private Sub VerticalScrollBar_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles VerticalScrollBar.Scroll

        VerticalScrollOffset = InterStringInterval * VerticalScrollBar.Value

        Invalidate()

    End Sub

    Private Sub CopyString()
        If ElementsSelected Then
            Dim SelectedString As String = ""

            Select Case initType
                Case 0
                    If initIndex < lastIndex Then
                        SelectedString = strNNseq.Substring(initIndex, lastIndex - initIndex + 1)
                    Else
                        SelectedString = strNNseq.Substring(lastIndex, initIndex - lastIndex + 1)
                    End If
                Case 1
                    If initIndex < lastIndex Then
                        SelectedString = strAASeq.Substring(initIndex, lastIndex - initIndex + 1)
                    Else
                        SelectedString = strAASeq.Substring(lastIndex, initIndex - lastIndex + 1)
                    End If
            End Select

            Clipboard.SetText(SelectedString)

        End If
    End Sub

    Private Sub PasteString(ByVal Str As String)
        If strNNseq = "" Then
            NucleotideSequence = Str
            CursorIndex = 0
        Else
            NucleotideSequence = strNNseq.Insert(CursorIndex, Str)
            CursorIndex += Str.Length
        End If

    End Sub

    Private Sub Translation_Viewer_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.PageDown And VerticalScrollBar.Value < VerticalScrollBar.Maximum Then

            VerticalScrollBar.Value += 1
            VerticalScrollOffset = InterStringInterval * VerticalScrollBar.Value

            Invalidate()
        End If

        If e.KeyCode = Keys.PageUp And VerticalScrollBar.Value > VerticalScrollBar.Minimum Then
            VerticalScrollBar.Value -= 1
            VerticalScrollOffset = InterStringInterval * VerticalScrollBar.Value

            Invalidate()
        End If

        If e.KeyCode = Keys.Home Then
            VerticalScrollBar.Value = VerticalScrollBar.Minimum
            VerticalScrollOffset = InterStringInterval * VerticalScrollBar.Value

            Invalidate()
        End If

        If e.KeyCode = Keys.End Then
            VerticalScrollBar.Value = VerticalScrollBar.Maximum
            VerticalScrollOffset = InterStringInterval * VerticalScrollBar.Value

            Invalidate()
        End If

        If e.KeyCode = Keys.C And e.Modifiers = Keys.Control Then
            CopyString()
        End If

        'Control cursor

        If e.KeyCode = Keys.Right And e.Modifiers = Keys.Control Then
            CursorIndex += 1

            If CursorIndex > strNNseq.Length Then
                CursorIndex = strNNseq.Length
            End If
            Invalidate()

        End If

        If e.KeyCode = Keys.Left And e.Modifiers = Keys.Control Then
            CursorIndex -= 1

            If CursorIndex < 0 Then
                CursorIndex = 0
            End If
            Invalidate()

        End If

        'Enter sequence

        Select Case e.KeyCode
            Case Keys.A
                NucleotideSequence = strNNseq.Insert(CursorIndex, "A")
                CursorIndex += 1
            Case Keys.T
                NucleotideSequence = strNNseq.Insert(CursorIndex, "T")
                CursorIndex += 1
            Case Keys.G
                NucleotideSequence = strNNseq.Insert(CursorIndex, "G")
                CursorIndex += 1
            Case Keys.C
                NucleotideSequence = strNNseq.Insert(CursorIndex, "C")
                CursorIndex += 1
            Case Keys.U
                NucleotideSequence = strNNseq.Insert(CursorIndex, "T")
                CursorIndex += 1
            Case Keys.Back
                If CursorIndex > 0 Then
                    NucleotideSequence = strNNseq.Remove(CursorIndex - 1, 1)
                    CursorIndex -= 1
                End If
        End Select

    End Sub

    Private Sub Translation_Viewer_Resize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        If Not strNNseq = "" Then
            ArrangeLayout()
            Invalidate()
        End If

    End Sub

    Private Sub SelectNucleoideSequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectNucleoideSequenceToolStripMenuItem.Click
        initType = 0
        initIndex = 0
        lastIndex = strNNseq.Length - 1
        ElementsSelected = True
        CopyString()
        RedrawSelection()
        Invalidate()

    End Sub

    Private Sub SelectProteinSequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectProteinSequenceToolStripMenuItem.Click
        initType = 1
        initIndex = 0
        lastIndex = strAASeq.Length - 1
        ElementsSelected = True
        CopyString()
        RedrawSelection()
        Invalidate()

    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyToolStripMenuItem.Click
        CopyString()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteToolStripMenuItem.Click
        PasteString(Clipboard.GetText)
    End Sub

    Private Sub ClearToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearToolStripMenuItem.Click
        NucleotideSequence = ""

    End Sub
End Class
