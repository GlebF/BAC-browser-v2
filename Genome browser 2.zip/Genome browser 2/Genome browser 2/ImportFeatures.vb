﻿Public Class ImportFeatures
    Public MyGenomeViewer As Genome_Viewer

    Public FileLoaded As Boolean = False


    Private Sub OpenButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenButton.Click
        If Master.OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim FS As New IO.FileStream(Master.OpenFileDialog.FileName, IO.FileMode.Open)
            Dim Reader As New IO.StreamReader(FS)
            Dim HeaderString As String() = Reader.ReadLine.Split(Chr(9))

            OldTagComboBox.Items.Clear()
            TAGComboBox.Items.Clear()
            NameComboBox.Items.Clear()
            StartComboBox.Items.Clear()
            EndComboBox.Items.Clear()
            DirectionComboBox.Items.Clear()
            TypeComboBox.Items.Clear()
            DescrComboBox.Items.Clear()
            OrthoComboBox.Items.Clear()

            TAGComboBox.Items.Add("-cancel-")
            NameComboBox.Items.Add("-cancel-")
            StartComboBox.Items.Add("-cancel-")
            EndComboBox.Items.Add("-cancel-")
            DirectionComboBox.Items.Add("-cancel-")
            TypeComboBox.Items.Add("-cancel-")
            DescrComboBox.Items.Add("-cancel-")
            OrthoComboBox.Items.Add("-cancel-")

            TypeComboBox.Items.Add("-CDS-")
            TypeComboBox.Items.Add("-Structural RNA-")
            TypeComboBox.Items.Add("-Operon-")
            TypeComboBox.Items.Add("-TSS-")
            TypeComboBox.Items.Add("-TTS-")
            TypeComboBox.Items.Add("-Regulatory site-")
            TypeComboBox.Items.Add("-Non-coding RNA-")
            TypeComboBox.Items.Add("-User feature-")

            For Each Header As String In HeaderString
                OldTagComboBox.Items.Add(Header)
                TAGComboBox.Items.Add(Header)
                NameComboBox.Items.Add(Header)
                StartComboBox.Items.Add(Header)
                EndComboBox.Items.Add(Header)
                DirectionComboBox.Items.Add(Header)
                TypeComboBox.Items.Add(Header)
                DescrComboBox.Items.Add(Header)
                OrthoComboBox.Items.Add(Header)
            Next

            DescrComboBox.Text = "-cancel-"
            OrthoComboBox.Text = "-cancel-"

            If AutodetectCheckBox.Checked Then
                For Each Header As String In HeaderString
                    Select Case Header
                        Case "TAG"
                            TAGComboBox.Text = Header
                        Case "ID"
                            TAGComboBox.Text = Header
                        Case "id"
                            TAGComboBox.Text = Header
                        Case "Name"
                            NameComboBox.Text = Header
                        Case "name"
                            NameComboBox.Text = Header
                        Case "Start"
                            StartComboBox.Text = Header
                        Case "start"
                            StartComboBox.Text = Header
                        Case "End"
                            EndComboBox.Text = Header
                        Case "end"
                            EndComboBox.Text = Header
                        Case "Direction"
                            DirectionComboBox.Text = Header
                        Case "direction"
                            DirectionComboBox.Text = Header
                        Case "Dir"
                            DirectionComboBox.Text = Header
                        Case "dir"
                            DirectionComboBox.Text = Header
                        Case "Type"
                            TypeComboBox.Text = Header
                        Case "type"
                            TypeComboBox.Text = Header
                        Case "Description"
                            DescrComboBox.Text = Header
                        Case "description"
                            DescrComboBox.Text = Header
                        Case "Descr"
                            DescrComboBox.Text = Header
                        Case "descr"
                            DescrComboBox.Text = Header
                        Case "Orthology"
                            OrthoComboBox.Text = Header
                        Case "orthology"
                            OrthoComboBox.Text = Header
                    End Select
                Next
            End If

            Reader.Close()
            FS.Close()
            Reader.Dispose()
            FS.Dispose()
            ImportButton.BackColor = Color.Lime
            FileLoaded = True
            FileTextBox.Text = Master.OpenFileDialog.FileName
        End If




    End Sub

    Private Sub ImportButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportButton.Click
        Try
            If FileLoaded Then
                If ReplacementCheckBox.Checked Then 'Replace
                    DataIO.ReplaceFeatures(Master.OpenFileDialog.FileName, OldTagComboBox.Text, TAGComboBox.Text, NameComboBox.Text, StartComboBox.Text, EndComboBox.Text, DirectionComboBox.Text, TypeComboBox.Text, DescrComboBox.Text, OrthoComboBox.Text, MyGenomeViewer)
                Else 'Add new
                    DataIO.ImportFeaturesToAnnotation(Master.OpenFileDialog.FileName, TAGComboBox.Text, NameComboBox.Text, StartComboBox.Text, EndComboBox.Text, DirectionComboBox.Text, TypeComboBox.Text, DescrComboBox.Text, OrthoComboBox.Text, MyGenomeViewer, MainImport.Checked)
                End If
                MyGenomeViewer.DisplayFeatures()
                FileLoaded = False
                ImportButton.BackColor = System.Drawing.SystemColors.Control
                Me.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub ImportFeatures_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FileLoaded = False
        ImportButton.BackColor = System.Drawing.SystemColors.Control
    End Sub

    Private Sub ReplacementCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReplacementCheckBox.CheckedChanged
        OldTagComboBox.Enabled = ReplacementCheckBox.Checked
    End Sub
End Class