﻿Public Class K_Word
    Private RelativePosition As Integer = 0 'Position within query phrase
    Private WordText As String = ""
    Private AlignedPositions As New List(Of Integer) 'For subject sequence only, store here hits from query

    Public Property Relative_Position() As Integer
        Get
            Relative_Position = RelativePosition
        End Get
        Set(ByVal value As Integer)
            RelativePosition = value
        End Set
    End Property

    Public Property Word_Text() As String
        Get
            Word_Text = WordText
        End Get
        Set(ByVal value As String)
            WordText = value
        End Set
    End Property

    Public Property Aligned_Positions() As List(Of Integer)
        Get
            Aligned_Positions = AlignedPositions
        End Get
        Set(ByVal value As List(Of Integer))
            AlignedPositions = value
        End Set
    End Property

End Class
