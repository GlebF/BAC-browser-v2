﻿Public Class Needleman_Wunsch_Cell
    Private sScore As Short = 0
    Private bDir As Byte = 0
    Private bMatch As Byte = 0

    Public Property Score() As Short
        Get
            Score = sScore
        End Get
        Set(ByVal value As Short)
            sScore = value
        End Set
    End Property

    Public Property Direction() As String
        '0 - Upper left cell
        '1 - Diagonal
        '2 - Left
        '3 - Up

        Get
            Direction = bDir
        End Get
        Set(ByVal value As String)
            bDir = value
        End Set
    End Property

    Public Property Match() As Byte
        Get
            Match = bMatch
        End Get
        Set(ByVal value As Byte)
            bMatch = value
        End Set
    End Property

End Class
