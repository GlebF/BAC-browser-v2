﻿Public Class QuantControl
    Public MyGenomeViewer As Genome_Viewer

    Public FileLoaded As Boolean = False

    Private Sub ColorButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorButton.Click
        If Master.ColorSelectDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            ColorPanel.BackColor = Master.ColorSelectDialog.Color
        End If
    End Sub

    Private Sub OpenButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenButton.Click
        If Master.OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

            Dim FS As New IO.FileStream(Master.OpenFileDialog.FileName, IO.FileMode.Open)
            Dim Reader As New IO.StreamReader(FS)
            Dim HeaderString As String() = Reader.ReadLine.Split(Chr(9))


            TAGComboBox.Items.Clear()
            StartComboBox.Items.Clear()
            EndComboBox.Items.Clear()
            DirectionComboBox.Items.Clear()
            DescrComboBox.Items.Clear()
            ValuesComboBox.Items.Clear()



            DescrComboBox.Items.Add("-cancel-")

            For Each Header As String In HeaderString
                TAGComboBox.Items.Add(Header)
                StartComboBox.Items.Add(Header)
                EndComboBox.Items.Add(Header)
                DirectionComboBox.Items.Add(Header)
                DescrComboBox.Items.Add(Header)
                ValuesComboBox.Items.Add(Header)

            Next

            DescrComboBox.Text = "-cancel-"

            For Each Header As String In HeaderString
                Select Case Header
                    Case "TAG"
                        TAGComboBox.Text = Header
                    Case "ID"
                        TAGComboBox.Text = Header
                    Case "id"
                        TAGComboBox.Text = Header
                    Case "Name"
                        TAGComboBox.Text = Header
                    Case "name"
                        TAGComboBox.Text = Header
                    Case "Start"
                        StartComboBox.Text = Header
                    Case "start"
                        StartComboBox.Text = Header
                    Case "End"
                        EndComboBox.Text = Header
                    Case "end"
                        EndComboBox.Text = Header
                    Case "Direction"
                        DirectionComboBox.Text = Header
                    Case "direction"
                        DirectionComboBox.Text = Header
                    Case "Dir"
                        DirectionComboBox.Text = Header
                    Case "dir"
                        DirectionComboBox.Text = Header
                    Case "Description"
                        DescrComboBox.Text = Header
                    Case "description"
                        DescrComboBox.Text = Header
                    Case "Descr"
                        DescrComboBox.Text = Header
                    Case "descr"
                        DescrComboBox.Text = Header
                    Case "cov"
                        ValuesComboBox.Text = Header
                    Case "Cov"
                        ValuesComboBox.Text = Header
                    Case "Value"
                        ValuesComboBox.Text = Header
                    Case "value"
                        ValuesComboBox.Text = Header
                End Select
            Next

            Reader.Close()
            FS.Close()
            Reader.Dispose()
            FS.Dispose()
            ImportButton.BackColor = Color.Lime
            FileLoaded = True
            FileTextBox.Text = Master.OpenFileDialog.FileName

        End If
    End Sub

    Private Sub QuantumControl_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FileLoaded = False
        ImportButton.BackColor = System.Drawing.SystemColors.Control
        ColorPanel.BackColor = Color.Black
    End Sub

    Private Sub ImportButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportButton.Click
        If FileLoaded Then
            Try
                DataIO.RetrieveIntegratedValues(Master.OpenFileDialog.FileName, ValuesComboBox.Text, TAGComboBox.Text, StartComboBox.Text, EndComboBox.Text, DirectionComboBox.Text, DescrComboBox.Text, ColorPanel.BackColor, MyGenomeViewer)

                MyGenomeViewer.DisplayFeatures()
                FileLoaded = False
                ImportButton.BackColor = System.Drawing.SystemColors.Control
                Me.Close()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try


        End If
    End Sub

End Class