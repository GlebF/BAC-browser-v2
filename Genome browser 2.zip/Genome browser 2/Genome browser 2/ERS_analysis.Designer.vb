﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ERS_analysis
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ERS_analysis))
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.RefreshGroupsButton = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.RemoveItemButton = New System.Windows.Forms.Button
        Me.AddItemButton = New System.Windows.Forms.Button
        Me.AllRemoveButton = New System.Windows.Forms.Button
        Me.AllAddButton = New System.Windows.Forms.Button
        Me.AnalysisHolderListBox = New System.Windows.Forms.ListBox
        Me.AllHoldersListBox = New System.Windows.Forms.ListBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.TSSPosMatchTextBox = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.SignalToNoiseTextBox = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.TSSCovTextBox = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.SearchWindowTextBox = New System.Windows.Forms.TextBox
        Me.GoButton = New System.Windows.Forms.Button
        Me.StatusLabelMinus = New System.Windows.Forms.Label
        Me.StatusLabelPlus = New System.Windows.Forms.Label
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.RefreshGroupsButton)
        Me.GroupBox6.Controls.Add(Me.Label8)
        Me.GroupBox6.Controls.Add(Me.Label7)
        Me.GroupBox6.Controls.Add(Me.RemoveItemButton)
        Me.GroupBox6.Controls.Add(Me.AddItemButton)
        Me.GroupBox6.Controls.Add(Me.AllRemoveButton)
        Me.GroupBox6.Controls.Add(Me.AllAddButton)
        Me.GroupBox6.Controls.Add(Me.AnalysisHolderListBox)
        Me.GroupBox6.Controls.Add(Me.AllHoldersListBox)
        Me.GroupBox6.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(462, 150)
        Me.GroupBox6.TabIndex = 16
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Coverage profiles"
        '
        'RefreshGroupsButton
        '
        Me.RefreshGroupsButton.BackgroundImage = CType(resources.GetObject("RefreshGroupsButton.BackgroundImage"), System.Drawing.Image)
        Me.RefreshGroupsButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.RefreshGroupsButton.Location = New System.Drawing.Point(97, 18)
        Me.RefreshGroupsButton.Name = "RefreshGroupsButton"
        Me.RefreshGroupsButton.Size = New System.Drawing.Size(38, 23)
        Me.RefreshGroupsButton.TabIndex = 8
        Me.RefreshGroupsButton.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 28)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(88, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Available groups:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(253, 26)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(95, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Groups to analyze:"
        '
        'RemoveItemButton
        '
        Me.RemoveItemButton.BackgroundImage = CType(resources.GetObject("RemoveItemButton.BackgroundImage"), System.Drawing.Image)
        Me.RemoveItemButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.RemoveItemButton.Location = New System.Drawing.Point(212, 68)
        Me.RemoveItemButton.Name = "RemoveItemButton"
        Me.RemoveItemButton.Size = New System.Drawing.Size(38, 23)
        Me.RemoveItemButton.TabIndex = 5
        Me.RemoveItemButton.UseVisualStyleBackColor = True
        '
        'AddItemButton
        '
        Me.AddItemButton.BackgroundImage = CType(resources.GetObject("AddItemButton.BackgroundImage"), System.Drawing.Image)
        Me.AddItemButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.AddItemButton.Location = New System.Drawing.Point(212, 94)
        Me.AddItemButton.Name = "AddItemButton"
        Me.AddItemButton.Size = New System.Drawing.Size(38, 23)
        Me.AddItemButton.TabIndex = 4
        Me.AddItemButton.UseVisualStyleBackColor = True
        '
        'AllRemoveButton
        '
        Me.AllRemoveButton.BackgroundImage = CType(resources.GetObject("AllRemoveButton.BackgroundImage"), System.Drawing.Image)
        Me.AllRemoveButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.AllRemoveButton.Location = New System.Drawing.Point(212, 42)
        Me.AllRemoveButton.Name = "AllRemoveButton"
        Me.AllRemoveButton.Size = New System.Drawing.Size(38, 23)
        Me.AllRemoveButton.TabIndex = 3
        Me.AllRemoveButton.UseVisualStyleBackColor = True
        '
        'AllAddButton
        '
        Me.AllAddButton.BackgroundImage = CType(resources.GetObject("AllAddButton.BackgroundImage"), System.Drawing.Image)
        Me.AllAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.AllAddButton.Location = New System.Drawing.Point(212, 120)
        Me.AllAddButton.Name = "AllAddButton"
        Me.AllAddButton.Size = New System.Drawing.Size(38, 23)
        Me.AllAddButton.TabIndex = 2
        Me.AllAddButton.UseVisualStyleBackColor = True
        '
        'AnalysisHolderListBox
        '
        Me.AnalysisHolderListBox.FormattingEnabled = True
        Me.AnalysisHolderListBox.Location = New System.Drawing.Point(256, 44)
        Me.AnalysisHolderListBox.Name = "AnalysisHolderListBox"
        Me.AnalysisHolderListBox.Size = New System.Drawing.Size(200, 95)
        Me.AnalysisHolderListBox.TabIndex = 1
        '
        'AllHoldersListBox
        '
        Me.AllHoldersListBox.FormattingEnabled = True
        Me.AllHoldersListBox.Location = New System.Drawing.Point(6, 44)
        Me.AllHoldersListBox.Name = "AllHoldersListBox"
        Me.AllHoldersListBox.Size = New System.Drawing.Size(200, 95)
        Me.AllHoldersListBox.TabIndex = 0
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.TSSPosMatchTextBox)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.SignalToNoiseTextBox)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.TSSCovTextBox)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.SearchWindowTextBox)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 168)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(462, 133)
        Me.GroupBox3.TabIndex = 17
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Coverage analysis"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(17, 100)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(133, 13)
        Me.Label17.TabIndex = 30
        Me.Label17.Text = "Min TSS position matches:"
        '
        'TSSPosMatchTextBox
        '
        Me.TSSPosMatchTextBox.Location = New System.Drawing.Point(156, 97)
        Me.TSSPosMatchTextBox.Name = "TSSPosMatchTextBox"
        Me.TSSPosMatchTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TSSPosMatchTextBox.TabIndex = 29
        Me.TSSPosMatchTextBox.Text = "2"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(48, 74)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(102, 13)
        Me.Label16.TabIndex = 28
        Me.Label16.Text = "Signal to noise ratio:"
        '
        'SignalToNoiseTextBox
        '
        Me.SignalToNoiseTextBox.Location = New System.Drawing.Point(156, 71)
        Me.SignalToNoiseTextBox.Name = "SignalToNoiseTextBox"
        Me.SignalToNoiseTextBox.Size = New System.Drawing.Size(50, 20)
        Me.SignalToNoiseTextBox.TabIndex = 27
        Me.SignalToNoiseTextBox.Text = "5"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(51, 48)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(99, 13)
        Me.Label15.TabIndex = 26
        Me.Label15.Text = "Min TSS coverage:"
        '
        'TSSCovTextBox
        '
        Me.TSSCovTextBox.Location = New System.Drawing.Point(156, 45)
        Me.TSSCovTextBox.Name = "TSSCovTextBox"
        Me.TSSCovTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TSSCovTextBox.TabIndex = 25
        Me.TSSCovTextBox.Text = "10"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(43, 22)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(107, 13)
        Me.Label14.TabIndex = 24
        Me.Label14.Text = "Background window:"
        '
        'SearchWindowTextBox
        '
        Me.SearchWindowTextBox.Location = New System.Drawing.Point(156, 19)
        Me.SearchWindowTextBox.Name = "SearchWindowTextBox"
        Me.SearchWindowTextBox.Size = New System.Drawing.Size(50, 20)
        Me.SearchWindowTextBox.TabIndex = 23
        Me.SearchWindowTextBox.Text = "5"
        '
        'GoButton
        '
        Me.GoButton.Location = New System.Drawing.Point(401, 446)
        Me.GoButton.Name = "GoButton"
        Me.GoButton.Size = New System.Drawing.Size(75, 23)
        Me.GoButton.TabIndex = 19
        Me.GoButton.Text = "Go"
        Me.GoButton.UseVisualStyleBackColor = True
        '
        'StatusLabelMinus
        '
        Me.StatusLabelMinus.AutoSize = True
        Me.StatusLabelMinus.Location = New System.Drawing.Point(9, 459)
        Me.StatusLabelMinus.Name = "StatusLabelMinus"
        Me.StatusLabelMinus.Size = New System.Drawing.Size(38, 13)
        Me.StatusLabelMinus.TabIndex = 21
        Me.StatusLabelMinus.Text = "Ready"
        '
        'StatusLabelPlus
        '
        Me.StatusLabelPlus.AutoSize = True
        Me.StatusLabelPlus.Location = New System.Drawing.Point(9, 443)
        Me.StatusLabelPlus.Name = "StatusLabelPlus"
        Me.StatusLabelPlus.Size = New System.Drawing.Size(38, 13)
        Me.StatusLabelPlus.TabIndex = 20
        Me.StatusLabelPlus.Text = "Ready"
        '
        'ERS_analysis
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(488, 481)
        Me.Controls.Add(Me.StatusLabelMinus)
        Me.Controls.Add(Me.StatusLabelPlus)
        Me.Controls.Add(Me.GoButton)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox6)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "ERS_analysis"
        Me.Text = "5'-ERS libraries analysis"
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents RefreshGroupsButton As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents RemoveItemButton As System.Windows.Forms.Button
    Friend WithEvents AddItemButton As System.Windows.Forms.Button
    Friend WithEvents AllRemoveButton As System.Windows.Forms.Button
    Friend WithEvents AllAddButton As System.Windows.Forms.Button
    Friend WithEvents AnalysisHolderListBox As System.Windows.Forms.ListBox
    Friend WithEvents AllHoldersListBox As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GoButton As System.Windows.Forms.Button
    Friend WithEvents StatusLabelMinus As System.Windows.Forms.Label
    Friend WithEvents StatusLabelPlus As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TSSCovTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents SearchWindowTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents SignalToNoiseTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TSSPosMatchTextBox As System.Windows.Forms.TextBox
End Class
