﻿Public Class SystemProgressBarBox

End Class