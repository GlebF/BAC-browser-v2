﻿Public Class CoverageStep
    Private intPosition As Integer
    Private bType As Boolean 'True for TSS False for TT

    Public Property Position() As Integer
        Get
            Position = intPosition
        End Get
        Set(ByVal value As Integer)
            intPosition = value
        End Set
    End Property

    Public Property Type() As Boolean
        Get
            Type = bType
        End Get
        Set(ByVal value As Boolean)
            bType = value
        End Set
    End Property


End Class
