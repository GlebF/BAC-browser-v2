﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MetaSearch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MetaSearch))
        Me.ResultDataGridView = New System.Windows.Forms.DataGridView
        Me.SearchButton = New System.Windows.Forms.Button
        Me.QueryTextBox = New System.Windows.Forms.TextBox
        Me.TextRadioButton = New System.Windows.Forms.RadioButton
        Me.NucRadioButton = New System.Windows.Forms.RadioButton
        Me.ProtRadioButton = New System.Windows.Forms.RadioButton
        Me.IDCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ResultCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.StartCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.EndCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        CType(Me.ResultDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ResultDataGridView
        '
        Me.ResultDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ResultDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDCol, Me.ResultCol, Me.StartCol, Me.EndCol})
        Me.ResultDataGridView.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ResultDataGridView.Location = New System.Drawing.Point(0, 114)
        Me.ResultDataGridView.Name = "ResultDataGridView"
        Me.ResultDataGridView.ReadOnly = True
        Me.ResultDataGridView.Size = New System.Drawing.Size(674, 115)
        Me.ResultDataGridView.TabIndex = 0
        '
        'SearchButton
        '
        Me.SearchButton.Location = New System.Drawing.Point(237, 38)
        Me.SearchButton.Name = "SearchButton"
        Me.SearchButton.Size = New System.Drawing.Size(75, 23)
        Me.SearchButton.TabIndex = 1
        Me.SearchButton.Text = "Search"
        Me.SearchButton.UseVisualStyleBackColor = True
        '
        'QueryTextBox
        '
        Me.QueryTextBox.Location = New System.Drawing.Point(12, 12)
        Me.QueryTextBox.Name = "QueryTextBox"
        Me.QueryTextBox.Size = New System.Drawing.Size(300, 20)
        Me.QueryTextBox.TabIndex = 2
        '
        'TextRadioButton
        '
        Me.TextRadioButton.AutoSize = True
        Me.TextRadioButton.Checked = True
        Me.TextRadioButton.Location = New System.Drawing.Point(12, 38)
        Me.TextRadioButton.Name = "TextRadioButton"
        Me.TextRadioButton.Size = New System.Drawing.Size(46, 17)
        Me.TextRadioButton.TabIndex = 3
        Me.TextRadioButton.TabStop = True
        Me.TextRadioButton.Text = "Text"
        Me.TextRadioButton.UseVisualStyleBackColor = True
        '
        'NucRadioButton
        '
        Me.NucRadioButton.AutoSize = True
        Me.NucRadioButton.Location = New System.Drawing.Point(12, 61)
        Me.NucRadioButton.Name = "NucRadioButton"
        Me.NucRadioButton.Size = New System.Drawing.Size(76, 17)
        Me.NucRadioButton.TabIndex = 4
        Me.NucRadioButton.Text = "Nucleotide"
        Me.NucRadioButton.UseVisualStyleBackColor = True
        '
        'ProtRadioButton
        '
        Me.ProtRadioButton.AutoSize = True
        Me.ProtRadioButton.Location = New System.Drawing.Point(12, 84)
        Me.ProtRadioButton.Name = "ProtRadioButton"
        Me.ProtRadioButton.Size = New System.Drawing.Size(61, 17)
        Me.ProtRadioButton.TabIndex = 5
        Me.ProtRadioButton.Text = "Peptide"
        Me.ProtRadioButton.UseVisualStyleBackColor = True
        '
        'IDCol
        '
        Me.IDCol.HeaderText = "Tab"
        Me.IDCol.Name = "IDCol"
        Me.IDCol.ReadOnly = True
        Me.IDCol.Width = 250
        '
        'ResultCol
        '
        Me.ResultCol.HeaderText = "Result"
        Me.ResultCol.Name = "ResultCol"
        Me.ResultCol.ReadOnly = True
        Me.ResultCol.Width = 250
        '
        'StartCol
        '
        Me.StartCol.HeaderText = "Start"
        Me.StartCol.Name = "StartCol"
        Me.StartCol.ReadOnly = True
        Me.StartCol.Width = 50
        '
        'EndCol
        '
        Me.EndCol.HeaderText = "End"
        Me.EndCol.Name = "EndCol"
        Me.EndCol.ReadOnly = True
        Me.EndCol.Width = 50
        '
        'MetaSearch
        '
        Me.AcceptButton = Me.SearchButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(674, 229)
        Me.Controls.Add(Me.ProtRadioButton)
        Me.Controls.Add(Me.NucRadioButton)
        Me.Controls.Add(Me.TextRadioButton)
        Me.Controls.Add(Me.QueryTextBox)
        Me.Controls.Add(Me.SearchButton)
        Me.Controls.Add(Me.ResultDataGridView)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "MetaSearch"
        Me.Text = "Metasearch"
        CType(Me.ResultDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ResultDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents SearchButton As System.Windows.Forms.Button
    Friend WithEvents QueryTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TextRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents NucRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents ProtRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents IDCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ResultCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StartCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EndCol As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
