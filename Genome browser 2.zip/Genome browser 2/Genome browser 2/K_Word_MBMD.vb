﻿Public Class K_Word_MBMD
    Inherits K_Word
    Private bRestricted As Boolean = False
    Private bBlocked As Boolean = False
    Private OriginID As String = ""

    Public Property Is_Restricted() As Boolean
        Get
            Is_Restricted = bRestricted
        End Get
        Set(ByVal value As Boolean)
            bRestricted = value
        End Set
    End Property

    Public Property Is_Blocked() As Boolean
        Get
            Is_Blocked = bBlocked
        End Get
        Set(ByVal value As Boolean)
            bBlocked = value
        End Set
    End Property

    Public Property Seq_ID() As String
        Get
            Seq_ID = OriginID
        End Get
        Set(ByVal value As String)
            OriginID = value
        End Set
    End Property

End Class
