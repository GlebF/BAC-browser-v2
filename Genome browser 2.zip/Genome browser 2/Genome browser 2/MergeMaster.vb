﻿Public Class MergeMaster

    Public MergeList As New List(Of FeaturesAssembly)
    Public MyViewer As Genome_Viewer

    Private Sub MergeButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MergeButton.Click

        If Not MergeTargetComboBox.Text = "" Then

            Dim Found As Boolean = False
            For Each Asm As FeaturesAssembly In MergeList
                If Asm.AssemblyName = MergeTargetComboBox.Text Then
                    Found = True
                End If
            Next

            If Found Then 'Collect features in one existing list
                Dim TargetAsm As FeaturesAssembly = DataIO.GetCurrentGroup(MyViewer.Features_Groups_List, MergeTargetComboBox.Text)

                If Not IsNothing(TargetAsm) Then
                    For Each Assembly As FeaturesAssembly In MergeList

                        If Not Assembly.AssemblyName = TargetAsm.AssemblyName Then

                            For Each Feature As Genome_Feature In Assembly.FeaturesList
                                TargetAsm.FeaturesList.Add(Feature)
                            Next

                        End If

                    Next
                End If

                For i = MergeList.Count - 1 To 0 Step -1
                    If Not MergeList(i).AssemblyName = TargetAsm.AssemblyName Then
                        If Not MergeList(i).AssemblyName = MyViewer.MainFeaturesListName Then
                            If Not MergeList(i).AssemblyName = MyViewer.UserFeaturesListName Then
                                MyViewer.Features_Groups_List.Remove(DataIO.GetCurrentGroup(MyViewer.Features_Groups_List, MergeList(i).AssemblyName))
                            End If
                        End If
                    End If
                Next

                MyViewer.RefreshAssemblyList()
                Me.Close()

            Else 'Create new merged list

                Dim NewAsm As New FeaturesAssembly
                NewAsm.AssemblyName = MergeTargetComboBox.Text
                NewAsm.Visible = True

                For Each Assembly As FeaturesAssembly In MergeList
                    For Each Feature As Genome_Feature In Assembly.FeaturesList
                        NewAsm.FeaturesList.Add(Feature)
                    Next
                Next

                For i = MergeList.Count - 1 To 0 Step -1
                    If Not MergeList(i).AssemblyName = MyViewer.MainFeaturesListName Then
                        If Not MergeList(i).AssemblyName = MyViewer.UserFeaturesListName Then
                            MyViewer.Features_Groups_List.Remove(DataIO.GetCurrentGroup(MyViewer.Features_Groups_List, MergeList(i).AssemblyName))
                        End If
                    End If
                Next

                MyViewer.Features_Groups_List.Add(NewAsm)

                MyViewer.RefreshAssemblyList()
                Me.Close()
            End If






        End If

    End Sub

End Class