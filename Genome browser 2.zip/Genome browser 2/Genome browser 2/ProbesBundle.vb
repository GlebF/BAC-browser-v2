﻿Public Class ProbesBundle
    Private strSeq As String = ""
    Private strLeft As String = ""
    Private strRight As String = ""
    Private strPolymorphRegion As String = ""
    Private strID As String = ""
    Private strProbes As New List(Of String)
    Private sglRefDG As Single = 0
    Private intRefStart As Integer
    Private intRefEnd As Integer


    'Private lPolymorphVariants As New List(Of String)

    Public Property Sequence() As String
        Get
            Sequence = strSeq
        End Get
        Set(ByVal value As String)
            strSeq = value
        End Set
    End Property

    Public Property LeftPart() As String
        Get
            LeftPart = strLeft
        End Get
        Set(ByVal value As String)
            strLeft = value
        End Set
    End Property

    Public Property RightPart() As String
        Get
            RightPart = strRight
        End Get
        Set(ByVal value As String)
            strRight = value
        End Set
    End Property

    Public Property PolymorphRegion() As String
        Get
            PolymorphRegion = strPolymorphRegion
        End Get
        Set(ByVal value As String)
            strPolymorphRegion = value
        End Set
    End Property

    Public Property Probes() As List(Of String)
        Get
            Probes = strProbes
        End Get
        Set(ByVal value As List(Of String))
            strProbes = value
        End Set
    End Property

    Public Property SNP_ID() As String
        Get
            SNP_ID = strID
        End Get
        Set(ByVal value As String)
            strID = value
        End Set
    End Property

    Public Property RefDG() As Single
        Get
            RefDG = sglRefDG
        End Get
        Set(ByVal value As Single)
            sglRefDG = value
        End Set
    End Property

    Public Property RefStart() As Integer
        Get
            RefStart = intRefStart
        End Get
        Set(ByVal value As Integer)
            intRefStart = value
        End Set
    End Property

    Public Property RefEnd() As Integer
        Get
            RefEnd = intRefEnd
        End Get
        Set(ByVal value As Integer)
            intRefEnd = value
        End Set
    End Property

    'Public Property PolymorphVariants() As List(Of String)
    'Get
    'PolymorphVariants = lPolymorphVariants
    'End Get
    'Set(ByVal value As List(Of String))
    'lPolymorphVariants = value
    'End Set
    'End Property

    Public Function GetMissingNt(ByVal Nt As String)
        Dim NtList As New List(Of String)

        Select Case Nt
            Case "A"
                NtList.Add("T")
                NtList.Add("G")
                NtList.Add("C")
            Case "T"
                NtList.Add("A")
                NtList.Add("G")
                NtList.Add("C")
            Case "G"
                NtList.Add("A")
                NtList.Add("T")
                NtList.Add("C")
            Case "C"
                NtList.Add("A")
                NtList.Add("T")
                NtList.Add("G")
        End Select


        Return NtList
    End Function

    Public Sub CreateBundleForSNP(ByVal Make_RC As Boolean)
        Probes.Add(strSeq)
        Dim MissingNt As List(Of String) = GetMissingNt(strPolymorphRegion)
        For Each Nt As String In MissingNt
            Probes.Add(strLeft & Nt & strRight)
        Next Nt

        If Make_RC Then
            Dim RC_Probes As New List(Of String)
            For Each Probe As String In strProbes
                RC_Probes.Add(Bioinformatics.GetReverseComplement(Probe))
            Next Probe

            For Each RC_Probe As String In RC_Probes
                Probes.Add(RC_Probe)
            Next RC_Probe
        End If

    End Sub

End Class
