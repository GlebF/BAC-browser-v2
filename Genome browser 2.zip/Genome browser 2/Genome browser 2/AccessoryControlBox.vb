﻿Public Class AccessoryControlBox
    Private cMyParent As Genome_Viewer

    Public Property MyParent() As Genome_Viewer
        Get
            MyParent = cMyParent
        End Get
        Set(ByVal value As Genome_Viewer)
            cMyParent = value
        End Set
    End Property

    Private Sub Go()
        Try
            Dim SearchID As String = AccessoryGridView.CurrentRow.Cells(1).Value

            For Each Feature As Genome_Feature In MyParent.User_Features
                If Feature.TAG = SearchID Then
                    MyParent.RangeStart = Feature.AbsoluteStart
                    MyParent.RangeEnd = Feature.AbsoluteEnd
                    MyParent.DisplayFeatures()
                    Exit For
                End If
            Next

        Catch ex As Exception
            MsgBox("Failed to display feature!")
        End Try
    End Sub

    Private Sub DeleteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteToolStripMenuItem.Click, DeleteFeatureButton.Click
        Dim SearchID As String = ""
        Dim ItemID As Integer = 0
        For i = AccessoryGridView.SelectedRows.Count - 1 To 0 Step -1
            SearchID = AccessoryGridView.SelectedRows(i).Cells(1).Value
            ItemID = AccessoryGridView.SelectedRows(i).Index
            AccessoryGridView.Rows.RemoveAt(AccessoryGridView.SelectedRows(i).Index)
            MyParent.RemoveUserFeature(SearchID)
        Next

        MyParent.DisplayFeatures()

    End Sub

    Private Sub ViewThisFeatureToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewThisFeatureToolStripMenuItem.Click
        Go()
    End Sub

    Private Sub ClearToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearToolStripButton.Click
        MyParent.ClearUserFeatures()
        AccessoryGridView.Rows.Clear()
        MyParent.DisplayFeatures()
    End Sub

    Private Sub UpdateToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateToolStripButton.Click

        Dim SearchID As String = ""

        For i = 0 To AccessoryGridView.Rows.Count - 2
            SearchID = AccessoryGridView.Rows(i).Cells(1).Value
            For Each Feature As Genome_Feature In MyParent.User_Features
                If Feature.TAG = SearchID Then
                    Feature.Visible = AccessoryGridView.Rows(i).Cells(0).Value
                End If
            Next
        Next

        MyParent.DisplayFeatures()

    End Sub

    Private Sub ViewToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewToolStripButton.Click
        Go()
    End Sub

    Private Sub AddToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToolStripButton.Click

        Dim Range As Integer = 0

        If MyParent.RangeStart < MyParent.RangeEnd Then 'Normal position of projection window
            Range = MyParent.RangeEnd - MyParent.RangeStart
        Else
            Range = MyParent.Genome_Sequence.Length - MyParent.RangeStart + MyParent.RangeEnd
        End If

        Dim CurrentX As Integer = MyParent.RangeStart + Windows.Forms.Cursor.Position.X * Range / Me.Width
        MyParent.AddOligo(CurrentX - 10, CurrentX + 10)
        MyParent.DisplayFeatures()

    End Sub

    Private Sub CheckStateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckStateButton.Click
        Static Check As Boolean = False

        For i = 0 To AccessoryGridView.Rows.Count - 2
            AccessoryGridView.Rows(i).Cells(0).Value = Check
        Next

        Check = Not Check


    End Sub

    Private Sub AccessoryGridView_CellEndEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles AccessoryGridView.CellEndEdit

        If e.ColumnIndex = 0 Then
            Dim SearchID As String = ""

            For i = 0 To AccessoryGridView.Rows.Count - 2
                SearchID = AccessoryGridView.Rows(i).Cells(1).Value
                For Each Feature As Genome_Feature In MyParent.User_Features
                    If Feature.TAG = SearchID Then
                        Feature.Visible = AccessoryGridView.Rows(i).Cells(0).Value
                    End If
                Next
            Next

            MyParent.DisplayFeatures()
        End If

        If e.ColumnIndex = 2 Then
            Dim SearchID As String = ""
            For i = 0 To AccessoryGridView.Rows.Count - 2
                SearchID = AccessoryGridView.Rows(i).Cells(1).Value
                For Each Feature As Genome_Feature In MyParent.User_Features
                    If Feature.TAG = SearchID Then
                        Feature.Name = AccessoryGridView.Rows(i).Cells(2).Value
                    End If
                Next
            Next

            MyParent.DisplayFeatures()
        End If

        If e.ColumnIndex = 7 Then
            For Each Feature As Genome_Feature In MyParent.User_Features
                If Feature.TAG = AccessoryGridView.CurrentRow.Cells(1).Value Then
                    If Not AccessoryGridView.CurrentRow.Cells(7).Value = "" Then
                        Feature.Type = 7
                        AccessoryGridView.CurrentRow.Cells(6).Value = "Feature"
                        Feature.Sequence = AccessoryGridView.CurrentRow.Cells(7).Value
                        Feature.AbsoluteEnd = Feature.AbsoluteStart + Feature.Sequence.Length - 1
                        AccessoryGridView.CurrentRow.Cells(3).Value = Feature.AbsoluteStart
                        AccessoryGridView.CurrentRow.Cells(4).Value = Feature.AbsoluteEnd
                    Else
                        Feature.Type = 8
                        Feature.Direction = 0
                        AccessoryGridView.CurrentRow.Cells(5).Value = "None"
                        AccessoryGridView.CurrentRow.Cells(6).Value = "Genome"
                    End If
                End If
            Next

            MyParent.DisplayFeatures()
        End If

        If e.ColumnIndex = 5 Then
            For Each Feature As Genome_Feature In MyParent.User_Features
                If Feature.TAG = AccessoryGridView.CurrentRow.Cells(1).Value Then
                    If Feature.Type = 7 Then
                        Select Case AccessoryGridView.CurrentRow.Cells(5).Value.ToString
                            Case "None"
                                Feature.Direction = 0
                            Case "Plus"
                                Feature.Direction = 1
                            Case "Minus"
                                Feature.Direction = 2
                        End Select
                    Else
                        AccessoryGridView.CurrentRow.Cells(5).Value = "None"
                    End If
                End If
            Next

            MyParent.DisplayFeatures()
        End If

    End Sub

    Private Sub AccessoryGridView_SelectionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AccessoryGridView.SelectionChanged
        If AccessoryGridView.SelectedRows.Count > 0 Then
            DeleteFeatureButton.Enabled = True
        Else
            DeleteFeatureButton.Enabled = False
        End If
    End Sub

End Class
