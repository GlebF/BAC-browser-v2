﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BrowserControlBox
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MainTabControl = New System.Windows.Forms.TabControl
        Me.FeaturesPage = New System.Windows.Forms.TabPage
        Me.OperonsCheckBox = New System.Windows.Forms.CheckBox
        Me.UserCheckBox = New System.Windows.Forms.CheckBox
        Me.TranscriptionCheckBox = New System.Windows.Forms.CheckBox
        Me.RepCheckBox = New System.Windows.Forms.CheckBox
        Me.NCCheckBox = New System.Windows.Forms.CheckBox
        Me.SiteCheckBox = New System.Windows.Forms.CheckBox
        Me.CodingCheckBox = New System.Windows.Forms.CheckBox
        Me.GridCheckBox = New System.Windows.Forms.CheckBox
        Me.SelectionPage = New System.Windows.Forms.TabPage
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.AuxOnButton = New System.Windows.Forms.RadioButton
        Me.AuxOffButton = New System.Windows.Forms.RadioButton
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.R3CheckBox = New System.Windows.Forms.CheckBox
        Me.R2CheckBox = New System.Windows.Forms.CheckBox
        Me.R1CheckBox = New System.Windows.Forms.CheckBox
        Me.F3CheckBox = New System.Windows.Forms.CheckBox
        Me.F2CheckBox = New System.Windows.Forms.CheckBox
        Me.F1CheckBox = New System.Windows.Forms.CheckBox
        Me.ColorCodeCheckBox = New System.Windows.Forms.CheckBox
        Me.TranslationOnButton = New System.Windows.Forms.RadioButton
        Me.TranslationOffButton = New System.Windows.Forms.RadioButton
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.SkewOnRadioButton = New System.Windows.Forms.RadioButton
        Me.SkewOffRadioButton = New System.Windows.Forms.RadioButton
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.MarckupOnRadioButton = New System.Windows.Forms.RadioButton
        Me.MarckupOffRadioButton = New System.Windows.Forms.RadioButton
        Me.SitePage = New System.Windows.Forms.TabPage
        Me.BackButton = New System.Windows.Forms.Button
        Me.DetectButton = New System.Windows.Forms.Button
        Me.ClearButton = New System.Windows.Forms.Button
        Me.DetectorListBox = New System.Windows.Forms.CheckedListBox
        Me.GenomePage = New System.Windows.Forms.TabPage
        Me.Label6 = New System.Windows.Forms.Label
        Me.SeqNameTextBox = New System.Windows.Forms.TextBox
        Me.RefreshButton = New System.Windows.Forms.Button
        Me.Label5 = New System.Windows.Forms.Label
        Me.GenomeMWTextBox = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.CommentTextBox = New System.Windows.Forms.TextBox
        Me.LengthTextBox = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.TransComboBox = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.TopologyComboBox = New System.Windows.Forms.ComboBox
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.InfoDataGridView = New System.Windows.Forms.DataGridView
        Me.InfoKeyCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.InfoValCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.MainTabControl.SuspendLayout()
        Me.FeaturesPage.SuspendLayout()
        Me.SelectionPage.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SitePage.SuspendLayout()
        Me.GenomePage.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.InfoDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MainTabControl
        '
        Me.MainTabControl.Controls.Add(Me.FeaturesPage)
        Me.MainTabControl.Controls.Add(Me.SelectionPage)
        Me.MainTabControl.Controls.Add(Me.SitePage)
        Me.MainTabControl.Controls.Add(Me.GenomePage)
        Me.MainTabControl.Controls.Add(Me.TabPage1)
        Me.MainTabControl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MainTabControl.Location = New System.Drawing.Point(0, 0)
        Me.MainTabControl.Name = "MainTabControl"
        Me.MainTabControl.SelectedIndex = 0
        Me.MainTabControl.Size = New System.Drawing.Size(200, 300)
        Me.MainTabControl.TabIndex = 1
        '
        'FeaturesPage
        '
        Me.FeaturesPage.AutoScroll = True
        Me.FeaturesPage.Controls.Add(Me.OperonsCheckBox)
        Me.FeaturesPage.Controls.Add(Me.UserCheckBox)
        Me.FeaturesPage.Controls.Add(Me.TranscriptionCheckBox)
        Me.FeaturesPage.Controls.Add(Me.RepCheckBox)
        Me.FeaturesPage.Controls.Add(Me.NCCheckBox)
        Me.FeaturesPage.Controls.Add(Me.SiteCheckBox)
        Me.FeaturesPage.Controls.Add(Me.CodingCheckBox)
        Me.FeaturesPage.Controls.Add(Me.GridCheckBox)
        Me.FeaturesPage.Location = New System.Drawing.Point(4, 22)
        Me.FeaturesPage.Name = "FeaturesPage"
        Me.FeaturesPage.Padding = New System.Windows.Forms.Padding(3)
        Me.FeaturesPage.Size = New System.Drawing.Size(192, 274)
        Me.FeaturesPage.TabIndex = 0
        Me.FeaturesPage.Text = "Show"
        Me.FeaturesPage.UseVisualStyleBackColor = True
        '
        'OperonsCheckBox
        '
        Me.OperonsCheckBox.AutoSize = True
        Me.OperonsCheckBox.Checked = True
        Me.OperonsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.OperonsCheckBox.Location = New System.Drawing.Point(6, 52)
        Me.OperonsCheckBox.Name = "OperonsCheckBox"
        Me.OperonsCheckBox.Size = New System.Drawing.Size(155, 17)
        Me.OperonsCheckBox.TabIndex = 7
        Me.OperonsCheckBox.Text = "Coding transcripts/Operons"
        Me.OperonsCheckBox.UseVisualStyleBackColor = True
        '
        'UserCheckBox
        '
        Me.UserCheckBox.AutoSize = True
        Me.UserCheckBox.Checked = True
        Me.UserCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.UserCheckBox.Location = New System.Drawing.Point(6, 167)
        Me.UserCheckBox.Name = "UserCheckBox"
        Me.UserCheckBox.Size = New System.Drawing.Size(135, 17)
        Me.UserCheckBox.TabIndex = 6
        Me.UserCheckBox.Text = "User designed features"
        Me.UserCheckBox.UseVisualStyleBackColor = True
        '
        'TranscriptionCheckBox
        '
        Me.TranscriptionCheckBox.AutoSize = True
        Me.TranscriptionCheckBox.Checked = True
        Me.TranscriptionCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.TranscriptionCheckBox.Location = New System.Drawing.Point(6, 144)
        Me.TranscriptionCheckBox.Name = "TranscriptionCheckBox"
        Me.TranscriptionCheckBox.Size = New System.Drawing.Size(92, 17)
        Me.TranscriptionCheckBox.TabIndex = 5
        Me.TranscriptionCheckBox.Text = "TSS and TTS"
        Me.TranscriptionCheckBox.UseVisualStyleBackColor = True
        '
        'RepCheckBox
        '
        Me.RepCheckBox.AutoSize = True
        Me.RepCheckBox.Checked = True
        Me.RepCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.RepCheckBox.Location = New System.Drawing.Point(6, 121)
        Me.RepCheckBox.Name = "RepCheckBox"
        Me.RepCheckBox.Size = New System.Drawing.Size(66, 17)
        Me.RepCheckBox.TabIndex = 4
        Me.RepCheckBox.Text = "Repeats"
        Me.RepCheckBox.UseVisualStyleBackColor = True
        '
        'NCCheckBox
        '
        Me.NCCheckBox.AutoSize = True
        Me.NCCheckBox.Checked = True
        Me.NCCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.NCCheckBox.Location = New System.Drawing.Point(6, 98)
        Me.NCCheckBox.Name = "NCCheckBox"
        Me.NCCheckBox.Size = New System.Drawing.Size(151, 17)
        Me.NCCheckBox.TabIndex = 3
        Me.NCCheckBox.Text = "Small and antisense RNAs"
        Me.NCCheckBox.UseVisualStyleBackColor = True
        '
        'SiteCheckBox
        '
        Me.SiteCheckBox.AutoSize = True
        Me.SiteCheckBox.Checked = True
        Me.SiteCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.SiteCheckBox.Location = New System.Drawing.Point(6, 75)
        Me.SiteCheckBox.Name = "SiteCheckBox"
        Me.SiteCheckBox.Size = New System.Drawing.Size(171, 17)
        Me.SiteCheckBox.TabIndex = 2
        Me.SiteCheckBox.Text = "Binding sites/Regulatory motifs"
        Me.SiteCheckBox.UseVisualStyleBackColor = True
        '
        'CodingCheckBox
        '
        Me.CodingCheckBox.AutoSize = True
        Me.CodingCheckBox.Checked = True
        Me.CodingCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CodingCheckBox.Location = New System.Drawing.Point(6, 29)
        Me.CodingCheckBox.Name = "CodingCheckBox"
        Me.CodingCheckBox.Size = New System.Drawing.Size(151, 17)
        Me.CodingCheckBox.TabIndex = 1
        Me.CodingCheckBox.Text = "CDSs and structural RNAs"
        Me.CodingCheckBox.UseVisualStyleBackColor = True
        '
        'GridCheckBox
        '
        Me.GridCheckBox.AutoSize = True
        Me.GridCheckBox.Checked = True
        Me.GridCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.GridCheckBox.Location = New System.Drawing.Point(6, 6)
        Me.GridCheckBox.Name = "GridCheckBox"
        Me.GridCheckBox.Size = New System.Drawing.Size(45, 17)
        Me.GridCheckBox.TabIndex = 0
        Me.GridCheckBox.Text = "Grid"
        Me.GridCheckBox.UseVisualStyleBackColor = True
        '
        'SelectionPage
        '
        Me.SelectionPage.AutoScroll = True
        Me.SelectionPage.Controls.Add(Me.GroupBox4)
        Me.SelectionPage.Controls.Add(Me.GroupBox1)
        Me.SelectionPage.Controls.Add(Me.GroupBox3)
        Me.SelectionPage.Controls.Add(Me.GroupBox2)
        Me.SelectionPage.Location = New System.Drawing.Point(4, 22)
        Me.SelectionPage.Name = "SelectionPage"
        Me.SelectionPage.Padding = New System.Windows.Forms.Padding(3)
        Me.SelectionPage.Size = New System.Drawing.Size(192, 274)
        Me.SelectionPage.TabIndex = 1
        Me.SelectionPage.Text = "Panels"
        Me.SelectionPage.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.AuxOnButton)
        Me.GroupBox4.Controls.Add(Me.AuxOffButton)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 104)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(163, 43)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Multiline coverage panel"
        '
        'AuxOnButton
        '
        Me.AuxOnButton.AutoSize = True
        Me.AuxOnButton.Location = New System.Drawing.Point(51, 19)
        Me.AuxOnButton.Name = "AuxOnButton"
        Me.AuxOnButton.Size = New System.Drawing.Size(39, 17)
        Me.AuxOnButton.TabIndex = 5
        Me.AuxOnButton.Text = "On"
        Me.AuxOnButton.UseVisualStyleBackColor = True
        '
        'AuxOffButton
        '
        Me.AuxOffButton.AutoSize = True
        Me.AuxOffButton.Checked = True
        Me.AuxOffButton.Location = New System.Drawing.Point(6, 19)
        Me.AuxOffButton.Name = "AuxOffButton"
        Me.AuxOffButton.Size = New System.Drawing.Size(39, 17)
        Me.AuxOffButton.TabIndex = 4
        Me.AuxOffButton.TabStop = True
        Me.AuxOffButton.Text = "Off"
        Me.AuxOffButton.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.R3CheckBox)
        Me.GroupBox1.Controls.Add(Me.R2CheckBox)
        Me.GroupBox1.Controls.Add(Me.R1CheckBox)
        Me.GroupBox1.Controls.Add(Me.F3CheckBox)
        Me.GroupBox1.Controls.Add(Me.F2CheckBox)
        Me.GroupBox1.Controls.Add(Me.F1CheckBox)
        Me.GroupBox1.Controls.Add(Me.ColorCodeCheckBox)
        Me.GroupBox1.Controls.Add(Me.TranslationOnButton)
        Me.GroupBox1.Controls.Add(Me.TranslationOffButton)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 153)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(163, 112)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Translation panel"
        '
        'R3CheckBox
        '
        Me.R3CheckBox.AutoSize = True
        Me.R3CheckBox.Checked = True
        Me.R3CheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.R3CheckBox.Location = New System.Drawing.Point(97, 88)
        Me.R3CheckBox.Name = "R3CheckBox"
        Me.R3CheckBox.Size = New System.Drawing.Size(35, 17)
        Me.R3CheckBox.TabIndex = 10
        Me.R3CheckBox.Text = "-3"
        Me.R3CheckBox.UseVisualStyleBackColor = True
        '
        'R2CheckBox
        '
        Me.R2CheckBox.AutoSize = True
        Me.R2CheckBox.Checked = True
        Me.R2CheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.R2CheckBox.Location = New System.Drawing.Point(51, 88)
        Me.R2CheckBox.Name = "R2CheckBox"
        Me.R2CheckBox.Size = New System.Drawing.Size(35, 17)
        Me.R2CheckBox.TabIndex = 9
        Me.R2CheckBox.Text = "-2"
        Me.R2CheckBox.UseVisualStyleBackColor = True
        '
        'R1CheckBox
        '
        Me.R1CheckBox.AutoSize = True
        Me.R1CheckBox.Checked = True
        Me.R1CheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.R1CheckBox.Location = New System.Drawing.Point(6, 88)
        Me.R1CheckBox.Name = "R1CheckBox"
        Me.R1CheckBox.Size = New System.Drawing.Size(35, 17)
        Me.R1CheckBox.TabIndex = 8
        Me.R1CheckBox.Text = "-1"
        Me.R1CheckBox.UseVisualStyleBackColor = True
        '
        'F3CheckBox
        '
        Me.F3CheckBox.AutoSize = True
        Me.F3CheckBox.Checked = True
        Me.F3CheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.F3CheckBox.Location = New System.Drawing.Point(97, 65)
        Me.F3CheckBox.Name = "F3CheckBox"
        Me.F3CheckBox.Size = New System.Drawing.Size(38, 17)
        Me.F3CheckBox.TabIndex = 7
        Me.F3CheckBox.Text = "+3"
        Me.F3CheckBox.UseVisualStyleBackColor = True
        '
        'F2CheckBox
        '
        Me.F2CheckBox.AutoSize = True
        Me.F2CheckBox.Checked = True
        Me.F2CheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.F2CheckBox.Location = New System.Drawing.Point(51, 65)
        Me.F2CheckBox.Name = "F2CheckBox"
        Me.F2CheckBox.Size = New System.Drawing.Size(38, 17)
        Me.F2CheckBox.TabIndex = 6
        Me.F2CheckBox.Text = "+2"
        Me.F2CheckBox.UseVisualStyleBackColor = True
        '
        'F1CheckBox
        '
        Me.F1CheckBox.AutoSize = True
        Me.F1CheckBox.Checked = True
        Me.F1CheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.F1CheckBox.Location = New System.Drawing.Point(6, 65)
        Me.F1CheckBox.Name = "F1CheckBox"
        Me.F1CheckBox.Size = New System.Drawing.Size(38, 17)
        Me.F1CheckBox.TabIndex = 5
        Me.F1CheckBox.Text = "+1"
        Me.F1CheckBox.UseVisualStyleBackColor = True
        '
        'ColorCodeCheckBox
        '
        Me.ColorCodeCheckBox.AutoSize = True
        Me.ColorCodeCheckBox.Location = New System.Drawing.Point(6, 42)
        Me.ColorCodeCheckBox.Name = "ColorCodeCheckBox"
        Me.ColorCodeCheckBox.Size = New System.Drawing.Size(95, 17)
        Me.ColorCodeCheckBox.TabIndex = 4
        Me.ColorCodeCheckBox.Text = "Full color code"
        Me.ColorCodeCheckBox.UseVisualStyleBackColor = True
        '
        'TranslationOnButton
        '
        Me.TranslationOnButton.AutoSize = True
        Me.TranslationOnButton.Location = New System.Drawing.Point(51, 19)
        Me.TranslationOnButton.Name = "TranslationOnButton"
        Me.TranslationOnButton.Size = New System.Drawing.Size(39, 17)
        Me.TranslationOnButton.TabIndex = 3
        Me.TranslationOnButton.Text = "On"
        Me.TranslationOnButton.UseVisualStyleBackColor = True
        '
        'TranslationOffButton
        '
        Me.TranslationOffButton.AutoSize = True
        Me.TranslationOffButton.Checked = True
        Me.TranslationOffButton.Location = New System.Drawing.Point(6, 19)
        Me.TranslationOffButton.Name = "TranslationOffButton"
        Me.TranslationOffButton.Size = New System.Drawing.Size(39, 17)
        Me.TranslationOffButton.TabIndex = 2
        Me.TranslationOffButton.TabStop = True
        Me.TranslationOffButton.Text = "Off"
        Me.TranslationOffButton.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.SkewOnRadioButton)
        Me.GroupBox3.Controls.Add(Me.SkewOffRadioButton)
        Me.GroupBox3.Location = New System.Drawing.Point(6, 55)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(163, 43)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Coverage panel"
        '
        'SkewOnRadioButton
        '
        Me.SkewOnRadioButton.AutoSize = True
        Me.SkewOnRadioButton.Location = New System.Drawing.Point(51, 19)
        Me.SkewOnRadioButton.Name = "SkewOnRadioButton"
        Me.SkewOnRadioButton.Size = New System.Drawing.Size(39, 17)
        Me.SkewOnRadioButton.TabIndex = 3
        Me.SkewOnRadioButton.Text = "On"
        Me.SkewOnRadioButton.UseVisualStyleBackColor = True
        '
        'SkewOffRadioButton
        '
        Me.SkewOffRadioButton.AutoSize = True
        Me.SkewOffRadioButton.Checked = True
        Me.SkewOffRadioButton.Location = New System.Drawing.Point(6, 19)
        Me.SkewOffRadioButton.Name = "SkewOffRadioButton"
        Me.SkewOffRadioButton.Size = New System.Drawing.Size(39, 17)
        Me.SkewOffRadioButton.TabIndex = 2
        Me.SkewOffRadioButton.TabStop = True
        Me.SkewOffRadioButton.Text = "Off"
        Me.SkewOffRadioButton.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.MarckupOnRadioButton)
        Me.GroupBox2.Controls.Add(Me.MarckupOffRadioButton)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(163, 43)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Sequence panel"
        '
        'MarckupOnRadioButton
        '
        Me.MarckupOnRadioButton.AutoSize = True
        Me.MarckupOnRadioButton.Location = New System.Drawing.Point(51, 19)
        Me.MarckupOnRadioButton.Name = "MarckupOnRadioButton"
        Me.MarckupOnRadioButton.Size = New System.Drawing.Size(39, 17)
        Me.MarckupOnRadioButton.TabIndex = 1
        Me.MarckupOnRadioButton.Text = "On"
        Me.MarckupOnRadioButton.UseVisualStyleBackColor = True
        '
        'MarckupOffRadioButton
        '
        Me.MarckupOffRadioButton.AutoSize = True
        Me.MarckupOffRadioButton.Checked = True
        Me.MarckupOffRadioButton.Location = New System.Drawing.Point(6, 19)
        Me.MarckupOffRadioButton.Name = "MarckupOffRadioButton"
        Me.MarckupOffRadioButton.Size = New System.Drawing.Size(39, 17)
        Me.MarckupOffRadioButton.TabIndex = 0
        Me.MarckupOffRadioButton.TabStop = True
        Me.MarckupOffRadioButton.Text = "Off"
        Me.MarckupOffRadioButton.UseVisualStyleBackColor = True
        '
        'SitePage
        '
        Me.SitePage.AutoScroll = True
        Me.SitePage.Controls.Add(Me.BackButton)
        Me.SitePage.Controls.Add(Me.DetectButton)
        Me.SitePage.Controls.Add(Me.ClearButton)
        Me.SitePage.Controls.Add(Me.DetectorListBox)
        Me.SitePage.Location = New System.Drawing.Point(4, 22)
        Me.SitePage.Name = "SitePage"
        Me.SitePage.Padding = New System.Windows.Forms.Padding(3)
        Me.SitePage.Size = New System.Drawing.Size(192, 274)
        Me.SitePage.TabIndex = 3
        Me.SitePage.Text = "Sites"
        Me.SitePage.UseVisualStyleBackColor = True
        '
        'BackButton
        '
        Me.BackButton.Location = New System.Drawing.Point(3, 198)
        Me.BackButton.Name = "BackButton"
        Me.BackButton.Size = New System.Drawing.Size(50, 23)
        Me.BackButton.TabIndex = 5
        Me.BackButton.Text = "Back"
        Me.BackButton.UseVisualStyleBackColor = True
        '
        'DetectButton
        '
        Me.DetectButton.Location = New System.Drawing.Point(59, 198)
        Me.DetectButton.Name = "DetectButton"
        Me.DetectButton.Size = New System.Drawing.Size(50, 23)
        Me.DetectButton.TabIndex = 4
        Me.DetectButton.Text = "Find"
        Me.DetectButton.UseVisualStyleBackColor = True
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(115, 198)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(50, 23)
        Me.ClearButton.TabIndex = 3
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'DetectorListBox
        '
        Me.DetectorListBox.CheckOnClick = True
        Me.DetectorListBox.FormattingEnabled = True
        Me.DetectorListBox.Location = New System.Drawing.Point(3, 6)
        Me.DetectorListBox.Name = "DetectorListBox"
        Me.DetectorListBox.Size = New System.Drawing.Size(169, 184)
        Me.DetectorListBox.TabIndex = 0
        '
        'GenomePage
        '
        Me.GenomePage.AutoScroll = True
        Me.GenomePage.Controls.Add(Me.Label6)
        Me.GenomePage.Controls.Add(Me.SeqNameTextBox)
        Me.GenomePage.Controls.Add(Me.RefreshButton)
        Me.GenomePage.Controls.Add(Me.Label5)
        Me.GenomePage.Controls.Add(Me.GenomeMWTextBox)
        Me.GenomePage.Controls.Add(Me.Label4)
        Me.GenomePage.Controls.Add(Me.CommentTextBox)
        Me.GenomePage.Controls.Add(Me.LengthTextBox)
        Me.GenomePage.Controls.Add(Me.Label3)
        Me.GenomePage.Controls.Add(Me.TransComboBox)
        Me.GenomePage.Controls.Add(Me.Label2)
        Me.GenomePage.Controls.Add(Me.Label1)
        Me.GenomePage.Controls.Add(Me.TopologyComboBox)
        Me.GenomePage.Location = New System.Drawing.Point(4, 22)
        Me.GenomePage.Name = "GenomePage"
        Me.GenomePage.Padding = New System.Windows.Forms.Padding(3)
        Me.GenomePage.Size = New System.Drawing.Size(192, 274)
        Me.GenomePage.TabIndex = 2
        Me.GenomePage.Text = "Seq"
        Me.GenomePage.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 8)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Sequence name:"
        '
        'SeqNameTextBox
        '
        Me.SeqNameTextBox.Location = New System.Drawing.Point(6, 24)
        Me.SeqNameTextBox.Multiline = True
        Me.SeqNameTextBox.Name = "SeqNameTextBox"
        Me.SeqNameTextBox.ReadOnly = True
        Me.SeqNameTextBox.Size = New System.Drawing.Size(180, 33)
        Me.SeqNameTextBox.TabIndex = 12
        '
        'RefreshButton
        '
        Me.RefreshButton.Location = New System.Drawing.Point(111, 227)
        Me.RefreshButton.Name = "RefreshButton"
        Me.RefreshButton.Size = New System.Drawing.Size(75, 23)
        Me.RefreshButton.TabIndex = 11
        Me.RefreshButton.Text = "Refresh"
        Me.RefreshButton.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(43, 207)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(30, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "MW:"
        '
        'GenomeMWTextBox
        '
        Me.GenomeMWTextBox.Location = New System.Drawing.Point(76, 201)
        Me.GenomeMWTextBox.Name = "GenomeMWTextBox"
        Me.GenomeMWTextBox.ReadOnly = True
        Me.GenomeMWTextBox.Size = New System.Drawing.Size(110, 20)
        Me.GenomeMWTextBox.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(19, 149)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Comment:"
        '
        'CommentTextBox
        '
        Me.CommentTextBox.Location = New System.Drawing.Point(76, 143)
        Me.CommentTextBox.Multiline = True
        Me.CommentTextBox.Name = "CommentTextBox"
        Me.CommentTextBox.Size = New System.Drawing.Size(110, 52)
        Me.CommentTextBox.TabIndex = 6
        '
        'LengthTextBox
        '
        Me.LengthTextBox.Location = New System.Drawing.Point(76, 117)
        Me.LengthTextBox.Name = "LengthTextBox"
        Me.LengthTextBox.ReadOnly = True
        Me.LengthTextBox.Size = New System.Drawing.Size(110, 20)
        Me.LengthTextBox.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 123)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Length:"
        '
        'TransComboBox
        '
        Me.TransComboBox.FormattingEnabled = True
        Me.TransComboBox.Location = New System.Drawing.Point(76, 90)
        Me.TransComboBox.Name = "TransComboBox"
        Me.TransComboBox.Size = New System.Drawing.Size(110, 21)
        Me.TransComboBox.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 96)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Translation:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(19, 69)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Topology:"
        '
        'TopologyComboBox
        '
        Me.TopologyComboBox.FormattingEnabled = True
        Me.TopologyComboBox.Items.AddRange(New Object() {"Linear", "Circular"})
        Me.TopologyComboBox.Location = New System.Drawing.Point(76, 63)
        Me.TopologyComboBox.Name = "TopologyComboBox"
        Me.TopologyComboBox.Size = New System.Drawing.Size(110, 21)
        Me.TopologyComboBox.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.InfoDataGridView)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(192, 274)
        Me.TabPage1.TabIndex = 4
        Me.TabPage1.Text = "Info"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'InfoDataGridView
        '
        Me.InfoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.InfoDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.InfoKeyCol, Me.InfoValCol})
        Me.InfoDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.InfoDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.InfoDataGridView.Name = "InfoDataGridView"
        Me.InfoDataGridView.Size = New System.Drawing.Size(186, 268)
        Me.InfoDataGridView.TabIndex = 0
        '
        'InfoKeyCol
        '
        Me.InfoKeyCol.HeaderText = "Key"
        Me.InfoKeyCol.Name = "InfoKeyCol"
        Me.InfoKeyCol.Width = 75
        '
        'InfoValCol
        '
        Me.InfoValCol.HeaderText = "Value"
        Me.InfoValCol.Name = "InfoValCol"
        '
        'BrowserControlBox
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.MainTabControl)
        Me.Name = "BrowserControlBox"
        Me.Size = New System.Drawing.Size(200, 300)
        Me.MainTabControl.ResumeLayout(False)
        Me.FeaturesPage.ResumeLayout(False)
        Me.FeaturesPage.PerformLayout()
        Me.SelectionPage.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.SitePage.ResumeLayout(False)
        Me.GenomePage.ResumeLayout(False)
        Me.GenomePage.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        CType(Me.InfoDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MainTabControl As System.Windows.Forms.TabControl
    Friend WithEvents FeaturesPage As System.Windows.Forms.TabPage
    Friend WithEvents TranscriptionCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents RepCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents NCCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents SiteCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents CodingCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GridCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents SelectionPage As System.Windows.Forms.TabPage
    Friend WithEvents GenomePage As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TopologyComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TransComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents LengthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents SitePage As System.Windows.Forms.TabPage
    Friend WithEvents DetectorListBox As System.Windows.Forms.CheckedListBox
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents DetectButton As System.Windows.Forms.Button
    Friend WithEvents BackButton As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents MarckupOnRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents MarckupOffRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents CommentTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UserCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents SkewOnRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents SkewOffRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents OperonsCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TranslationOnButton As System.Windows.Forms.RadioButton
    Friend WithEvents TranslationOffButton As System.Windows.Forms.RadioButton
    Friend WithEvents ColorCodeCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents R3CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents R2CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents R1CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents F3CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents F2CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents F1CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GenomeMWTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RefreshButton As System.Windows.Forms.Button
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents InfoDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents InfoKeyCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents InfoValCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents AuxOnButton As System.Windows.Forms.RadioButton
    Friend WithEvents AuxOffButton As System.Windows.Forms.RadioButton
    Friend WithEvents SeqNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label

End Class
