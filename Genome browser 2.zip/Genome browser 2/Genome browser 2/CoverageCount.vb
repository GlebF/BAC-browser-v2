﻿Public Class CoverageCount
    Public MyGenomeViewer As Genome_Viewer

    Private Sub RefreshGroups()
        Dim GroupList As New List(Of String)
        Dim Found As Boolean = False
        For Each Holder As PositionalValuesHolder In MyGenomeViewer.Positional_Values_Collection
            Found = False

            For Each Group As String In GroupList
                If Group = Holder.Group Then
                    Found = True
                    Exit For
                End If
            Next

            If Not Found Then
                GroupList.Add(Holder.Group)
            End If


        Next

        AnalysisHolderListBox.Items.Clear()
        AllHoldersListBox.Items.Clear()
        For Each Group As String In GroupList
            AllHoldersListBox.Items.Add(Group)
        Next
    End Sub

    Private Sub RefreshAnnot()
        SourceComboBox.Items.Clear()
        For Each Group As FeaturesAssembly In MyGenomeViewer.Features_Groups_List
            SourceComboBox.Items.Add(Group.AssemblyName)
        Next Group
    End Sub

    Private Sub CoverageCount_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Fill annotation source box
        RefreshAnnot()


        'Fill group list box
        RefreshGroups()


    End Sub

    Private Sub RefreshGroupsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshGroupsButton.Click
        RefreshAnnot()
        RefreshGroups()

    End Sub

    Private Sub AddItemButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddItemButton.Click
        If Not IsNothing(AllHoldersListBox.SelectedItem) Then
            AnalysisHolderListBox.Items.Add(AllHoldersListBox.SelectedItem)
            AllHoldersListBox.Items.Remove(AllHoldersListBox.SelectedItem)
        End If
    End Sub

    Private Sub RemoveItemButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveItemButton.Click
        If Not IsNothing(AnalysisHolderListBox.SelectedItem) Then
            AllHoldersListBox.Items.Add(AnalysisHolderListBox.SelectedItem)
            AnalysisHolderListBox.Items.Remove(AnalysisHolderListBox.SelectedItem)
        End If
    End Sub

    Private Sub AllAddButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AllAddButton.Click
        For Each Item As String In AllHoldersListBox.Items
            AnalysisHolderListBox.Items.Add(Item)

        Next

        AllHoldersListBox.Items.Clear()

    End Sub

    Private Sub AllRemoveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AllRemoveButton.Click
        For Each Item As String In AnalysisHolderListBox.Items
            AllHoldersListBox.Items.Add(Item)

        Next

        AnalysisHolderListBox.Items.Clear()
    End Sub

    Private Sub GoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoButton.Click
        If Master.SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then


            'Get annotation
            Dim Annotation As FeaturesAssembly = Nothing

            For Each Group As FeaturesAssembly In MyGenomeViewer.Features_Groups_List
                If Group.AssemblyName = SourceComboBox.Text Then
                    Annotation = DataIO.GetCurrentGroup(MyGenomeViewer.Features_Groups_List, MyGenomeViewer.MainFeaturesListName)
                End If
            Next Group

            If IsNothing(Annotation) Then

                MsgBox("Annotation was not found!")

                Exit Sub

            End If



            'Identify scale factors
            Dim TotalValues As New List(Of Integer)
            Dim ScaleFactors As New List(Of Single)
            Dim LocalSum As Integer = 0


            For Each Group As String In AnalysisHolderListBox.Items
                LocalSum = 0

                For i = 0 To MyGenomeViewer.Positional_Values_Collection.Count - 1
                    If MyGenomeViewer.Positional_Values_Collection(i).Group = Group Then

                        If AllLibRadioButton.Checked Then
                            LocalSum += Bioinformatics.GetAggregatedCoverage(MyGenomeViewer.Positional_Values_Collection(i).Positional_Values)

                        End If

                        If CodingRadioButton.Checked Then
                            LocalSum += Bioinformatics.GetCodingCoverage_SingleStrand(MyGenomeViewer.Positional_Values_Collection(i).Positional_Values, Annotation.FeaturesList)

                        End If

                    End If

                Next i

                TotalValues.Add(LocalSum)

            Next Group

            Dim MaxCov As Integer = 0
            For Each Value As Integer In TotalValues
                If Value > MaxCov Then
                    MaxCov = Value
                End If
            Next

            If ScaleToMaxRadioButton.Checked Then

                For i = 0 To TotalValues.Count - 1
                    ScaleFactors.Add(MaxCov / TotalValues(i))
                Next

            ElseIf ScaleIndipendentlyRadioButton.Checked Then

                For i = 0 To TotalValues.Count - 1
                    ScaleFactors.Add(1000000 / TotalValues(i))
                Next

            End If


            'Integrate and normalize coverage for each feature in each group

            Dim NormalizedCoverage As Single = 0 'Normalized coverage for feature
            Dim PileupAggregate As Integer = 0 'Pileup sum of coverage for feature

            Dim AS_NormalizedCoverage As Single = 0 'Normalized coverage for feature for antisense
            Dim AS_PileupAgregate As Integer = 0 'Pileup sum of coverage for antisense



            Dim CurrentCoverage As PositionalValuesHolder = Nothing

            Dim ReportTable As New List(Of String)
            Dim ReportString As String = "TAG" & Chr(9) & "Name" & Chr(9) & "Start" & Chr(9) & "End" & Chr(9) & "Direction" & Chr(9)

            For k = 0 To AnalysisHolderListBox.Items.Count - 1


                If ASCheckBox.Checked Then
                    ReportString &= AnalysisHolderListBox.Items(k) & " RPKM (Scale factor=" & ScaleFactors(k) & ")" & Chr(9) & AnalysisHolderListBox.Items(k) & " Coverage" & Chr(9) & AnalysisHolderListBox.Items(k) & " RPKM-as" & Chr(9) & AnalysisHolderListBox.Items(k) & " Coverage-as" & Chr(9)

                Else
                    ReportString &= AnalysisHolderListBox.Items(k) & " RPKM (Scale factor=" & ScaleFactors(k) & ")" & Chr(9) & AnalysisHolderListBox.Items(k) & " Coverage" & Chr(9)

                End If

            Next k

            ReportTable.Add(ReportString)


            For Each Feature As Genome_Feature In Annotation.FeaturesList
                'Integrate coverage from all pileups from the same group for each feature

                If Feature.Type = 1 Or Feature.Type = 2 Or Feature.Type = 4 Or Feature.Type = 12 Then 'Count only transcribed features


                    ReportString = Feature.TAG & Chr(9) & Feature.Name & Chr(9) & Feature.AbsoluteStart & Chr(9) & Feature.AbsoluteEnd & Chr(9) & Feature.Direction & Chr(9)


                    For k = 0 To AnalysisHolderListBox.Items.Count - 1
                        'Iterate trough the groups of coverage

                        NormalizedCoverage = 0
                        PileupAggregate = 0


                        For i = 0 To MyGenomeViewer.Positional_Values_Collection.Count - 1
                            If MyGenomeViewer.Positional_Values_Collection(i).Group = AnalysisHolderListBox.Items(k) Then
                                CurrentCoverage = MyGenomeViewer.Positional_Values_Collection(i)



                                If CurrentCoverage.Strand = 0 Then 'Add coverage to features regardless of direction

                                    NormalizedCoverage += Bioinformatics.GetPileUpSumPerLength(Feature.AbsoluteStart + 1, Feature.AbsoluteEnd + 1, CurrentCoverage.Positional_Values) * ScaleFactors(k)
                                    PileupAggregate += Bioinformatics.GetPileUpSum(Feature.AbsoluteStart + 1, Feature.AbsoluteEnd + 1, CurrentCoverage.Positional_Values)

                                Else 'Coverage is directional
                                    If Feature.Direction = CurrentCoverage.Strand Then

                                        NormalizedCoverage += Bioinformatics.GetPileUpSumPerLength(Feature.AbsoluteStart + 1, Feature.AbsoluteEnd + 1, CurrentCoverage.Positional_Values) * ScaleFactors(k)
                                        PileupAggregate += Bioinformatics.GetPileUpSum(Feature.AbsoluteStart + 1, Feature.AbsoluteEnd + 1, CurrentCoverage.Positional_Values)

                                    End If


                                    If ASCheckBox.Checked Then
                                        If Not Feature.Direction = CurrentCoverage.Strand Then
                                            AS_NormalizedCoverage += Bioinformatics.GetPileUpSumPerLength(Feature.AbsoluteStart + 1, Feature.AbsoluteEnd + 1, CurrentCoverage.Positional_Values) * ScaleFactors(k)
                                            AS_PileupAgregate += Bioinformatics.GetPileUpSum(Feature.AbsoluteStart + 1, Feature.AbsoluteEnd + 1, CurrentCoverage.Positional_Values)
                                        End If
                                    End If

                                End If



                            End If
                        Next i


                        'Save data


                        If ASCheckBox.Checked Then
                            ReportString &= NormalizedCoverage & Chr(9) & PileupAggregate & Chr(9) & AS_NormalizedCoverage & Chr(9) & AS_PileupAgregate & Chr(9)

                        Else
                            ReportString &= NormalizedCoverage & Chr(9) & PileupAggregate & Chr(9)

                        End If



                    Next k

                    ReportTable.Add(ReportString)

                End If 'Feature.Type



            Next Feature





            Dim WriteStream As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.Create)
            Dim Writer As New IO.StreamWriter(WriteStream)
            Dim Line As String = ""

            For Each L As String In ReportTable
                Writer.WriteLine(L)
            Next L

            Writer.Close()
            WriteStream.Close()
            Writer.Dispose()
            WriteStream.Dispose()

            MsgBox("Export finished!")

        End If

    End Sub
End Class