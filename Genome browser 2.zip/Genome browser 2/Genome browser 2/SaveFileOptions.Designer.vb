﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SaveFileOptions
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.AnnotRadioButton = New System.Windows.Forms.RadioButton
        Me.GFFRadioButton = New System.Windows.Forms.RadioButton
        Me.GBRadioButton = New System.Windows.Forms.RadioButton
        Me.FastaOnlyRadioButton = New System.Windows.Forms.RadioButton
        Me.ExitButton = New System.Windows.Forms.Button
        Me.OKButton = New System.Windows.Forms.Button
        Me.ShortAnnotRadioButton = New System.Windows.Forms.RadioButton
        Me.SuspendLayout()
        '
        'AnnotRadioButton
        '
        Me.AnnotRadioButton.AutoSize = True
        Me.AnnotRadioButton.Checked = True
        Me.AnnotRadioButton.Location = New System.Drawing.Point(12, 12)
        Me.AnnotRadioButton.Name = "AnnotRadioButton"
        Me.AnnotRadioButton.Size = New System.Drawing.Size(93, 17)
        Me.AnnotRadioButton.TabIndex = 0
        Me.AnnotRadioButton.TabStop = True
        Me.AnnotRadioButton.Text = ".fasta + .annot"
        Me.AnnotRadioButton.UseVisualStyleBackColor = True
        '
        'GFFRadioButton
        '
        Me.GFFRadioButton.AutoSize = True
        Me.GFFRadioButton.Enabled = False
        Me.GFFRadioButton.Location = New System.Drawing.Point(12, 58)
        Me.GFFRadioButton.Name = "GFFRadioButton"
        Me.GFFRadioButton.Size = New System.Drawing.Size(84, 17)
        Me.GFFRadioButton.TabIndex = 1
        Me.GFFRadioButton.Text = ".fasta + .gff3"
        Me.GFFRadioButton.UseVisualStyleBackColor = True
        '
        'GBRadioButton
        '
        Me.GBRadioButton.AutoSize = True
        Me.GBRadioButton.Location = New System.Drawing.Point(12, 81)
        Me.GBRadioButton.Name = "GBRadioButton"
        Me.GBRadioButton.Size = New System.Drawing.Size(40, 17)
        Me.GBRadioButton.TabIndex = 2
        Me.GBRadioButton.Text = ".gb"
        Me.GBRadioButton.UseVisualStyleBackColor = True
        '
        'FastaOnlyRadioButton
        '
        Me.FastaOnlyRadioButton.AutoSize = True
        Me.FastaOnlyRadioButton.Location = New System.Drawing.Point(12, 104)
        Me.FastaOnlyRadioButton.Name = "FastaOnlyRadioButton"
        Me.FastaOnlyRadioButton.Size = New System.Drawing.Size(73, 17)
        Me.FastaOnlyRadioButton.TabIndex = 3
        Me.FastaOnlyRadioButton.Text = ".fasta only"
        Me.FastaOnlyRadioButton.UseVisualStyleBackColor = True
        '
        'ExitButton
        '
        Me.ExitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ExitButton.Location = New System.Drawing.Point(12, 148)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(75, 23)
        Me.ExitButton.TabIndex = 4
        Me.ExitButton.Text = "Cancel"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(93, 148)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.Size = New System.Drawing.Size(75, 23)
        Me.OKButton.TabIndex = 5
        Me.OKButton.Text = "OK"
        Me.OKButton.UseVisualStyleBackColor = True
        '
        'ShortAnnotRadioButton
        '
        Me.ShortAnnotRadioButton.AutoSize = True
        Me.ShortAnnotRadioButton.Location = New System.Drawing.Point(12, 35)
        Me.ShortAnnotRadioButton.Name = "ShortAnnotRadioButton"
        Me.ShortAnnotRadioButton.Size = New System.Drawing.Size(125, 17)
        Me.ShortAnnotRadioButton.TabIndex = 6
        Me.ShortAnnotRadioButton.Text = ".fasta + .annot (short)"
        Me.ShortAnnotRadioButton.UseVisualStyleBackColor = True
        '
        'SaveFileOptions
        '
        Me.AcceptButton = Me.OKButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.ExitButton
        Me.ClientSize = New System.Drawing.Size(181, 183)
        Me.Controls.Add(Me.ShortAnnotRadioButton)
        Me.Controls.Add(Me.OKButton)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.FastaOnlyRadioButton)
        Me.Controls.Add(Me.GBRadioButton)
        Me.Controls.Add(Me.GFFRadioButton)
        Me.Controls.Add(Me.AnnotRadioButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "SaveFileOptions"
        Me.Text = "Select format"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents AnnotRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents GFFRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents GBRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents FastaOnlyRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    Friend WithEvents OKButton As System.Windows.Forms.Button
    Friend WithEvents ShortAnnotRadioButton As System.Windows.Forms.RadioButton
End Class
