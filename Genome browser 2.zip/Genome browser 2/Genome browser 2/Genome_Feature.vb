﻿Public Class Genome_Feature

#Region "Variables"

    Private strTAG As String = ""
    Private strName As String = ""
    Private strDescription As String = ""
    Private intAbsoluteStart As Integer = 0
    Private intAbsoluteEnd As Integer = 0
    Private shDir As Short = 0
    Private shType As Short = 0
    Private strOrthology As String = ""
    Private strGroup As String = ""

    Private intLayoutOrder As Integer = 0
    Private intProjectionStart As Integer = 0
    Private intProjectionEnd As Integer = 0

    Private bVisible As Boolean = True
    Private bSelected As Boolean = False

    Private strSequence As String = ""
    Private shIdentity As Short

    Private strTranslation As String = ""
    Private bTranslationMode As Boolean = False

    Private bUseReadList As Boolean = False
    Private listReadList As New List(Of ReadItem)

    Private bInvertedView As Boolean

    Private AdditionalInfo As FeatureData = Nothing

    'Direction list
    '0 - None
    '1 - Plus
    '2 - Minus
    '3 - Symmetrical
    '4 - Hairpin plus/minus
    '5 - Hairpin minus/plus

    'Type list
    '0 - Unknown
    '1 - ORF
    '2 - Structural RNA
    '3 - Regulatory sequence/Binding site
    '4 - Non-coding/Antisense RNA
    '5 - Transcription initiation site
    '6 - Transcription termination site
    '7 - Highlighted sequence 'Movable
    '8 - User designed oligo
    '9 - Repeat
    '10 - User feature to store in annotation
    '11 - Like User feature but not movable
    '12 - Operon markup (continuous coding RNAs)


    '//////Additional keys for compatibility
    '99 - Mark for Region/source feature, e.g. whole sequence itself
    '100 - Mark for CDS assembly for GFF compatibility
    '101 - Partial CDS mark for GFF compatibility 
    '102 - Exon mark for GFF compatibility

#End Region

    Public Property TAG() As String
        Get
            TAG = strTAG
        End Get
        Set(ByVal value As String)
            strTAG = value
        End Set
    End Property

    Public Property Name() As String
        Get
            Name = strName
        End Get
        Set(ByVal value As String)
            strName = value
        End Set
    End Property

    Public Property Description() As String
        Get
            Description = strDescription
        End Get
        Set(ByVal value As String)
            strDescription = value
        End Set
    End Property

    Public Property AbsoluteStart() As Integer
        Get
            AbsoluteStart = intAbsoluteStart
        End Get
        Set(ByVal value As Integer)
            intAbsoluteStart = value
        End Set
    End Property

    Public Property AbsoluteEnd() As Integer
        Get
            AbsoluteEnd = intAbsoluteEnd
        End Get
        Set(ByVal value As Integer)
            intAbsoluteEnd = value
        End Set
    End Property

    Public Property Direction() As Short
        Get
            Direction = shDir
        End Get
        Set(ByVal value As Short)
            shDir = value
        End Set
    End Property

    Public Property Type() As Short
        Get
            Type = shType
        End Get
        Set(ByVal value As Short)
            shType = value
        End Set
    End Property

    Public Property Group() As String
        Get
            Group = strGroup
        End Get
        Set(ByVal value As String)
            strGroup = value
        End Set
    End Property

    Public Property ProjectionStart() As Integer
        Get
            ProjectionStart = intProjectionStart
        End Get
        Set(ByVal value As Integer)
            intProjectionStart = value
        End Set
    End Property

    Public Property ProjectionEnd() As Integer
        Get
            ProjectionEnd = intProjectionEnd
        End Get
        Set(ByVal value As Integer)
            intProjectionEnd = value
        End Set
    End Property

    Public Property LayoutOrder() As Integer
        Get
            LayoutOrder = intLayoutOrder
        End Get
        Set(ByVal value As Integer)
            intLayoutOrder = value
        End Set
    End Property

    Public Property Orthology() As String
        Get
            Orthology = strOrthology
        End Get
        Set(ByVal value As String)
            strOrthology = value
        End Set
    End Property

    Public Property Selected() As Boolean
        Get
            Selected = bSelected
        End Get
        Set(ByVal value As Boolean)
            bSelected = value
        End Set
    End Property

    Public Property Sequence() As String
        Get
            Sequence = strSequence
        End Get
        Set(ByVal value As String)
            strSequence = value
        End Set
    End Property

    Public Property Visible() As Boolean
        Get
            Visible = bVisible
        End Get
        Set(ByVal value As Boolean)
            bVisible = value
        End Set
    End Property

    Public Property Identity() As Short
        Get
            Identity = shIdentity
        End Get
        Set(ByVal value As Short)
            shIdentity = value
        End Set
    End Property

    Public Property ReadList() As List(Of ReadItem)
        Get
            ReadList = listReadList
        End Get
        Set(ByVal value As List(Of ReadItem))
            listReadList = value
        End Set
    End Property

    Public Property UseReadList() As Boolean
        Get
            UseReadList = bUseReadList
        End Get
        Set(ByVal value As Boolean)
            bUseReadList = value
        End Set
    End Property

    Public Property InvertedView() As Boolean
        Get
            InvertedView = bInvertedView
        End Get
        Set(ByVal value As Boolean)
            bInvertedView = value
        End Set
    End Property

    Public Property Translation() As String
        Get
            Translation = strTranslation
        End Get
        Set(ByVal value As String)
            strTranslation = value
        End Set
    End Property

    Public Property DisplayTranslation() As Boolean
        Get
            DisplayTranslation = bTranslationMode
        End Get
        Set(ByVal value As Boolean)
            bTranslationMode = value
        End Set
    End Property

    Public Property AdditionalProperties() As FeatureData
        Get
            AdditionalProperties = AdditionalInfo
        End Get
        Set(ByVal value As FeatureData)
            AdditionalInfo = value
        End Set
    End Property

    Public Function GetDescriptionOfType()
        Return GetDescriptionOfType(shType)
    End Function

    Public Shared Function GetDescriptionOfType(ByVal Type As Short)
        Dim Descr As String = ""
        Select Case Type
            Case 1
                Descr = "Coding sequence"
            Case 2
                Descr = "Structural RNA"
            Case 3
                Descr = "Binding site/Regulatory sequence"
            Case 4
                Descr = "Small/Antisense RNA"
            Case 5
                Descr = "Transcription start site"
            Case 6
                Descr = "Transcription terminator"
            Case 7
                Descr = "Highlighted sequence"
            Case 8
                Descr = "User feature"
            Case 9
                Descr = "Repeat"
            Case 10
                Descr = "Annotated user feature"
            Case 11
                Descr = "User non-movable"
            Case 12
                Descr = "Continuous transcript"
            Case Else
                Descr = "Unknown"
        End Select
        Return Descr
    End Function

    Public Shared Function GetTypeFromDescription(ByVal Descr As String)
        Dim CurrentType As Short = 0

        Select Case Descr
            Case "Coding sequence"
                CurrentType = 1
            Case "Structural RNA"
                CurrentType = 2
            Case "Binding site/Regulatory sequence"
                CurrentType = 3
            Case "Small/Antisense RNA"
                CurrentType = 4
            Case "Transcription start site"
                CurrentType = 5
            Case "Transcription terminator"
                CurrentType = 6
            Case "Highlighted sequence"
                CurrentType = 7
            Case "User feature"
                CurrentType = 8
            Case "Repeat"
                CurrentType = 9
            Case "Annotated user feature"
                CurrentType = 10
            Case "User non-movable"
                CurrentType = 11
            Case "Continuous transcript"
                CurrentType = 12
            Case "Unknown"
                CurrentType = 0
            Case Else
                CurrentType = 0

        End Select


        Return CurrentType
    End Function

    Public Shared Function GetListOfTypes(ByVal Max As Integer)
        Dim List As New List(Of String)
        For i = 0 To Max
            List.Add(GetDescriptionOfType(i))
        Next
        Return List
    End Function

    Public Function GetDescriptionOfDirection()
        Return GetDescriptionOfDirection(shDir)
    End Function

    Public Sub SetTranslation(ByVal Translation_Mode As Boolean, Optional ByVal Seq As String = "", Optional ByVal GeneticCode As Short = 1)
        bTranslationMode = Translation_Mode
        Dim CodeTable As DataTable = Bioinformatics.GetTranslationTable(GeneticCode)

        If bTranslationMode Then
            If Not Seq = "" Then
                strTranslation = Bioinformatics.Translate(Seq, CodeTable)
            Else
                bTranslationMode = False
            End If
        Else
            strTranslation = ""
            Seq = ""
        End If

    End Sub

    Public Shared Function GetDescriptionOfDirection(ByVal Dir As Short)
        Dim Descr As String = ""
        Select Case Dir
            Case 0
                Descr = "Unknown"
            Case 1
                Descr = "Plus"
            Case 2
                Descr = "Minus"
            Case 3
                Descr = "Symmetrical"
            Case Else

        End Select
        Return Descr
    End Function

    Public Function GetAdditionalValue(ByVal Header As String)
        Dim Val As String = ""

        If Not IsNothing(AdditionalInfo) Then

            For i = 0 To AdditionalInfo.DataHeaders.Count - 1
                If AdditionalInfo.DataHeaders(i) = Header Then
                    Val = AdditionalInfo.DataValues(i)
                    Exit For
                End If
            Next i

        End If


        Return Val
    End Function

End Class
