﻿Public Class SequenceCoordinate
    Private intAbsoluteStart As Integer = 0
    Private intAbsoluteEnd As Integer = 0
    Private shDir As Short = 0

    Public Property AbsoluteStart() As Integer
        Get
            AbsoluteStart = intAbsoluteStart
        End Get
        Set(ByVal value As Integer)
            intAbsoluteStart = value
        End Set
    End Property

    Public Property AbsoluteEnd() As Integer
        Get
            AbsoluteEnd = intAbsoluteEnd
        End Get
        Set(ByVal value As Integer)
            intAbsoluteEnd = value
        End Set
    End Property

    Public Property Direction() As Short
        Get
            Direction = shDir
        End Get
        Set(ByVal value As Short)
            shDir = value
        End Set
    End Property

    Public Sub New(ByVal StartPos As Integer, ByVal EndPos As Integer, ByVal Dir As Short)
        intAbsoluteStart = StartPos
        intAbsoluteEnd = EndPos
        shDir = Dir

    End Sub

End Class
