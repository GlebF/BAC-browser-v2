﻿Public Class AssemblySeed
    Private sglTm As Single
    Private intAbsoluteStart As Integer = 0
    Private intAbsoluteEnd As Integer = 0
    Private intGC_content As Integer = 0
    Private bHomopolymer As Boolean = False


    Public Property AbsoluteStart() As Integer
        Get
            AbsoluteStart = intAbsoluteStart
        End Get
        Set(ByVal value As Integer)
            intAbsoluteStart = value
        End Set
    End Property

    Public Property AbsoluteEnd() As Integer
        Get
            AbsoluteEnd = intAbsoluteEnd
        End Get
        Set(ByVal value As Integer)
            intAbsoluteEnd = value
        End Set
    End Property

    Public Property Tm() As Single
        Get
            Tm = sglTm
        End Get
        Set(ByVal value As Single)
            sglTm = value
        End Set
    End Property

    Public Property GC_Content() As Integer
        Get
            GC_Content = intGC_content
        End Get
        Set(ByVal value As Integer)
            intGC_content = value
        End Set
    End Property

    Public Property Homopolymer() As Boolean
        Get
            Homopolymer = bHomopolymer
        End Get
        Set(ByVal value As Boolean)
            bHomopolymer = value
        End Set
    End Property

End Class
