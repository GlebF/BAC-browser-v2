﻿Public Class MetaSearch

    Private Sub FindText()
        Dim Query As String = QueryTextBox.Text.ToLower

        ResultDataGridView.Rows.Clear()

        For i = 0 To Master.MasterTabControl.TabPages.Count - 1

            For Each Component As Control In Master.MasterTabControl.TabPages(i).Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component
                    CurrentGenomeViewer.FeaturesGroupDataGridView.Rows.Clear()

                    For Each FeaturesList As FeaturesAssembly In CurrentGenomeViewer.Features_Groups_List
                        For Each Feature As Genome_Feature In FeaturesList.FeaturesList
                            If Feature.TAG.ToLower.Contains(Query) Or Feature.Name.ToLower.Contains(Query) Or Feature.Description.ToLower.Contains(Query) Or Feature.Orthology.ToLower.Contains(Query) Then
                                CurrentGenomeViewer.WriteFeatureRow(Feature, CurrentGenomeViewer.FeaturesGroupDataGridView)

                                ResultDataGridView.Rows.Add(Master.MasterTabControl.TabPages(i).Text, _
                                                            Feature.TAG & "; " & Feature.Name & "; " & Feature.Description, _
                                                            Feature.AbsoluteStart, Feature.AbsoluteEnd)

                            End If
                        Next Feature
                    Next FeaturesList

                    Exit For
                End If
            Next Component

        Next i

    End Sub

    Private Sub FindNucleotide()
        ResultDataGridView.Rows.Clear()
        Dim Query As String = QueryTextBox.Text.ToUpper


        For i = 0 To Master.MasterTabControl.TabPages.Count - 1

            For Each Component As Control In Master.MasterTabControl.TabPages(i).Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component

                    Dim ForCoordList As List(Of CoordHit) = Nothing
                    Dim RevCoordList As List(Of CoordHit) = Nothing

                    ForCoordList = Bioinformatics.UngappedSequenceSearch(CurrentGenomeViewer.Genome_Sequence, Query, 1)
                    RevCoordList = Bioinformatics.UngappedSequenceSearch(CurrentGenomeViewer.Genome_Sequence, Bioinformatics.GetReverseComplement(Query), 1)

                    If ForCoordList.Count > 0 Or RevCoordList.Count > 0 Then


                        For Each PrimerCoord As CoordHit In ForCoordList
                            CurrentGenomeViewer.AddOligo(PrimerCoord.Position, PrimerCoord.Position + Query.Length - 1, "", 1, 7, Query, PrimerCoord.Identity)
                            ResultDataGridView.Rows.Add(Master.MasterTabControl.TabPages(i).Text, "", PrimerCoord.Position, PrimerCoord.Position + Query.Length - 1)

                        Next PrimerCoord

                        For Each PrimerCoord As CoordHit In RevCoordList
                            CurrentGenomeViewer.AddOligo(PrimerCoord.Position, PrimerCoord.Position + Query.Length - 1, "", 2, 7, Query, PrimerCoord.Identity)
                            ResultDataGridView.Rows.Add(Master.MasterTabControl.TabPages(i).Text, "", PrimerCoord.Position, PrimerCoord.Position + Query.Length - 1)

                        Next PrimerCoord


                    End If




                    Exit For
                End If
            Next Component

        Next i




    End Sub

    Private Sub FindPeptide()
        ResultDataGridView.Rows.Clear()
        Dim Query As String = QueryTextBox.Text.ToUpper

        For i = 0 To Master.MasterTabControl.TabPages.Count - 1

            For Each Component As Control In Master.MasterTabControl.TabPages(i).Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component

                    If CurrentGenomeViewer.Protein_Refresh_Required = True Then
                        CurrentGenomeViewer.Protein_Translation_List = Bioinformatics.MakeProteinList(CurrentGenomeViewer.Features_Groups_List(0).FeaturesList, CurrentGenomeViewer.Genome_Sequence, Bioinformatics.GetTranslationTable(CurrentGenomeViewer.Control_Box.TransComboBox.Text.Split("-")(0)), Master.AminoacidMWList, SystemProgressBarBox)
                        CurrentGenomeViewer.Protein_Refresh_Required = False
                    End If



                    For Each Prot As ProtPeptide In CurrentGenomeViewer.Protein_Translation_List

                        Dim TargetPept As Genome_Feature = Bioinformatics.LookProteinForPeptide(Prot, Query)

                        If Not IsNothing(TargetPept) Then
                            CurrentGenomeViewer.AddOligo(TargetPept.AbsoluteStart, TargetPept.AbsoluteEnd, , TargetPept.Direction)
                            ResultDataGridView.Rows.Add(Master.MasterTabControl.TabPages(i).Text, "", TargetPept.AbsoluteStart, TargetPept.AbsoluteEnd)
                        End If

                    Next Prot


                    Exit For
                End If
            Next Component


        Next i

    End Sub

    Private Sub SearchButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchButton.Click
        If QueryTextBox.Text = "" Then

            MsgBox("Enter query for search!")

        Else


            If TextRadioButton.Checked Then
                FindText()
            ElseIf NucRadioButton.Checked Then
                FindNucleotide()
            ElseIf ProtRadioButton.Checked Then
                FindPeptide()
            End If
        End If
    End Sub

    Private Sub ResultDataGridView_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ResultDataGridView.MouseDoubleClick
        For i = 0 To Master.MasterTabControl.TabPages.Count - 1
            If Master.MasterTabControl.TabPages(i).Text = ResultDataGridView.CurrentRow.Cells(0).Value Then
                Master.MasterTabControl.SelectTab(i)

                For Each Component As Control In Master.MasterTabControl.TabPages(i).Controls
                    If Component.GetType.Name = "Genome_Viewer" Then
                        Dim CurrentGenomeViewer As Genome_Viewer = Component
                        CurrentGenomeViewer.RangeStart = ResultDataGridView.CurrentRow.Cells(2).Value
                        CurrentGenomeViewer.RangeEnd = ResultDataGridView.CurrentRow.Cells(3).Value
                        If Math.Abs(CurrentGenomeViewer.RangeStart - CurrentGenomeViewer.RangeEnd) < 10 Then
                            CurrentGenomeViewer.RangeStart -= 5
                            CurrentGenomeViewer.RangeEnd += 5
                        End If
                        CurrentGenomeViewer.DisplayFeatures()
                    End If
                Next Component

                Exit For
            End If

        Next i

    End Sub

End Class