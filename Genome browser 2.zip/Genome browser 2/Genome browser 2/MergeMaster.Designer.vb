﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MergeMaster
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MergeTargetComboBox = New System.Windows.Forms.ComboBox
        Me.MergeButton = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'MergeTargetComboBox
        '
        Me.MergeTargetComboBox.FormattingEnabled = True
        Me.MergeTargetComboBox.Location = New System.Drawing.Point(12, 12)
        Me.MergeTargetComboBox.Name = "MergeTargetComboBox"
        Me.MergeTargetComboBox.Size = New System.Drawing.Size(179, 21)
        Me.MergeTargetComboBox.TabIndex = 0
        '
        'MergeButton
        '
        Me.MergeButton.Location = New System.Drawing.Point(197, 10)
        Me.MergeButton.Name = "MergeButton"
        Me.MergeButton.Size = New System.Drawing.Size(75, 23)
        Me.MergeButton.TabIndex = 1
        Me.MergeButton.Text = "Merge"
        Me.MergeButton.UseVisualStyleBackColor = True
        '
        'MergeMaster
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 44)
        Me.Controls.Add(Me.MergeButton)
        Me.Controls.Add(Me.MergeTargetComboBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "MergeMaster"
        Me.Text = "Merge into:"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MergeTargetComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents MergeButton As System.Windows.Forms.Button
End Class
