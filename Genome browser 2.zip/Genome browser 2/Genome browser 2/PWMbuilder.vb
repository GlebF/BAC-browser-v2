﻿Public Class PWMbuilder
    Public CurrentPWM As PWM
    Public MotiffLOGO As New SequenceLOGO


    Public Sub SavePWM(ByVal TargetPWM As PWM)
        If Master.SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim FS As New IO.FileStream(Master.SaveFileDialog.FileName & ".txt", IO.FileMode.Create)
            Dim Writer As New IO.StreamWriter(FS)

            Dim CurrentLine As String = ""

            CurrentLine = "A" & Chr(9)
            For Each Position As PWM_cell In TargetPWM.PWM_Table
                CurrentLine &= Position.A_Weight & Chr(9)
            Next
            CurrentLine = CurrentLine.Remove(CurrentLine.Length - 1, 1)
            Writer.WriteLine(CurrentLine)

            CurrentLine = "T" & Chr(9)
            For Each Position As PWM_cell In TargetPWM.PWM_Table
                CurrentLine &= Position.T_Weight & Chr(9)
            Next
            CurrentLine = CurrentLine.Remove(CurrentLine.Length - 1, 1)
            Writer.WriteLine(CurrentLine)

            CurrentLine = "G" & Chr(9)
            For Each Position As PWM_cell In TargetPWM.PWM_Table
                CurrentLine &= Position.G_Weight & Chr(9)
            Next
            CurrentLine = CurrentLine.Remove(CurrentLine.Length - 1, 1)
            Writer.WriteLine(CurrentLine)

            CurrentLine = "C" & Chr(9)
            For Each Position As PWM_cell In TargetPWM.PWM_Table
                CurrentLine &= Position.C_Weight & Chr(9)
            Next
            CurrentLine = CurrentLine.Remove(CurrentLine.Length - 1, 1)
            Writer.WriteLine(CurrentLine)

            Writer.Close()
            FS.Close()
            Writer.Dispose()
            FS.Dispose()

        End If
    End Sub

    Public Sub DrawPWM(ByVal SelectedPWM As PWM)
        PWMDataGridView.Columns.Clear()
        For i = 0 To SelectedPWM.PWM_Table.Count - 1
            PWMDataGridView.Columns.Add(i + 1, i + 1)
            PWMDataGridView.Columns(i).Width = 50
        Next


        PWMDataGridView.Rows.Add(4)
        PWMDataGridView.Rows(0).HeaderCell.Value = "A"
        PWMDataGridView.Rows(1).HeaderCell.Value = "T"
        PWMDataGridView.Rows(2).HeaderCell.Value = "G"
        PWMDataGridView.Rows(3).HeaderCell.Value = "C"

        For i = 0 To SelectedPWM.PWM_Table.Count - 1
            PWMDataGridView.Rows(0).Cells(i).Value = SelectedPWM.PWM_Table(i).A_Weight
            PWMDataGridView.Rows(1).Cells(i).Value = SelectedPWM.PWM_Table(i).T_Weight
            PWMDataGridView.Rows(2).Cells(i).Value = SelectedPWM.PWM_Table(i).G_Weight
            PWMDataGridView.Rows(3).Cells(i).Value = SelectedPWM.PWM_Table(i).C_Weight

        Next
    End Sub

    Private Sub GoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoButton.Click
        SeqTextBox.Text = SeqTextBox.Text.ToUpper()
        Dim Sequences As New List(Of Char())
        Dim SeqArr As String() = SeqTextBox.Text.Split(vbNewLine)
        Dim CurrentSeq As String = ""

        For Each Seq As String In SeqArr
            CurrentSeq = Seq
            CurrentSeq = CurrentSeq.Replace(Chr(10), "")
            CurrentSeq = CurrentSeq.Replace(Chr(13), "")
            If Not CurrentSeq = "" And Not CurrentSeq.StartsWith(">") Then
                Sequences.Add(CurrentSeq.ToCharArray)
            End If
        Next

       

        Dim NewPWM As New PWM

        If PWMLogLikelyhoodButton.Checked Then



            If GCButton.Checked Then
                NewPWM = Bioinformatics.CalculatePWM(Sequences, GCTextBox.Text, SizeCorrectionCheckBox.Checked)
            ElseIf AutoPButton.Checked Then

                Dim A_C As Integer = 0
                Dim T_C As Integer = 0
                Dim G_C As Integer = 0
                Dim C_C As Integer = 0
                Dim Total As Integer = 0
                For i = 0 To Sequences.Count - 1
                    For j = 0 To Sequences(0).Length - 1
                        Select Case Sequences(i)(j)
                            Case "A"
                                A_C += 1
                            Case "T"
                                T_C += 1
                            Case "G"
                                G_C += 1
                            Case "C"
                                C_C += 1
                        End Select
                    Next
                Next
                Total = A_C + T_C + G_C + C_C



                Dim A_P As Single = A_C / Total
                Dim T_P As Single = T_C / Total
                Dim G_P As Single = G_C / Total
                Dim C_P As Single = C_C / Total

                TextBox_AP.Text = A_P
                TextBox_TP.Text = T_P
                TextBox_GP.Text = G_P
                TextBox_CP.Text = C_P

                NewPWM = Bioinformatics.CalculatePWM(Sequences, A_P, T_P, G_P, C_P, SizeCorrectionCheckBox.Checked)


            ElseIf ManualPButton.Checked Then
                Dim A_P As Single = TextBox_AP.Text
                Dim T_P As Single = TextBox_TP.Text
                Dim G_P As Single = TextBox_GP.Text
                Dim C_P As Single = TextBox_CP.Text

                If A_P + T_P + G_P + C_P = 1 Then
                    NewPWM = Bioinformatics.CalculatePWM(Sequences, A_P, T_P, G_P, C_P, SizeCorrectionCheckBox.Checked)
                Else
                    TextBox_AP.Text = 0.25
                    TextBox_TP.Text = 0.25
                    TextBox_GP.Text = 0.25
                    TextBox_CP.Text = 0.25
                    A_P = 0.25
                    T_P = 0.25
                    G_P = 0.25
                    C_P = 0.25
                    NewPWM = Bioinformatics.CalculatePWM(Sequences, A_P, T_P, G_P, C_P, SizeCorrectionCheckBox.Checked)
                    MsgBox("Nucleotide frequencies sum must be 1 (100%)!")
                End If

            End If

        End If


        If PWMShannonButton.Checked Then
            NewPWM = Bioinformatics.CalculateInformationContent(Sequences, SizeCorrectionCheckBox.Checked)
        End If


        If LogoEntropyButton.Checked Then
            MotiffLOGO.Sequences_List = Sequences
            MotiffLOGO.CalculateInformationContent(SizeCorrectionCheckBox.Checked)
        ElseIf LogoPWMButton.Checked Then
            MotiffLOGO.Motiff_PWM = NewPWM
            MotiffLOGO.ConvertPWMToLOGO(True)
        End If

        MotiffLOGO.InverseX = InvertXCheckBox.Checked
        MotiffLOGO.Invalidate()


        DrawPWM(NewPWM)

        CurrentPWM = NewPWM

        MaxTextBox.Text = NewPWM.GetMaxWeight
        MinTextBox.Text = NewPWM.GetMinWeight

    End Sub

   
    Private Sub PWMbuilder_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MotiffLOGO.Location = New Point(0, 0)
        MotiffLOGO.Dock = DockStyle.Fill
        LOGOPanel.Controls.Add(MotiffLOGO)
        CurrentPWM = Nothing

    End Sub

    Private Sub SaveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        SavePWM(CurrentPWM)
    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        SeqTextBox.Text = ""

    End Sub

    Private Sub SaveLogoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveLogoButton.Click
        If SaveImageDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim FileName As String = SaveImageDialog.FileName
            Dim OutputResolutionFactor As Integer = 10

            Dim ExportImage As Image = New Bitmap(MotiffLOGO.Width * OutputResolutionFactor, MotiffLOGO.Height * OutputResolutionFactor, System.Drawing.Imaging.PixelFormat.Format24bppRgb)
            Using outputG As Graphics = Graphics.FromImage(ExportImage)
                outputG.Clear(Color.White)
                MotiffLOGO.DrawLogo(outputG, OutputResolutionFactor)
            End Using

            Select Case SaveImageDialog.FilterIndex
                Case 1
                    If Not FileName.EndsWith(".bmp") Then
                        FileName = String.Concat(FileName, ".bmp")
                    End If
                    ExportImage.Save(FileName, Imaging.ImageFormat.Bmp)
                Case 2
                    If Not FileName.EndsWith(".jpg") Then
                        FileName = String.Concat(FileName, ".jpg")
                    End If
                    ExportImage.Save(FileName, Imaging.ImageFormat.Jpeg)
                Case 3
                    If Not FileName.EndsWith(".png") Then
                        FileName = String.Concat(FileName, ".png")
                    End If
                    ExportImage.Save(FileName, Imaging.ImageFormat.Png)
                Case 4
                    If Not FileName.EndsWith(".tif") Then
                        FileName = String.Concat(FileName, ".tif")
                    End If
                    ExportImage.Save(FileName, Imaging.ImageFormat.Tiff)
            End Select

        End If
    End Sub

    Private Sub PWMbuilder_SizeChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.SizeChanged
        'If Me.Width < 720 Then
        'Dim NewSize As New Size(720, Me.Height)
        'Me.Size = NewSize
        'End If

        'If Me.Height < 510 Then
        'Dim NewSize As New Size(Me.Width, 510)
        'Me.Size = NewSize
        'End If

    End Sub
End Class