﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SAM_convert_dialog
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.OKButton = New System.Windows.Forms.Button
        Me.ExitButton = New System.Windows.Forms.Button
        Me.PlusShiftTextBox = New System.Windows.Forms.TextBox
        Me.MinusShiftTextBox = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.FirstNTCovCheckBox = New System.Windows.Forms.CheckBox
        Me.SuspendLayout()
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(96, 109)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.Size = New System.Drawing.Size(75, 23)
        Me.OKButton.TabIndex = 3
        Me.OKButton.Text = "OK"
        Me.OKButton.UseVisualStyleBackColor = True
        '
        'ExitButton
        '
        Me.ExitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ExitButton.Location = New System.Drawing.Point(15, 109)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(75, 23)
        Me.ExitButton.TabIndex = 4
        Me.ExitButton.Text = "Cancel"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'PlusShiftTextBox
        '
        Me.PlusShiftTextBox.Location = New System.Drawing.Point(115, 12)
        Me.PlusShiftTextBox.Name = "PlusShiftTextBox"
        Me.PlusShiftTextBox.Size = New System.Drawing.Size(50, 20)
        Me.PlusShiftTextBox.TabIndex = 5
        Me.PlusShiftTextBox.Text = "0"
        '
        'MinusShiftTextBox
        '
        Me.MinusShiftTextBox.Location = New System.Drawing.Point(115, 38)
        Me.MinusShiftTextBox.Name = "MinusShiftTextBox"
        Me.MinusShiftTextBox.Size = New System.Drawing.Size(50, 20)
        Me.MinusShiftTextBox.TabIndex = 6
        Me.MinusShiftTextBox.Text = "0"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Plus strand shift:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(17, 41)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Minus strand shift:"
        '
        'FirstNTCovCheckBox
        '
        Me.FirstNTCovCheckBox.AutoSize = True
        Me.FirstNTCovCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.FirstNTCovCheckBox.Location = New System.Drawing.Point(32, 64)
        Me.FirstNTCovCheckBox.Name = "FirstNTCovCheckBox"
        Me.FirstNTCovCheckBox.Size = New System.Drawing.Size(97, 30)
        Me.FirstNTCovCheckBox.TabIndex = 9
        Me.FirstNTCovCheckBox.Text = "First nucleotide" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "coverage only"
        Me.FirstNTCovCheckBox.UseVisualStyleBackColor = True
        '
        'SAM_convert_dialog
        '
        Me.AcceptButton = Me.OKButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.ExitButton
        Me.ClientSize = New System.Drawing.Size(185, 148)
        Me.Controls.Add(Me.FirstNTCovCheckBox)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.MinusShiftTextBox)
        Me.Controls.Add(Me.PlusShiftTextBox)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.OKButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "SAM_convert_dialog"
        Me.Text = "Import SAM"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OKButton As System.Windows.Forms.Button
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    Friend WithEvents PlusShiftTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MinusShiftTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents FirstNTCovCheckBox As System.Windows.Forms.CheckBox
End Class
