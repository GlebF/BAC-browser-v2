﻿Public Class SeqRetrieval
    Public Dialog_Res As Boolean = False
    Public GetORF As Boolean = True
    Public Strand As Boolean = True
    Public DownSeq As Integer = 0
    Public UpSeq As Integer = 0
    Public UpLower As Boolean
    Public ORFLower As Boolean
    Public DownLower As Boolean

    Private Sub EscButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EscButton.Click
        Dialog_Res = False
        Me.Close()
    End Sub

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        Dialog_Res = True

        If ForRadioButton.Checked Then
            Strand = True
        End If

        If RevRadioButton.Checked Then
            Strand = False
        End If

        If DownstreamCheckBox.Checked Then
            DownSeq = DownTextBox.Text
        Else
            DownSeq = 0
        End If

        If UpstreamCheckBox.Checked Then
            UpSeq = UpTextBox.Text
        Else
            UpSeq = 0
        End If


        GetORF = ORFCheckBox.Checked


        UpLower = UpLowerCheckBox.Checked
        DownLower = DownLowerCheckBox.Checked
        ORFLower = ORFLowerCheckBox.Checked


        Me.Close()
    End Sub

End Class