﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SeqExporter
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SeqExporter))
        Me.FormatComboBox = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.UpstreamCheckBox = New System.Windows.Forms.CheckBox
        Me.FeatureCheckBox = New System.Windows.Forms.CheckBox
        Me.DownstreamCheckBox = New System.Windows.Forms.CheckBox
        Me.UpstreamTextBox = New System.Windows.Forms.TextBox
        Me.DownstreamTextBox = New System.Windows.Forms.TextBox
        Me.BannedTextBox = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.CodingCheckBox = New System.Windows.Forms.CheckBox
        Me.OperonsCheckBox = New System.Windows.Forms.CheckBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.TailTextBox = New System.Windows.Forms.TextBox
        Me.HeadTextBox = New System.Windows.Forms.TextBox
        Me.TailCheckBox = New System.Windows.Forms.CheckBox
        Me.HeadCheckBox = New System.Windows.Forms.CheckBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.UserCheckBox = New System.Windows.Forms.CheckBox
        Me.TSSCheckBox = New System.Windows.Forms.CheckBox
        Me.SiteCheckBox = New System.Windows.Forms.CheckBox
        Me.StructRNAsCheckBox = New System.Windows.Forms.CheckBox
        Me.ExportButton = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.SourceComboBox = New System.Windows.Forms.ComboBox
        Me.SelectTextBox = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'FormatComboBox
        '
        Me.FormatComboBox.FormattingEnabled = True
        Me.FormatComboBox.Items.AddRange(New Object() {"FASTA", "Table", "ID/Seq", "DrOligo"})
        Me.FormatComboBox.Location = New System.Drawing.Point(198, 12)
        Me.FormatComboBox.Name = "FormatComboBox"
        Me.FormatComboBox.Size = New System.Drawing.Size(121, 21)
        Me.FormatComboBox.TabIndex = 0
        Me.FormatComboBox.Text = "FASTA"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(150, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Format:"
        '
        'UpstreamCheckBox
        '
        Me.UpstreamCheckBox.AutoSize = True
        Me.UpstreamCheckBox.Location = New System.Drawing.Point(62, 21)
        Me.UpstreamCheckBox.Name = "UpstreamCheckBox"
        Me.UpstreamCheckBox.Size = New System.Drawing.Size(71, 17)
        Me.UpstreamCheckBox.TabIndex = 4
        Me.UpstreamCheckBox.Text = "Upstream"
        Me.UpstreamCheckBox.UseVisualStyleBackColor = True
        '
        'FeatureCheckBox
        '
        Me.FeatureCheckBox.AutoSize = True
        Me.FeatureCheckBox.Checked = True
        Me.FeatureCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.FeatureCheckBox.Location = New System.Drawing.Point(62, 47)
        Me.FeatureCheckBox.Name = "FeatureCheckBox"
        Me.FeatureCheckBox.Size = New System.Drawing.Size(62, 17)
        Me.FeatureCheckBox.TabIndex = 5
        Me.FeatureCheckBox.Text = "Feature"
        Me.FeatureCheckBox.UseVisualStyleBackColor = True
        '
        'DownstreamCheckBox
        '
        Me.DownstreamCheckBox.AutoSize = True
        Me.DownstreamCheckBox.Location = New System.Drawing.Point(62, 73)
        Me.DownstreamCheckBox.Name = "DownstreamCheckBox"
        Me.DownstreamCheckBox.Size = New System.Drawing.Size(85, 17)
        Me.DownstreamCheckBox.TabIndex = 6
        Me.DownstreamCheckBox.Text = "Downstream"
        Me.DownstreamCheckBox.UseVisualStyleBackColor = True
        '
        'UpstreamTextBox
        '
        Me.UpstreamTextBox.Location = New System.Drawing.Point(6, 19)
        Me.UpstreamTextBox.Name = "UpstreamTextBox"
        Me.UpstreamTextBox.Size = New System.Drawing.Size(50, 20)
        Me.UpstreamTextBox.TabIndex = 7
        Me.UpstreamTextBox.Text = "25"
        '
        'DownstreamTextBox
        '
        Me.DownstreamTextBox.Location = New System.Drawing.Point(6, 71)
        Me.DownstreamTextBox.Name = "DownstreamTextBox"
        Me.DownstreamTextBox.Size = New System.Drawing.Size(50, 20)
        Me.DownstreamTextBox.TabIndex = 9
        Me.DownstreamTextBox.Text = "25"
        '
        'BannedTextBox
        '
        Me.BannedTextBox.Location = New System.Drawing.Point(198, 39)
        Me.BannedTextBox.Name = "BannedTextBox"
        Me.BannedTextBox.Size = New System.Drawing.Size(121, 20)
        Me.BannedTextBox.TabIndex = 10
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(176, 13)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Exclude by name OR description (;):"
        '
        'CodingCheckBox
        '
        Me.CodingCheckBox.AutoSize = True
        Me.CodingCheckBox.Checked = True
        Me.CodingCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CodingCheckBox.Location = New System.Drawing.Point(6, 21)
        Me.CodingCheckBox.Name = "CodingCheckBox"
        Me.CodingCheckBox.Size = New System.Drawing.Size(100, 17)
        Me.CodingCheckBox.TabIndex = 12
        Me.CodingCheckBox.Text = "Coding features"
        Me.CodingCheckBox.UseVisualStyleBackColor = True
        '
        'OperonsCheckBox
        '
        Me.OperonsCheckBox.AutoSize = True
        Me.OperonsCheckBox.Location = New System.Drawing.Point(6, 44)
        Me.OperonsCheckBox.Name = "OperonsCheckBox"
        Me.OperonsCheckBox.Size = New System.Drawing.Size(66, 17)
        Me.OperonsCheckBox.TabIndex = 13
        Me.OperonsCheckBox.Text = "Operons"
        Me.OperonsCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TailTextBox)
        Me.GroupBox1.Controls.Add(Me.HeadTextBox)
        Me.GroupBox1.Controls.Add(Me.TailCheckBox)
        Me.GroupBox1.Controls.Add(Me.HeadCheckBox)
        Me.GroupBox1.Controls.Add(Me.UpstreamTextBox)
        Me.GroupBox1.Controls.Add(Me.UpstreamCheckBox)
        Me.GroupBox1.Controls.Add(Me.FeatureCheckBox)
        Me.GroupBox1.Controls.Add(Me.DownstreamCheckBox)
        Me.GroupBox1.Controls.Add(Me.DownstreamTextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(34, 118)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(158, 160)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Topology"
        '
        'TailTextBox
        '
        Me.TailTextBox.Location = New System.Drawing.Point(6, 123)
        Me.TailTextBox.Name = "TailTextBox"
        Me.TailTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TailTextBox.TabIndex = 13
        Me.TailTextBox.Text = "50"
        '
        'HeadTextBox
        '
        Me.HeadTextBox.Location = New System.Drawing.Point(6, 97)
        Me.HeadTextBox.Name = "HeadTextBox"
        Me.HeadTextBox.Size = New System.Drawing.Size(50, 20)
        Me.HeadTextBox.TabIndex = 12
        Me.HeadTextBox.Text = "50"
        '
        'TailCheckBox
        '
        Me.TailCheckBox.AutoSize = True
        Me.TailCheckBox.Location = New System.Drawing.Point(62, 125)
        Me.TailCheckBox.Name = "TailCheckBox"
        Me.TailCheckBox.Size = New System.Drawing.Size(71, 17)
        Me.TailCheckBox.TabIndex = 11
        Me.TailCheckBox.Text = "Tail (only)"
        Me.TailCheckBox.UseVisualStyleBackColor = True
        '
        'HeadCheckBox
        '
        Me.HeadCheckBox.AutoSize = True
        Me.HeadCheckBox.Location = New System.Drawing.Point(62, 99)
        Me.HeadCheckBox.Name = "HeadCheckBox"
        Me.HeadCheckBox.Size = New System.Drawing.Size(80, 17)
        Me.HeadCheckBox.TabIndex = 10
        Me.HeadCheckBox.Text = "Head (only)"
        Me.HeadCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.UserCheckBox)
        Me.GroupBox2.Controls.Add(Me.TSSCheckBox)
        Me.GroupBox2.Controls.Add(Me.SiteCheckBox)
        Me.GroupBox2.Controls.Add(Me.StructRNAsCheckBox)
        Me.GroupBox2.Controls.Add(Me.CodingCheckBox)
        Me.GroupBox2.Controls.Add(Me.OperonsCheckBox)
        Me.GroupBox2.Location = New System.Drawing.Point(198, 118)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(121, 160)
        Me.GroupBox2.TabIndex = 15
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Features"
        '
        'UserCheckBox
        '
        Me.UserCheckBox.AutoSize = True
        Me.UserCheckBox.Checked = True
        Me.UserCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.UserCheckBox.Location = New System.Drawing.Point(6, 136)
        Me.UserCheckBox.Name = "UserCheckBox"
        Me.UserCheckBox.Size = New System.Drawing.Size(89, 17)
        Me.UserCheckBox.TabIndex = 18
        Me.UserCheckBox.Text = "User features"
        Me.UserCheckBox.UseVisualStyleBackColor = True
        '
        'TSSCheckBox
        '
        Me.TSSCheckBox.AutoSize = True
        Me.TSSCheckBox.Location = New System.Drawing.Point(6, 113)
        Me.TSSCheckBox.Name = "TSSCheckBox"
        Me.TSSCheckBox.Size = New System.Drawing.Size(54, 17)
        Me.TSSCheckBox.TabIndex = 17
        Me.TSSCheckBox.Text = "TSS's"
        Me.TSSCheckBox.UseVisualStyleBackColor = True
        '
        'SiteCheckBox
        '
        Me.SiteCheckBox.AutoSize = True
        Me.SiteCheckBox.Location = New System.Drawing.Point(6, 90)
        Me.SiteCheckBox.Name = "SiteCheckBox"
        Me.SiteCheckBox.Size = New System.Drawing.Size(85, 17)
        Me.SiteCheckBox.TabIndex = 16
        Me.SiteCheckBox.Text = "Binding sites"
        Me.SiteCheckBox.UseVisualStyleBackColor = True
        '
        'StructRNAsCheckBox
        '
        Me.StructRNAsCheckBox.AutoSize = True
        Me.StructRNAsCheckBox.Checked = True
        Me.StructRNAsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.StructRNAsCheckBox.Location = New System.Drawing.Point(6, 67)
        Me.StructRNAsCheckBox.Name = "StructRNAsCheckBox"
        Me.StructRNAsCheckBox.Size = New System.Drawing.Size(102, 17)
        Me.StructRNAsCheckBox.TabIndex = 15
        Me.StructRNAsCheckBox.Text = "Structural RNAs"
        Me.StructRNAsCheckBox.UseVisualStyleBackColor = True
        '
        'ExportButton
        '
        Me.ExportButton.Location = New System.Drawing.Point(244, 284)
        Me.ExportButton.Name = "ExportButton"
        Me.ExportButton.Size = New System.Drawing.Size(75, 23)
        Me.ExportButton.TabIndex = 16
        Me.ExportButton.Text = "Export"
        Me.ExportButton.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(95, 94)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 13)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Source of features:"
        '
        'SourceComboBox
        '
        Me.SourceComboBox.FormattingEnabled = True
        Me.SourceComboBox.Items.AddRange(New Object() {"Main Features", "User Features"})
        Me.SourceComboBox.Location = New System.Drawing.Point(198, 91)
        Me.SourceComboBox.Name = "SourceComboBox"
        Me.SourceComboBox.Size = New System.Drawing.Size(121, 21)
        Me.SourceComboBox.TabIndex = 19
        Me.SourceComboBox.Text = "Main Features"
        '
        'SelectTextBox
        '
        Me.SelectTextBox.Location = New System.Drawing.Point(198, 65)
        Me.SelectTextBox.Name = "SelectTextBox"
        Me.SelectTextBox.Size = New System.Drawing.Size(121, 20)
        Me.SelectTextBox.TabIndex = 20
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(19, 68)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(173, 13)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Include by name OR description (;):"
        '
        'SeqExporter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(331, 312)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.SelectTextBox)
        Me.Controls.Add(Me.SourceComboBox)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ExportButton)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.BannedTextBox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.FormatComboBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "SeqExporter"
        Me.Text = "Sequence Exporter"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents FormatComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents UpstreamCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents FeatureCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents DownstreamCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents UpstreamTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DownstreamTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BannedTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents CodingCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents OperonsCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents ExportButton As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents SourceComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents StructRNAsCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents SiteCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents TailTextBox As System.Windows.Forms.TextBox
    Friend WithEvents HeadTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TailCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents HeadCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents TSSCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents UserCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents SelectTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
