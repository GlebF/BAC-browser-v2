﻿Public Class SELEX_Word
    Private strSeq As String = ""
    Private intCount As Integer = 0

    Public Property Sequence() As String
        Get
            Sequence = strSeq
        End Get
        Set(ByVal value As String)
            strSeq = value
        End Set
    End Property

    Public Property Count() As Integer
        Get
            Count = intCount
        End Get
        Set(ByVal value As Integer)
            intCount = value
        End Set
    End Property

End Class
