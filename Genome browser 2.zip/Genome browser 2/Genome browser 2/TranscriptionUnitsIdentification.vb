﻿Public Class TranscriptionUnitsIdentification
    Public MyViewer As Genome_Viewer
    Public SearchCount As Integer = 0


    Private Sub GoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoButton.Click

        'Try
        StatusLabelMinus.Text = "Ready"
        StatusLabelMinus.Refresh()

        Dim Annotation As FeaturesAssembly = DataIO.GetCurrentGroup(MyViewer.Features_Groups_List, MyViewer.MainFeaturesListName)


        Dim Steps_Plus As New List(Of CoverageStep)
        Dim Steps_Minus As New List(Of CoverageStep)


        Dim TotalValues As New List(Of Integer)
        Dim ScaleFactors As New List(Of Single)
        Dim LocalSum As Integer = 0

        If Not NoNormRadioButton.Checked Then

            For Each Group As String In AnalysisHolderListBox.Items
                LocalSum = 0

                For i = 0 To MyViewer.Positional_Values_Collection.Count - 1
                    If MyViewer.Positional_Values_Collection(i).Group = Group Then

                        If AllLibRadioButton.Checked Then
                            LocalSum += Bioinformatics.GetAggregatedCoverage(MyViewer.Positional_Values_Collection(i).Positional_Values)

                        End If

                        If CodingRadioButton.Checked Then
                            LocalSum += Bioinformatics.GetCodingCoverage_SingleStrand(MyViewer.Positional_Values_Collection(i).Positional_Values, Annotation.FeaturesList)

                        End If

                    End If

                Next i

                TotalValues.Add(LocalSum)

            Next Group


            Dim MaxCov As Integer = 0
            For Each Value As Integer In TotalValues
                If Value > MaxCov Then
                    MaxCov = Value
                End If
            Next


            For i = 0 To TotalValues.Count - 1
                ScaleFactors.Add(MaxCov / TotalValues(i))
            Next


        End If

      

        Dim GroupCounter As Integer = 0

        Dim CoverageArrayPlus As New List(Of List(Of Integer))
        Dim CoverageArrayMinus As New List(Of List(Of Integer))


        For Each Group As String In AnalysisHolderListBox.Items

            StatusLabelPlus.Text = "Preparing data..."
            StatusLabelPlus.Refresh()

            Dim PlusCount As Integer = 0
            Dim MinusCount As Integer = 0

            For i = 0 To MyViewer.Positional_Values_Collection.Count - 1
                If MyViewer.Positional_Values_Collection(i).Group = Group Then
                    Select Case MyViewer.Positional_Values_Collection(i).Strand
                        Case 1
                            PlusCount += 1
                        Case 2
                            MinusCount += 1
                    End Select
                End If
            Next i

            Dim CovListArrayPlus(PlusCount - 1) As List(Of Integer)
            Dim CovListArrayMinus(MinusCount - 1) As List(Of Integer)

            PlusCount = 0
            MinusCount = 0

            For i = 0 To MyViewer.Positional_Values_Collection.Count - 1
                If MyViewer.Positional_Values_Collection(i).Group = Group Then
                    Select Case MyViewer.Positional_Values_Collection(i).Strand
                        Case 1
                            CovListArrayPlus(PlusCount) = MyViewer.Positional_Values_Collection(i).Positional_Values
                            PlusCount += 1
                        Case 2
                            'We reverse minus list
                            CovListArrayMinus(MinusCount) = Bioinformatics.ReverseIntList(MyViewer.Positional_Values_Collection(i).Positional_Values)
                            MinusCount += 1
                    End Select
                End If
            Next i

            StatusLabelPlus.Text = "Integrating coverage..."
            StatusLabelPlus.Refresh()


            Dim IntegratedCoveragePlus As List(Of Integer) = Nothing
            Dim IntegratedCoverageMinus As List(Of Integer) = Nothing

            If Not NoNormRadioButton.Checked Then
                IntegratedCoveragePlus = Bioinformatics.ScaleLibrary_Int(Bioinformatics.SumIntLists(CovListArrayPlus), ScaleFactors(GroupCounter))
                IntegratedCoverageMinus = Bioinformatics.ScaleLibrary_Int(Bioinformatics.SumIntLists(CovListArrayMinus), ScaleFactors(GroupCounter))
            Else
                IntegratedCoveragePlus = Bioinformatics.SumIntLists(CovListArrayPlus)
                IntegratedCoverageMinus = Bioinformatics.SumIntLists(CovListArrayMinus)
            End If

            CoverageArrayPlus.Add(IntegratedCoveragePlus)
            CoverageArrayMinus.Add(IntegratedCoverageMinus)

            Dim BlockFiltrationMethod As Short = 0
            If SDIntervalFiltrationRadioButton.Checked Then
                BlockFiltrationMethod = 1
            End If

            Steps_Plus.AddRange(Bioinformatics.AnalyzeCoverage(IntegratedCoveragePlus, _
                                                               SmoothingTextBox.Text, _
                                                               TSSBackgroundTextBox.Text, _
                                                               TSSIdentificationWindowTextBox.Text, _
                                                               TSSFiltrationWindowTextBox.Text, _
                                                               TSSAsymmetryCheckBox.Checked, _
                                                               TSSDropLengthTextBox.Text, _
                                                               TSSDropTresholdTextBox.Text, _
                                                               TermBackgroundTextBox.Text, _
                                                               TermIdentificationWindowTextBox.Text, _
                                                               TermFiltrationWindowTextBox.Text, _
                                                               RemoveBackgroundCheckBox.Checked, _
                                                               BackgroundWindowTextBox.Text, _
                                                               BackgroundCoverageTextBox.Text, _
                                                               TermCDSCorrectionCheckBox.Checked, _
                                                               True, _
                                                               Annotation, _
                                                               TermCDSCorrectionTextBox.Text, _
                                                               BlockFiltrationMethod, _
                                                               SDFiltrationTextBox.Text, _
                                                               StatusLabelPlus))

            Steps_Minus.AddRange(Bioinformatics.AnalyzeCoverage(IntegratedCoverageMinus, _
                                                               SmoothingTextBox.Text, _
                                                               TSSBackgroundTextBox.Text, _
                                                               TSSIdentificationWindowTextBox.Text, _
                                                               TSSFiltrationWindowTextBox.Text, _
                                                               TSSAsymmetryCheckBox.Checked, _
                                                               TSSDropLengthTextBox.Text, _
                                                               TSSDropTresholdTextBox.Text, _
                                                               TermBackgroundTextBox.Text, _
                                                               TermIdentificationWindowTextBox.Text, _
                                                               TermFiltrationWindowTextBox.Text, _
                                                               RemoveBackgroundCheckBox.Checked, _
                                                               BackgroundWindowTextBox.Text, _
                                                               BackgroundCoverageTextBox.Text, _
                                                               TermCDSCorrectionCheckBox.Checked, _
                                                               False, _
                                                               Annotation, _
                                                               TermCDSCorrectionTextBox.Text, _
                                                               BlockFiltrationMethod, _
                                                               SDFiltrationTextBox.Text, _
                                                               StatusLabelMinus))



            GroupCounter += 1
        Next Group

        Bioinformatics.SortCoverageSteps(Steps_Plus)
        Bioinformatics.SortCoverageSteps(Steps_Minus)


        'Add cross-groups TSS filtration!!!

        Dim F_Steps_Plus As New List(Of CoverageStep)
        Dim F_Steps_Minus As New List(Of CoverageStep)
        F_Steps_Plus = Bioinformatics.RemoveStepDuplicates(Steps_Plus, GroupFiltrationTextBox.Text)
        F_Steps_Minus = Bioinformatics.RemoveStepDuplicates(Steps_Minus, GroupFiltrationTextBox.Text)



        If BlocksCheckBox.Checked Then
            GroupCounter = 0
            Dim ChartColor As Color = Color.Red

            Dim BlocksGroups As New List(Of QuantBlockHolder)


            For Each Group As String In AnalysisHolderListBox.Items
                Dim NewHolder As QuantBlockHolder = Bioinformatics.MakeTranscriptionBlocksFromSteps(F_Steps_Plus, F_Steps_Minus, CoverageArrayPlus(GroupCounter), CoverageArrayMinus(GroupCounter), Group & "-Transcription blocks search-" & SearchCount) ', 10 ^ NormTextBox.Text 'RemoveLowIntervalsCheckBox.Checked, NormTextBox.Text)
                NewHolder.SetColor(ChartColor)
                BlocksGroups.Add(NewHolder)
                GroupCounter += 1
            Next Group


            Dim MinimalCoverage As Single = MinimalIntervalCoverageTextBox.Text

            If RemoveLowIntervalsCheckBox.Checked Then
                'Now remove blocks that are zero in ALL groups
                'Here lists of blocks are identical in all groups except of their value
                Dim IsNotZero As Boolean = False
                Dim BlockIndex As Integer = 0
                'Dim InitBlocksCount As Integer = BlocksGroups(0).BlocksList.Count

                Do

                    If BlockIndex > BlocksGroups(0).BlocksList.Count - 1 Then
                        Exit Do
                    End If

                    IsNotZero = False
                    For GroupIndex = 0 To BlocksGroups.Count - 1
                        If BlocksGroups(GroupIndex).BlocksList(BlockIndex).Aux_Value > MinimalCoverage Then
                            IsNotZero = True
                        End If
                    Next GroupIndex

                    If Not IsNotZero Then
                        'Remove the block from all groups

                        For GroupIndex = 0 To BlocksGroups.Count - 1
                            BlocksGroups(GroupIndex).BlocksList.RemoveAt(BlockIndex)
                        Next

                        BlockIndex -= 1
                    End If

                    BlockIndex += 1
                Loop

                'StatusLabelPlus.Text &= "Zero blocks removed :" & InitBlocksCount - BlocksGroups(0).BlocksList.Count

            End If


            Dim ScaleLogC As Integer = NormTextBox.Text
            Dim MinValue As Single = ScaleLogC


            If RemoveLowIntervalsCheckBox.Checked Then
                For Each Holder As QuantBlockHolder In BlocksGroups
                    For Each Block As QuantitationBlock In Holder.BlocksList
                        If Block.Value < MinValue And Block.Aux_Value > MinimalCoverage Then
                            MinValue = Block.Value
                        End If
                    Next
                Next
            Else
                For Each Holder As QuantBlockHolder In BlocksGroups
                    For Each Block As QuantitationBlock In Holder.BlocksList
                        If Block.Value < MinValue And Not Block.Value = 0 Then
                            MinValue = Block.Value
                        End If
                    Next
                Next
            End If



            If MinValue < ScaleLogC Then 'This will be less than zero in log view
                Dim ScaleFactor As Single = ScaleLogC / MinValue

                For Each Holder As QuantBlockHolder In BlocksGroups
                    For Each Block As QuantitationBlock In Holder.BlocksList
                        Block.Value *= ScaleFactor
                    Next
                Next

            End If

            'Draw blocks
            For Each Holder As QuantBlockHolder In BlocksGroups
                MyViewer.Integrated_Values.Add(Holder)

                MyViewer.Control_Box.SkewOnRadioButton.Checked = True

                MyViewer.IntervalsListView.Items.Add(Holder.Name)
                MyViewer.IntervalsListView.Items(MyViewer.IntervalsListView.Items.Count - 1).Checked = True
                MyViewer.IntervalsListView.Items(MyViewer.IntervalsListView.Items.Count - 1).ForeColor = ChartColor

            Next


        End If



        If TSSandTTCheckBox.Checked Then
            MyViewer.Features_Groups_List.Add(Bioinformatics.MakeTranscriptionSitesFromSteps(F_Steps_Plus, F_Steps_Minus, "Promoters & terminators " & SearchCount, MyViewer.Genome_Sequence.Length))
            MyViewer.RefreshAssemblyList()
        End If


        MyViewer.DisplayFeatures()




        'Catch ex As Exception
        'MsgBox(ex.Message)
        'End Try


        SearchCount += 1
    End Sub

    Private Sub SDIntervalFiltrationRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SDIntervalFiltrationRadioButton.CheckedChanged
        SDFiltrationTextBox.Enabled = SDIntervalFiltrationRadioButton.Checked

    End Sub

    Private Sub TSSAsymmetryCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TSSAsymmetryCheckBox.CheckedChanged
        TSSDropLengthTextBox.Enabled = TSSAsymmetryCheckBox.Checked
        TSSDropTresholdTextBox.Enabled = TSSAsymmetryCheckBox.Checked

    End Sub

    Private Sub TermCDSCorrectionCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TermCDSCorrectionCheckBox.CheckedChanged
        TermCDSCorrectionTextBox.Enabled = TermCDSCorrectionCheckBox.Checked

    End Sub

  
    Private Sub AllAddButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AllAddButton.Click
        For Each Item As String In AllHoldersListBox.Items
            AnalysisHolderListBox.Items.Add(Item)

        Next

        AllHoldersListBox.Items.Clear()

    End Sub

    Private Sub AllRemoveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AllRemoveButton.Click
        For Each Item As String In AnalysisHolderListBox.Items
            AllHoldersListBox.Items.Add(Item)

        Next

        AnalysisHolderListBox.Items.Clear()
    End Sub

    Private Sub AddItemButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddItemButton.Click
        If Not IsNothing(AllHoldersListBox.SelectedItem) Then
            AnalysisHolderListBox.Items.Add(AllHoldersListBox.SelectedItem)
            AllHoldersListBox.Items.Remove(AllHoldersListBox.SelectedItem)
        End If
    End Sub

    Private Sub RemoveItemButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveItemButton.Click
        If Not IsNothing(AnalysisHolderListBox.SelectedItem) Then
            AllHoldersListBox.Items.Add(AnalysisHolderListBox.SelectedItem)
            AnalysisHolderListBox.Items.Remove(AnalysisHolderListBox.SelectedItem)
        End If
    End Sub

    
    Private Sub RemoveBackgroundCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveBackgroundCheckBox.CheckedChanged
        BackgroundCoverageTextBox.Enabled = RemoveBackgroundCheckBox.Checked
        BackgroundWindowTextBox.Enabled = RemoveBackgroundCheckBox.Checked

    End Sub

    Private Sub RemoveLowIntervalsCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveLowIntervalsCheckBox.CheckedChanged
        MinimalIntervalCoverageTextBox.Enabled = RemoveLowIntervalsCheckBox.Checked

    End Sub

   
    Private Sub RefreshGroupsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshGroupsButton.Click
        AnalysisHolderListBox.Items.Clear()
        AllHoldersListBox.Items.Clear()

        Dim GroupList As New List(Of String)
        Dim Found As Boolean = False
        For Each Holder As PositionalValuesHolder In MyViewer.Positional_Values_Collection
            Found = False

            For Each Group As String In GroupList
                If Group = Holder.Group Then
                    Found = True
                    Exit For
                End If
            Next

            If Not Found Then
                GroupList.Add(Holder.Group)
            End If


        Next



        For Each Group As String In GroupList
            AllHoldersListBox.Items.Add(Group)
        Next
    End Sub

    Private Sub TranscriptionUnitsIdentification_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SDFiltrationTextBox.Text = (0.5).ToString
        TSSDropTresholdTextBox.Text = (0.7).ToString


    End Sub
End Class