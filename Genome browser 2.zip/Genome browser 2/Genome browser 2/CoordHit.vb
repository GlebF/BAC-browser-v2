﻿Public Class CoordHit
    Private intCoord As Integer
    Private sglHit As Single
    Private bUsed As Boolean = False
    Private bRC As Boolean = False
    Private strLabel As String = ""

    Public Property Position() As Integer
        Get
            Position = intCoord
        End Get
        Set(ByVal value As Integer)
            intCoord = value
        End Set
    End Property

    Public Property Identity() As Integer
        Get
            Identity = sglHit
        End Get
        Set(ByVal value As Integer)
            sglHit = value
        End Set
    End Property

    Public Property Used() As Boolean
        Get
            Used = bUsed
        End Get
        Set(ByVal value As Boolean)
            bUsed = value
        End Set
    End Property

    Public Property RC() As Boolean
        Get
            RC = bRC
        End Get
        Set(ByVal value As Boolean)
            bRC = value
        End Set
    End Property

    Public Property Label() As String
        Get
            Label = strLabel
        End Get
        Set(ByVal value As String)
            strLabel = value
        End Set
    End Property

    Public Sub New(ByVal Pos As Integer, ByVal Hit As Single, Optional ByVal RC_Tag As Boolean = False)
        intCoord = Pos
        sglHit = Hit
        bRC = RC_Tag
    End Sub

End Class
