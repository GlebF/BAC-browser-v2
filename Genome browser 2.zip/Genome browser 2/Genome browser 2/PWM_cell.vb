﻿Public Class PWM_cell
    Private sglA_Weight As Single
    Private sglT_Weight As Single
    Private sglG_Weight As Single
    Private sglC_Weight As Single

    Public Property A_Weight() As Single
        Get
            A_Weight = sglA_Weight
        End Get
        Set(ByVal value As Single)
            sglA_Weight = value
        End Set
    End Property

    Public Property T_Weight() As Single
        Get
            T_Weight = sglT_Weight
        End Get
        Set(ByVal value As Single)
            sglT_Weight = value
        End Set
    End Property

    Public Property G_Weight() As Single
        Get
            G_Weight = sglG_Weight
        End Get
        Set(ByVal value As Single)
            sglG_Weight = value
        End Set
    End Property

    Public Property C_Weight() As Single
        Get
            C_Weight = sglC_Weight
        End Get
        Set(ByVal value As Single)
            sglC_Weight = value
        End Set
    End Property

End Class
