﻿Public Class QuantBlockHolder
    Private cntBlocksList As New List(Of QuantitationBlock)
    Private strName As String = ""

    Public Property BlocksList() As List(Of QuantitationBlock)
        Get
            BlocksList = cntBlocksList
        End Get
        Set(ByVal value As List(Of QuantitationBlock))
            cntBlocksList = value
        End Set
    End Property

    Public Property Name() As String
        Get
            Name = strName
        End Get
        Set(ByVal value As String)
            strName = value
        End Set
    End Property

    Public Sub SetVisibility(ByVal Visible As Boolean)
        For Each Block As QuantitationBlock In cntBlocksList
            Block.Visible = Visible
        Next
    End Sub

    Public Sub SetColor(ByVal NewColor As Color)
        For Each Block As QuantitationBlock In cntBlocksList
            Block.Draw_Color = NewColor
        Next
    End Sub

End Class
