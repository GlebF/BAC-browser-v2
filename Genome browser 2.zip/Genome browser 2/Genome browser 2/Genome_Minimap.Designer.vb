﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Genome_Minimap
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MoveButton = New System.Windows.Forms.Button
        Me.RangeEndButton = New System.Windows.Forms.Button
        Me.RangeStartButton = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'MoveButton
        '
        Me.MoveButton.BackColor = System.Drawing.Color.Cyan
        Me.MoveButton.Location = New System.Drawing.Point(3, 28)
        Me.MoveButton.Name = "MoveButton"
        Me.MoveButton.Size = New System.Drawing.Size(30, 10)
        Me.MoveButton.TabIndex = 15
        Me.MoveButton.UseVisualStyleBackColor = False
        '
        'RangeEndButton
        '
        Me.RangeEndButton.BackColor = System.Drawing.Color.Red
        Me.RangeEndButton.Location = New System.Drawing.Point(23, 3)
        Me.RangeEndButton.Name = "RangeEndButton"
        Me.RangeEndButton.Size = New System.Drawing.Size(10, 20)
        Me.RangeEndButton.TabIndex = 13
        Me.RangeEndButton.UseVisualStyleBackColor = False
        '
        'RangeStartButton
        '
        Me.RangeStartButton.BackColor = System.Drawing.Color.Red
        Me.RangeStartButton.Location = New System.Drawing.Point(3, 3)
        Me.RangeStartButton.Name = "RangeStartButton"
        Me.RangeStartButton.Size = New System.Drawing.Size(10, 20)
        Me.RangeStartButton.TabIndex = 12
        Me.RangeStartButton.UseVisualStyleBackColor = False
        '
        'Genome_Minimap
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.MoveButton)
        Me.Controls.Add(Me.RangeEndButton)
        Me.Controls.Add(Me.RangeStartButton)
        Me.Name = "Genome_Minimap"
        Me.Size = New System.Drawing.Size(400, 50)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MoveButton As System.Windows.Forms.Button
    Friend WithEvents RangeEndButton As System.Windows.Forms.Button
    Friend WithEvents RangeStartButton As System.Windows.Forms.Button

End Class
