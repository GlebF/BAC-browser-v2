﻿Public Class ListInputBox



    Private Sub ItemsListBox_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ItemsListBox.DoubleClick
        If Not IsNothing(ItemsListBox.SelectedItem) Then
            DialogResult = Windows.Forms.DialogResult.OK
            Me.Close()
        End If
    End Sub

End Class