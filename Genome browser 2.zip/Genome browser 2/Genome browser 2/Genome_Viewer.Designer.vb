﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Genome_Viewer
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Genome_Viewer))
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.PrimarySplitContainer = New System.Windows.Forms.SplitContainer
        Me.SecondarySplitContainer = New System.Windows.Forms.SplitContainer
        Me.GraphicsSplitContainer = New System.Windows.Forms.SplitContainer
        Me.DrawPanel = New System.Windows.Forms.Panel
        Me.DrawPanelMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.SequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VisibleRangeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FeatureSequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SequenceRetrievalMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SelectedRegionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PlusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MinusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator
        Me.FindPrimersForVisibleRangeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PCRToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FindPrimersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.PlusStrandThermodynamicsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MinusStrandThermodynamicsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FindProbesForArrayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CenterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TopologyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ProtMapToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DatabaseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddToAnnotationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddOligoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteOligoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TranslatePanel = New System.Windows.Forms.Panel
        Me.TranslationContextMenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ExportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FastaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SynonymousTripletToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ChangeAminoacidToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GraphPanel = New System.Windows.Forms.Panel
        Me.GraphPanelMenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.FindBlockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator21 = New System.Windows.Forms.ToolStripSeparator
        Me.SplitBlockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MergeBlocksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteBlockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SequencePanel = New System.Windows.Forms.Panel
        Me.SequenceContextMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.GetMarkedSequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.IdentifySiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.InsertSequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.InsertPromoterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ForwardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReverseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditSequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteSequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LigateSequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CutPasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CutRemoveSequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SelectForRestrictionPositionAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SelectForRestrictionPositionBToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DesselectRestrictionSitesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CopySequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CutSequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PasteSequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator25 = New System.Windows.Forms.ToolStripSeparator
        Me.CopyRegionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CutRegionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FlipRegionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PasteRegionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SendSeqMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PrimerFinderMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SecondaryStructureFinderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.InternalHomologyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AssemblyDesignerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RepeatPlotToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.NewMarkerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SingleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PairedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MinimapPanel = New System.Windows.Forms.Panel
        Me.EditorToolStrip = New System.Windows.Forms.ToolStrip
        Me.GoToSeqButton = New System.Windows.Forms.ToolStripButton
        Me.MaxOutButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripLabel10 = New System.Windows.Forms.ToolStripLabel
        Me.SimpleMarkerButton = New System.Windows.Forms.ToolStripButton
        Me.SinglePairedButton = New System.Windows.Forms.ToolStripButton
        Me.ClearMarkersButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator
        Me.CurrentMarkerLabel = New System.Windows.Forms.ToolStripLabel
        Me.GetSequenceButton = New System.Windows.Forms.ToolStripButton
        Me.CopyDataButton = New System.Windows.Forms.ToolStripButton
        Me.CutToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.PasteDataButton = New System.Windows.Forms.ToolStripButton
        Me.FlipToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.InsertSequenceButton = New System.Windows.Forms.ToolStripButton
        Me.ReplaceSequenceButton = New System.Windows.Forms.ToolStripButton
        Me.DeleteSequenceButton = New System.Windows.Forms.ToolStripButton
        Me.InsertLigationButton = New System.Windows.Forms.ToolStripButton
        Me.ReplaceLigationButton = New System.Windows.Forms.ToolStripButton
        Me.DeleteRestrictionButton = New System.Windows.Forms.ToolStripButton
        Me.InsertPromoterButton = New System.Windows.Forms.ToolStripSplitButton
        Me.PromoterForwardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PromoterReverseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewerToolStrip = New System.Windows.Forms.ToolStrip
        Me.ZoomInButton = New System.Windows.Forms.ToolStripButton
        Me.ZoomOutButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.LeftBorderStripButton = New System.Windows.Forms.ToolStripButton
        Me.MoveLeftButton = New System.Windows.Forms.ToolStripButton
        Me.JumpBackButton = New System.Windows.Forms.ToolStripButton
        Me.JumpForButton = New System.Windows.Forms.ToolStripButton
        Me.MoveRightButton = New System.Windows.Forms.ToolStripButton
        Me.RightBorderStripButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripLabel4 = New System.Windows.Forms.ToolStripLabel
        Me.StartTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripLabel5 = New System.Windows.Forms.ToolStripLabel
        Me.EndTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.GoButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripLabel6 = New System.Windows.Forms.ToolStripLabel
        Me.RangeTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripLabel7 = New System.Windows.Forms.ToolStripLabel
        Me.SearchOptionsDropDownButton = New System.Windows.Forms.ToolStripDropDownButton
        Me.QueryTypeBox = New System.Windows.Forms.ToolStripComboBox
        Me.SearchSequenceTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.AlignmentTypeComboBox = New System.Windows.Forms.ToolStripComboBox
        Me.ToolStripLabel8 = New System.Windows.Forms.ToolStripLabel
        Me.IdentityPercentTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripLabel9 = New System.Windows.Forms.ToolStripLabel
        Me.OligoNameTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.SearchButton = New System.Windows.Forms.ToolStripButton
        Me.FeaturesTabControl = New System.Windows.Forms.TabControl
        Me.Features = New System.Windows.Forms.TabPage
        Me.FeaturesGroupDataGridView = New System.Windows.Forms.DataGridView
        Me.F_TAG = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.F_Name = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.F_Descr = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.F_Start = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.F_End = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.F_Dir = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.F_Type = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.F_Ort = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.F_Read = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Group_ID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataContextMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CenterViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GetSequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator
        Me.AddToLargeScaleViewerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddToVirtual2DEFViewerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator17 = New System.Windows.Forms.ToolStripSeparator
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FeaturesGroupsListBox = New System.Windows.Forms.ListView
        Me.AnnotationToolStrip = New System.Windows.Forms.ToolStrip
        Me.AllFeaturesButton = New System.Windows.Forms.ToolStripButton
        Me.RenameAsmButton = New System.Windows.Forms.ToolStripButton
        Me.ImportSplitButton = New System.Windows.Forms.ToolStripSplitButton
        Me.AnnotationFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TabseparatedFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaveFeaturesButton = New System.Windows.Forms.ToolStripButton
        Me.MergeListsButton = New System.Windows.Forms.ToolStripButton
        Me.DeleteAllButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator18 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripLabel11 = New System.Windows.Forms.ToolStripLabel
        Me.QueryTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripLabel12 = New System.Windows.Forms.ToolStripLabel
        Me.FieldComboBox = New System.Windows.Forms.ToolStripComboBox
        Me.ToolStripLabel14 = New System.Windows.Forms.ToolStripLabel
        Me.SearchGroupComboBox = New System.Windows.Forms.ToolStripComboBox
        Me.SearchFeaturesButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripLabel13 = New System.Windows.Forms.ToolStripLabel
        Me.CountButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator
        Me.DelFButton = New System.Windows.Forms.ToolStripButton
        Me.AddFButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator15 = New System.Windows.Forms.ToolStripSeparator
        Me.DisplayToTopologyToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator23 = New System.Windows.Forms.ToolStripSeparator
        Me.EraseTableButton = New System.Windows.Forms.ToolStripButton
        Me.Values = New System.Windows.Forms.TabPage
        Me.IntervalsDataGridView = New System.Windows.Forms.DataGridView
        Me.IntervalID_Col = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.IntervalStart_Col = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.IntervalEnd_Col = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.IntervalDir_Col = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.IntervalValue_Col = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.HolderName_Col = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.IntervalsListView = New System.Windows.Forms.ListView
        Me.IntervalsMenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.RenameIntervalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator16 = New System.Windows.Forms.ToolStripSeparator
        Me.ColorIntervalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.QuantitationToolStrip = New System.Windows.Forms.ToolStrip
        Me.ViewIntervalsButton = New System.Windows.Forms.ToolStripButton
        Me.BlocksCountButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator20 = New System.Windows.Forms.ToolStripSeparator
        Me.ClearIntegratedToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator19 = New System.Windows.Forms.ToolStripSeparator
        Me.AddValuesButton = New System.Windows.Forms.ToolStripButton
        Me.DelValsToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.ToggleDisplayModeButton = New System.Windows.Forms.ToolStripSplitButton
        Me.LinearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LogarithmToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.QuantStyleSplitButton = New System.Windows.Forms.ToolStripSplitButton
        Me.FrameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FillToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MultValuesButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator
        Me.SaveBlocksButton = New System.Windows.Forms.ToolStripButton
        Me.BlocksDifexpressionButton = New System.Windows.Forms.ToolStripButton
        Me.ScanSlipperingToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.ScanSameIntervalToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.IntervalMarkTableButton = New System.Windows.Forms.ToolStripButton
        Me.PositionalValues = New System.Windows.Forms.TabPage
        Me.PositionalValuesDataGridView = New System.Windows.Forms.DataGridView
        Me.ChartVisible = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.ChartName = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ChartStrand = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.ChartColor = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ChartScale = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.Holder_Group_Col = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.NewLaneCol = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.PositionalValuesToolStrip = New System.Windows.Forms.ToolStrip
        Me.DeleteAllPosValuesButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator
        Me.PositionalButton = New System.Windows.Forms.ToolStripButton
        Me.DeleteCurrentPosValButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator
        Me.NormalizationTypeButton = New System.Windows.Forms.ToolStripSplitButton
        Me.AllChartsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.IndividualToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AllDataStyleButton = New System.Windows.Forms.ToolStripSplitButton
        Me.LinearPileupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LogarithmPileupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AllVisibleButton = New System.Windows.Forms.ToolStripSplitButton
        Me.SelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.UnselectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSplitButton1 = New System.Windows.Forms.ToolStripSplitButton
        Me.LineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator22 = New System.Windows.Forms.ToolStripSeparator
        Me.SmoothToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.SavePileupButton = New System.Windows.Forms.ToolStripButton
        Me.AssemblePileupButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator24 = New System.Windows.Forms.ToolStripSeparator
        Me.ShiftCovLeftToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.ShiftCovRightToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.ScrollTimer = New System.Windows.Forms.Timer(Me.components)
        Me.PrimarySplitContainer.Panel2.SuspendLayout()
        Me.PrimarySplitContainer.SuspendLayout()
        Me.SecondarySplitContainer.Panel1.SuspendLayout()
        Me.SecondarySplitContainer.Panel2.SuspendLayout()
        Me.SecondarySplitContainer.SuspendLayout()
        Me.GraphicsSplitContainer.Panel1.SuspendLayout()
        Me.GraphicsSplitContainer.SuspendLayout()
        Me.DrawPanelMenu.SuspendLayout()
        Me.TranslationContextMenuStrip.SuspendLayout()
        Me.GraphPanelMenuStrip.SuspendLayout()
        Me.SequenceContextMenu.SuspendLayout()
        Me.EditorToolStrip.SuspendLayout()
        Me.ViewerToolStrip.SuspendLayout()
        Me.FeaturesTabControl.SuspendLayout()
        Me.Features.SuspendLayout()
        CType(Me.FeaturesGroupDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DataContextMenu.SuspendLayout()
        Me.AnnotationToolStrip.SuspendLayout()
        Me.Values.SuspendLayout()
        CType(Me.IntervalsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.IntervalsMenuStrip.SuspendLayout()
        Me.QuantitationToolStrip.SuspendLayout()
        Me.PositionalValues.SuspendLayout()
        CType(Me.PositionalValuesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PositionalValuesToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'PrimarySplitContainer
        '
        Me.PrimarySplitContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PrimarySplitContainer.Location = New System.Drawing.Point(0, 0)
        Me.PrimarySplitContainer.Name = "PrimarySplitContainer"
        '
        'PrimarySplitContainer.Panel1
        '
        Me.PrimarySplitContainer.Panel1.AutoScroll = True
        '
        'PrimarySplitContainer.Panel2
        '
        Me.PrimarySplitContainer.Panel2.Controls.Add(Me.SecondarySplitContainer)
        Me.PrimarySplitContainer.Size = New System.Drawing.Size(1346, 637)
        Me.PrimarySplitContainer.SplitterDistance = 204
        Me.PrimarySplitContainer.TabIndex = 0
        '
        'SecondarySplitContainer
        '
        Me.SecondarySplitContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SecondarySplitContainer.Location = New System.Drawing.Point(0, 0)
        Me.SecondarySplitContainer.Name = "SecondarySplitContainer"
        Me.SecondarySplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SecondarySplitContainer.Panel1
        '
        Me.SecondarySplitContainer.Panel1.AutoScroll = True
        Me.SecondarySplitContainer.Panel1.Controls.Add(Me.GraphicsSplitContainer)
        Me.SecondarySplitContainer.Panel1.Controls.Add(Me.EditorToolStrip)
        Me.SecondarySplitContainer.Panel1.Controls.Add(Me.ViewerToolStrip)
        '
        'SecondarySplitContainer.Panel2
        '
        Me.SecondarySplitContainer.Panel2.Controls.Add(Me.FeaturesTabControl)
        Me.SecondarySplitContainer.Size = New System.Drawing.Size(1138, 637)
        Me.SecondarySplitContainer.SplitterDistance = 458
        Me.SecondarySplitContainer.TabIndex = 0
        '
        'GraphicsSplitContainer
        '
        Me.GraphicsSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GraphicsSplitContainer.Location = New System.Drawing.Point(0, 50)
        Me.GraphicsSplitContainer.Name = "GraphicsSplitContainer"
        Me.GraphicsSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'GraphicsSplitContainer.Panel1
        '
        Me.GraphicsSplitContainer.Panel1.Controls.Add(Me.DrawPanel)
        Me.GraphicsSplitContainer.Panel1.Controls.Add(Me.TranslatePanel)
        Me.GraphicsSplitContainer.Panel1.Controls.Add(Me.GraphPanel)
        Me.GraphicsSplitContainer.Panel1.Controls.Add(Me.SequencePanel)
        Me.GraphicsSplitContainer.Panel1.Controls.Add(Me.MinimapPanel)
        '
        'GraphicsSplitContainer.Panel2
        '
        Me.GraphicsSplitContainer.Panel2.AutoScroll = True
        Me.GraphicsSplitContainer.Panel2Collapsed = True
        Me.GraphicsSplitContainer.Size = New System.Drawing.Size(1138, 408)
        Me.GraphicsSplitContainer.SplitterDistance = 325
        Me.GraphicsSplitContainer.TabIndex = 11
        '
        'DrawPanel
        '
        Me.DrawPanel.BackColor = System.Drawing.Color.White
        Me.DrawPanel.ContextMenuStrip = Me.DrawPanelMenu
        Me.DrawPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DrawPanel.Location = New System.Drawing.Point(0, 160)
        Me.DrawPanel.Name = "DrawPanel"
        Me.DrawPanel.Size = New System.Drawing.Size(1138, 148)
        Me.DrawPanel.TabIndex = 8
        '
        'DrawPanelMenu
        '
        Me.DrawPanelMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SequenceToolStripMenuItem, Me.PCRToolStripMenuItem, Me.ViewToolStripMenuItem, Me.AddToAnnotationToolStripMenuItem, Me.AddOligoToolStripMenuItem, Me.DeleteOligoToolStripMenuItem})
        Me.DrawPanelMenu.Name = "DrawPanelMenu"
        Me.DrawPanelMenu.Size = New System.Drawing.Size(194, 136)
        '
        'SequenceToolStripMenuItem
        '
        Me.SequenceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VisibleRangeToolStripMenuItem, Me.FeatureSequenceToolStripMenuItem, Me.SequenceRetrievalMasterToolStripMenuItem, Me.SelectedRegionToolStripMenuItem, Me.ToolStripSeparator9, Me.FindPrimersForVisibleRangeToolStripMenuItem})
        Me.SequenceToolStripMenuItem.Name = "SequenceToolStripMenuItem"
        Me.SequenceToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.SequenceToolStripMenuItem.Text = "Sequence"
        '
        'VisibleRangeToolStripMenuItem
        '
        Me.VisibleRangeToolStripMenuItem.Name = "VisibleRangeToolStripMenuItem"
        Me.VisibleRangeToolStripMenuItem.Size = New System.Drawing.Size(227, 22)
        Me.VisibleRangeToolStripMenuItem.Text = "Visible range"
        '
        'FeatureSequenceToolStripMenuItem
        '
        Me.FeatureSequenceToolStripMenuItem.Name = "FeatureSequenceToolStripMenuItem"
        Me.FeatureSequenceToolStripMenuItem.Size = New System.Drawing.Size(227, 22)
        Me.FeatureSequenceToolStripMenuItem.Text = "Feature sequence"
        '
        'SequenceRetrievalMasterToolStripMenuItem
        '
        Me.SequenceRetrievalMasterToolStripMenuItem.Name = "SequenceRetrievalMasterToolStripMenuItem"
        Me.SequenceRetrievalMasterToolStripMenuItem.Size = New System.Drawing.Size(227, 22)
        Me.SequenceRetrievalMasterToolStripMenuItem.Text = "Sequence retrieval master"
        '
        'SelectedRegionToolStripMenuItem
        '
        Me.SelectedRegionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PlusToolStripMenuItem, Me.MinusToolStripMenuItem})
        Me.SelectedRegionToolStripMenuItem.Name = "SelectedRegionToolStripMenuItem"
        Me.SelectedRegionToolStripMenuItem.Size = New System.Drawing.Size(227, 22)
        Me.SelectedRegionToolStripMenuItem.Text = "Selected region"
        '
        'PlusToolStripMenuItem
        '
        Me.PlusToolStripMenuItem.Name = "PlusToolStripMenuItem"
        Me.PlusToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.PlusToolStripMenuItem.Text = "Plus"
        '
        'MinusToolStripMenuItem
        '
        Me.MinusToolStripMenuItem.Name = "MinusToolStripMenuItem"
        Me.MinusToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.MinusToolStripMenuItem.Text = "Minus"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(224, 6)
        '
        'FindPrimersForVisibleRangeToolStripMenuItem
        '
        Me.FindPrimersForVisibleRangeToolStripMenuItem.Name = "FindPrimersForVisibleRangeToolStripMenuItem"
        Me.FindPrimersForVisibleRangeToolStripMenuItem.Size = New System.Drawing.Size(227, 22)
        Me.FindPrimersForVisibleRangeToolStripMenuItem.Text = "Find primers for visible range"
        '
        'PCRToolStripMenuItem
        '
        Me.PCRToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FindPrimersToolStripMenuItem, Me.ToolStripSeparator2, Me.PlusStrandThermodynamicsToolStripMenuItem, Me.MinusStrandThermodynamicsToolStripMenuItem, Me.FindProbesForArrayToolStripMenuItem})
        Me.PCRToolStripMenuItem.Name = "PCRToolStripMenuItem"
        Me.PCRToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.PCRToolStripMenuItem.Text = "PCR/Thermodynamics"
        '
        'FindPrimersToolStripMenuItem
        '
        Me.FindPrimersToolStripMenuItem.Name = "FindPrimersToolStripMenuItem"
        Me.FindPrimersToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.FindPrimersToolStripMenuItem.Text = "Find primers"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(233, 6)
        '
        'PlusStrandThermodynamicsToolStripMenuItem
        '
        Me.PlusStrandThermodynamicsToolStripMenuItem.Name = "PlusStrandThermodynamicsToolStripMenuItem"
        Me.PlusStrandThermodynamicsToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.PlusStrandThermodynamicsToolStripMenuItem.Text = "Plus strand thermodynamics"
        '
        'MinusStrandThermodynamicsToolStripMenuItem
        '
        Me.MinusStrandThermodynamicsToolStripMenuItem.Name = "MinusStrandThermodynamicsToolStripMenuItem"
        Me.MinusStrandThermodynamicsToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.MinusStrandThermodynamicsToolStripMenuItem.Text = "Minus strand thermodynamics"
        '
        'FindProbesForArrayToolStripMenuItem
        '
        Me.FindProbesForArrayToolStripMenuItem.Name = "FindProbesForArrayToolStripMenuItem"
        Me.FindProbesForArrayToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
        Me.FindProbesForArrayToolStripMenuItem.Text = "Find probes for array"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CenterToolStripMenuItem, Me.TopologyToolStripMenuItem, Me.ProtMapToolStripMenuItem, Me.DatabaseToolStripMenuItem})
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'CenterToolStripMenuItem
        '
        Me.CenterToolStripMenuItem.Name = "CenterToolStripMenuItem"
        Me.CenterToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.CenterToolStripMenuItem.Text = "Center feature"
        '
        'TopologyToolStripMenuItem
        '
        Me.TopologyToolStripMenuItem.Name = "TopologyToolStripMenuItem"
        Me.TopologyToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.TopologyToolStripMenuItem.Text = "CIrcular map"
        '
        'ProtMapToolStripMenuItem
        '
        Me.ProtMapToolStripMenuItem.Name = "ProtMapToolStripMenuItem"
        Me.ProtMapToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.ProtMapToolStripMenuItem.Text = "2D-EF map"
        '
        'DatabaseToolStripMenuItem
        '
        Me.DatabaseToolStripMenuItem.Name = "DatabaseToolStripMenuItem"
        Me.DatabaseToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.DatabaseToolStripMenuItem.Text = "Database"
        '
        'AddToAnnotationToolStripMenuItem
        '
        Me.AddToAnnotationToolStripMenuItem.Name = "AddToAnnotationToolStripMenuItem"
        Me.AddToAnnotationToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.AddToAnnotationToolStripMenuItem.Text = "Add to annotation"
        '
        'AddOligoToolStripMenuItem
        '
        Me.AddOligoToolStripMenuItem.Name = "AddOligoToolStripMenuItem"
        Me.AddOligoToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.AddOligoToolStripMenuItem.Text = "Add oligo"
        '
        'DeleteOligoToolStripMenuItem
        '
        Me.DeleteOligoToolStripMenuItem.Name = "DeleteOligoToolStripMenuItem"
        Me.DeleteOligoToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.DeleteOligoToolStripMenuItem.Text = "Delete oligo"
        '
        'TranslatePanel
        '
        Me.TranslatePanel.BackColor = System.Drawing.Color.White
        Me.TranslatePanel.ContextMenuStrip = Me.TranslationContextMenuStrip
        Me.TranslatePanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.TranslatePanel.Location = New System.Drawing.Point(0, 135)
        Me.TranslatePanel.Name = "TranslatePanel"
        Me.TranslatePanel.Size = New System.Drawing.Size(1138, 25)
        Me.TranslatePanel.TabIndex = 9
        '
        'TranslationContextMenuStrip
        '
        Me.TranslationContextMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExportToolStripMenuItem, Me.SynonymousTripletToolStripMenuItem, Me.ChangeAminoacidToolStripMenuItem})
        Me.TranslationContextMenuStrip.Name = "TranslationContextMenuStrip"
        Me.TranslationContextMenuStrip.Size = New System.Drawing.Size(183, 70)
        '
        'ExportToolStripMenuItem
        '
        Me.ExportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FastaToolStripMenuItem, Me.TableToolStripMenuItem})
        Me.ExportToolStripMenuItem.Name = "ExportToolStripMenuItem"
        Me.ExportToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.ExportToolStripMenuItem.Text = "Export"
        '
        'FastaToolStripMenuItem
        '
        Me.FastaToolStripMenuItem.Name = "FastaToolStripMenuItem"
        Me.FastaToolStripMenuItem.Size = New System.Drawing.Size(101, 22)
        Me.FastaToolStripMenuItem.Text = "Fasta"
        '
        'TableToolStripMenuItem
        '
        Me.TableToolStripMenuItem.Name = "TableToolStripMenuItem"
        Me.TableToolStripMenuItem.Size = New System.Drawing.Size(101, 22)
        Me.TableToolStripMenuItem.Text = "Table"
        '
        'SynonymousTripletToolStripMenuItem
        '
        Me.SynonymousTripletToolStripMenuItem.Name = "SynonymousTripletToolStripMenuItem"
        Me.SynonymousTripletToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.SynonymousTripletToolStripMenuItem.Text = "Synonymous triplets"
        '
        'ChangeAminoacidToolStripMenuItem
        '
        Me.ChangeAminoacidToolStripMenuItem.Name = "ChangeAminoacidToolStripMenuItem"
        Me.ChangeAminoacidToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.ChangeAminoacidToolStripMenuItem.Text = "Change aminoacid"
        '
        'GraphPanel
        '
        Me.GraphPanel.BackColor = System.Drawing.Color.White
        Me.GraphPanel.ContextMenuStrip = Me.GraphPanelMenuStrip
        Me.GraphPanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.GraphPanel.Location = New System.Drawing.Point(0, 308)
        Me.GraphPanel.Name = "GraphPanel"
        Me.GraphPanel.Size = New System.Drawing.Size(1138, 100)
        Me.GraphPanel.TabIndex = 7
        Me.GraphPanel.Visible = False
        '
        'GraphPanelMenuStrip
        '
        Me.GraphPanelMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FindBlockToolStripMenuItem, Me.ToolStripSeparator21, Me.SplitBlockToolStripMenuItem, Me.MergeBlocksToolStripMenuItem, Me.DeleteBlockToolStripMenuItem})
        Me.GraphPanelMenuStrip.Name = "GraphPanelMenuStrip"
        Me.GraphPanelMenuStrip.Size = New System.Drawing.Size(146, 98)
        '
        'FindBlockToolStripMenuItem
        '
        Me.FindBlockToolStripMenuItem.Name = "FindBlockToolStripMenuItem"
        Me.FindBlockToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.FindBlockToolStripMenuItem.Text = "Find block"
        '
        'ToolStripSeparator21
        '
        Me.ToolStripSeparator21.Name = "ToolStripSeparator21"
        Me.ToolStripSeparator21.Size = New System.Drawing.Size(142, 6)
        '
        'SplitBlockToolStripMenuItem
        '
        Me.SplitBlockToolStripMenuItem.Name = "SplitBlockToolStripMenuItem"
        Me.SplitBlockToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.SplitBlockToolStripMenuItem.Text = "Split block"
        '
        'MergeBlocksToolStripMenuItem
        '
        Me.MergeBlocksToolStripMenuItem.Name = "MergeBlocksToolStripMenuItem"
        Me.MergeBlocksToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.MergeBlocksToolStripMenuItem.Text = "Merge blocks"
        '
        'DeleteBlockToolStripMenuItem
        '
        Me.DeleteBlockToolStripMenuItem.Name = "DeleteBlockToolStripMenuItem"
        Me.DeleteBlockToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.DeleteBlockToolStripMenuItem.Text = "Delete block"
        '
        'SequencePanel
        '
        Me.SequencePanel.BackColor = System.Drawing.Color.White
        Me.SequencePanel.ContextMenuStrip = Me.SequenceContextMenu
        Me.SequencePanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.SequencePanel.Location = New System.Drawing.Point(0, 110)
        Me.SequencePanel.Name = "SequencePanel"
        Me.SequencePanel.Size = New System.Drawing.Size(1138, 25)
        Me.SequencePanel.TabIndex = 6
        '
        'SequenceContextMenu
        '
        Me.SequenceContextMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GetMarkedSequenceToolStripMenuItem, Me.IdentifySiteToolStripMenuItem, Me.InsertSequenceToolStripMenuItem, Me.InsertPromoterToolStripMenuItem, Me.EditSequenceToolStripMenuItem, Me.DeleteSequenceToolStripMenuItem, Me.LigateSequenceToolStripMenuItem, Me.CutPasteToolStripMenuItem, Me.CutRemoveSequenceToolStripMenuItem, Me.SelectForRestrictionPositionAToolStripMenuItem, Me.SelectForRestrictionPositionBToolStripMenuItem, Me.DesselectRestrictionSitesToolStripMenuItem, Me.CopySequenceToolStripMenuItem, Me.CutSequenceToolStripMenuItem, Me.PasteSequenceToolStripMenuItem, Me.ToolStripSeparator25, Me.CopyRegionToolStripMenuItem, Me.CutRegionToolStripMenuItem, Me.FlipRegionToolStripMenuItem, Me.PasteRegionToolStripMenuItem, Me.SendSeqMenuItem, Me.ToolStripSeparator7, Me.NewMarkerToolStripMenuItem, Me.DeleteToolStripMenuItem})
        Me.SequenceContextMenu.Name = "SequenceContextMenuStrip"
        Me.SequenceContextMenu.Size = New System.Drawing.Size(280, 500)
        '
        'GetMarkedSequenceToolStripMenuItem
        '
        Me.GetMarkedSequenceToolStripMenuItem.Image = CType(resources.GetObject("GetMarkedSequenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GetMarkedSequenceToolStripMenuItem.Name = "GetMarkedSequenceToolStripMenuItem"
        Me.GetMarkedSequenceToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.GetMarkedSequenceToolStripMenuItem.Text = "Get sequence"
        '
        'IdentifySiteToolStripMenuItem
        '
        Me.IdentifySiteToolStripMenuItem.Image = CType(resources.GetObject("IdentifySiteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.IdentifySiteToolStripMenuItem.Name = "IdentifySiteToolStripMenuItem"
        Me.IdentifySiteToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.IdentifySiteToolStripMenuItem.Text = "Identify site"
        '
        'InsertSequenceToolStripMenuItem
        '
        Me.InsertSequenceToolStripMenuItem.Image = CType(resources.GetObject("InsertSequenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.InsertSequenceToolStripMenuItem.Name = "InsertSequenceToolStripMenuItem"
        Me.InsertSequenceToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.InsertSequenceToolStripMenuItem.Text = "Insert sequence"
        '
        'InsertPromoterToolStripMenuItem
        '
        Me.InsertPromoterToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ForwardToolStripMenuItem, Me.ReverseToolStripMenuItem})
        Me.InsertPromoterToolStripMenuItem.Image = CType(resources.GetObject("InsertPromoterToolStripMenuItem.Image"), System.Drawing.Image)
        Me.InsertPromoterToolStripMenuItem.Name = "InsertPromoterToolStripMenuItem"
        Me.InsertPromoterToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.InsertPromoterToolStripMenuItem.Text = "Insert regulatory sequence"
        '
        'ForwardToolStripMenuItem
        '
        Me.ForwardToolStripMenuItem.Image = CType(resources.GetObject("ForwardToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ForwardToolStripMenuItem.Name = "ForwardToolStripMenuItem"
        Me.ForwardToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.ForwardToolStripMenuItem.Text = "Forward"
        '
        'ReverseToolStripMenuItem
        '
        Me.ReverseToolStripMenuItem.Image = CType(resources.GetObject("ReverseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ReverseToolStripMenuItem.Name = "ReverseToolStripMenuItem"
        Me.ReverseToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.ReverseToolStripMenuItem.Text = "Reverse"
        '
        'EditSequenceToolStripMenuItem
        '
        Me.EditSequenceToolStripMenuItem.Image = CType(resources.GetObject("EditSequenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditSequenceToolStripMenuItem.Name = "EditSequenceToolStripMenuItem"
        Me.EditSequenceToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.EditSequenceToolStripMenuItem.Text = "Replace sequence"
        '
        'DeleteSequenceToolStripMenuItem
        '
        Me.DeleteSequenceToolStripMenuItem.Image = CType(resources.GetObject("DeleteSequenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DeleteSequenceToolStripMenuItem.Name = "DeleteSequenceToolStripMenuItem"
        Me.DeleteSequenceToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.DeleteSequenceToolStripMenuItem.Text = "Delete sequence"
        '
        'LigateSequenceToolStripMenuItem
        '
        Me.LigateSequenceToolStripMenuItem.Image = CType(resources.GetObject("LigateSequenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LigateSequenceToolStripMenuItem.Name = "LigateSequenceToolStripMenuItem"
        Me.LigateSequenceToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.LigateSequenceToolStripMenuItem.Text = "Insert region by restriction-ligation"
        '
        'CutPasteToolStripMenuItem
        '
        Me.CutPasteToolStripMenuItem.Image = CType(resources.GetObject("CutPasteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CutPasteToolStripMenuItem.Name = "CutPasteToolStripMenuItem"
        Me.CutPasteToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.CutPasteToolStripMenuItem.Text = "Exchange region by restriction-ligation"
        '
        'CutRemoveSequenceToolStripMenuItem
        '
        Me.CutRemoveSequenceToolStripMenuItem.Image = CType(resources.GetObject("CutRemoveSequenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CutRemoveSequenceToolStripMenuItem.Name = "CutRemoveSequenceToolStripMenuItem"
        Me.CutRemoveSequenceToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.CutRemoveSequenceToolStripMenuItem.Text = "Remove region by restriction-ligation"
        '
        'SelectForRestrictionPositionAToolStripMenuItem
        '
        Me.SelectForRestrictionPositionAToolStripMenuItem.Image = CType(resources.GetObject("SelectForRestrictionPositionAToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SelectForRestrictionPositionAToolStripMenuItem.Name = "SelectForRestrictionPositionAToolStripMenuItem"
        Me.SelectForRestrictionPositionAToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.SelectForRestrictionPositionAToolStripMenuItem.Text = "Select for restriction position A"
        '
        'SelectForRestrictionPositionBToolStripMenuItem
        '
        Me.SelectForRestrictionPositionBToolStripMenuItem.Image = CType(resources.GetObject("SelectForRestrictionPositionBToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SelectForRestrictionPositionBToolStripMenuItem.Name = "SelectForRestrictionPositionBToolStripMenuItem"
        Me.SelectForRestrictionPositionBToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.SelectForRestrictionPositionBToolStripMenuItem.Text = "Select for restriction position B"
        '
        'DesselectRestrictionSitesToolStripMenuItem
        '
        Me.DesselectRestrictionSitesToolStripMenuItem.Image = CType(resources.GetObject("DesselectRestrictionSitesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DesselectRestrictionSitesToolStripMenuItem.Name = "DesselectRestrictionSitesToolStripMenuItem"
        Me.DesselectRestrictionSitesToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.DesselectRestrictionSitesToolStripMenuItem.Text = "Desselect restriction sites"
        '
        'CopySequenceToolStripMenuItem
        '
        Me.CopySequenceToolStripMenuItem.Image = CType(resources.GetObject("CopySequenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopySequenceToolStripMenuItem.Name = "CopySequenceToolStripMenuItem"
        Me.CopySequenceToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.CopySequenceToolStripMenuItem.Text = "Copy sequence"
        '
        'CutSequenceToolStripMenuItem
        '
        Me.CutSequenceToolStripMenuItem.Image = CType(resources.GetObject("CutSequenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CutSequenceToolStripMenuItem.Name = "CutSequenceToolStripMenuItem"
        Me.CutSequenceToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.CutSequenceToolStripMenuItem.Text = "Cut sequence"
        '
        'PasteSequenceToolStripMenuItem
        '
        Me.PasteSequenceToolStripMenuItem.Image = CType(resources.GetObject("PasteSequenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PasteSequenceToolStripMenuItem.Name = "PasteSequenceToolStripMenuItem"
        Me.PasteSequenceToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.PasteSequenceToolStripMenuItem.Text = "Paste sequence"
        '
        'ToolStripSeparator25
        '
        Me.ToolStripSeparator25.Name = "ToolStripSeparator25"
        Me.ToolStripSeparator25.Size = New System.Drawing.Size(276, 6)
        '
        'CopyRegionToolStripMenuItem
        '
        Me.CopyRegionToolStripMenuItem.Image = CType(resources.GetObject("CopyRegionToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyRegionToolStripMenuItem.Name = "CopyRegionToolStripMenuItem"
        Me.CopyRegionToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.CopyRegionToolStripMenuItem.Text = "Copy region"
        '
        'CutRegionToolStripMenuItem
        '
        Me.CutRegionToolStripMenuItem.Image = CType(resources.GetObject("CutRegionToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CutRegionToolStripMenuItem.Name = "CutRegionToolStripMenuItem"
        Me.CutRegionToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.CutRegionToolStripMenuItem.Text = "Cut region"
        '
        'FlipRegionToolStripMenuItem
        '
        Me.FlipRegionToolStripMenuItem.Image = CType(resources.GetObject("FlipRegionToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FlipRegionToolStripMenuItem.Name = "FlipRegionToolStripMenuItem"
        Me.FlipRegionToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.FlipRegionToolStripMenuItem.Text = "Flip region"
        '
        'PasteRegionToolStripMenuItem
        '
        Me.PasteRegionToolStripMenuItem.Image = CType(resources.GetObject("PasteRegionToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PasteRegionToolStripMenuItem.Name = "PasteRegionToolStripMenuItem"
        Me.PasteRegionToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.PasteRegionToolStripMenuItem.Text = "Paste region"
        '
        'SendSeqMenuItem
        '
        Me.SendSeqMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PrimerFinderMenuItem, Me.SecondaryStructureFinderToolStripMenuItem, Me.InternalHomologyToolStripMenuItem, Me.AssemblyDesignerToolStripMenuItem, Me.RepeatPlotToolStripMenuItem})
        Me.SendSeqMenuItem.Name = "SendSeqMenuItem"
        Me.SendSeqMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.SendSeqMenuItem.Text = "Send sequence to:"
        '
        'PrimerFinderMenuItem
        '
        Me.PrimerFinderMenuItem.Image = CType(resources.GetObject("PrimerFinderMenuItem.Image"), System.Drawing.Image)
        Me.PrimerFinderMenuItem.Name = "PrimerFinderMenuItem"
        Me.PrimerFinderMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.PrimerFinderMenuItem.Text = "Primer finder"
        '
        'SecondaryStructureFinderToolStripMenuItem
        '
        Me.SecondaryStructureFinderToolStripMenuItem.Name = "SecondaryStructureFinderToolStripMenuItem"
        Me.SecondaryStructureFinderToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.SecondaryStructureFinderToolStripMenuItem.Text = "Secondary structure finder"
        '
        'InternalHomologyToolStripMenuItem
        '
        Me.InternalHomologyToolStripMenuItem.Name = "InternalHomologyToolStripMenuItem"
        Me.InternalHomologyToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.InternalHomologyToolStripMenuItem.Text = "Repetitive sequences finder"
        '
        'AssemblyDesignerToolStripMenuItem
        '
        Me.AssemblyDesignerToolStripMenuItem.Name = "AssemblyDesignerToolStripMenuItem"
        Me.AssemblyDesignerToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.AssemblyDesignerToolStripMenuItem.Text = "Assembly designer"
        '
        'RepeatPlotToolStripMenuItem
        '
        Me.RepeatPlotToolStripMenuItem.Name = "RepeatPlotToolStripMenuItem"
        Me.RepeatPlotToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.RepeatPlotToolStripMenuItem.Text = "Hit plot"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(276, 6)
        '
        'NewMarkerToolStripMenuItem
        '
        Me.NewMarkerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SingleToolStripMenuItem, Me.PairedToolStripMenuItem})
        Me.NewMarkerToolStripMenuItem.Name = "NewMarkerToolStripMenuItem"
        Me.NewMarkerToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.NewMarkerToolStripMenuItem.Text = "New marker"
        '
        'SingleToolStripMenuItem
        '
        Me.SingleToolStripMenuItem.Name = "SingleToolStripMenuItem"
        Me.SingleToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.SingleToolStripMenuItem.Text = "Single"
        '
        'PairedToolStripMenuItem
        '
        Me.PairedToolStripMenuItem.Name = "PairedToolStripMenuItem"
        Me.PairedToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.PairedToolStripMenuItem.Text = "Paired"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.DeleteToolStripMenuItem.Text = "Delete marker"
        '
        'MinimapPanel
        '
        Me.MinimapPanel.BackColor = System.Drawing.Color.White
        Me.MinimapPanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.MinimapPanel.Location = New System.Drawing.Point(0, 0)
        Me.MinimapPanel.Name = "MinimapPanel"
        Me.MinimapPanel.Size = New System.Drawing.Size(1138, 110)
        Me.MinimapPanel.TabIndex = 5
        '
        'EditorToolStrip
        '
        Me.EditorToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GoToSeqButton, Me.MaxOutButton, Me.ToolStripSeparator1, Me.ToolStripLabel10, Me.SimpleMarkerButton, Me.SinglePairedButton, Me.ClearMarkersButton, Me.ToolStripSeparator8, Me.CurrentMarkerLabel, Me.GetSequenceButton, Me.CopyDataButton, Me.CutToolStripButton, Me.PasteDataButton, Me.FlipToolStripButton, Me.InsertSequenceButton, Me.ReplaceSequenceButton, Me.DeleteSequenceButton, Me.InsertLigationButton, Me.ReplaceLigationButton, Me.DeleteRestrictionButton, Me.InsertPromoterButton})
        Me.EditorToolStrip.Location = New System.Drawing.Point(0, 25)
        Me.EditorToolStrip.Name = "EditorToolStrip"
        Me.EditorToolStrip.Size = New System.Drawing.Size(1138, 25)
        Me.EditorToolStrip.TabIndex = 1
        Me.EditorToolStrip.Text = "ToolStrip1"
        '
        'GoToSeqButton
        '
        Me.GoToSeqButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.GoToSeqButton.Image = CType(resources.GetObject("GoToSeqButton.Image"), System.Drawing.Image)
        Me.GoToSeqButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.GoToSeqButton.Name = "GoToSeqButton"
        Me.GoToSeqButton.Size = New System.Drawing.Size(23, 22)
        Me.GoToSeqButton.Text = "Zoom to sequence"
        '
        'MaxOutButton
        '
        Me.MaxOutButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.MaxOutButton.Image = CType(resources.GetObject("MaxOutButton.Image"), System.Drawing.Image)
        Me.MaxOutButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.MaxOutButton.Name = "MaxOutButton"
        Me.MaxOutButton.Size = New System.Drawing.Size(23, 22)
        Me.MaxOutButton.Text = "Zoom out maximum"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel10
        '
        Me.ToolStripLabel10.Name = "ToolStripLabel10"
        Me.ToolStripLabel10.Size = New System.Drawing.Size(52, 22)
        Me.ToolStripLabel10.Text = "Markers:"
        '
        'SimpleMarkerButton
        '
        Me.SimpleMarkerButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SimpleMarkerButton.Image = CType(resources.GetObject("SimpleMarkerButton.Image"), System.Drawing.Image)
        Me.SimpleMarkerButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SimpleMarkerButton.Name = "SimpleMarkerButton"
        Me.SimpleMarkerButton.Size = New System.Drawing.Size(23, 22)
        Me.SimpleMarkerButton.Text = "Single marker"
        '
        'SinglePairedButton
        '
        Me.SinglePairedButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SinglePairedButton.Image = CType(resources.GetObject("SinglePairedButton.Image"), System.Drawing.Image)
        Me.SinglePairedButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SinglePairedButton.Name = "SinglePairedButton"
        Me.SinglePairedButton.Size = New System.Drawing.Size(23, 22)
        Me.SinglePairedButton.Text = "Paired"
        Me.SinglePairedButton.ToolTipText = "Paired marker"
        '
        'ClearMarkersButton
        '
        Me.ClearMarkersButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ClearMarkersButton.Image = CType(resources.GetObject("ClearMarkersButton.Image"), System.Drawing.Image)
        Me.ClearMarkersButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ClearMarkersButton.Name = "ClearMarkersButton"
        Me.ClearMarkersButton.Size = New System.Drawing.Size(23, 22)
        Me.ClearMarkersButton.Text = "Clear all markers"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 25)
        '
        'CurrentMarkerLabel
        '
        Me.CurrentMarkerLabel.Name = "CurrentMarkerLabel"
        Me.CurrentMarkerLabel.Size = New System.Drawing.Size(12, 22)
        Me.CurrentMarkerLabel.Text = "-"
        '
        'GetSequenceButton
        '
        Me.GetSequenceButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.GetSequenceButton.Image = CType(resources.GetObject("GetSequenceButton.Image"), System.Drawing.Image)
        Me.GetSequenceButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.GetSequenceButton.Name = "GetSequenceButton"
        Me.GetSequenceButton.Size = New System.Drawing.Size(23, 22)
        Me.GetSequenceButton.Text = "Get sequence"
        Me.GetSequenceButton.Visible = False
        '
        'CopyDataButton
        '
        Me.CopyDataButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CopyDataButton.Image = CType(resources.GetObject("CopyDataButton.Image"), System.Drawing.Image)
        Me.CopyDataButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyDataButton.Name = "CopyDataButton"
        Me.CopyDataButton.Size = New System.Drawing.Size(23, 22)
        Me.CopyDataButton.Text = "Copy region"
        Me.CopyDataButton.Visible = False
        '
        'CutToolStripButton
        '
        Me.CutToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CutToolStripButton.Image = CType(resources.GetObject("CutToolStripButton.Image"), System.Drawing.Image)
        Me.CutToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripButton.Name = "CutToolStripButton"
        Me.CutToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.CutToolStripButton.Text = "Cut region"
        '
        'PasteDataButton
        '
        Me.PasteDataButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PasteDataButton.Image = CType(resources.GetObject("PasteDataButton.Image"), System.Drawing.Image)
        Me.PasteDataButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteDataButton.Name = "PasteDataButton"
        Me.PasteDataButton.Size = New System.Drawing.Size(23, 22)
        Me.PasteDataButton.Text = "Paste region"
        Me.PasteDataButton.Visible = False
        '
        'FlipToolStripButton
        '
        Me.FlipToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.FlipToolStripButton.Image = CType(resources.GetObject("FlipToolStripButton.Image"), System.Drawing.Image)
        Me.FlipToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.FlipToolStripButton.Name = "FlipToolStripButton"
        Me.FlipToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.FlipToolStripButton.Text = "Flip region"
        '
        'InsertSequenceButton
        '
        Me.InsertSequenceButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.InsertSequenceButton.Image = CType(resources.GetObject("InsertSequenceButton.Image"), System.Drawing.Image)
        Me.InsertSequenceButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.InsertSequenceButton.Name = "InsertSequenceButton"
        Me.InsertSequenceButton.Size = New System.Drawing.Size(23, 22)
        Me.InsertSequenceButton.Text = "Insert sequence"
        Me.InsertSequenceButton.Visible = False
        '
        'ReplaceSequenceButton
        '
        Me.ReplaceSequenceButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ReplaceSequenceButton.Image = CType(resources.GetObject("ReplaceSequenceButton.Image"), System.Drawing.Image)
        Me.ReplaceSequenceButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ReplaceSequenceButton.Name = "ReplaceSequenceButton"
        Me.ReplaceSequenceButton.Size = New System.Drawing.Size(23, 22)
        Me.ReplaceSequenceButton.Text = "Replace sequence"
        Me.ReplaceSequenceButton.Visible = False
        '
        'DeleteSequenceButton
        '
        Me.DeleteSequenceButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DeleteSequenceButton.Image = CType(resources.GetObject("DeleteSequenceButton.Image"), System.Drawing.Image)
        Me.DeleteSequenceButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DeleteSequenceButton.Name = "DeleteSequenceButton"
        Me.DeleteSequenceButton.Size = New System.Drawing.Size(23, 22)
        Me.DeleteSequenceButton.Text = "Delete sequence"
        Me.DeleteSequenceButton.Visible = False
        '
        'InsertLigationButton
        '
        Me.InsertLigationButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.InsertLigationButton.Image = CType(resources.GetObject("InsertLigationButton.Image"), System.Drawing.Image)
        Me.InsertLigationButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.InsertLigationButton.Name = "InsertLigationButton"
        Me.InsertLigationButton.Size = New System.Drawing.Size(23, 22)
        Me.InsertLigationButton.Text = "Insert region by restriction-ligation"
        Me.InsertLigationButton.Visible = False
        '
        'ReplaceLigationButton
        '
        Me.ReplaceLigationButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ReplaceLigationButton.Image = CType(resources.GetObject("ReplaceLigationButton.Image"), System.Drawing.Image)
        Me.ReplaceLigationButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ReplaceLigationButton.Name = "ReplaceLigationButton"
        Me.ReplaceLigationButton.Size = New System.Drawing.Size(23, 22)
        Me.ReplaceLigationButton.Text = "Exchange region by restriction-ligation"
        Me.ReplaceLigationButton.Visible = False
        '
        'DeleteRestrictionButton
        '
        Me.DeleteRestrictionButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DeleteRestrictionButton.Image = CType(resources.GetObject("DeleteRestrictionButton.Image"), System.Drawing.Image)
        Me.DeleteRestrictionButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DeleteRestrictionButton.Name = "DeleteRestrictionButton"
        Me.DeleteRestrictionButton.Size = New System.Drawing.Size(23, 22)
        Me.DeleteRestrictionButton.Text = "Remove region by restriction-ligation"
        Me.DeleteRestrictionButton.Visible = False
        '
        'InsertPromoterButton
        '
        Me.InsertPromoterButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.InsertPromoterButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PromoterForwardToolStripMenuItem, Me.PromoterReverseToolStripMenuItem})
        Me.InsertPromoterButton.Image = CType(resources.GetObject("InsertPromoterButton.Image"), System.Drawing.Image)
        Me.InsertPromoterButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.InsertPromoterButton.Name = "InsertPromoterButton"
        Me.InsertPromoterButton.Size = New System.Drawing.Size(32, 22)
        Me.InsertPromoterButton.Text = "Insert regulatory sequence"
        Me.InsertPromoterButton.Visible = False
        '
        'PromoterForwardToolStripMenuItem
        '
        Me.PromoterForwardToolStripMenuItem.Image = CType(resources.GetObject("PromoterForwardToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PromoterForwardToolStripMenuItem.Name = "PromoterForwardToolStripMenuItem"
        Me.PromoterForwardToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.PromoterForwardToolStripMenuItem.Text = "Forward"
        '
        'PromoterReverseToolStripMenuItem
        '
        Me.PromoterReverseToolStripMenuItem.Image = CType(resources.GetObject("PromoterReverseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PromoterReverseToolStripMenuItem.Name = "PromoterReverseToolStripMenuItem"
        Me.PromoterReverseToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.PromoterReverseToolStripMenuItem.Text = "Reverse"
        '
        'ViewerToolStrip
        '
        Me.ViewerToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ZoomInButton, Me.ZoomOutButton, Me.ToolStripSeparator3, Me.LeftBorderStripButton, Me.MoveLeftButton, Me.JumpBackButton, Me.JumpForButton, Me.MoveRightButton, Me.RightBorderStripButton, Me.ToolStripSeparator4, Me.ToolStripLabel4, Me.StartTextBox, Me.ToolStripLabel5, Me.EndTextBox, Me.GoButton, Me.ToolStripLabel6, Me.RangeTextBox, Me.ToolStripSeparator5, Me.ToolStripLabel7, Me.SearchOptionsDropDownButton, Me.QueryTypeBox, Me.SearchSequenceTextBox, Me.AlignmentTypeComboBox, Me.ToolStripLabel8, Me.IdentityPercentTextBox, Me.ToolStripLabel9, Me.OligoNameTextBox, Me.SearchButton})
        Me.ViewerToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.ViewerToolStrip.Name = "ViewerToolStrip"
        Me.ViewerToolStrip.Size = New System.Drawing.Size(1138, 25)
        Me.ViewerToolStrip.TabIndex = 0
        Me.ViewerToolStrip.Text = "ToolStrip1"
        '
        'ZoomInButton
        '
        Me.ZoomInButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ZoomInButton.Image = CType(resources.GetObject("ZoomInButton.Image"), System.Drawing.Image)
        Me.ZoomInButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ZoomInButton.Name = "ZoomInButton"
        Me.ZoomInButton.Size = New System.Drawing.Size(23, 22)
        Me.ZoomInButton.Text = "Zoom in"
        '
        'ZoomOutButton
        '
        Me.ZoomOutButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ZoomOutButton.Image = CType(resources.GetObject("ZoomOutButton.Image"), System.Drawing.Image)
        Me.ZoomOutButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ZoomOutButton.Name = "ZoomOutButton"
        Me.ZoomOutButton.Size = New System.Drawing.Size(23, 22)
        Me.ZoomOutButton.Text = "Zoom out"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'LeftBorderStripButton
        '
        Me.LeftBorderStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.LeftBorderStripButton.Image = CType(resources.GetObject("LeftBorderStripButton.Image"), System.Drawing.Image)
        Me.LeftBorderStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.LeftBorderStripButton.Name = "LeftBorderStripButton"
        Me.LeftBorderStripButton.Size = New System.Drawing.Size(23, 22)
        Me.LeftBorderStripButton.Text = "Left border"
        '
        'MoveLeftButton
        '
        Me.MoveLeftButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.MoveLeftButton.Image = CType(resources.GetObject("MoveLeftButton.Image"), System.Drawing.Image)
        Me.MoveLeftButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.MoveLeftButton.Name = "MoveLeftButton"
        Me.MoveLeftButton.Size = New System.Drawing.Size(23, 22)
        Me.MoveLeftButton.Text = "Scroll backward"
        '
        'JumpBackButton
        '
        Me.JumpBackButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.JumpBackButton.Image = CType(resources.GetObject("JumpBackButton.Image"), System.Drawing.Image)
        Me.JumpBackButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.JumpBackButton.Name = "JumpBackButton"
        Me.JumpBackButton.Size = New System.Drawing.Size(23, 22)
        Me.JumpBackButton.Text = "x"
        '
        'JumpForButton
        '
        Me.JumpForButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.JumpForButton.Image = CType(resources.GetObject("JumpForButton.Image"), System.Drawing.Image)
        Me.JumpForButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.JumpForButton.Name = "JumpForButton"
        Me.JumpForButton.Size = New System.Drawing.Size(23, 22)
        Me.JumpForButton.Text = "Jump forward"
        '
        'MoveRightButton
        '
        Me.MoveRightButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.MoveRightButton.Image = CType(resources.GetObject("MoveRightButton.Image"), System.Drawing.Image)
        Me.MoveRightButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.MoveRightButton.Name = "MoveRightButton"
        Me.MoveRightButton.Size = New System.Drawing.Size(23, 22)
        Me.MoveRightButton.Text = "Scroll forward"
        '
        'RightBorderStripButton
        '
        Me.RightBorderStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.RightBorderStripButton.Image = CType(resources.GetObject("RightBorderStripButton.Image"), System.Drawing.Image)
        Me.RightBorderStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.RightBorderStripButton.Name = "RightBorderStripButton"
        Me.RightBorderStripButton.Size = New System.Drawing.Size(23, 22)
        Me.RightBorderStripButton.Text = "Right border"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel4
        '
        Me.ToolStripLabel4.Name = "ToolStripLabel4"
        Me.ToolStripLabel4.Size = New System.Drawing.Size(34, 22)
        Me.ToolStripLabel4.Text = "Start:"
        '
        'StartTextBox
        '
        Me.StartTextBox.Name = "StartTextBox"
        Me.StartTextBox.Size = New System.Drawing.Size(70, 25)
        '
        'ToolStripLabel5
        '
        Me.ToolStripLabel5.Name = "ToolStripLabel5"
        Me.ToolStripLabel5.Size = New System.Drawing.Size(30, 22)
        Me.ToolStripLabel5.Text = "End:"
        '
        'EndTextBox
        '
        Me.EndTextBox.Name = "EndTextBox"
        Me.EndTextBox.Size = New System.Drawing.Size(70, 25)
        '
        'GoButton
        '
        Me.GoButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.GoButton.Image = CType(resources.GetObject("GoButton.Image"), System.Drawing.Image)
        Me.GoButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.GoButton.Name = "GoButton"
        Me.GoButton.Size = New System.Drawing.Size(23, 22)
        Me.GoButton.Text = "Go"
        '
        'ToolStripLabel6
        '
        Me.ToolStripLabel6.Name = "ToolStripLabel6"
        Me.ToolStripLabel6.Size = New System.Drawing.Size(43, 22)
        Me.ToolStripLabel6.Text = "Range:"
        '
        'RangeTextBox
        '
        Me.RangeTextBox.Name = "RangeTextBox"
        Me.RangeTextBox.Size = New System.Drawing.Size(70, 25)
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel7
        '
        Me.ToolStripLabel7.Name = "ToolStripLabel7"
        Me.ToolStripLabel7.Size = New System.Drawing.Size(45, 22)
        Me.ToolStripLabel7.Text = "Search:"
        '
        'SearchOptionsDropDownButton
        '
        Me.SearchOptionsDropDownButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SearchOptionsDropDownButton.Image = CType(resources.GetObject("SearchOptionsDropDownButton.Image"), System.Drawing.Image)
        Me.SearchOptionsDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SearchOptionsDropDownButton.Name = "SearchOptionsDropDownButton"
        Me.SearchOptionsDropDownButton.Size = New System.Drawing.Size(29, 22)
        Me.SearchOptionsDropDownButton.Text = "Known sequences"
        Me.SearchOptionsDropDownButton.ToolTipText = "Search for sequences stored in database (like restriction sites)"
        '
        'QueryTypeBox
        '
        Me.QueryTypeBox.Items.AddRange(New Object() {"DNA", "Protein"})
        Me.QueryTypeBox.Name = "QueryTypeBox"
        Me.QueryTypeBox.Size = New System.Drawing.Size(75, 25)
        Me.QueryTypeBox.Text = "DNA"
        '
        'SearchSequenceTextBox
        '
        Me.SearchSequenceTextBox.Name = "SearchSequenceTextBox"
        Me.SearchSequenceTextBox.Size = New System.Drawing.Size(150, 25)
        '
        'AlignmentTypeComboBox
        '
        Me.AlignmentTypeComboBox.Items.AddRange(New Object() {"Ungapped", "Gapped"})
        Me.AlignmentTypeComboBox.Name = "AlignmentTypeComboBox"
        Me.AlignmentTypeComboBox.Size = New System.Drawing.Size(75, 25)
        Me.AlignmentTypeComboBox.Text = "Ungapped"
        '
        'ToolStripLabel8
        '
        Me.ToolStripLabel8.Name = "ToolStripLabel8"
        Me.ToolStripLabel8.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripLabel8.Text = "% :"
        '
        'IdentityPercentTextBox
        '
        Me.IdentityPercentTextBox.Name = "IdentityPercentTextBox"
        Me.IdentityPercentTextBox.Size = New System.Drawing.Size(25, 25)
        Me.IdentityPercentTextBox.Text = "100"
        '
        'ToolStripLabel9
        '
        Me.ToolStripLabel9.Name = "ToolStripLabel9"
        Me.ToolStripLabel9.Size = New System.Drawing.Size(42, 22)
        Me.ToolStripLabel9.Text = "Name:"
        '
        'OligoNameTextBox
        '
        Me.OligoNameTextBox.Name = "OligoNameTextBox"
        Me.OligoNameTextBox.Size = New System.Drawing.Size(50, 25)
        '
        'SearchButton
        '
        Me.SearchButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SearchButton.Image = CType(resources.GetObject("SearchButton.Image"), System.Drawing.Image)
        Me.SearchButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SearchButton.Name = "SearchButton"
        Me.SearchButton.Size = New System.Drawing.Size(23, 22)
        Me.SearchButton.Text = "Search sequence"
        '
        'FeaturesTabControl
        '
        Me.FeaturesTabControl.Controls.Add(Me.Features)
        Me.FeaturesTabControl.Controls.Add(Me.Values)
        Me.FeaturesTabControl.Controls.Add(Me.PositionalValues)
        Me.FeaturesTabControl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FeaturesTabControl.Location = New System.Drawing.Point(0, 0)
        Me.FeaturesTabControl.Name = "FeaturesTabControl"
        Me.FeaturesTabControl.SelectedIndex = 0
        Me.FeaturesTabControl.Size = New System.Drawing.Size(1138, 175)
        Me.FeaturesTabControl.TabIndex = 1
        '
        'Features
        '
        Me.Features.Controls.Add(Me.FeaturesGroupDataGridView)
        Me.Features.Controls.Add(Me.FeaturesGroupsListBox)
        Me.Features.Controls.Add(Me.AnnotationToolStrip)
        Me.Features.Location = New System.Drawing.Point(4, 22)
        Me.Features.Name = "Features"
        Me.Features.Size = New System.Drawing.Size(1130, 149)
        Me.Features.TabIndex = 3
        Me.Features.Text = "Annotation"
        Me.Features.UseVisualStyleBackColor = True
        '
        'FeaturesGroupDataGridView
        '
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.FeaturesGroupDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.FeaturesGroupDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.FeaturesGroupDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.F_TAG, Me.F_Name, Me.F_Descr, Me.F_Start, Me.F_End, Me.F_Dir, Me.F_Type, Me.F_Ort, Me.F_Read, Me.Group_ID})
        Me.FeaturesGroupDataGridView.ContextMenuStrip = Me.DataContextMenu
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.FeaturesGroupDataGridView.DefaultCellStyle = DataGridViewCellStyle11
        Me.FeaturesGroupDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FeaturesGroupDataGridView.Location = New System.Drawing.Point(160, 25)
        Me.FeaturesGroupDataGridView.Name = "FeaturesGroupDataGridView"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.FeaturesGroupDataGridView.RowHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.FeaturesGroupDataGridView.Size = New System.Drawing.Size(970, 124)
        Me.FeaturesGroupDataGridView.TabIndex = 2
        '
        'F_TAG
        '
        Me.F_TAG.HeaderText = "TAG"
        Me.F_TAG.Name = "F_TAG"
        Me.F_TAG.Width = 80
        '
        'F_Name
        '
        Me.F_Name.HeaderText = "Name"
        Me.F_Name.Name = "F_Name"
        Me.F_Name.Width = 80
        '
        'F_Descr
        '
        Me.F_Descr.HeaderText = "Description"
        Me.F_Descr.Name = "F_Descr"
        Me.F_Descr.Width = 200
        '
        'F_Start
        '
        Me.F_Start.HeaderText = "Start"
        Me.F_Start.Name = "F_Start"
        Me.F_Start.Width = 60
        '
        'F_End
        '
        Me.F_End.HeaderText = "End"
        Me.F_End.Name = "F_End"
        Me.F_End.Width = 60
        '
        'F_Dir
        '
        Me.F_Dir.HeaderText = "Direction"
        Me.F_Dir.Name = "F_Dir"
        Me.F_Dir.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.F_Dir.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.F_Dir.Width = 60
        '
        'F_Type
        '
        Me.F_Type.HeaderText = "Type"
        Me.F_Type.Name = "F_Type"
        Me.F_Type.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.F_Type.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.F_Type.Width = 130
        '
        'F_Ort
        '
        Me.F_Ort.HeaderText = "Orthologue"
        Me.F_Ort.Name = "F_Ort"
        Me.F_Ort.Width = 60
        '
        'F_Read
        '
        Me.F_Read.HeaderText = "Read"
        Me.F_Read.Name = "F_Read"
        '
        'Group_ID
        '
        Me.Group_ID.HeaderText = "Group"
        Me.Group_ID.Name = "Group_ID"
        '
        'DataContextMenu
        '
        Me.DataContextMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CenterViewToolStripMenuItem, Me.GetSequenceToolStripMenuItem, Me.ToolStripSeparator11, Me.AddToLargeScaleViewerToolStripMenuItem, Me.AddToVirtual2DEFViewerToolStripMenuItem, Me.ToolStripSeparator17, Me.CopyToolStripMenuItem})
        Me.DataContextMenu.Name = "DataContextMenu"
        Me.DataContextMenu.Size = New System.Drawing.Size(208, 126)
        '
        'CenterViewToolStripMenuItem
        '
        Me.CenterViewToolStripMenuItem.Image = CType(resources.GetObject("CenterViewToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CenterViewToolStripMenuItem.Name = "CenterViewToolStripMenuItem"
        Me.CenterViewToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.CenterViewToolStripMenuItem.Text = "Center view"
        '
        'GetSequenceToolStripMenuItem
        '
        Me.GetSequenceToolStripMenuItem.Image = CType(resources.GetObject("GetSequenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GetSequenceToolStripMenuItem.Name = "GetSequenceToolStripMenuItem"
        Me.GetSequenceToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.GetSequenceToolStripMenuItem.Text = "Get sequence"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(204, 6)
        '
        'AddToLargeScaleViewerToolStripMenuItem
        '
        Me.AddToLargeScaleViewerToolStripMenuItem.Name = "AddToLargeScaleViewerToolStripMenuItem"
        Me.AddToLargeScaleViewerToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.AddToLargeScaleViewerToolStripMenuItem.Text = "Add to circular map"
        '
        'AddToVirtual2DEFViewerToolStripMenuItem
        '
        Me.AddToVirtual2DEFViewerToolStripMenuItem.Name = "AddToVirtual2DEFViewerToolStripMenuItem"
        Me.AddToVirtual2DEFViewerToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.AddToVirtual2DEFViewerToolStripMenuItem.Text = "Add to virtual 2D-EF map"
        '
        'ToolStripSeparator17
        '
        Me.ToolStripSeparator17.Name = "ToolStripSeparator17"
        Me.ToolStripSeparator17.Size = New System.Drawing.Size(204, 6)
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Image = CType(resources.GetObject("CopyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'FeaturesGroupsListBox
        '
        Me.FeaturesGroupsListBox.CheckBoxes = True
        Me.FeaturesGroupsListBox.Dock = System.Windows.Forms.DockStyle.Left
        Me.FeaturesGroupsListBox.Location = New System.Drawing.Point(0, 25)
        Me.FeaturesGroupsListBox.Name = "FeaturesGroupsListBox"
        Me.FeaturesGroupsListBox.Size = New System.Drawing.Size(160, 124)
        Me.FeaturesGroupsListBox.TabIndex = 3
        Me.FeaturesGroupsListBox.UseCompatibleStateImageBehavior = False
        Me.FeaturesGroupsListBox.View = System.Windows.Forms.View.List
        '
        'AnnotationToolStrip
        '
        Me.AnnotationToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AllFeaturesButton, Me.RenameAsmButton, Me.ImportSplitButton, Me.SaveFeaturesButton, Me.MergeListsButton, Me.DeleteAllButton, Me.ToolStripSeparator18, Me.ToolStripLabel11, Me.QueryTextBox, Me.ToolStripLabel12, Me.FieldComboBox, Me.ToolStripLabel14, Me.SearchGroupComboBox, Me.SearchFeaturesButton, Me.ToolStripLabel13, Me.CountButton, Me.ToolStripSeparator14, Me.DelFButton, Me.AddFButton, Me.ToolStripSeparator15, Me.DisplayToTopologyToolStripButton, Me.ToolStripSeparator23, Me.EraseTableButton})
        Me.AnnotationToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.AnnotationToolStrip.Name = "AnnotationToolStrip"
        Me.AnnotationToolStrip.Size = New System.Drawing.Size(1130, 25)
        Me.AnnotationToolStrip.TabIndex = 1
        Me.AnnotationToolStrip.Text = "ToolStrip1"
        '
        'AllFeaturesButton
        '
        Me.AllFeaturesButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AllFeaturesButton.Image = CType(resources.GetObject("AllFeaturesButton.Image"), System.Drawing.Image)
        Me.AllFeaturesButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AllFeaturesButton.Name = "AllFeaturesButton"
        Me.AllFeaturesButton.Size = New System.Drawing.Size(23, 22)
        Me.AllFeaturesButton.Text = "Show all features"
        '
        'RenameAsmButton
        '
        Me.RenameAsmButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.RenameAsmButton.Image = CType(resources.GetObject("RenameAsmButton.Image"), System.Drawing.Image)
        Me.RenameAsmButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.RenameAsmButton.Name = "RenameAsmButton"
        Me.RenameAsmButton.Size = New System.Drawing.Size(23, 22)
        Me.RenameAsmButton.Text = "Rename group"
        '
        'ImportSplitButton
        '
        Me.ImportSplitButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ImportSplitButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AnnotationFileToolStripMenuItem, Me.TabseparatedFileToolStripMenuItem})
        Me.ImportSplitButton.Image = CType(resources.GetObject("ImportSplitButton.Image"), System.Drawing.Image)
        Me.ImportSplitButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ImportSplitButton.Name = "ImportSplitButton"
        Me.ImportSplitButton.Size = New System.Drawing.Size(32, 22)
        Me.ImportSplitButton.Text = "Import annotation"
        '
        'AnnotationFileToolStripMenuItem
        '
        Me.AnnotationFileToolStripMenuItem.Name = "AnnotationFileToolStripMenuItem"
        Me.AnnotationFileToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.AnnotationFileToolStripMenuItem.Text = "Annotation file"
        '
        'TabseparatedFileToolStripMenuItem
        '
        Me.TabseparatedFileToolStripMenuItem.Name = "TabseparatedFileToolStripMenuItem"
        Me.TabseparatedFileToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.TabseparatedFileToolStripMenuItem.Text = "Tab-separated file"
        '
        'SaveFeaturesButton
        '
        Me.SaveFeaturesButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveFeaturesButton.Image = CType(resources.GetObject("SaveFeaturesButton.Image"), System.Drawing.Image)
        Me.SaveFeaturesButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveFeaturesButton.Name = "SaveFeaturesButton"
        Me.SaveFeaturesButton.Size = New System.Drawing.Size(23, 22)
        Me.SaveFeaturesButton.Text = "Save annotation"
        Me.SaveFeaturesButton.ToolTipText = "Save annotation as .annot file"
        '
        'MergeListsButton
        '
        Me.MergeListsButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.MergeListsButton.Image = CType(resources.GetObject("MergeListsButton.Image"), System.Drawing.Image)
        Me.MergeListsButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.MergeListsButton.Name = "MergeListsButton"
        Me.MergeListsButton.Size = New System.Drawing.Size(23, 22)
        Me.MergeListsButton.Text = "Merge annotations"
        '
        'DeleteAllButton
        '
        Me.DeleteAllButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DeleteAllButton.Image = CType(resources.GetObject("DeleteAllButton.Image"), System.Drawing.Image)
        Me.DeleteAllButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DeleteAllButton.Name = "DeleteAllButton"
        Me.DeleteAllButton.Size = New System.Drawing.Size(23, 22)
        Me.DeleteAllButton.Text = "Delete annotation"
        '
        'ToolStripSeparator18
        '
        Me.ToolStripSeparator18.Name = "ToolStripSeparator18"
        Me.ToolStripSeparator18.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel11
        '
        Me.ToolStripLabel11.Name = "ToolStripLabel11"
        Me.ToolStripLabel11.Size = New System.Drawing.Size(42, 22)
        Me.ToolStripLabel11.Text = "Query:"
        '
        'QueryTextBox
        '
        Me.QueryTextBox.Name = "QueryTextBox"
        Me.QueryTextBox.Size = New System.Drawing.Size(120, 25)
        '
        'ToolStripLabel12
        '
        Me.ToolStripLabel12.Name = "ToolStripLabel12"
        Me.ToolStripLabel12.Size = New System.Drawing.Size(35, 22)
        Me.ToolStripLabel12.Text = "Field:"
        '
        'FieldComboBox
        '
        Me.FieldComboBox.Items.AddRange(New Object() {"Any", "TAG", "Name&Description", "Type", "Orthology"})
        Me.FieldComboBox.Name = "FieldComboBox"
        Me.FieldComboBox.Size = New System.Drawing.Size(121, 25)
        Me.FieldComboBox.Text = "Any"
        '
        'ToolStripLabel14
        '
        Me.ToolStripLabel14.Name = "ToolStripLabel14"
        Me.ToolStripLabel14.Size = New System.Drawing.Size(43, 22)
        Me.ToolStripLabel14.Text = "Group:"
        '
        'SearchGroupComboBox
        '
        Me.SearchGroupComboBox.Items.AddRange(New Object() {"Current", "Main", "All"})
        Me.SearchGroupComboBox.Name = "SearchGroupComboBox"
        Me.SearchGroupComboBox.Size = New System.Drawing.Size(75, 25)
        Me.SearchGroupComboBox.Text = "All"
        '
        'SearchFeaturesButton
        '
        Me.SearchFeaturesButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SearchFeaturesButton.Image = CType(resources.GetObject("SearchFeaturesButton.Image"), System.Drawing.Image)
        Me.SearchFeaturesButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SearchFeaturesButton.Name = "SearchFeaturesButton"
        Me.SearchFeaturesButton.Size = New System.Drawing.Size(23, 22)
        Me.SearchFeaturesButton.Text = "Search"
        '
        'ToolStripLabel13
        '
        Me.ToolStripLabel13.Name = "ToolStripLabel13"
        Me.ToolStripLabel13.Size = New System.Drawing.Size(54, 22)
        Me.ToolStripLabel13.Text = "Features:"
        '
        'CountButton
        '
        Me.CountButton.Image = CType(resources.GetObject("CountButton.Image"), System.Drawing.Image)
        Me.CountButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CountButton.Name = "CountButton"
        Me.CountButton.Size = New System.Drawing.Size(33, 22)
        Me.CountButton.Text = "0"
        Me.CountButton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.CountButton.ToolTipText = "Refresh number"
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(6, 25)
        '
        'DelFButton
        '
        Me.DelFButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DelFButton.Enabled = False
        Me.DelFButton.Image = CType(resources.GetObject("DelFButton.Image"), System.Drawing.Image)
        Me.DelFButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DelFButton.Name = "DelFButton"
        Me.DelFButton.Size = New System.Drawing.Size(23, 22)
        Me.DelFButton.Text = "Delete feature"
        '
        'AddFButton
        '
        Me.AddFButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AddFButton.Image = CType(resources.GetObject("AddFButton.Image"), System.Drawing.Image)
        Me.AddFButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AddFButton.Name = "AddFButton"
        Me.AddFButton.Size = New System.Drawing.Size(23, 22)
        Me.AddFButton.Text = "Add features"
        '
        'ToolStripSeparator15
        '
        Me.ToolStripSeparator15.Name = "ToolStripSeparator15"
        Me.ToolStripSeparator15.Size = New System.Drawing.Size(6, 25)
        '
        'DisplayToTopologyToolStripButton
        '
        Me.DisplayToTopologyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DisplayToTopologyToolStripButton.Image = CType(resources.GetObject("DisplayToTopologyToolStripButton.Image"), System.Drawing.Image)
        Me.DisplayToTopologyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DisplayToTopologyToolStripButton.Name = "DisplayToTopologyToolStripButton"
        Me.DisplayToTopologyToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.DisplayToTopologyToolStripButton.Text = "Add shown features to large scale viewer"
        '
        'ToolStripSeparator23
        '
        Me.ToolStripSeparator23.Name = "ToolStripSeparator23"
        Me.ToolStripSeparator23.Size = New System.Drawing.Size(6, 25)
        '
        'EraseTableButton
        '
        Me.EraseTableButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.EraseTableButton.Image = CType(resources.GetObject("EraseTableButton.Image"), System.Drawing.Image)
        Me.EraseTableButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.EraseTableButton.Name = "EraseTableButton"
        Me.EraseTableButton.Size = New System.Drawing.Size(23, 22)
        Me.EraseTableButton.Text = "Erase table"
        '
        'Values
        '
        Me.Values.Controls.Add(Me.IntervalsDataGridView)
        Me.Values.Controls.Add(Me.IntervalsListView)
        Me.Values.Controls.Add(Me.QuantitationToolStrip)
        Me.Values.Location = New System.Drawing.Point(4, 22)
        Me.Values.Name = "Values"
        Me.Values.Size = New System.Drawing.Size(1130, 149)
        Me.Values.TabIndex = 4
        Me.Values.Text = "Values"
        Me.Values.UseVisualStyleBackColor = True
        '
        'IntervalsDataGridView
        '
        Me.IntervalsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.IntervalsDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IntervalID_Col, Me.IntervalStart_Col, Me.IntervalEnd_Col, Me.IntervalDir_Col, Me.IntervalValue_Col, Me.HolderName_Col})
        Me.IntervalsDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.IntervalsDataGridView.Location = New System.Drawing.Point(241, 25)
        Me.IntervalsDataGridView.Name = "IntervalsDataGridView"
        Me.IntervalsDataGridView.Size = New System.Drawing.Size(889, 124)
        Me.IntervalsDataGridView.TabIndex = 5
        '
        'IntervalID_Col
        '
        Me.IntervalID_Col.HeaderText = "TAG"
        Me.IntervalID_Col.Name = "IntervalID_Col"
        '
        'IntervalStart_Col
        '
        Me.IntervalStart_Col.HeaderText = "Start"
        Me.IntervalStart_Col.Name = "IntervalStart_Col"
        Me.IntervalStart_Col.Width = 60
        '
        'IntervalEnd_Col
        '
        Me.IntervalEnd_Col.HeaderText = "End"
        Me.IntervalEnd_Col.Name = "IntervalEnd_Col"
        Me.IntervalEnd_Col.Width = 60
        '
        'IntervalDir_Col
        '
        Me.IntervalDir_Col.HeaderText = "Direction"
        Me.IntervalDir_Col.Items.AddRange(New Object() {"Plus", "Minus", "Unknown"})
        Me.IntervalDir_Col.Name = "IntervalDir_Col"
        Me.IntervalDir_Col.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.IntervalDir_Col.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.IntervalDir_Col.Width = 60
        '
        'IntervalValue_Col
        '
        Me.IntervalValue_Col.HeaderText = "Value"
        Me.IntervalValue_Col.Name = "IntervalValue_Col"
        Me.IntervalValue_Col.Width = 60
        '
        'HolderName_Col
        '
        Me.HolderName_Col.HeaderText = "Group"
        Me.HolderName_Col.Name = "HolderName_Col"
        Me.HolderName_Col.Width = 200
        '
        'IntervalsListView
        '
        Me.IntervalsListView.CheckBoxes = True
        Me.IntervalsListView.ContextMenuStrip = Me.IntervalsMenuStrip
        Me.IntervalsListView.Dock = System.Windows.Forms.DockStyle.Left
        Me.IntervalsListView.Location = New System.Drawing.Point(0, 25)
        Me.IntervalsListView.Name = "IntervalsListView"
        Me.IntervalsListView.Size = New System.Drawing.Size(241, 124)
        Me.IntervalsListView.TabIndex = 4
        Me.IntervalsListView.UseCompatibleStateImageBehavior = False
        Me.IntervalsListView.View = System.Windows.Forms.View.List
        '
        'IntervalsMenuStrip
        '
        Me.IntervalsMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RenameIntervalToolStripMenuItem, Me.ToolStripSeparator16, Me.ColorIntervalToolStripMenuItem})
        Me.IntervalsMenuStrip.Name = "IntervalsMenuStrip"
        Me.IntervalsMenuStrip.Size = New System.Drawing.Size(118, 54)
        '
        'RenameIntervalToolStripMenuItem
        '
        Me.RenameIntervalToolStripMenuItem.Name = "RenameIntervalToolStripMenuItem"
        Me.RenameIntervalToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.RenameIntervalToolStripMenuItem.Text = "Rename"
        '
        'ToolStripSeparator16
        '
        Me.ToolStripSeparator16.Name = "ToolStripSeparator16"
        Me.ToolStripSeparator16.Size = New System.Drawing.Size(114, 6)
        '
        'ColorIntervalToolStripMenuItem
        '
        Me.ColorIntervalToolStripMenuItem.Name = "ColorIntervalToolStripMenuItem"
        Me.ColorIntervalToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.ColorIntervalToolStripMenuItem.Text = "Color"
        '
        'QuantitationToolStrip
        '
        Me.QuantitationToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewIntervalsButton, Me.BlocksCountButton, Me.ToolStripSeparator20, Me.ClearIntegratedToolStripButton, Me.ToolStripSeparator19, Me.AddValuesButton, Me.DelValsToolStripButton, Me.ToolStripSeparator6, Me.ToggleDisplayModeButton, Me.QuantStyleSplitButton, Me.MultValuesButton, Me.ToolStripSeparator13, Me.SaveBlocksButton, Me.BlocksDifexpressionButton, Me.ScanSlipperingToolStripButton, Me.ScanSameIntervalToolStripButton, Me.IntervalMarkTableButton})
        Me.QuantitationToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.QuantitationToolStrip.Name = "QuantitationToolStrip"
        Me.QuantitationToolStrip.Size = New System.Drawing.Size(1130, 25)
        Me.QuantitationToolStrip.TabIndex = 0
        Me.QuantitationToolStrip.Text = "ToolStrip1"
        '
        'ViewIntervalsButton
        '
        Me.ViewIntervalsButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ViewIntervalsButton.Image = CType(resources.GetObject("ViewIntervalsButton.Image"), System.Drawing.Image)
        Me.ViewIntervalsButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ViewIntervalsButton.Name = "ViewIntervalsButton"
        Me.ViewIntervalsButton.Size = New System.Drawing.Size(23, 22)
        Me.ViewIntervalsButton.Text = "Show all features"
        '
        'BlocksCountButton
        '
        Me.BlocksCountButton.Image = CType(resources.GetObject("BlocksCountButton.Image"), System.Drawing.Image)
        Me.BlocksCountButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BlocksCountButton.Name = "BlocksCountButton"
        Me.BlocksCountButton.Size = New System.Drawing.Size(33, 22)
        Me.BlocksCountButton.Text = "0"
        Me.BlocksCountButton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.BlocksCountButton.ToolTipText = "Refresh number"
        '
        'ToolStripSeparator20
        '
        Me.ToolStripSeparator20.Name = "ToolStripSeparator20"
        Me.ToolStripSeparator20.Size = New System.Drawing.Size(6, 25)
        '
        'ClearIntegratedToolStripButton
        '
        Me.ClearIntegratedToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ClearIntegratedToolStripButton.Image = CType(resources.GetObject("ClearIntegratedToolStripButton.Image"), System.Drawing.Image)
        Me.ClearIntegratedToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ClearIntegratedToolStripButton.Name = "ClearIntegratedToolStripButton"
        Me.ClearIntegratedToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.ClearIntegratedToolStripButton.Text = "Clear all values"
        '
        'ToolStripSeparator19
        '
        Me.ToolStripSeparator19.Name = "ToolStripSeparator19"
        Me.ToolStripSeparator19.Size = New System.Drawing.Size(6, 25)
        '
        'AddValuesButton
        '
        Me.AddValuesButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AddValuesButton.Image = CType(resources.GetObject("AddValuesButton.Image"), System.Drawing.Image)
        Me.AddValuesButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AddValuesButton.Name = "AddValuesButton"
        Me.AddValuesButton.Size = New System.Drawing.Size(23, 22)
        Me.AddValuesButton.Text = "Add values"
        '
        'DelValsToolStripButton
        '
        Me.DelValsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DelValsToolStripButton.Enabled = False
        Me.DelValsToolStripButton.Image = CType(resources.GetObject("DelValsToolStripButton.Image"), System.Drawing.Image)
        Me.DelValsToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DelValsToolStripButton.Name = "DelValsToolStripButton"
        Me.DelValsToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.DelValsToolStripButton.Text = "Delete values"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'ToggleDisplayModeButton
        '
        Me.ToggleDisplayModeButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToggleDisplayModeButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LinearToolStripMenuItem, Me.LogarithmToolStripMenuItem})
        Me.ToggleDisplayModeButton.Image = CType(resources.GetObject("ToggleDisplayModeButton.Image"), System.Drawing.Image)
        Me.ToggleDisplayModeButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToggleDisplayModeButton.Name = "ToggleDisplayModeButton"
        Me.ToggleDisplayModeButton.Size = New System.Drawing.Size(32, 22)
        Me.ToggleDisplayModeButton.Text = "Toggle display mode for integrated values"
        '
        'LinearToolStripMenuItem
        '
        Me.LinearToolStripMenuItem.Checked = True
        Me.LinearToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.LinearToolStripMenuItem.Name = "LinearToolStripMenuItem"
        Me.LinearToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.LinearToolStripMenuItem.Text = "Linear"
        '
        'LogarithmToolStripMenuItem
        '
        Me.LogarithmToolStripMenuItem.Name = "LogarithmToolStripMenuItem"
        Me.LogarithmToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.LogarithmToolStripMenuItem.Text = "Logarithm"
        '
        'QuantStyleSplitButton
        '
        Me.QuantStyleSplitButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.QuantStyleSplitButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FrameToolStripMenuItem, Me.FillToolStripMenuItem})
        Me.QuantStyleSplitButton.Image = CType(resources.GetObject("QuantStyleSplitButton.Image"), System.Drawing.Image)
        Me.QuantStyleSplitButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.QuantStyleSplitButton.Name = "QuantStyleSplitButton"
        Me.QuantStyleSplitButton.Size = New System.Drawing.Size(32, 22)
        Me.QuantStyleSplitButton.Text = "Draw style"
        '
        'FrameToolStripMenuItem
        '
        Me.FrameToolStripMenuItem.Checked = True
        Me.FrameToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.FrameToolStripMenuItem.Name = "FrameToolStripMenuItem"
        Me.FrameToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.FrameToolStripMenuItem.Text = "Frame"
        '
        'FillToolStripMenuItem
        '
        Me.FillToolStripMenuItem.Name = "FillToolStripMenuItem"
        Me.FillToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.FillToolStripMenuItem.Text = "Fill"
        '
        'MultValuesButton
        '
        Me.MultValuesButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.MultValuesButton.Image = CType(resources.GetObject("MultValuesButton.Image"), System.Drawing.Image)
        Me.MultValuesButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.MultValuesButton.Name = "MultValuesButton"
        Me.MultValuesButton.Size = New System.Drawing.Size(23, 22)
        Me.MultValuesButton.Text = "Multiply values"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(6, 25)
        '
        'SaveBlocksButton
        '
        Me.SaveBlocksButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveBlocksButton.Enabled = False
        Me.SaveBlocksButton.Image = CType(resources.GetObject("SaveBlocksButton.Image"), System.Drawing.Image)
        Me.SaveBlocksButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveBlocksButton.Name = "SaveBlocksButton"
        Me.SaveBlocksButton.Size = New System.Drawing.Size(23, 22)
        Me.SaveBlocksButton.Text = "Save values"
        '
        'BlocksDifexpressionButton
        '
        Me.BlocksDifexpressionButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BlocksDifexpressionButton.Image = CType(resources.GetObject("BlocksDifexpressionButton.Image"), System.Drawing.Image)
        Me.BlocksDifexpressionButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BlocksDifexpressionButton.Name = "BlocksDifexpressionButton"
        Me.BlocksDifexpressionButton.Size = New System.Drawing.Size(23, 22)
        Me.BlocksDifexpressionButton.Text = "Calculate coverage for blocks"
        '
        'ScanSlipperingToolStripButton
        '
        Me.ScanSlipperingToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ScanSlipperingToolStripButton.Image = CType(resources.GetObject("ScanSlipperingToolStripButton.Image"), System.Drawing.Image)
        Me.ScanSlipperingToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ScanSlipperingToolStripButton.Name = "ScanSlipperingToolStripButton"
        Me.ScanSlipperingToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.ScanSlipperingToolStripButton.Text = "Slippering"
        '
        'ScanSameIntervalToolStripButton
        '
        Me.ScanSameIntervalToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ScanSameIntervalToolStripButton.Image = CType(resources.GetObject("ScanSameIntervalToolStripButton.Image"), System.Drawing.Image)
        Me.ScanSameIntervalToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ScanSameIntervalToolStripButton.Name = "ScanSameIntervalToolStripButton"
        Me.ScanSameIntervalToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.ScanSameIntervalToolStripButton.Text = "Scan for CDS in same intervals"
        '
        'IntervalMarkTableButton
        '
        Me.IntervalMarkTableButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.IntervalMarkTableButton.Image = CType(resources.GetObject("IntervalMarkTableButton.Image"), System.Drawing.Image)
        Me.IntervalMarkTableButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.IntervalMarkTableButton.Name = "IntervalMarkTableButton"
        Me.IntervalMarkTableButton.Size = New System.Drawing.Size(23, 22)
        Me.IntervalMarkTableButton.Text = "MarkIntervals"
        '
        'PositionalValues
        '
        Me.PositionalValues.Controls.Add(Me.PositionalValuesDataGridView)
        Me.PositionalValues.Controls.Add(Me.PositionalValuesToolStrip)
        Me.PositionalValues.Location = New System.Drawing.Point(4, 22)
        Me.PositionalValues.Name = "PositionalValues"
        Me.PositionalValues.Size = New System.Drawing.Size(1130, 149)
        Me.PositionalValues.TabIndex = 2
        Me.PositionalValues.Text = "Pileup"
        Me.PositionalValues.UseVisualStyleBackColor = True
        '
        'PositionalValuesDataGridView
        '
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PositionalValuesDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.PositionalValuesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PositionalValuesDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ChartVisible, Me.ChartName, Me.ChartStrand, Me.ChartColor, Me.ChartScale, Me.Holder_Group_Col, Me.NewLaneCol})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PositionalValuesDataGridView.DefaultCellStyle = DataGridViewCellStyle8
        Me.PositionalValuesDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PositionalValuesDataGridView.Location = New System.Drawing.Point(0, 25)
        Me.PositionalValuesDataGridView.Name = "PositionalValuesDataGridView"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PositionalValuesDataGridView.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.PositionalValuesDataGridView.Size = New System.Drawing.Size(1130, 124)
        Me.PositionalValuesDataGridView.TabIndex = 1
        '
        'ChartVisible
        '
        Me.ChartVisible.HeaderText = "Visible"
        Me.ChartVisible.Name = "ChartVisible"
        Me.ChartVisible.Width = 50
        '
        'ChartName
        '
        Me.ChartName.HeaderText = "Name"
        Me.ChartName.Name = "ChartName"
        Me.ChartName.Width = 300
        '
        'ChartStrand
        '
        Me.ChartStrand.HeaderText = "Direction"
        Me.ChartStrand.Items.AddRange(New Object() {"Plus", "Minus", "Undefined"})
        Me.ChartStrand.Name = "ChartStrand"
        Me.ChartStrand.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.ChartStrand.Width = 60
        '
        'ChartColor
        '
        Me.ChartColor.HeaderText = "Color"
        Me.ChartColor.Name = "ChartColor"
        Me.ChartColor.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ChartColor.Width = 50
        '
        'ChartScale
        '
        Me.ChartScale.HeaderText = "Scale"
        Me.ChartScale.Items.AddRange(New Object() {"Logarithm", "Linear"})
        Me.ChartScale.Name = "ChartScale"
        Me.ChartScale.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.ChartScale.Width = 80
        '
        'Holder_Group_Col
        '
        Me.Holder_Group_Col.HeaderText = "Group"
        Me.Holder_Group_Col.Name = "Holder_Group_Col"
        Me.Holder_Group_Col.Width = 200
        '
        'NewLaneCol
        '
        Me.NewLaneCol.HeaderText = "Separate lane"
        Me.NewLaneCol.Name = "NewLaneCol"
        '
        'PositionalValuesToolStrip
        '
        Me.PositionalValuesToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DeleteAllPosValuesButton, Me.ToolStripSeparator10, Me.PositionalButton, Me.DeleteCurrentPosValButton, Me.ToolStripSeparator12, Me.NormalizationTypeButton, Me.AllDataStyleButton, Me.AllVisibleButton, Me.ToolStripSplitButton1, Me.ToolStripSeparator22, Me.SmoothToolStripButton, Me.SavePileupButton, Me.AssemblePileupButton, Me.ToolStripSeparator24, Me.ShiftCovLeftToolStripButton, Me.ShiftCovRightToolStripButton})
        Me.PositionalValuesToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.PositionalValuesToolStrip.Name = "PositionalValuesToolStrip"
        Me.PositionalValuesToolStrip.Size = New System.Drawing.Size(1130, 25)
        Me.PositionalValuesToolStrip.TabIndex = 0
        Me.PositionalValuesToolStrip.Text = "ToolStrip1"
        '
        'DeleteAllPosValuesButton
        '
        Me.DeleteAllPosValuesButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DeleteAllPosValuesButton.Image = CType(resources.GetObject("DeleteAllPosValuesButton.Image"), System.Drawing.Image)
        Me.DeleteAllPosValuesButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DeleteAllPosValuesButton.Name = "DeleteAllPosValuesButton"
        Me.DeleteAllPosValuesButton.Size = New System.Drawing.Size(23, 22)
        Me.DeleteAllPosValuesButton.Text = "Delete all"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(6, 25)
        '
        'PositionalButton
        '
        Me.PositionalButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PositionalButton.Image = CType(resources.GetObject("PositionalButton.Image"), System.Drawing.Image)
        Me.PositionalButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PositionalButton.Name = "PositionalButton"
        Me.PositionalButton.Size = New System.Drawing.Size(23, 22)
        Me.PositionalButton.Text = "Import values"
        '
        'DeleteCurrentPosValButton
        '
        Me.DeleteCurrentPosValButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DeleteCurrentPosValButton.Enabled = False
        Me.DeleteCurrentPosValButton.Image = CType(resources.GetObject("DeleteCurrentPosValButton.Image"), System.Drawing.Image)
        Me.DeleteCurrentPosValButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DeleteCurrentPosValButton.Name = "DeleteCurrentPosValButton"
        Me.DeleteCurrentPosValButton.Size = New System.Drawing.Size(23, 22)
        Me.DeleteCurrentPosValButton.Text = "Delete values"
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(6, 25)
        '
        'NormalizationTypeButton
        '
        Me.NormalizationTypeButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NormalizationTypeButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AllChartsToolStripMenuItem, Me.IndividualToolStripMenuItem})
        Me.NormalizationTypeButton.Image = CType(resources.GetObject("NormalizationTypeButton.Image"), System.Drawing.Image)
        Me.NormalizationTypeButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NormalizationTypeButton.Name = "NormalizationTypeButton"
        Me.NormalizationTypeButton.Size = New System.Drawing.Size(32, 22)
        Me.NormalizationTypeButton.Text = "Normalization type"
        '
        'AllChartsToolStripMenuItem
        '
        Me.AllChartsToolStripMenuItem.Name = "AllChartsToolStripMenuItem"
        Me.AllChartsToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.AllChartsToolStripMenuItem.Text = "All chats"
        '
        'IndividualToolStripMenuItem
        '
        Me.IndividualToolStripMenuItem.Checked = True
        Me.IndividualToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.IndividualToolStripMenuItem.Name = "IndividualToolStripMenuItem"
        Me.IndividualToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.IndividualToolStripMenuItem.Text = "Individual"
        '
        'AllDataStyleButton
        '
        Me.AllDataStyleButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AllDataStyleButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LinearPileupToolStripMenuItem, Me.LogarithmPileupToolStripMenuItem})
        Me.AllDataStyleButton.Image = CType(resources.GetObject("AllDataStyleButton.Image"), System.Drawing.Image)
        Me.AllDataStyleButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.AllDataStyleButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AllDataStyleButton.Name = "AllDataStyleButton"
        Me.AllDataStyleButton.Size = New System.Drawing.Size(32, 22)
        Me.AllDataStyleButton.Text = "Data scale"
        '
        'LinearPileupToolStripMenuItem
        '
        Me.LinearPileupToolStripMenuItem.Name = "LinearPileupToolStripMenuItem"
        Me.LinearPileupToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.LinearPileupToolStripMenuItem.Text = "Linear"
        '
        'LogarithmPileupToolStripMenuItem
        '
        Me.LogarithmPileupToolStripMenuItem.Name = "LogarithmPileupToolStripMenuItem"
        Me.LogarithmPileupToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.LogarithmPileupToolStripMenuItem.Text = "Logarithm"
        '
        'AllVisibleButton
        '
        Me.AllVisibleButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AllVisibleButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SelectAllToolStripMenuItem, Me.UnselectAllToolStripMenuItem})
        Me.AllVisibleButton.Image = CType(resources.GetObject("AllVisibleButton.Image"), System.Drawing.Image)
        Me.AllVisibleButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AllVisibleButton.Name = "AllVisibleButton"
        Me.AllVisibleButton.Size = New System.Drawing.Size(32, 22)
        Me.AllVisibleButton.Text = "Select all"
        '
        'SelectAllToolStripMenuItem
        '
        Me.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem"
        Me.SelectAllToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.SelectAllToolStripMenuItem.Text = "Select all"
        '
        'UnselectAllToolStripMenuItem
        '
        Me.UnselectAllToolStripMenuItem.Name = "UnselectAllToolStripMenuItem"
        Me.UnselectAllToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.UnselectAllToolStripMenuItem.Text = "Unselect all"
        '
        'ToolStripSplitButton1
        '
        Me.ToolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripSplitButton1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LineToolStripMenuItem, Me.BarToolStripMenuItem})
        Me.ToolStripSplitButton1.Image = CType(resources.GetObject("ToolStripSplitButton1.Image"), System.Drawing.Image)
        Me.ToolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripSplitButton1.Name = "ToolStripSplitButton1"
        Me.ToolStripSplitButton1.Size = New System.Drawing.Size(32, 22)
        Me.ToolStripSplitButton1.Text = "Pileup draw style"
        '
        'LineToolStripMenuItem
        '
        Me.LineToolStripMenuItem.Checked = True
        Me.LineToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.LineToolStripMenuItem.Image = CType(resources.GetObject("LineToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LineToolStripMenuItem.Name = "LineToolStripMenuItem"
        Me.LineToolStripMenuItem.Size = New System.Drawing.Size(96, 22)
        Me.LineToolStripMenuItem.Text = "Line"
        '
        'BarToolStripMenuItem
        '
        Me.BarToolStripMenuItem.Image = CType(resources.GetObject("BarToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BarToolStripMenuItem.Name = "BarToolStripMenuItem"
        Me.BarToolStripMenuItem.Size = New System.Drawing.Size(96, 22)
        Me.BarToolStripMenuItem.Text = "Bar"
        '
        'ToolStripSeparator22
        '
        Me.ToolStripSeparator22.Name = "ToolStripSeparator22"
        Me.ToolStripSeparator22.Size = New System.Drawing.Size(6, 25)
        '
        'SmoothToolStripButton
        '
        Me.SmoothToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SmoothToolStripButton.Enabled = False
        Me.SmoothToolStripButton.Image = CType(resources.GetObject("SmoothToolStripButton.Image"), System.Drawing.Image)
        Me.SmoothToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SmoothToolStripButton.Name = "SmoothToolStripButton"
        Me.SmoothToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.SmoothToolStripButton.Text = "Smooth coverage"
        '
        'SavePileupButton
        '
        Me.SavePileupButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SavePileupButton.Enabled = False
        Me.SavePileupButton.Image = CType(resources.GetObject("SavePileupButton.Image"), System.Drawing.Image)
        Me.SavePileupButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SavePileupButton.Name = "SavePileupButton"
        Me.SavePileupButton.Size = New System.Drawing.Size(23, 22)
        Me.SavePileupButton.Text = "Save pileup"
        '
        'AssemblePileupButton
        '
        Me.AssemblePileupButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AssemblePileupButton.Enabled = False
        Me.AssemblePileupButton.Image = CType(resources.GetObject("AssemblePileupButton.Image"), System.Drawing.Image)
        Me.AssemblePileupButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AssemblePileupButton.Name = "AssemblePileupButton"
        Me.AssemblePileupButton.Size = New System.Drawing.Size(23, 22)
        Me.AssemblePileupButton.Text = "Merge pileup into table"
        '
        'ToolStripSeparator24
        '
        Me.ToolStripSeparator24.Name = "ToolStripSeparator24"
        Me.ToolStripSeparator24.Size = New System.Drawing.Size(6, 25)
        '
        'ShiftCovLeftToolStripButton
        '
        Me.ShiftCovLeftToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ShiftCovLeftToolStripButton.Enabled = False
        Me.ShiftCovLeftToolStripButton.Image = CType(resources.GetObject("ShiftCovLeftToolStripButton.Image"), System.Drawing.Image)
        Me.ShiftCovLeftToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ShiftCovLeftToolStripButton.Name = "ShiftCovLeftToolStripButton"
        Me.ShiftCovLeftToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.ShiftCovLeftToolStripButton.Text = "Shift coverage left"
        Me.ShiftCovLeftToolStripButton.ToolTipText = "Shift coverage left"
        '
        'ShiftCovRightToolStripButton
        '
        Me.ShiftCovRightToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ShiftCovRightToolStripButton.Enabled = False
        Me.ShiftCovRightToolStripButton.Image = CType(resources.GetObject("ShiftCovRightToolStripButton.Image"), System.Drawing.Image)
        Me.ShiftCovRightToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ShiftCovRightToolStripButton.Name = "ShiftCovRightToolStripButton"
        Me.ShiftCovRightToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.ShiftCovRightToolStripButton.Text = "Shift coverage right"
        Me.ShiftCovRightToolStripButton.ToolTipText = "Shift coverage right"
        '
        'ScrollTimer
        '
        '
        'Genome_Viewer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.PrimarySplitContainer)
        Me.Name = "Genome_Viewer"
        Me.Size = New System.Drawing.Size(1346, 637)
        Me.PrimarySplitContainer.Panel2.ResumeLayout(False)
        Me.PrimarySplitContainer.ResumeLayout(False)
        Me.SecondarySplitContainer.Panel1.ResumeLayout(False)
        Me.SecondarySplitContainer.Panel1.PerformLayout()
        Me.SecondarySplitContainer.Panel2.ResumeLayout(False)
        Me.SecondarySplitContainer.ResumeLayout(False)
        Me.GraphicsSplitContainer.Panel1.ResumeLayout(False)
        Me.GraphicsSplitContainer.ResumeLayout(False)
        Me.DrawPanelMenu.ResumeLayout(False)
        Me.TranslationContextMenuStrip.ResumeLayout(False)
        Me.GraphPanelMenuStrip.ResumeLayout(False)
        Me.SequenceContextMenu.ResumeLayout(False)
        Me.EditorToolStrip.ResumeLayout(False)
        Me.EditorToolStrip.PerformLayout()
        Me.ViewerToolStrip.ResumeLayout(False)
        Me.ViewerToolStrip.PerformLayout()
        Me.FeaturesTabControl.ResumeLayout(False)
        Me.Features.ResumeLayout(False)
        Me.Features.PerformLayout()
        CType(Me.FeaturesGroupDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DataContextMenu.ResumeLayout(False)
        Me.AnnotationToolStrip.ResumeLayout(False)
        Me.AnnotationToolStrip.PerformLayout()
        Me.Values.ResumeLayout(False)
        Me.Values.PerformLayout()
        CType(Me.IntervalsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.IntervalsMenuStrip.ResumeLayout(False)
        Me.QuantitationToolStrip.ResumeLayout(False)
        Me.QuantitationToolStrip.PerformLayout()
        Me.PositionalValues.ResumeLayout(False)
        Me.PositionalValues.PerformLayout()
        CType(Me.PositionalValuesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PositionalValuesToolStrip.ResumeLayout(False)
        Me.PositionalValuesToolStrip.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PrimarySplitContainer As System.Windows.Forms.SplitContainer
    Friend WithEvents SecondarySplitContainer As System.Windows.Forms.SplitContainer
    Friend WithEvents ViewerToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents StartTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents EndTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents RangeTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents DrawPanelMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents SequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VisibleRangeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FeatureSequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SequenceRetrievalMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SelectedRegionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PlusToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MinusToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PCRToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindPrimersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PlusStrandThermodynamicsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MinusStrandThermodynamicsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CenterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TopologyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProtMapToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DatabaseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddToAnnotationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddOligoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteOligoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripLabel4 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel5 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel6 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel7 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents SearchSequenceTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripLabel8 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents IdentityPercentTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ZoomInButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ZoomOutButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MoveLeftButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents MoveRightButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GoButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SearchButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ScrollTimer As System.Windows.Forms.Timer
    Friend WithEvents DataContextMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CenterViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetSequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AddToLargeScaleViewerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddToVirtual2DEFViewerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator17 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CopyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditorToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents DrawPanel As System.Windows.Forms.Panel
    Friend WithEvents SequencePanel As System.Windows.Forms.Panel
    Friend WithEvents MinimapPanel As System.Windows.Forms.Panel
    Friend WithEvents SearchOptionsDropDownButton As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents ToolStripLabel9 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents OligoNameTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents SequenceContextMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents InsertSequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditSequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteSequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents NewMarkerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SingleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SimpleMarkerButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel10 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents GetMarkedSequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearMarkersButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents PasteSequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CutSequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopySequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LigateSequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PairedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CutRemoveSequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SinglePairedButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents CurrentMarkerLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents SelectForRestrictionPositionAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SelectForRestrictionPositionBToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CutPasteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DesselectRestrictionSitesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetSequenceButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents InsertSequenceButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ReplaceSequenceButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents DeleteSequenceButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents InsertLigationButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ReplaceLigationButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents DeleteRestrictionButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents LeftBorderStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents RightBorderStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents FeaturesTabControl As System.Windows.Forms.TabControl
    Friend WithEvents AlignmentTypeComboBox As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents GraphPanel As System.Windows.Forms.Panel
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FindPrimersForVisibleRangeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PositionalValues As System.Windows.Forms.TabPage
    Friend WithEvents PositionalValuesToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents PositionalValuesDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents PositionalButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents DeleteAllPosValuesButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DeleteCurrentPosValButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents QueryTypeBox As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents Features As System.Windows.Forms.TabPage
    Friend WithEvents AnnotationToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents FeaturesGroupDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents AllFeaturesButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel11 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents QueryTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripLabel12 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents FieldComboBox As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents SearchFeaturesButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel13 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents CountButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel14 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents SearchGroupComboBox As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripSeparator14 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DelFButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents AddFButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents DeleteAllButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator18 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FeaturesGroupsListBox As System.Windows.Forms.ListView
    Friend WithEvents ImportSplitButton As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents AnnotationFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabseparatedFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveFeaturesButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents MergeListsButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents RenameAsmButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents Values As System.Windows.Forms.TabPage
    Friend WithEvents QuantitationToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents ToggleDisplayModeButton As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents LinearToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogarithmToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QuantStyleSplitButton As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents FrameToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FillToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DelValsToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents NormalizationTypeButton As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents AllChartsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IndividualToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GoToSeqButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents MaxOutButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents JumpBackButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents JumpForButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ClearIntegratedToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator19 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AddValuesButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SaveBlocksButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents MultValuesButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator15 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents EraseTableButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents SendSeqMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrimerFinderMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SecondaryStructureFinderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScanSlipperingToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents IntervalsListView As System.Windows.Forms.ListView
    Friend WithEvents IntervalsMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents RenameIntervalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator16 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ColorIntervalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IntervalsDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents ViewIntervalsButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator20 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BlocksCountButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents IntervalID_Col As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntervalStart_Col As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntervalEnd_Col As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntervalDir_Col As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents IntervalValue_Col As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents HolderName_Col As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GraphPanelMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents SplitBlockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MergeBlocksToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteBlockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindBlockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator21 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BlocksDifexpressionButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ScanSameIntervalToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents IntervalMarkTableButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents FindProbesForArrayToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IdentifySiteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TranslatePanel As System.Windows.Forms.Panel
    Friend WithEvents TranslationContextMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ExportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FastaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SynonymousTripletToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TableToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator22 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SavePileupButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents DisplayToTopologyToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator23 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AllDataStyleButton As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents LinearPileupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogarithmPileupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AllVisibleButton As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents SelectAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UnselectAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AssemblePileupButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSplitButton1 As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents LineToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChartVisible As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents ChartName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ChartStrand As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents ChartColor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ChartScale As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Holder_Group_Col As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NewLaneCol As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents GraphicsSplitContainer As System.Windows.Forms.SplitContainer
    Friend WithEvents SmoothToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ShiftCovLeftToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ShiftCovRightToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator24 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents F_TAG As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents F_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents F_Descr As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents F_Start As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents F_End As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents F_Dir As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents F_Type As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents F_Ort As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents F_Read As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Group_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ChangeAminoacidToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AssemblyDesignerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InsertPromoterButton As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents PromoterForwardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PromoterReverseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InsertPromoterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ForwardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReverseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InternalHomologyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyDataButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents PasteDataButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents CopyRegionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasteRegionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CutRegionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FlipRegionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator25 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CutToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents FlipToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents RepeatPlotToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
