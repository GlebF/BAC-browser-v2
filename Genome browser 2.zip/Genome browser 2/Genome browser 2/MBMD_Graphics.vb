﻿Public Class MBMD_Graphics
    Private MyLOGO As New SequenceLOGO
    Private MyResult As New MBMD_Result
    Private MyDistributionPlot As New MotifDistributionPlot
    Private bExpand As Boolean = False
    Private CollapsedH As Integer = 122

    Public Property MBMD_LOGO() As SequenceLOGO
        Get
            MBMD_LOGO = MyLOGO
        End Get
        Set(ByVal value As SequenceLOGO)
            MyLOGO = value
        End Set
    End Property

    Public Property SearchResult() As MBMD_Result
        Get
            SearchResult = MyResult
        End Get
        Set(ByVal value As MBMD_Result)
            MyResult = value
        End Set
    End Property

    Public Property DistributionPlot() As MotifDistributionPlot
        Get
            DistributionPlot = MyDistributionPlot
        End Get
        Set(ByVal value As MotifDistributionPlot)
            MyDistributionPlot = value
        End Set
    End Property

    Private Sub MBMD_Graphics_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MyLOGO.Location = New Point(20, 22)
        Me.Controls.Add(MyLOGO)
        MyDistributionPlot.Location = New Point(20, 122)
        Me.Controls.Add(MyDistributionPlot)
    End Sub

    Private Sub ExpandButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExpandButton.Click

        bExpand = Not bExpand
        If bExpand Then
            Me.Size = New Size(Me.Width, CollapsedH + MyDistributionPlot.Height)
        Else
            Me.Size = New Size(Me.Width, CollapsedH)
        End If

    End Sub

    Private Sub SavePWMButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SavePWMButton.Click
        Dim ShannonPWM As New PWM

        Dim SeqList As New List(Of Char())
        For Each Seq As String In MyLOGO.Sequences_List
            SeqList.Add(Seq.ToCharArray)
        Next Seq

        ShannonPWM = Bioinformatics.CalculateInformationContent(SeqList, True)

        PWMbuilder.SavePWM(ShannonPWM)
    End Sub

    Private Sub SeqButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SeqButton.Click
        Dim Result As String = ""
        For Each Hit As K_Word_PWM_Hit In MyResult.Motif_Hits
            Result &= Hit.Word_Text & vbNewLine 'Hit.Aligned_Seq_ID & vbTab & 
        Next
        Clipboard.SetText(Result)

    End Sub
End Class
