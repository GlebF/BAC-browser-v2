﻿Public Class QuantitativeCoverageStep
    Inherits CoverageStep

    Private sglCoverageBeforeStep As Single
    Private sglCoverageAfterStep As Single
    Private sglCoverageInStep As Single
    Private sglStepCoverageVariation As Single

    Public Property CoverageBeforeStep() As Single
        Get
            CoverageBeforeStep = sglCoverageBeforeStep
        End Get
        Set(ByVal value As Single)
            sglCoverageBeforeStep = value
        End Set
    End Property

    Public Property CoverageAfterStep() As Single
        Get
            CoverageAfterStep = sglCoverageAfterStep
        End Get
        Set(ByVal value As Single)
            sglCoverageAfterStep = value
        End Set
    End Property

    Public Property CoverageInStep() As Single
        Get
            CoverageInStep = sglCoverageInStep
        End Get
        Set(ByVal value As Single)
            sglCoverageInStep = value
        End Set
    End Property

    Public Property StepCoverageVariation() As Single
        Get
            StepCoverageVariation = sglStepCoverageVariation
        End Get
        Set(ByVal value As Single)
            sglStepCoverageVariation = value
        End Set
    End Property

End Class
