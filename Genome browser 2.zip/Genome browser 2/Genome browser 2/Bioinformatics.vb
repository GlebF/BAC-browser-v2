﻿Public Class Bioinformatics
    Const R As Single = 1.987
    Const SpaceChar As Char = "-"


#Region "Math"

    Public Shared Function Get_Random(ByVal Low As Integer, ByVal High As Integer)
        Return Math.Floor((High - Low + 1) * Rnd() + Low)
    End Function

    Public Shared Function Maximum(ByVal Val1 As Integer, ByVal Val2 As Integer, ByVal Val3 As Integer)
        Dim Result As Integer = Val1
        If Val2 > Result Then
            Result = Val2
        End If

        If Val3 > Result Then
            Result = Val3
        End If


        Return Result
    End Function

    Public Shared Function Maximum(ByVal Values() As Integer)
        Dim Max As Integer = Values(0)
        For Each Value As Integer In Values
            If Value > Max Then
                Max = Value
            End If
        Next
        Return Max
    End Function

    Public Shared Function Minimum(ByVal Values() As Integer)
        Dim Min As Integer = Values(0)
        For Each Value As Integer In Values
            If Value < Min Then
                Min = Value
            End If
        Next
        Return Min
    End Function

    Public Shared Function Maximum(ByVal Values() As Short)
        Dim Max As Short = Values(0)
        For Each Value As Short In Values
            If Value > Max Then
                Max = Value
            End If
        Next
        Return Max
    End Function

    Public Shared Function Minimum(ByVal Values() As Short)
        Dim Min As Short = Values(0)
        For Each Value As Short In Values
            If Value < Min Then
                Min = Value
            End If
        Next
        Return Min
    End Function

    Public Shared Function Maximum(ByVal Values() As Single)
        Dim Max As Single = Values(0)
        For Each Value As Single In Values
            If Value > Max Then
                Max = Value
            End If
        Next
        Return Max
    End Function

    Public Shared Function Maximum(ByVal Values As List(Of Single))
        Dim Max As Single = Values(0)
        For Each Value As Single In Values
            If Value > Max Then
                Max = Value
            End If
        Next
        Return Max
    End Function

    Public Shared Function Maximum(ByVal Values As List(Of Integer))
        Dim Max As Integer = Values(0)
        For Each Value As Integer In Values
            If Value > Max Then
                Max = Value
            End If
        Next
        Return Max
    End Function

    Public Shared Function Minimum(ByVal Values() As Single)
        Dim Min As Single = Values(0)
        For Each Value As Single In Values
            If Value < Min Then
                Min = Value
            End If
        Next
        Return Min
    End Function

    Public Shared Function Minimum(ByVal Values As List(Of Single))
        Dim Min As Single = Values(0)
        For Each Value As Single In Values
            If Value < Min Then
                Min = Value
            End If
        Next
        Return Min
    End Function

    Public Shared Function Minimum(ByVal Values As List(Of Integer))
        Dim Min As Integer = Values(0)
        For Each Value As Integer In Values
            If Value < Min Then
                Min = Value
            End If
        Next
        Return Min
    End Function

    Public Shared Function Get_Angle_Deg(ByVal Ref_Point As Point, ByVal Target_Point As Point)

        Dim deltaY As Single = Ref_Point.Y - Target_Point.Y
        Dim deltaX As Single = Ref_Point.X - Target_Point.X

        Dim angle As Single = 180 * (Math.Acos(deltaY / (deltaX ^ 2 + deltaY ^ 2) ^ (0.5))) / Math.PI

        If Target_Point.X < Ref_Point.X Then
            angle = 360 - angle
        End If

        Return angle
    End Function

    Public Shared Function Get_Radius_Int(ByVal Ref_Point As Point, ByVal Target_Point As Point)

        Dim deltaY As Single = Ref_Point.Y - Target_Point.Y
        Dim deltaX As Single = Ref_Point.X - Target_Point.X
        Dim Radius As Integer = Math.Sqrt(deltaX ^ 2 + deltaY ^ 2)

        Return Radius
    End Function

    Public Shared Function GetIntSubList(ByVal intList As List(Of Integer), ByVal StartIndex As Integer, ByVal Length As Integer)
        Dim SubList As New List(Of Integer)

        For i = StartIndex To StartIndex + Length - 1
            SubList.Add(intList(i))
        Next

        Return SubList
    End Function

    Public Shared Function GetIntSubList(ByVal intList As List(Of Integer), ByVal StartIndex As Integer)
        Dim SubList As New List(Of Integer)

        For i = StartIndex To intList.Count - 1
            SubList.Add(intList(i))
        Next

        Return SubList
    End Function

    Public Shared Function ConcatIntLists(ByVal intList1 As List(Of Integer), ByVal intList2 As List(Of Integer))
        Dim NewList As New List(Of Integer)
        For i = 0 To intList1.Count - 1
            NewList.Add(intList1(i))
        Next

        For i = 0 To intList2.Count - 1
            NewList.Add(intList2(i))
        Next

        Return NewList
    End Function

    Public Shared Function GetSglSubList(ByVal sglList As List(Of Single), ByVal StartIndex As Single, ByVal Length As Single)
        Dim SubList As New List(Of Single)

        For i = StartIndex To StartIndex + Length - 1
            SubList.Add(sglList(i))
        Next

        Return SubList
    End Function

    Public Shared Function GetSglSubList(ByVal sglList As List(Of Single), ByVal StartIndex As Single)
        Dim SubList As New List(Of Single)

        For i = StartIndex To sglList.Count - 1
            SubList.Add(sglList(i))
        Next

        Return SubList
    End Function

    Public Shared Function ConcatSglLists(ByVal sglList1 As List(Of Single), ByVal sglList2 As List(Of Single))
        Dim NewList As New List(Of Single)
        For i = 0 To sglList1.Count - 1
            NewList.Add(sglList1(i))
        Next

        For i = 0 To sglList2.Count - 1
            NewList.Add(sglList2(i))
        Next

        Return NewList
    End Function

    Public Shared Function TransposeDataTable(ByVal Table As DataTable)
        Dim T_Table As New DataTable


        For i = 0 To Table.Rows.Count - 1
            T_Table.Columns.Add()
        Next


        For i = 0 To Table.Columns.Count - 1
            T_Table.Rows.Add()
        Next

        For i = 0 To Table.Columns.Count - 1
            For j = 0 To Table.Rows.Count - 1
                T_Table.Rows(i).Item(j) = Table.Rows(j).Item(i)
            Next
        Next


        Return T_Table

    End Function

    Public Shared Function Factorial(ByVal Val As Integer)

        Dim Result As Double = 1

        If Val > 0 Then
            For i = 1 To Val
                Result *= i
            Next
        ElseIf Val < 0 Then
            Result = 0
        End If

        Return Result

    End Function

#End Region

#Region "Statistics"

    Public Shared Function Median(ByVal Data As List(Of Integer))

        Dim Result As Single = 0
        Dim DVR As Long = 0

        Data.Sort()
        Dim Index As Integer = Math.DivRem(Data.Count, 2, DVR)

        If DVR = 0 Then
            Result = (Data(Index - 1) + Data(Index)) / 2
        Else
            Result = Data(Index)
        End If

        Return Result
    End Function

    Public Shared Function Median(ByVal Data As List(Of Single), Optional ByVal ExcludeZero As Boolean = False)

        Dim Result As Single = 0
        Dim DVR As Long = 0

        If ExcludeZero Then
            For i = Data.Count - 1 To 0 Step -1
                If Data(i) = 0 Then
                    Data.RemoveAt(i)
                End If
            Next i
        End If


        Data.Sort()
        Dim Index As Integer = Math.DivRem(Data.Count, 2, DVR)

        If DVR = 0 Then
            Result = (Data(Index - 1) + Data(Index)) / 2
        Else
            Result = Data(Index)
        End If

        Return Result
    End Function

    Public Shared Function GeometricMean(ByVal Data As List(Of Integer))
        Dim Result As Double = 1

        For Each Value As Integer In Data
            Result *= Value
        Next Value

        Result = Result ^ (1 / Data.Count)

        Return Result
    End Function

    Public Shared Function GeometricMean(ByVal Data As List(Of Single))
        Dim Result As Double = 1

        For Each Value As Single In Data
            Result *= Value
        Next Value

        Result = Result ^ (1 / Data.Count)

        Return Result
    End Function

    Public Shared Function StandartDeviation(ByVal Data As List(Of Integer))
        Dim SD As Single = 0
        Dim MeanValue As Single = 0
        Dim Sum As Integer = 0
        For Each Value As Integer In Data
            Sum += Value
        Next

        MeanValue = Sum / Data.Count

        Dim S As Single = 0

        For Each Value As Integer In Data
            S += (Value - MeanValue) ^ 2
        Next

        Dim Sigma As Single = Math.Sqrt(S / Data.Count)

        SD = Math.Sqrt(Data.Count / (Data.Count - 1) * Sigma ^ 2)

        Return SD
    End Function

    Public Shared Function StandartDeviation(ByVal Data As List(Of Single))
        Dim SD As Single = 0
        Dim MeanValue As Single = 0
        Dim Sum As Single = 0
        For Each Value As Single In Data
            Sum += Value
        Next

        MeanValue = Sum / Data.Count

        Dim S As Single = 0

        For Each Value As Single In Data
            S += (Value - MeanValue) ^ 2
        Next

        Dim Sigma As Single = Math.Sqrt(S / Data.Count)

        SD = Math.Sqrt(Data.Count / (Data.Count - 1) * Sigma ^ 2)

        Return SD
    End Function

    Public Shared Function SD_corridor(ByVal Data As List(Of Integer), Optional ByVal SD_multiplier As Integer = 1)
        Dim Result(2) As Single

        Dim SD As Single = 0
        Dim MeanValue As Single = 0
        Dim Sum As Integer = 0
        For Each Value As Integer In Data
            Sum += Value
        Next

        MeanValue = Sum / Data.Count

        Dim S As Single = 0

        For Each Value As Integer In Data
            S += (Value - MeanValue) ^ 2
        Next

        SD = Math.Sqrt(S / Data.Count)


        Result(0) = MeanValue + SD * SD_multiplier
        Result(1) = MeanValue
        Result(2) = MeanValue - SD * SD_multiplier


        Return Result
    End Function

    Public Shared Function StandartDeviationAndMeanValue(ByVal Data As List(Of Integer))
        Dim SD As Single = 0
        Dim MeanValue As Single = 0
        Dim Sum As Integer = 0
        For Each Value As Integer In Data
            Sum += Value
        Next

        MeanValue = Sum / Data.Count

        Dim S As Single = 0

        For Each Value As Integer In Data
            S += (Value - MeanValue) ^ 2
        Next

        Dim Sigma As Single = Math.Sqrt(S / Data.Count)

        SD = Math.Sqrt(Data.Count / (Data.Count - 1) * Sigma ^ 2)

        Dim Result(2) As Single
        Result(0) = MeanValue
        Result(1) = SD
        Result(2) = Sigma

        Return Result
    End Function

    Public Shared Function GetPoissonProbability(ByVal Mean As Integer, ByVal Iterator As Integer)
        Return ((Mean ^ Iterator) * Math.E ^ (-Mean)) / Factorial(Iterator)
    End Function

    Public Shared Function GetPoissonCorridor(ByVal Mean As Integer, ByVal pVal As Single)

        Dim Result(2) As Integer

        Dim CumulativeProbability As Single = 0
        Dim ThresholdProbability As Single = 1 - pVal


        Dim C_Mean As Integer = 0
        Dim Norm As Integer = 0

        If Mean > 0 Then
            Norm = Math.Log10(Mean)
        End If


        Dim Demultiplicator As Integer = 1
        Dim IteratorFor As Integer = 0
        Dim IteratorRev As Integer = 0
        Dim Lim As Integer = 0

        If Norm <= 2 Then '<100
            C_Mean = Mean
        Else
            Demultiplicator = 10 ^ (Norm - 2)
            C_Mean = Mean / Demultiplicator
        End If


        IteratorFor = C_Mean
        IteratorRev = C_Mean - 1

        Do

            CumulativeProbability += GetPoissonProbability(C_Mean, IteratorFor)
            CumulativeProbability += GetPoissonProbability(C_Mean, IteratorRev)

            If CumulativeProbability >= ThresholdProbability Then
                Exit Do
            End If

            IteratorFor += 1
            IteratorRev -= 1
            Lim += 1

            If Lim > 100 Then
                Exit Do
            End If

        Loop

        If Norm > 2 Then
            IteratorRev *= Demultiplicator
            IteratorFor *= Demultiplicator
        End If


        Result(0) = Mean
        Result(1) = IteratorRev 'Min
        Result(2) = IteratorFor 'Max



        Return Result
    End Function

#End Region

#Region "Sequence operations"


    Public Shared Function CountCharacters(ByVal Sequence As Char(), ByVal Character As Char)
        Dim ChrNum As Integer = 0

        For Each Chr As Char In Sequence
            If Character = Chr Then
                ChrNum += 1
            End If
        Next

        Return ChrNum
    End Function

    Public Shared Function AppendCharacters(ByVal Seq As String, ByVal AddChar As Char, ByVal Count As Integer, ByVal AppendToTail As Boolean)
        Dim Result As String = ""
        Dim AppendString As String = ""

        For i = 1 To Count
            AppendString &= AddChar
        Next

        If AppendToTail Then 'False - append to head, True - append to tail
            Result = Seq & AppendString
        Else
            Result = AppendString & Seq
        End If

        Return Result
    End Function

    Public Shared Function TrimChars(ByVal Seq As String, ByVal TrimChar As Char, ByVal MaxDropoff As Integer, ByVal TrimTail As Boolean)
        Dim TrimmedSeq As String = ""

        Dim CurrentN As Char = ""
        Dim CurrentDropOff As Integer = MaxDropoff
        Dim i As Integer = 0

        If TrimTail Then

            For i = Seq.Length - 1 To 0 Step -1
                CurrentN = Seq.Substring(i, 1)

                If CurrentN = TrimChar And CurrentDropOff < MaxDropoff Then
                    CurrentDropOff += 1
                End If

                If Not CurrentN = TrimChar Then
                    CurrentDropOff -= 1
                End If

                If CurrentDropOff = 0 Then
                    Exit For
                End If

            Next

            TrimmedSeq = Seq.Substring(0, i + 2)

        Else
            For i = 0 To Seq.Length - 1
                CurrentN = Seq.Substring(i, 1)

                If CurrentN = TrimChar And CurrentDropOff < MaxDropoff Then
                    CurrentDropOff += 1
                End If

                If Not CurrentN = TrimChar Then
                    CurrentDropOff -= 1
                End If

                If CurrentDropOff = 0 Then
                    Exit For
                End If

            Next

            TrimmedSeq = Seq.Substring(i - 1)

        End If



        Return TrimmedSeq
    End Function

    Public Shared Function GetCharacters(ByVal AddChar As Char, ByVal Count As Integer)
        Dim Result As String = ""

        For i = 1 To Count
            Result &= AddChar
        Next

        Return Result
    End Function

    Public Shared Function GetComplement(ByVal Seq As String)
        Seq = Seq.Replace(Chr(13), vbNullString)
        Seq = Seq.Replace(Chr(10), vbNullString)

        Dim Strand As Char() = Seq.ToCharArray
        Dim ComplementStrand(Seq.Length - 1) As Char
        Dim i As Integer = 0
        For i = 0 To Strand.Length - 1
            'ReDim Preserve ComplementStrand(i)
            Char.ToUpperInvariant(Strand(i))
            Select Case Strand(i)
                Case "A"
                    ComplementStrand(i) = "T"
                Case "G"
                    ComplementStrand(i) = "C"
                Case "C"
                    ComplementStrand(i) = "G"
                Case "T"
                    ComplementStrand(i) = "A"
                Case "N"
                    ComplementStrand(i) = "N"
                Case "U"
                    ComplementStrand(i) = "A"
                Case "I"
                    ComplementStrand(i) = "C"
                Case "R"
                    ComplementStrand(i) = "Y"
                Case "Y"
                    ComplementStrand(i) = "R"
                Case "W"
                    ComplementStrand(i) = "W"
                Case "S"
                    ComplementStrand(i) = "S"
                Case "K"
                    ComplementStrand(i) = "M"
                Case "M"
                    ComplementStrand(i) = "K"
                Case "B"
                    ComplementStrand(i) = "V"
                Case "V"
                    ComplementStrand(i) = "B"
                Case "D"
                    ComplementStrand(i) = "H"
                Case "H"
                    ComplementStrand(i) = "D"
                Case "-"
                    ComplementStrand(i) = "-"
                Case Else
                    ComplementStrand(i) = "N"
            End Select

        Next

        Dim Result As String = New String(ComplementStrand)

        Return Result

    End Function

    Public Shared Function ReverseStrand(ByVal Seq As String)
        Seq = Seq.Replace(Chr(13), vbNullString)
        Seq = Seq.Replace(Chr(10), vbNullString)

        Dim Strand As Char() = Seq.ToCharArray

        Array.Reverse(Strand)

        Return New String(Strand)
    End Function

    Public Shared Function GetReverseComplement(ByVal Seq As String)
        Return ReverseStrand(GetComplement(Seq))
    End Function

    Public Shared Function IsComplement(ByVal N1 As Char, ByVal N2 As Char)
        Char.ToUpperInvariant(N1)
        Char.ToUpperInvariant(N2)
        If (N1 = "A" And N2 = "T") Or (N1 = "T" And N2 = "A") Then
            Return True
        End If
        If (N1 = "G" And N2 = "C") Or (N1 = "C" And N2 = "G") Then
            Return True
        End If
        If (N1 = "A" And N2 = "U") Or (N1 = "U" And N2 = "A") Then
            Return True
        End If
        If (N1 = "I" And N2 = "C") Or (N1 = "C" And N2 = "I") Then
            Return True
        End If

        Return False
    End Function

    Public Shared Function IsComplementRNA(ByVal N1 As Char, ByVal N2 As Char, Optional ByVal Use_GU As Boolean = True)
        Char.ToUpperInvariant(N1)
        Char.ToUpperInvariant(N2)
        If (N1 = "A" And N2 = "U") Or (N1 = "U" And N2 = "A") Then
            Return True
        End If
        If (N1 = "G" And N2 = "C") Or (N1 = "C" And N2 = "G") Then
            Return True
        End If

        If Use_GU Then
            If (N1 = "G" And N2 = "U") Or (N1 = "U" And N2 = "G") Then
                Return True
            End If
        End If

        If (N1 = "I" And N2 = "C") Or (N1 = "C" And N2 = "I") Then
            Return True
        End If

        Return False
    End Function

    Public Shared Function IsEquivalent(ByVal Seq1 As Char(), ByVal Seq2 As Char())
        Dim result As Boolean = False

        If Seq1.Length = Seq2.Length Then
            Dim Found As Boolean = False

            For i = 0 To Seq1.GetUpperBound(0)
                If IsEquivalentN(Seq1(i), Seq2(i)) Then
                    Found = True
                Else
                    Found = False
                End If

                If Not Found Then
                    result = False
                    Exit For
                End If

            Next

            If Found Then
                result = True
            End If

        Else
            result = False
        End If

        Return result
    End Function

    Public Shared Function IsEquivalentN(ByVal N1 As Char, ByVal N2 As Char)
        If N1 = N2 Then
            Return True
        End If

        If (N1 = "R" And N2 = "A") Or (N1 = "A" And N2 = "R") Then
            Return True
        End If

        If (N1 = "R" And N2 = "G") Or (N1 = "G" And N2 = "R") Then
            Return True
        End If

        If (N1 = "Y" And N2 = "C") Or (N1 = "C" And N2 = "Y") Then
            Return True
        End If

        If (N1 = "Y" And N2 = "T") Or (N1 = "T" And N2 = "Y") Then
            Return True
        End If

        If (N1 = "S" And N2 = "C") Or (N1 = "C" And N2 = "S") Then
            Return True
        End If

        If (N1 = "S" And N2 = "G") Or (N1 = "G" And N2 = "S") Then
            Return True
        End If

        If (N1 = "W" And N2 = "A") Or (N1 = "A" And N2 = "W") Then
            Return True
        End If

        If (N1 = "W" And N2 = "T") Or (N1 = "T" And N2 = "W") Then
            Return True
        End If

        If (N1 = "K" And N2 = "G") Or (N1 = "G" And N2 = "K") Then
            Return True
        End If

        If (N1 = "K" And N2 = "T") Or (N1 = "T" And N2 = "K") Then
            Return True
        End If

        If (N1 = "M" And N2 = "A") Or (N1 = "A" And N2 = "M") Then
            Return True
        End If

        If (N1 = "M" And N2 = "C") Or (N1 = "C" And N2 = "M") Then
            Return True
        End If

        If (N1 = "B" And Not N2 = "A") Or (Not N1 = "A" And N2 = "B") Then
            Return True
        End If

        If (N1 = "D" And Not N2 = "C") Or (Not N1 = "C" And N2 = "D") Then
            Return True
        End If

        If (N1 = "H" And Not N2 = "G") Or (Not N1 = "G" And N2 = "H") Then
            Return True
        End If

        If (N1 = "V" And Not N2 = "T") Or (Not N1 = "T" And N2 = "V") Then
            Return True
        End If

        If N1 = "N" Or N2 = "N" Then
            Return True
        End If


        Return False
    End Function

    Public Shared Function ContainsEquivalent(ByVal DataString As String, ByVal QueryString As String)
        Dim CoordArray As New List(Of Integer)
        Dim DataSubstring As String = ""
        Dim FrameReader As Integer = 0
        For i = 0 To DataString.Length - QueryString.Length
            DataSubstring = DataString.Substring(FrameReader, QueryString.Length)
            If IsEquivalent(DataSubstring, QueryString) Then
                CoordArray.Add(FrameReader)
            End If
            FrameReader += 1
        Next
        Return CoordArray
    End Function

    Public Shared Function DetectClamp(ByVal Sequence As String, ByVal ClampValue As Integer)
        Dim NSeq As Char() = Sequence.Substring(Sequence.Length - 5, 5).ToCharArray
        Dim ClampCounter As Integer = 0

        For Each Nucleotide As Char In NSeq
            If Nucleotide = "G" Or Nucleotide = "C" Then
                ClampCounter += 1
            End If
        Next

        Dim result As Boolean = False
        If ClampCounter >= ClampValue Then
            result = True
        End If

        Return result
    End Function

    Public Shared Function ReadGeneticCode(ByVal Tripplete As String, ByVal CodeTable As DataTable)
        Dim AA As String = "#"

        For Each Code As DataRow In CodeTable.Rows
            If Code.Item(0) = Tripplete Then
                AA = Code.Item(1)
                Exit For
            End If
        Next

        Return AA
    End Function

    Public Shared Function Translate(ByVal Sequence As String, ByVal CodeTable As DataTable, Optional ByVal AddSeparator As Boolean = False)
        Dim TranslatedSequence As String = ""
        Dim CurrentTripplete As String = ""
        Dim CurrentAA As String = ""
        Dim FrameReader As Integer = 0
        Dim Separator As Char = ""


        If AddSeparator Then

            Separator = "-"

            Dim Max As Integer = Math.Truncate(Sequence.Length / 3) - 1
            Dim ResultCharArray(Max * 3 + 2) As Char


            For i = 0 To Max

                CurrentTripplete = Sequence.Substring(FrameReader, 3)
                CurrentAA = ReadGeneticCode(CurrentTripplete, CodeTable)
                'TranslatedSequence &= Separator & CurrentAA & Separator



                ResultCharArray(FrameReader) = Separator
                ResultCharArray(FrameReader + 1) = CurrentAA
                ResultCharArray(FrameReader + 2) = Separator


                FrameReader += 3
            Next i

            TranslatedSequence = ResultCharArray


            'ReportForm.ReportTextBox.Text &= TranslatedSequence & vbNewLine & TranslatedSequence.Length & vbNewLine


        Else

            Dim Max As Integer = Math.Truncate(Sequence.Length / 3) - 1
            Dim ResultCharArray(Max) As Char

            For i = 0 To Max

                CurrentTripplete = Sequence.Substring(FrameReader, 3)
                CurrentAA = ReadGeneticCode(CurrentTripplete, CodeTable)
                ResultCharArray(i) = CurrentAA

                FrameReader += 3
            Next i

            TranslatedSequence = ResultCharArray

        End If



        Return TranslatedSequence
    End Function

    Public Shared Function GetOppositeDirection(ByVal Dir As Short)
        If Dir = 1 Then
            Return 2
        ElseIf Dir = 2 Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Public Shared Function GetTranslationTable(ByVal TableCode As Short)
        Dim SpecificTableFile As String = String.Concat(My.Computer.FileSystem.CurrentDirectory, "\Translation\Table-", TableCode, ".txt")
        Dim UniversalTableFile As String = String.Concat(My.Computer.FileSystem.CurrentDirectory, "\Translation\Table-1.txt")

        Dim CodeTable As New DataTable
        CodeTable.Columns.Add("Tripplet")
        CodeTable.Columns.Add("Aminoacid")

        If My.Computer.FileSystem.FileExists(SpecificTableFile) Then

            Dim ReadStream As New IO.FileStream(SpecificTableFile, IO.FileMode.Open, IO.FileAccess.Read)
            Dim Reader As New IO.StreamReader(ReadStream)
            Dim CurrentLine As String = ""
            Dim Values As String()

            While Reader.Peek > -1
                CurrentLine = Reader.ReadLine
                Values = CurrentLine.Split(Chr(9))
                CodeTable.Rows.Add(Values(0), Values(1))
            End While

            Reader.Close()
            ReadStream.Close()
            Reader.Dispose()
            ReadStream.Dispose()

        Else

            If My.Computer.FileSystem.FileExists(UniversalTableFile) Then

                Dim ReadStream As New IO.FileStream(UniversalTableFile, IO.FileMode.Open, IO.FileAccess.Read)
                Dim Reader As New IO.StreamReader(ReadStream)
                Dim CurrentLine As String = ""
                Dim Values As String()

                While Reader.Peek > -1
                    CurrentLine = Reader.ReadLine
                    Values = CurrentLine.Split(Chr(9))
                    CodeTable.Rows.Add(Values(0), Values(1))
                End While

                Reader.Close()
                ReadStream.Close()
                Reader.Dispose()
                ReadStream.Dispose()

            Else
                MsgBox("Translation table not found!", MsgBoxStyle.Critical, "Error")
            End If
        End If

        Return CodeTable
    End Function

    Public Shared Function GetCodeNamesTable()
        Dim FilePath As String = String.Concat(My.Computer.FileSystem.CurrentDirectory, "\Translation\Codes.txt")
        Dim CodeList As New DataTable

        CodeList.Columns.Add("Code")
        CodeList.Columns.Add("Description")

        Dim ReadStream As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(ReadStream)
        Dim CurrentLine As String = ""
        Dim Values As String()

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            Values = CurrentLine.Split(Chr(9))
            CodeList.Rows.Add(Values(0), Values(1))
        End While

        Reader.Close()
        ReadStream.Close()
        Reader.Dispose()
        ReadStream.Dispose()

        Return CodeList
    End Function

    Public Shared Function UngappedSequenceSearch(ByVal SubjectSequence As String, ByVal QuerySequence As String, Optional ByVal Identity As Single = 1, Optional ByVal RC_Tag As Boolean = False)
        QuerySequence = QuerySequence.ToUpper

        Dim Coord As New List(Of CoordHit)
        Dim CurrentSeq As String = ""
        Dim FastSearch As Boolean = True
        Dim Hits As Integer = 0

        If QuerySequence.Contains("R") _
           Or QuerySequence.Contains("Y") _
           Or QuerySequence.Contains("S") _
           Or QuerySequence.Contains("W") _
           Or QuerySequence.Contains("K") _
           Or QuerySequence.Contains("M") _
           Or QuerySequence.Contains("B") _
           Or QuerySequence.Contains("D") _
           Or QuerySequence.Contains("H") _
           Or QuerySequence.Contains("V") Then
            FastSearch = False
        Else
            FastSearch = True
        End If

        If Identity = 1 Then

            If QuerySequence.Contains("N") Then
                FastSearch = False
            End If

            If FastSearch Then

                For i = 0 To SubjectSequence.Length - QuerySequence.Length
                    CurrentSeq = SubjectSequence.Substring(i, QuerySequence.Length)
                    If CurrentSeq = QuerySequence Then
                        Coord.Add(New CoordHit(i + 1, 100))
                    End If
                Next

            Else

                For i = 0 To SubjectSequence.Length - QuerySequence.Length
                    CurrentSeq = SubjectSequence.Substring(i, QuerySequence.Length)

                    If IsEquivalent(CurrentSeq, QuerySequence) Then
                        Coord.Add(New CoordHit(i + 1, 100))
                    End If
                Next

            End If

        Else

            If FastSearch Then

                For i = 0 To SubjectSequence.Length - QuerySequence.Length
                    CurrentSeq = SubjectSequence.Substring(i, QuerySequence.Length)
                    Hits = 0

                    For j = 0 To QuerySequence.Length - 1
                        If CurrentSeq(j) = QuerySequence(j) Or QuerySequence(j) = "N" Then
                            Hits += 1
                        End If
                    Next

                    If Hits / QuerySequence.Length >= Identity Then
                        Coord.Add(New CoordHit(i + 1, Math.Round(Hits / QuerySequence.Length, 2) * 100, RC_Tag))
                    End If
                Next

            Else

                For i = 0 To SubjectSequence.Length - QuerySequence.Length
                    CurrentSeq = SubjectSequence.Substring(i, QuerySequence.Length)
                    Hits = 0

                    For j = 0 To QuerySequence.Length - 1
                        If IsEquivalentN(CurrentSeq(j), QuerySequence(j)) Then
                            Hits += 1
                        End If
                    Next

                    If Hits / QuerySequence.Length >= Identity Then
                        Coord.Add(New CoordHit(i + 1, Math.Round(Hits / QuerySequence.Length, 2) * 100, RC_Tag))
                    End If
                Next

            End If

        End If

        Return Coord
    End Function

    Public Shared Function UngappedSequenceSearch_DS(ByVal SubjectSequence As String, ByVal QuerySequence As String, Optional ByVal Identity As Single = 1)
        Dim HitList As New List(Of CoordHit)
        HitList.AddRange(UngappedSequenceSearch(SubjectSequence, QuerySequence, Identity))
        HitList.AddRange(UngappedSequenceSearch(SubjectSequence, GetReverseComplement(QuerySequence), Identity, True))

        Return HitList
    End Function

    Public Shared Function GetSites()
        Dim FilePath As String = String.Concat(My.Computer.FileSystem.CurrentDirectory, "\Sites\Sites.txt")
        Dim SiteSeqList As New DataTable

        SiteSeqList.Columns.Add("Name")
        SiteSeqList.Columns.Add("Seq")

        Dim ReadStream As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(ReadStream)
        Dim CurrentLine As String = ""
        Dim Values As String()

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            Values = CurrentLine.Split(Chr(9))
            SiteSeqList.Rows.Add(Values(0), Values(1))
        End While

        Reader.Close()
        ReadStream.Close()
        Reader.Dispose()
        ReadStream.Dispose()

        Return SiteSeqList
    End Function

    Public Shared Sub InsertSequence(ByRef Sequence As String, ByVal Insert_Sequence As String, ByVal Position As Integer, Optional ByRef FeaturesGroupList As List(Of FeaturesAssembly) = Nothing, Optional ByVal History As List(Of String) = Nothing)
        Try
            Dim TruePos As Integer = Position - 1

            Sequence = Sequence.Insert(TruePos, Insert_Sequence)

            If Not IsNothing(History) Then
                Dim HistoryRecord As String = ""
                HistoryRecord = "Ins:" & Position & "|" & Insert_Sequence.Length
                History.Add(HistoryRecord)
            End If


            If Not IsNothing(FeaturesGroupList) Then
                For Each Group As FeaturesAssembly In FeaturesGroupList
                    For Each Feature As Genome_Feature In Group.FeaturesList
                        If Feature.AbsoluteStart > TruePos Then
                            Feature.AbsoluteStart += Insert_Sequence.Length
                        End If

                        If Feature.AbsoluteEnd > TruePos Then
                            Feature.AbsoluteEnd += Insert_Sequence.Length
                        End If

                    Next Feature
                Next Group
            End If


            'If Not IsNothing(AccessoryFeatures) Then
            'For Each Feature As Genome_Feature In AccessoryFeatures
            'If Feature.AbsoluteStart > TruePos Then
            'Feature.AbsoluteStart += Insert_Sequence.Length
            'End If

            'If Feature.AbsoluteEnd > TruePos Then
            'Feature.AbsoluteEnd += Insert_Sequence.Length
            'End If

            'Next
            'End If




        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Public Shared Sub DeleteSequence(ByRef Sequence As String, ByVal CutStart As Integer, ByVal CutEnd As Integer, Optional ByRef FeaturesGroupList As List(Of FeaturesAssembly) = Nothing, Optional ByVal History As List(Of String) = Nothing, Optional ByVal UndoList As List(Of Genome_Feature) = Nothing)
        Dim TrueStart As Integer = CutStart - 1
        Dim TrueEnd As Integer = CutEnd - 1
        Dim CutRange As Integer = CutEnd - CutStart


        Dim CutedSeq As String = ""
        If Not IsNothing(History) Then
            CutedSeq = Sequence.Substring(TrueStart, CutRange)
        End If

        Sequence = Sequence.Remove(TrueStart, CutRange)

        Dim HistoryRecord As String = ""


        If Not IsNothing(FeaturesGroupList) Then

            For Each Group As FeaturesAssembly In FeaturesGroupList


                For i = Group.FeaturesList.Count - 1 To 0 Step -1
                    If TrueEnd < Group.FeaturesList(i).AbsoluteStart Then 'Feature is away from deleted region
                        Group.FeaturesList(i).AbsoluteStart -= CutRange
                        Group.FeaturesList(i).AbsoluteEnd -= CutRange
                    ElseIf TrueStart > Group.FeaturesList(i).AbsoluteEnd And TrueStart > Group.FeaturesList(i).AbsoluteStart Then

                    ElseIf TrueStart <= Group.FeaturesList(i).AbsoluteStart And TrueEnd >= Group.FeaturesList(i).AbsoluteEnd Then 'Feature within deleted range
                        If Not IsNothing(History) And Not IsNothing(UndoList) Then
                            UndoList.Add(Group.FeaturesList(i))
                            HistoryRecord = "Del:" & Group.FeaturesList(i).TAG & "|Asm=" & Group.AssemblyName
                            History.Add(HistoryRecord)
                        End If
                        Group.FeaturesList.Remove(Group.FeaturesList(i))

                    ElseIf TrueStart >= Group.FeaturesList(i).AbsoluteStart And TrueEnd <= Group.FeaturesList(i).AbsoluteEnd Then 'Deleted range is within feature
                        Group.FeaturesList(i).AbsoluteEnd -= CutRange

                    ElseIf TrueStart >= Group.FeaturesList(i).AbsoluteStart And TrueEnd >= Group.FeaturesList(i).AbsoluteEnd Then  'End of the feature is within deleted range
                        Group.FeaturesList(i).AbsoluteEnd = TrueStart

                    ElseIf TrueStart <= Group.FeaturesList(i).AbsoluteStart And TrueEnd <= Group.FeaturesList(i).AbsoluteEnd Then  'Start of the feature is within deleted range
                        Group.FeaturesList(i).AbsoluteStart = TrueStart + 1
                        Group.FeaturesList(i).AbsoluteEnd -= CutRange

                    End If

                Next i
            Next Group


        End If


        'If Not IsNothing(AccessoryFeatures) Then
        'For i = AccessoryFeatures.Count - 1 To 0 Step -1
        'If AccessoryFeatures(i).AbsoluteStart > TrueEnd Then 'Feature is away from deleted region
        'AccessoryFeatures(i).AbsoluteStart -= CutRange
        'AccessoryFeatures(i).AbsoluteEnd -= CutRange
        'ElseIf TrueStart < AccessoryFeatures(i).AbsoluteStart And TrueEnd > AccessoryFeatures(i).AbsoluteEnd Then 'Feature within deleted range
        'AccessoryFeatures.Remove(Features(i))
        'ElseIf TrueStart > AccessoryFeatures(i).AbsoluteStart And TrueEnd < AccessoryFeatures(i).AbsoluteEnd Then 'Deleted range is within feature
        'AccessoryFeatures(i).AbsoluteEnd -= CutRange
        'ElseIf TrueStart > AccessoryFeatures(i).AbsoluteStart And TrueEnd > AccessoryFeatures(i).AbsoluteEnd Then  'End of the feature is within deleted range
        'AccessoryFeatures(i).AbsoluteEnd = TrueStart
        'ElseIf TrueStart < AccessoryFeatures(i).AbsoluteStart And TrueEnd < AccessoryFeatures(i).AbsoluteEnd Then  'Start of the feature is within deleted range
        'AccessoryFeatures(i).AbsoluteStart = TrueEnd
        'End If
        'Next
        'End If


        If Not IsNothing(History) Then
            HistoryRecord = "Cut:" & TrueStart & "|" & CutedSeq
            History.Add(HistoryRecord)
        End If


    End Sub

    Public Shared Function ClearSeq(ByVal Seq As String)
        Dim ClearedSeq As String = ""
        Dim CharSeq As Char() = Seq.ToCharArray
        For Each Item As Char In CharSeq
            If _
            Item = Chr(65) Or _
            Item = Chr(67) Or _
            Item = Chr(71) Or _
            Item = Chr(84) Or _
            Item = Chr(78) Or _
            Item = Chr(82) Or _
            Item = Chr(89) Or _
            Item = Chr(83) Or _
            Item = Chr(87) Or _
            Item = Chr(75) Or _
            Item = Chr(77) Or _
            Item = Chr(66) Or _
            Item = Chr(68) Or _
            Item = Chr(72) Or _
            Item = Chr(87) Then

                ClearedSeq &= Item
            End If

            If Item = Chr(85) Then
                ClearedSeq &= Chr(84)
            End If

        Next

        Return ClearedSeq
    End Function

    Public Shared Function BisulphiteTreatment(ByVal Seq As String, ByVal Pattern As List(Of String))

        Dim ResultString As String = ""
        Dim SiteRunner As String = ""
        Dim BlockedPositions As New List(Of Integer)

        For Each Site As String In Pattern

            For i = 0 To Seq.Length - Site.Length
                SiteRunner = Seq.Substring(i, Site.Length)
                If SiteRunner = Site Then
                    For j = 0 To Site.Length - 1
                        BlockedPositions.Add(i + j)
                    Next
                End If
            Next

        Next

        Dim Blocked As Boolean = False

        For i = 0 To Seq.Length - 1

            Blocked = False
            For Each BlockedPos As Integer In BlockedPositions
                If i = BlockedPos Then
                    Blocked = True
                    Exit For
                End If
            Next

            If Seq(i) = "C" Then
                If Blocked Then
                    ResultString &= Seq(i)
                Else
                    ResultString &= "T"
                End If
            Else
                ResultString &= Seq(i)
            End If

        Next


        Return ResultString
    End Function

    Public Shared Function DNA_To_RNA(ByVal Seq As String)
        Dim RNA As String = Seq.Replace("T", "U")
        Return RNA
    End Function

    Public Shared Function RNA_To_DNA(ByVal Seq As String)
        Dim DNA As String = Seq.Replace("U", "T")
        Return DNA
    End Function

    Public Shared Function GetRandomSequence(ByVal SeqLength As Integer, ByVal GC_content As Integer)
        Dim Result As String = ""

        Dim A As Integer = 0
        Dim G As Integer = 0
        Dim T As Integer = 0
        Dim C As Integer = 0

        Dim CurrentChar As Char = ""


        For i = 0 To SeqLength - 1

            If Bioinformatics.Get_Random(1, 100) <= GC_content Then 'char = G or C

                If Bioinformatics.Get_Random(0, 1) = 0 Then
                    G += 1
                    CurrentChar = "G"
                Else
                    C += 1
                    CurrentChar = "C"
                End If

            Else 'char = A or T

                If Bioinformatics.Get_Random(0, 1) = 0 Then
                    A += 1
                    CurrentChar = "A"
                Else
                    T += 1
                    CurrentChar = "T"
                End If

            End If

            Result &= CurrentChar

        Next

        Return Result

    End Function

#End Region

#Region "Oligo properties"

    Public Shared Function GetOligoThermodynamicsList()
        Dim FilePath As String = String.Concat(My.Computer.FileSystem.CurrentDirectory, "\Oligo\Thermodynamics.txt")
        Dim OligoThermodynamics As New DataTable

        OligoThermodynamics.Columns.Add("Seq")
        OligoThermodynamics.Columns.Add("dH")
        OligoThermodynamics.Columns.Add("dS")

        Dim ReadStream As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(ReadStream)
        Dim CurrentLine As String = ""
        Dim Values As String()

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            Values = CurrentLine.Split(Chr(9))
            OligoThermodynamics.Rows.Add(Values(0), Values(1), Values(2))
        End While

        Reader.Close()
        ReadStream.Close()
        Reader.Dispose()
        ReadStream.Dispose()

        Return OligoThermodynamics
    End Function

    Public Shared Function GetOligoThermodynamicsList_RNA()
        Dim FilePath As String = String.Concat(My.Computer.FileSystem.CurrentDirectory, "\Oligo\RNA_Thermodynamics.txt")
        Dim OligoThermodynamics As New DataTable

        OligoThermodynamics.Columns.Add("Seq")
        OligoThermodynamics.Columns.Add("dH")
        OligoThermodynamics.Columns.Add("dS")

        Dim ReadStream As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(ReadStream)
        Dim CurrentLine As String = ""
        Dim Values As String()

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            Values = CurrentLine.Split(Chr(9))
            OligoThermodynamics.Rows.Add(Values(0), Values(1), Values(2))
        End While

        Reader.Close()
        ReadStream.Close()
        Reader.Dispose()
        ReadStream.Dispose()

        Return OligoThermodynamics
    End Function

    Public Shared Function ReturnThermodynamics(ByVal ThermodynamicsValues As DataTable, ByVal Seq As String)
        Dim DecimalFormat As System.Globalization.NumberFormatInfo = System.Globalization.CultureInfo.InstalledUICulture.NumberFormat.Clone
        DecimalFormat.NumberDecimalSeparator = "."

        Dim Thermodynamics(1) As Single

        For Each Row As DataRow In ThermodynamicsValues.Rows

            If Row.Item(0) = Seq Then
                Thermodynamics(0) = Single.Parse(Row.Item(1), DecimalFormat) 'dH
                Thermodynamics(1) = Single.Parse(Row.Item(2), DecimalFormat) 'dS
            End If

        Next


        Return Thermodynamics
    End Function

    Public Shared Function GetOligoModificationsList()
        Dim FilePath As String = String.Concat(My.Computer.FileSystem.CurrentDirectory, "\Oligo\Modifications.txt")
        Dim OligoModifications As New DataTable

        OligoModifications.Columns.Add("Name")
        OligoModifications.Columns.Add("MW")
        OligoModifications.Columns.Add("Absorbance")

        Dim ReadStream As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(ReadStream)
        Dim CurrentLine As String = ""
        Dim Values As String()

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            Values = CurrentLine.Split(Chr(9))
            OligoModifications.Rows.Add(Values(0), Values(1), Values(2))
        End While

        Reader.Close()
        ReadStream.Close()
        Reader.Dispose()
        ReadStream.Dispose()

        Return OligoModifications
    End Function

    Public Shared Function CalculateCGContent(ByVal Sequence As Char())
        Dim GCcount As Integer = 0
        For Each Nucleotide As Char In Sequence
            If Nucleotide = "G" Or Nucleotide = "C" Then
                GCcount += 1
            End If
        Next

        Return Math.Round((GCcount / Sequence.Length * 100), 1)
    End Function

    Public Shared Function CalculateCGContentAsFraction(ByVal Sequence As Char())
        Dim GCcount As Integer = 0
        For Each Nucleotide As Char In Sequence
            If Nucleotide = "G" Or Nucleotide = "C" Then
                GCcount += 1
            End If
        Next

        Return Math.Round((GCcount / Sequence.Length), 4)
    End Function

    Public Shared Function CalculateAContent(ByVal Sequence As Char())
        Dim count As Integer = 0
        For Each Nucleotide As Char In Sequence
            If Nucleotide = "A" Then
                count += 1
            End If
        Next

        Return Math.Round((count / Sequence.Length * 100), 1)
    End Function

    Public Shared Function CalculateTContent(ByVal Sequence As Char())
        Dim count As Integer = 0
        For Each Nucleotide As Char In Sequence
            If Nucleotide = "T" Then
                count += 1
            End If
        Next

        Return Math.Round((count / Sequence.Length * 100), 1)
    End Function

    Public Shared Function CalculateOligoC(ByVal Sequence As Char(), ByVal OD As Single, ByVal Modification_Absorbance As Integer)
        Dim nT As Integer = 0
        Dim nA As Integer = 0
        Dim nG As Integer = 0
        Dim nC As Integer = 0

        For Each N As Char In Sequence
            Select Case N
                Case "A"
                    nA += 1
                Case "T"
                    nT += 1
                Case "G"
                    nG += 1
                Case "C"
                    nC += 1
            End Select
        Next

        Return Math.Round(OD / (nA * 15200 + nG * 12010 + nC * 7050 + nT * 8400 + Modification_Absorbance) * 10 ^ 6, 4)

    End Function

    Public Shared Function pMolTOmkg(ByVal pMol As Single, ByVal Sequence As Char())
        Return CalculateOligoMass(pMol, CalculateOligoMW(Sequence))
    End Function

    Public Shared Function mkgTOpMol(ByVal mkg As Single, ByVal Sequence As Char())
        Return mkg * 10 ^ 6 / CalculateOligoMW(Sequence)
    End Function

    Public Shared Function MolTopMol(ByVal Mol As Single)
        Return Mol * 10 ^ -6
    End Function

    Public Shared Function CalculateOligoMass(ByVal OligoC As Single, ByVal OligoMW As Single)
        Return Math.Round((OligoC * OligoMW / 10 ^ 6), 4)
    End Function

    Public Shared Function CalculateOligoMW(ByVal Sequence As Char(), Optional ByVal ModificationList As List(Of Single) = Nothing)
        Dim nT As Integer = 0
        Dim nA As Integer = 0
        Dim nG As Integer = 0
        Dim nC As Integer = 0

        For Each N As Char In Sequence
            Select Case N
                Case "A"
                    nA += 1
                Case "T"
                    nT += 1
                Case "G"
                    nG += 1
                Case "C"
                    nC += 1
            End Select
        Next

        Dim Correction As Single = -61.96

        If Not IsNothing(ModificationList) Then
            For Each Modification As Single In ModificationList
                Correction += Modification - 1
            Next
        End If

        Return Math.Round((nA * 313.21 + nT * 304.2 + nC * 289.18 + nG * 329.21 + Correction), 2)
    End Function

    Public Shared Function CalculateThermodynamicSum_SingleStrand(ByVal Sequence As Char(), Optional ByVal CalculateEnds As Boolean = True)

        Dim DH As Single = 0
        Dim DS As Single = 0

        If Not Sequence.Length < 2 Then
            Dim NNList As New List(Of String)
            Dim i As Integer = 0
            For i = 0 To Sequence.GetUpperBound(0) - 1
                NNList.Add(String.Concat(Sequence(i), Sequence(i + 1)))
            Next

            If CalculateEnds Then


                Dim StartThermo As Single() = ReturnThermodynamics(Master.OligoThermodynamics, Sequence(0))
                Dim EndThermo As Single() = ReturnThermodynamics(Master.OligoThermodynamics, Sequence(Sequence.Count - 1))

                DH += StartThermo(0)
                DS += StartThermo(1)
                DH += EndThermo(0)
                DS += EndThermo(1)


                'Select Case Sequence(0)
                'Case "A"
                'DH += 2.3
                'DS += 4.1
                'Case "T"
                'DH += 2.3
                'DS += 4.1
                'Case "G"
                'DH += 0.1
                'DS += -2.8
                'Case "C"
                'DH += 0.1
                'DS += -2.8
                'End Select

                'Select Case Sequence(Sequence.Count - 1)
                'Case "A"
                'DH += 2.3
                'DS += 4.1
                'Case "T"
                'DH += 2.3
                'DS += 4.1
                'Case "G"
                'DH += 0.1
                'DS += -2.8
                'Case "C"
                'DH += 0.1
                'DS += -2.8
                'End Select
            End If

            Dim NN_thermo As Single()

            For Each NN As String In NNList

                NN_thermo = ReturnThermodynamics(Master.OligoThermodynamics, NN)
                DH += NN_thermo(0)
                DS += NN_thermo(1)

                'Select Case NN

                'Case "AA"
                'DH += -7.9
                'DS += -22.2
                'Case "TT"
                'DH += -7.9
                'DS += -22.2
                'Case "AT"
                'DH += -7.2
                'DS += -20.4
                'Case "TA"
                'DH += -7.2
                'DS += -21.3
                'Case "AC"
                'DH += -8.4
                'DS += -22.4
                'Case "TG"
                'DH += -8.5
                'DS += -22.7
                'Case "CA"
                'DH += -8.5
                'DS += -22.7
                'Case "GT"
                'DH += -8.4
                'DS += -22.4
                'Case "CT"
                'DH += -7.8
                'DS += -21
                'Case "GA"
                'DH += -8.2
                'DS += -22.2
                'Case "TC"
                'DH += -8.2
                'DS += -22.2
                'Case "AG"
                'DH += -7.8
                'DS += -21
                'Case "CG"
                'DH += -10.6
                'DS += -27.2
                'Case "GC"
                'DH += -9.8
                'DS += -24.4
                'Case "GG"
                'DH += -8
                'DS += -19.9
                'Case "CC"
                'DH += -8
                'DS += -19.9
                'End Select
            Next


        End If

        Dim Result(3) As Single

        Result(0) = DH
        Result(1) = DS

        Return Result
    End Function

    Public Shared Function CalculateThermodynamicSum_ssRNA(ByVal Sequence As Char(), Optional ByVal CalculateEnds As Boolean = True)

        Dim DH As Single = 0
        Dim DS As Single = 0

        If Not Sequence.Length < 2 Then
            Dim NNList As New List(Of String)
            Dim i As Integer = 0
            For i = 0 To Sequence.GetUpperBound(0) - 1
                NNList.Add(String.Concat(Sequence(i), Sequence(i + 1)))
            Next

            If CalculateEnds Then


                Dim StartThermo As Single() = ReturnThermodynamics(Master.RNAThermodynamics, Sequence(0))
                Dim EndThermo As Single() = ReturnThermodynamics(Master.RNAThermodynamics, Sequence(Sequence.Count - 1))

                DH += StartThermo(0)
                DS += StartThermo(1)
                DH += EndThermo(0)
                DS += EndThermo(1)


                'Select Case Sequence(0)
                'Case "A"
                'DH += 3.72
                'DS += 10.5
                'Case "U"
                'DH += 3.72
                'DS += 10.5
                'Case "G"
                'DH += 0
                'DS += 0
                'Case "C"
                'DH += 0
                'DS += 0
                'End Select

                'Select Case Sequence(Sequence.Count - 1)
                'Case "A"
                'DH += 3.72
                'DS += 10.5
                'Case "U"
                'DH += 3.72
                'DS += 10.5
                'Case "G"
                'DH += 0
                'DS += 0
                'Case "C"
                'DH += 0
                'DS += 0
                'End Select
            End If

            Dim NN_thermo As Single()

            For Each NN As String In NNList


                NN_thermo = ReturnThermodynamics(Master.OligoThermodynamics, NN)
                DH += NN_thermo(0)
                DS += NN_thermo(1)


                'Select Case NN

                'Case "AA"
                'DH += -6.82
                'DS += -19
                'Case "UU"
                'DH += -6.82
                'DS += -19
                'Case "AU"
                'DH += -9.38
                'DS += -26.7
                'Case "UA"
                'DH += -7.69
                'DS += -20.5
                'Case "AC"
                'DH += -11.4
                'DS += -29.5
                'Case "UG"
                'DH += -10.44
                'DS += -26.9
                'Case "CA"
                'DH += -10.44
                'DS += -26.9
                'Case "GU"
                'DH += -11.4
                'DS += -29.5
                'Case "CU"
                'DH += -10.48
                'DS += -27.1
                'Case "GA"
                'DH += -12.44
                'DS += -32.5
                'Case "UC"
                'DH += -12.44
                'DS += -32.5
                'Case "AG"
                'DH += -10.48
                'DS += -27.1
                'Case "CG"
                'DH += -10.64
                'DS += -26.7
                'Case "GC"
                'DH += -14.88
                'DS += -36.9
                'Case "GG"
                'DH += -13.39
                'DS += -32.7
                'Case "CC"
                'DH += -13.39
                'DS += -32.7
                'End Select
            Next


        End If

        Dim Result(3) As Single

        Result(0) = DH
        Result(1) = DS
        Return Result
    End Function

    Public Shared Function CalculateThermodynamicSum(ByVal Sequence As Char(), ByVal ThermodynamicsTable As DataTable, Optional ByVal CalculateEnds As Boolean = True)
        Dim DH As Single = 0
        Dim DS As Single = 0

        Dim DecimalFormat As System.Globalization.NumberFormatInfo = System.Globalization.CultureInfo.InstalledUICulture.NumberFormat.Clone
        DecimalFormat.NumberDecimalSeparator = "."

        If Not Sequence.Length < 2 Then
            Dim NNList As New List(Of String)
            Dim i As Integer = 0
            For i = 0 To Sequence.GetUpperBound(0) - 1
                NNList.Add(String.Concat(Sequence(i), Sequence(i + 1)))
            Next

            If CalculateEnds Then
                For Each Row As DataRow In ThermodynamicsTable.Rows
                    If Sequence(0) = Row.Item(0) Then
                        DH += Single.Parse(Row.Item(1), DecimalFormat)
                        DS += Single.Parse(Row.Item(2), DecimalFormat)
                    End If
                    If Sequence(Sequence.Count - 1) = Row.Item(0) Then
                        DH += Single.Parse(Row.Item(1), DecimalFormat)
                        DS += Single.Parse(Row.Item(2), DecimalFormat)
                    End If
                Next
            End If

            For Each NN As String In NNList
                For Each Row As DataRow In ThermodynamicsTable.Rows
                    If NN = Row.Item(0) Then
                        DH += Single.Parse(Row.Item(1), DecimalFormat)
                        DS += Single.Parse(Row.Item(2), DecimalFormat)
                    End If
                Next
            Next

        End If

        Dim Result(1) As Single

        Result(0) = DH
        Result(1) = DS

        Return Result
    End Function

    Public Shared Function CalculateOligoDG(ByVal Sequence As Char(), ByVal T As Single, Optional ByVal CalculateEnds As Boolean = True)

        Dim OligoThermodynamics As Single() = CalculateThermodynamicSum_SingleStrand(Sequence, CalculateEnds)
        Dim DH As Single = OligoThermodynamics(0)
        Dim DS As Single = OligoThermodynamics(1)

        Dim OligoC As Single = My.Settings.OligoC * 10 ^ -9 'M
        Dim NaC As Single = My.Settings.NaC * 10 ^ -3 'M
        Dim dNTPC As Single = My.Settings.dNTPC  'mM 0.2
        Dim MgC As Single = My.Settings.MgC 'mM 1.5

        Dim MgCorrection As Single = 0
        If MgC > dNTPC Then
            MgCorrection = Math.Sqrt(MgC - dNTPC)
        End If

        Dim IonCorrection As Single = NaC + 120 * MgCorrection / 1000

        Dim adjDS As Single = DS + (0.368 * (Sequence.Length - 1) * Math.Log(IonCorrection))

        Dim DG As Single = Math.Round((DH - adjDS * (273.15 + T) / 1000), 2)

        Return DG
    End Function

    Public Shared Function CalculateOligoDG(ByVal Sequence As Char(), ByVal T As Single, ByVal OligoC As Single, ByVal NaC As Single, ByVal dNTPC As Single, ByVal MgC As Single, Optional ByVal CalculateEnds As Boolean = True)
        Dim OligoThermodynamics As Single() = CalculateThermodynamicSum_SingleStrand(Sequence, CalculateEnds)
        Dim DH As Single = OligoThermodynamics(0)
        Dim DS As Single = OligoThermodynamics(1)

        OligoC = OligoC * 10 ^ -9 'M
        NaC = NaC * 10 ^ -3 'M


        Dim MgCorrection As Single = 0
        If MgC > dNTPC Then
            MgCorrection = Math.Sqrt(MgC - dNTPC)
        End If

        Dim IonCorrection As Single = NaC + 120 * MgCorrection / 1000

        Dim adjDS As Single = DS + (0.368 * (Sequence.Length - 1) * Math.Log(IonCorrection))

        Dim DG As Single = Math.Round((DH - adjDS * (273.15 + T) / 1000), 2)

        Return DG
    End Function

    Public Shared Function CalculateOligoDG_RNA(ByVal Sequence As Char(), ByVal T As Single, Optional ByVal CalculateEnds As Boolean = True)

        Dim OligoThermodynamics As Single() = CalculateThermodynamicSum_ssRNA(Sequence, CalculateEnds)
        Dim DH As Single = OligoThermodynamics(0)
        Dim DS As Single = OligoThermodynamics(1)

        ' Dim OligoC As Single = My.Settings.OligoC * 10 ^ -9 'M
        Dim NaC As Single = 0.2 'My.Settings.NaC * 10 ^ -3 'M
        Dim dNTPC As Single = 0 'My.Settings.dNTPC  'mM 0.2
        Dim MgC As Single = 0 'My.Settings.MgC 'mM 1.5

        Dim MgCorrection As Single = 0
        If MgC > dNTPC Then
            MgCorrection = Math.Sqrt(MgC - dNTPC)
        End If

        Dim IonCorrection As Single = NaC + 120 * MgCorrection / 1000

        Dim adjDS As Single = DS + (0.368 * (Sequence.Length - 1) * Math.Log(IonCorrection))

        Dim DG As Single = Math.Round((DH - adjDS * (273.15 + T) / 1000), 2)

        Return DG
    End Function

    Public Shared Function CalculateOligoTm(ByVal Sequence As Char(), Optional ByVal CalculateEnds As Boolean = True)
        Dim OligoThermodynamics As Single() = CalculateThermodynamicSum_SingleStrand(Sequence, CalculateEnds)
        Dim DH As Single = OligoThermodynamics(0)
        Dim DS As Single = OligoThermodynamics(1)

        Dim OligoC As Single = My.Settings.OligoC * 10 ^ -9 'M
        Dim NaC As Single = My.Settings.NaC * 10 ^ -3 'M
        Dim dNTPC As Single = My.Settings.dNTPC  'mM 0.2
        Dim MgC As Single = My.Settings.MgC 'mM 1.5

        Dim MgCorrection As Single = 0
        If MgC > dNTPC Then
            MgCorrection = Math.Sqrt(MgC - dNTPC)
        End If

        Dim IonCorrection As Single = NaC + 120 * MgCorrection / 1000
        Dim adjDH As Single = DH * 10 ^ 3 'DH is in kcal/mol
        Dim adjDS As Single = DS + (0.368 * (Sequence.Length - 1) * Math.Log(IonCorrection))

        Dim Tm As Single = ((adjDH) / (adjDS + R * Math.Log(OligoC))) - 273.15

        Return Math.Round(Tm, 2)
    End Function

    Public Shared Function CalculateOligoTm(ByVal Sequence As Char(), ByVal OligoC As Single, ByVal NaC As Single, ByVal dNTPC As Single, ByVal MgC As Single, Optional ByVal CalculateEnds As Boolean = True)
        Dim OligoThermodynamics As Single() = CalculateThermodynamicSum_SingleStrand(Sequence, CalculateEnds)
        Dim DH As Single = OligoThermodynamics(0)
        Dim DS As Single = OligoThermodynamics(1)

        OligoC = OligoC * 10 ^ -9 'M
        NaC = NaC * 10 ^ -3 'M

        Dim MgCorrection As Single = 0
        If MgC > dNTPC Then
            MgCorrection = Math.Sqrt(MgC - dNTPC)
        End If

        Dim IonCorrection As Single = NaC + 120 * MgCorrection / 1000
        Dim adjDH As Single = DH * 10 ^ 3 'DH is in kcal/mol
        Dim adjDS As Single = DS + (0.368 * (Sequence.Length - 1) * Math.Log(IonCorrection))

        Dim Tm As Single = ((adjDH) / (adjDS + R * Math.Log(OligoC))) - 273.15

        Return Math.Round(Tm, 2)
    End Function

    Public Shared Function CalculateOligoThermodynamics(ByVal Sequence As Char(), ByVal T As Single)

        Dim OligoThermodynamics As Single() = CalculateThermodynamicSum(Sequence, Master.OligoThermodynamics)
        Dim DH As Single = OligoThermodynamics(0)
        Dim DS As Single = OligoThermodynamics(1)

        Dim OligoC As Single = My.Settings.OligoC * 10 ^ -9 'M
        Dim NaC As Single = My.Settings.NaC * 10 ^ -3 'M
        Dim dNTPC As Single = My.Settings.dNTPC  'mM 0.2
        Dim MgC As Single = My.Settings.MgC 'mM 1.5

        Dim MgCorrection As Single = 0
        If MgC > dNTPC Then
            MgCorrection = Math.Sqrt(MgC - dNTPC)
        End If

        Dim IonCorrection As Single = NaC + 120 * MgCorrection / 1000

        Dim adjDS As Single = DS + (0.368 * (Sequence.Length - 1) * Math.Log(IonCorrection))
        Dim adjDH As Single = DH * 10 ^ 3 'DH is in kcal/mol required only for Tm calculations

        Dim DG As Single = Math.Round((DH - adjDS * (273.15 + T) / 1000), 2)
        Dim Tm As Single = ((adjDH) / (adjDS + R * Math.Log(OligoC))) - 273.15

        Dim Result(3) As Single

        Result(0) = Math.Round(DH, 2)
        Result(1) = Math.Round(adjDS, 2)
        Result(2) = Math.Round(DG, 2)
        Result(3) = Math.Round(Tm, 2)

        Return Result
    End Function

    Public Shared Function CalculateShortOligoTm(ByVal Sequence As Char()) 'For Oligos<14 nt
        Dim nT As Integer = 0
        Dim nA As Integer = 0
        Dim nG As Integer = 0
        Dim nC As Integer = 0

        For Each N As Char In Sequence
            Select Case N
                Case "A"
                    nA += 1
                Case "T"
                    nT += 1
                Case "G"
                    nG += 1
                Case "C"
                    nC += 1
            End Select
        Next

        Return 2 * (nT + nA) + 4 * (nG + nC)
    End Function

#End Region

#Region "Oligo aligner"

    Public Shared Function CreateAlignedList(ByVal Oligo_1 As String, ByVal Oligo_2 As String, ByVal T As Single, ByVal N3cutoff As Short)
        Dim AlignedList As New List(Of OligoAlignment)
        Dim MaxShift As Short = Oligo_1.Length + Oligo_2.Length - 1

        ' 5` and 3` relatively to oligo_1

        Dim Fadd5 As Short = 0
        Dim Fadd3 As Short = 0
        Dim Radd5 As Short = 0
        Dim Radd3 As Short = 0

        For shift = 1 To MaxShift
            Fadd5 = Oligo_2.Length - shift
            Fadd3 = shift - Oligo_1.Length
            Radd5 = shift - Oligo_2.Length
            Radd3 = Oligo_1.Length - shift

            If Fadd5 < 0 Then Fadd5 = 0
            If Fadd3 < 0 Then Fadd3 = 0
            If Radd5 < 0 Then Radd5 = 0
            If Radd3 < 0 Then Radd3 = 0

            Dim NewAlignment As New OligoAlignment
            NewAlignment.ForSeq = GetSpace(Fadd5) & Oligo_1 & GetSpace(Fadd3)
            NewAlignment.RevSeq = GetSpace(Radd5) & Oligo_2 & GetSpace(Radd3)
            NewAlignment.CalculateSumDG(T)
            NewAlignment.CalculateExtensibility(N3cutoff)
            AlignedList.Add(NewAlignment)
        Next


        Return AlignedList
    End Function

    Public Shared Function CreateAlignedList_RNA(ByVal Oligo_1 As String, ByVal Oligo_2 As String, ByVal T As Single)
        Dim AlignedList As New List(Of OligoAlignment)
        Dim MaxShift As Short = Oligo_1.Length + Oligo_2.Length - 1

        ' 5` and 3` relatively to oligo_1

        Dim Fadd5 As Short = 0
        Dim Fadd3 As Short = 0
        Dim Radd5 As Short = 0
        Dim Radd3 As Short = 0

        For shift = 1 To MaxShift
            Fadd5 = Oligo_2.Length - shift
            Fadd3 = shift - Oligo_1.Length
            Radd5 = shift - Oligo_2.Length
            Radd3 = Oligo_1.Length - shift

            If Fadd5 < 0 Then Fadd5 = 0
            If Fadd3 < 0 Then Fadd3 = 0
            If Radd5 < 0 Then Radd5 = 0
            If Radd3 < 0 Then Radd3 = 0

            Dim NewAlignment As New OligoAlignment
            NewAlignment.Fadd3 = Fadd3
            NewAlignment.Fadd5 = Fadd5

            NewAlignment.ForSeq = GetSpace(Fadd5) & Oligo_1 & GetSpace(Fadd3)
            NewAlignment.RevSeq = GetSpace(Radd5) & Oligo_2 & GetSpace(Radd3)
            NewAlignment.CalculateSumDG_RNA(T)
            AlignedList.Add(NewAlignment)
        Next


        Return AlignedList
    End Function

    Public Shared Function CreateHairpinList(ByVal Oligo As String, ByVal T As Single, Optional ByVal N3cutoff As Short = 3, Optional ByVal UseMin_dG As Boolean = False, Optional ByVal Min_dG As Single = 0)


        Dim AlignedList As New List(Of OligoAlignment)


        'Even loops

        Dim MaxShift As Short = Oligo.Length - 1
        Dim add5 As Short = 0
        Dim add3 As Short = 0


        For shift = 1 To MaxShift

            add5 = Oligo.Length - shift * 2
            add3 = shift * 2 - Oligo.Length

            If add5 < 0 Then add5 = 0
            If add3 < 0 Then add3 = 0

            Dim NewAlignment As New OligoAlignment

            NewAlignment.ForSeq = Oligo.Substring(shift) & GetSpace(add3)
            NewAlignment.RevSeq = ReverseStrand(Oligo.Substring(0, shift)) & GetSpace(add5)
            NewAlignment.CalculateSumDG(T)
            NewAlignment.CalculateExtensibility(N3cutoff)

            If Not UseMin_dG Then
                AlignedList.Add(NewAlignment)
            End If

            If UseMin_dG And NewAlignment.SumDG < Min_dG Then
                AlignedList.Add(NewAlignment)
                Exit For
            End If

        Next

        'Odd loops

        MaxShift = Oligo.Length - 2

        For shift = 1 To MaxShift

            add5 = Oligo.Length - (shift * 2 + 1)
            add3 = (shift * 2 + 1) - Oligo.Length

            If add5 < 0 Then add5 = 0
            If add3 < 0 Then add3 = 0

            Dim NewAlignment As New OligoAlignment

            NewAlignment.ForSeq = Oligo.Substring(shift + 1) & GetSpace(add3)
            NewAlignment.RevSeq = ReverseStrand(Oligo.Substring(0, shift)) & GetSpace(add5)
            NewAlignment.OddChar = Oligo.Substring(shift, 1)
            NewAlignment.CalculateSumDG(T)
            NewAlignment.CalculateExtensibility()

            If Not UseMin_dG Then
                AlignedList.Add(NewAlignment)
            End If

            If UseMin_dG And NewAlignment.SumDG < Min_dG Then
                AlignedList.Add(NewAlignment)
                Exit For
            End If

        Next



        Return AlignedList
    End Function

    Public Shared Function GetSpace(ByVal N As Integer)
        Dim Space As String = ""
        For i = 1 To N
            Space &= SpaceChar
        Next
        Return Space
    End Function

    Public Shared Function GetSpaceChar()
        Return SpaceChar
    End Function

    Public Shared Function GetLastLetter(ByVal Seq As String)
        Dim Index As Integer = 0
        Dim CharSeq As Char() = Seq.ToCharArray

        For i = Seq.Length - 1 To 0 Step -1
            If Not CharSeq(i) = SpaceChar Then
                Index = i
                Exit For
            End If
        Next


        Return Index
    End Function

    Public Shared Function GetFirstLetter(ByVal Seq As String)
        Dim Index As Integer = 0
        Dim CharSeq As Char() = Seq.ToCharArray

        For i = 0 To Seq.Length - 1
            If Not CharSeq(i) = SpaceChar Then
                Index = i
                Exit For
            End If
        Next

        Return Index
    End Function

    Public Shared Function GetDimersDG(Optional ByVal ForSeq As String = "", Optional ByVal RevSeq As String = "", Optional ByVal T As Single = 37, Optional ByVal N3complement As Short = 3)
        Dim ForForAlignment As List(Of OligoAlignment) = Nothing
        Dim ForRevAlignment As List(Of OligoAlignment) = Nothing
        Dim RevRevAlignment As List(Of OligoAlignment) = Nothing

        If Not ForSeq = "" Then
            ForForAlignment = Bioinformatics.CreateAlignedList(ForSeq, Bioinformatics.ReverseStrand(ForSeq), T, N3complement)
        End If

        If Not RevSeq = "" Then
            RevRevAlignment = Bioinformatics.CreateAlignedList(RevSeq, Bioinformatics.ReverseStrand(RevSeq), T, N3complement)
        End If

        If Not ForSeq = "" And Not RevSeq = "" Then
            ForRevAlignment = Bioinformatics.CreateAlignedList(ForSeq, Bioinformatics.ReverseStrand(RevSeq), T, N3complement)
        End If


        Dim SuperList As New List(Of Single)
        Dim ExtList As New List(Of Single)
        Dim Result(1) As Single


        'Create single dG filtered list
        If Not IsNothing(ForForAlignment) Then
            For Each Item As OligoAlignment In ForForAlignment
                If Item.SumDG < 0 Then
                    Item.AlignmentName = "For vs For"
                    SuperList.Add(Item.SumDG)
                    If Item.IsExtensible Then
                        ExtList.Add(Item.SumDG)
                    End If
                End If
            Next
        End If

        If Not IsNothing(ForRevAlignment) Then
            For Each Item As OligoAlignment In ForRevAlignment
                If Item.SumDG < 0 Then
                    Item.AlignmentName = "For vs Rev"
                    SuperList.Add(Item.SumDG)
                    If Item.IsExtensible Then
                        ExtList.Add(Item.SumDG)
                    End If
                End If
            Next
        End If

        If Not IsNothing(RevRevAlignment) Then
            For Each Item As OligoAlignment In RevRevAlignment
                If Item.SumDG < 0 Then
                    Item.AlignmentName = "Rev vs Rev"
                    SuperList.Add(Item.SumDG)
                    If Item.IsExtensible Then
                        ExtList.Add(Item.SumDG)
                    End If
                End If
            Next
        End If

        'Sort by dG
        Dim Tmp As Single = 0
        For i = 1 To SuperList.Count - 1
            For j = 0 To SuperList.Count - 1 - i
                If SuperList(j) > SuperList(j + 1) Then
                    Tmp = SuperList(j)
                    SuperList(j) = SuperList(j + 1)
                    SuperList(j + 1) = Tmp
                End If
            Next
        Next

        If Not SuperList.Count = 0 Then
            Result(0) = Minimum(SuperList)
        Else
            Result(0) = 0
        End If

        If Not ExtList.Count = 0 Then
            Result(1) = Minimum(ExtList)
        Else
            Result(1) = 0
        End If

        Return Result
    End Function


#End Region

#Region "Genomics"

    Public Shared Function GetWordExpect(ByVal Word As String, ByVal GC As Single, ByVal SeqLength As Integer, Optional ByVal ReverseComplement As Boolean = True)
        Dim Expect As Integer = 0
        Dim AT_count As Integer = 0
        Dim GC_count As Integer = 0

        Dim GC_freq As Single = GC / 2
        Dim AT_freq As Single = (1 - GC) / 2

        Dim ChrWord As Char() = Word.ToCharArray

        Dim RC_Multiplier As Integer = 1
        If ReverseComplement Then
            RC_Multiplier = 2
        End If

        For Each ChrW As Char In ChrWord
            Select Case ChrW
                Case "A"
                    AT_count += 1
                Case "T"
                    AT_count += 1
                Case "G"
                    GC_count += 1
                Case "C"
                    GC_count += 1
            End Select
        Next

        Expect = AT_freq ^ AT_count * GC_freq ^ GC_count * (SeqLength - Word.Length) * RC_Multiplier



        Return Expect
    End Function

    Public Shared Function DoExtensionStep(ByVal Words As List(Of String))
        Dim ExtendedList As New List(Of String)

        For Each Word As String In Words
            ExtendedList.Add(Word & "A")
            ExtendedList.Add(Word & "G")
            ExtendedList.Add(Word & "T")
            ExtendedList.Add(Word & "C")
        Next

        Return ExtendedList
    End Function

    Public Shared Function GenerateWordSpace(ByVal Length As Integer)
        Dim Words As New List(Of String)

        Words.Add("A")
        Words.Add("G")
        Words.Add("C")
        Words.Add("T")

        For i = 1 To Length - 1
            Words = DoExtensionStep(Words)
        Next

        Return Words
    End Function

    Public Shared Function GetWordStatistics(ByVal Seq As String, ByVal Length As Integer, ByVal GC As Single, _
                                             Optional ByVal MiniProgressBar As ToolStripProgressBar = Nothing, _
                                             Optional ByVal ProgressControlBox As SystemProgressBarBox = Nothing)

        Dim ResultTable As New DataTable 'Format Seq-Count
        Dim strWordSpace As List(Of String) = GenerateWordSpace(Length)


        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.StatusLabel.Text = "Indexing sequence..."
            ProgressControlBox.StatusLabel.Refresh()
        End If

        Dim WordSpaceHashed As New List(Of K_Word_Hashed)
        For Each W As String In strWordSpace
            Dim NewWord As New K_Word_Hashed
            NewWord.Word_Text = W
            NewWord.Hash = HashSeqQuick(NewWord.Word_Text)
            WordSpaceHashed.Add(NewWord)
        Next W

        ResultTable.Columns.Add()
        ResultTable.Columns.Add()
        ResultTable.Columns.Add()



        If Not IsNothing(MiniProgressBar) Then
            MiniProgressBar.Value = 0
            MiniProgressBar.Maximum = WordSpaceHashed.Count + 1
        End If


        Dim SeqChar As Char() = Seq.ToCharArray
        Dim Char_RC(SeqChar.Length - 1) As Char
        Dim counter As Integer = 0

        For i = SeqChar.Length - 1 To 0 Step -1
            Select Case SeqChar(i)
                Case "A"
                    Char_RC(counter) = "T"
                Case "G"
                    Char_RC(counter) = "C"
                Case "C"
                    Char_RC(counter) = "G"
                Case "T"
                    Char_RC(counter) = "A"
            End Select
            counter += 1
        Next

        Dim Sec_RC As New String(Char_RC)

        Dim ForWords As List(Of K_Word_Hashed) = Bioinformatics.Make_K_Word_Hash(Seq, Length)
        Dim RevWords As List(Of K_Word_Hashed) = Bioinformatics.Make_K_Word_Hash(Sec_RC, Length)



        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.MasterProgressBar.Value = 0
            ProgressControlBox.MasterProgressBar.Maximum = WordSpaceHashed.Count + 1
            ProgressControlBox.StatusLabel.Text = "Calculating K-mer space..."
            ProgressControlBox.StatusLabel.Refresh()
        End If




        Dim ForCount As Integer = 0
        Dim RevCount As Integer = 0

        For i = 0 To WordSpaceHashed.Count - 1

            ForCount = 0
            RevCount = 0

            For j = 0 To ForWords.Count - 1
                If ForWords(j).Hash = WordSpaceHashed(i).Hash Then
                    ForCount += 1
                End If
            Next

            For j = 0 To RevWords.Count - 1
                If RevWords(j).Hash = WordSpaceHashed(i).Hash Then
                    RevCount += 1
                End If
            Next

            ResultTable.Rows.Add(WordSpaceHashed(i).Word_Text, ForCount + RevCount, GetWordExpect(WordSpaceHashed(i).Word_Text, GC, Seq.Length))

            If Not IsNothing(MiniProgressBar) Then
                MiniProgressBar.Value += 1
            End If


            If Not IsNothing(ProgressControlBox) Then
                ProgressControlBox.MasterProgressBar.PerformStep()
            End If

        Next

        If Not IsNothing(MiniProgressBar) Then
            MiniProgressBar.Value = 0
        End If

        Return ResultTable
    End Function

    Public Shared Function IsMatch(ByVal QuerySeq As String, ByVal SubjectSeq As String, ByVal MismatchCount As Integer)
        Dim Result As Boolean = False
        Dim Count As Integer = 0

        For i = 0 To SubjectSeq.Length - 1
            If Not QuerySeq(i) = SubjectSeq(i) Then
                Count += 1
                If Count > MismatchCount Then
                    Result = False
                    Exit For
                End If
            End If
        Next i

        If Count <= MismatchCount Then
            Result = True
        End If

        Return Result
    End Function

    Public Shared Function LexAnalysis(ByVal Sequences As List(Of String), Optional ByVal WordLength As Integer = 6, Optional ByVal pVal As Single = 0.05)
        Dim ResultTable As New DataTable
        'General principle
        'Calculate for each word its expect count, poisson range of possible variations of the count (0,05 FDR chance for example), 
        'calculate actual count with account for mismatches (1, 2 ...), identify words that are avoided, they seem to carry regulatory function

        'At first generate wors space
        Dim GeneralWordSpace As List(Of String) = GenerateWordSpace(WordLength)
        Dim ActualWordList As New List(Of String)

        Dim ActualSpaceLength As Integer = 0
        Dim ActualSpaceGC As Single = 0
        Dim GCList As New List(Of Single)


        For Each Seq As String In Sequences
            Dim WordList As List(Of String) = Make_K_Word_List_Simple(Seq, WordLength, True)
            ActualWordList.AddRange(WordList)

            ActualSpaceLength += Seq.Length
            GCList.Add(CalculateCGContentAsFraction(Seq))
        Next Seq



        'Get average GC content
        For Each GC As Single In GCList
            ActualSpaceGC += GC
        Next GC
        ActualSpaceGC /= GCList.Count

        ResultTable.Columns.Add("WordSeq")
        ResultTable.Columns.Add("ExpectCount")
        ResultTable.Columns.Add("MinCount")
        ResultTable.Columns.Add("MaxCount")
        ResultTable.Columns.Add("ActualCount")
        ResultTable.Columns.Add("PoissonTest")
        ResultTable.Columns.Add("Deviation")

        Dim ExpectCount As Integer = 0
        Dim PoissonCorridor As Integer()
        Dim WordCount As Integer = 0

        SystemProgressBarBox.Show()
        SystemProgressBarBox.Focus()

        SystemProgressBarBox.MasterProgressBar.Value = 0
        SystemProgressBarBox.MasterProgressBar.Maximum = GeneralWordSpace.Count + 1
        SystemProgressBarBox.StatusLabel.Text = "Word space = " & GeneralWordSpace.Count
        SystemProgressBarBox.StatusLabel.Refresh()


        Dim PoissonResult As Boolean = False
        Dim Dev As Single = 0

        For Each Word As String In GeneralWordSpace
            SystemProgressBarBox.MasterProgressBar.PerformStep()

            'Find expect count for the given word in a actual space
            'Single-stranded!
            ExpectCount = GetWordExpect(Word, ActualSpaceGC, ActualSpaceLength)

            'Find poisson corridor
            PoissonCorridor = GetPoissonCorridor(ExpectCount, pVal)

            'Find actual count of the word
            'Single-stranded!
            WordCount = 0
            For Each ActualWord As String In ActualWordList
                If ActualWord = Word Then
                    WordCount += 1
                End If
            Next ActualWord

            If WordCount >= PoissonCorridor(1) And WordCount <= PoissonCorridor(2) Then
                PoissonResult = True
            Else
                PoissonResult = False
            End If

            Dev = WordCount / ExpectCount
            ResultTable.Rows.Add(Word, ExpectCount, PoissonCorridor(1), PoissonCorridor(2), WordCount, PoissonResult, Dev)


        Next Word

        SystemProgressBarBox.Close()

        Return ResultTable
    End Function

    Public Shared Function WordDistribution(ByVal Words As List(Of String), ByVal ReferenceSeq As String, ByVal InclusionList As List(Of SequenceCoordinate), ByVal Identity As Single, Optional ByVal RepeatGapMin As Integer = 3, Optional ByVal RepeatGapMax As Integer = 9)
        'Map each word onto reference sequence
        Dim HitList As List(Of CoordHit) = Nothing
        Dim Distance As Integer = 0
        Dim ResultTable As New DataTable
        ResultTable.Columns.Add("Word")
        ResultTable.Columns.Add("Pos")
        ResultTable.Columns.Add("Dir")

        For Each Word As String In Words
            HitList = UngappedSequenceSearch_DS(ReferenceSeq, Word, Identity)

            'Identify words that form repeats
            For i = 0 To HitList.Count - 1

                For j = 0 To HitList.Count - 1
                    ' If Not HitList(j).Used Then


                    Distance = Math.Abs(HitList(i).Position - HitList(j).Position) - Word.Length
                    If Distance >= RepeatGapMin And Distance <= RepeatGapMax Then
                        'One of the repeats must be within inclusion space

                        For Each Pos As SequenceCoordinate In InclusionList
                            If (HitList(i).Position >= Pos.AbsoluteStart And HitList(i).Position <= Pos.AbsoluteEnd) Or (HitList(j).Position >= Pos.AbsoluteStart And HitList(j).Position <= Pos.AbsoluteEnd) Then
                                'Add repeats into the list
                                '  HitList(i).Used = True

                                ResultTable.Rows.Add(Word, HitList(i).Position, HitList(i).RC)
                                ResultTable.Rows.Add(Word, HitList(j).Position, HitList(j).RC)


                            End If
                        Next Pos

                    End If

                    '  End If

                Next j

            Next i

        Next

        Return ResultTable
    End Function

    Public Shared Function GetStructureDistribution(ByVal Seq As String, ByVal WindowL As Integer, ByVal Topology As Boolean, Optional ByVal T As Single = 37, Optional ByVal Multiplier As Single = 1, Optional ByVal ProgressControlBox As SystemProgressBarBox = Nothing)

        Dim dG_values As New List(Of Integer)
        Dim dG As Single = 0

        Dim StartPos As Integer = 0
        Dim EndPos As Integer = 0

        Dim Word As String = ""
        Dim HairpinList As List(Of OligoAlignment) = Nothing

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.Show()
            ProgressControlBox.Focus()
            ProgressControlBox.MasterProgressBar.Maximum = Seq.Length
            ProgressControlBox.MasterProgressBar.Value = 0
            ProgressControlBox.StatusLabel.Text = ""
        End If

        If Topology Then 'Circular DNA
            For i = 1 To Seq.Length


                StartPos = i - WindowL
                EndPos = i + WindowL

                Word = DataIO.RetrieveSeqFromCache(Seq, StartPos, EndPos)

                HairpinList = Bioinformatics.CreateHairpinList(Word, T)

                dG = 0
                For Each Item As OligoAlignment In HairpinList
                    If Item.SumDG < dG Then
                        dG = Item.SumDG
                    End If
                Next Item


                If dG >= 0 Then
                    dG_values.Add(0)
                Else
                    dG_values.Add(Math.Abs(dG * Multiplier))
                End If

                If Not IsNothing(ProgressControlBox) Then
                    ProgressControlBox.MasterProgressBar.PerformStep()
                End If


            Next i
        Else 'Linear DNA

            For i = 1 To WindowL
                dG_values.Add(0)
            Next i

            For i = 1 + WindowL To Seq.Length - WindowL
                StartPos = i - WindowL
                EndPos = i + WindowL

                Word = DataIO.RetrieveSeqFromCache(Seq, StartPos, EndPos)

                HairpinList = Bioinformatics.CreateHairpinList(Word, T)

                dG = 0
                For Each Item As OligoAlignment In HairpinList
                    If Item.SumDG < dG Then
                        dG = Item.SumDG
                    End If
                Next Item

                If dG >= 0 Then
                    dG_values.Add(0)
                Else
                    dG_values.Add(Math.Abs(dG * Multiplier))
                End If

                If Not IsNothing(ProgressControlBox) Then
                    ProgressControlBox.MasterProgressBar.PerformStep()
                End If

            Next i

            For i = 1 To WindowL
                dG_values.Add(0)
            Next i

        End If

        If Not IsNothing(ProgressControlBox) Then
            SystemProgressBarBox.Close()
        End If

        Return dG_values
    End Function

    Public Shared Function GetPolyNDistribution(ByVal Seq As String, ByVal WindowL As Integer, ByVal Topology As Boolean, ByVal Nt As Char, Optional ByVal Multiplier As Single = 100, Optional ByVal ProgressControlBox As SystemProgressBarBox = Nothing)
        Dim Values As New List(Of Integer)
        Dim T_Count As Integer = 0

        Dim StartPos As Integer = 0
        Dim EndPos As Integer = 0

        Dim Word As String = ""
        Dim TrueWindowWidth As Integer = WindowL * 2 + 1

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.Show()
            ProgressControlBox.Focus()
            ProgressControlBox.MasterProgressBar.Maximum = Seq.Length
            ProgressControlBox.MasterProgressBar.Value = 0
            ProgressControlBox.StatusLabel.Text = ""
        End If

        If Topology Then 'Circular DNA
            For i = 1 To Seq.Length


                StartPos = i - WindowL
                EndPos = i + WindowL

                Word = DataIO.RetrieveSeqFromCache(Seq, StartPos, EndPos)

                T_Count = 0
                For Each N As Char In Word
                    If N = Nt Then
                        T_Count += 1
                    End If
                Next N

                Values.Add(T_Count / TrueWindowWidth * Multiplier)

                If Not IsNothing(ProgressControlBox) Then
                    ProgressControlBox.MasterProgressBar.PerformStep()
                End If


            Next i
        Else 'Linear DNA
            For i = 1 To WindowL
                Values.Add(0)
            Next i

            For i = 1 + WindowL To Seq.Length - WindowL
                StartPos = i - WindowL
                EndPos = i + WindowL

                Word = DataIO.RetrieveSeqFromCache(Seq, StartPos, EndPos)


                T_Count = 0
                For Each N As Char In Word
                    If N = Nt Then
                        T_Count += 1
                    End If
                Next N

                Values.Add(T_Count / TrueWindowWidth * Multiplier)


                If Not IsNothing(ProgressControlBox) Then
                    ProgressControlBox.MasterProgressBar.PerformStep()
                End If

            Next i

            For i = 1 To WindowL
                Values.Add(0)
            Next i

        End If

        If Not IsNothing(ProgressControlBox) Then
            SystemProgressBarBox.Close()
        End If

        Return Values
    End Function

    Public Shared Function GetSELEXWordStat(ByVal Sequences As List(Of String), ByVal WordLength As Integer, ByVal Mismatches As Integer, Optional ByVal ProgressControlBox As SystemProgressBarBox = Nothing)
        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.Show()
            ProgressControlBox.Focus()
            ProgressControlBox.MasterProgressBar.Maximum = 4 ^ WordLength
            ProgressControlBox.MasterProgressBar.Value = 0
            ProgressControlBox.StatusLabel.Text = "Calculating word space"
        End If

        Dim Words As List(Of String) = GenerateWordSpace(WordLength)

        Dim WordSpace As New List(Of SELEX_Word)
        For Each W As String In Words
            Dim NewWord As New SELEX_Word
            NewWord.Sequence = W
            WordSpace.Add(NewWord)


            If Not IsNothing(ProgressControlBox) Then
                ProgressControlBox.MasterProgressBar.PerformStep()
            End If

        Next W

        Words.Clear()


        Dim LocalWord As String = ""
        Dim LocalMismatchCounter As Integer = 0
        Dim WordResult As Boolean = False

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.Show()
            ProgressControlBox.Focus()
            ProgressControlBox.MasterProgressBar.Maximum = WordSpace.Count
            ProgressControlBox.MasterProgressBar.Value = 0
            ProgressControlBox.StatusLabel.Text = "Analyzing sequences"
        End If

        For Each Word As SELEX_Word In WordSpace
            For Each Seq As String In Sequences

                For i = 0 To Seq.Length - WordLength

                    LocalWord = Seq.Substring(i, WordLength)
                    LocalMismatchCounter = 0
                    WordResult = False

                    For j = 0 To WordLength - 1
                        If Not Word.Sequence(j) = LocalWord(j) Then
                            LocalMismatchCounter += 1
                            If LocalMismatchCounter > Mismatches Then
                                WordResult = True
                                Exit For
                            End If
                        End If
                    Next j

                    If WordResult = False Then
                        Word.Count += 1
                    End If

                Next i


            Next Seq


            If Not IsNothing(ProgressControlBox) Then
                ProgressControlBox.MasterProgressBar.PerformStep()
            End If

        Next Word


        If Not IsNothing(ProgressControlBox) Then
            SystemProgressBarBox.Close()
        End If

        Return WordSpace
    End Function

    Public Shared Function CalculateGCDistribution(ByVal Seq As String, _
                                                   Optional ByVal SearchWindow As Integer = 100, _
                                                   Optional ByVal Topology As Boolean = False, _
                                                   Optional ByVal Derivative As Boolean = False, _
                                                   Optional ByVal ProgressControlBox As SystemProgressBarBox = Nothing)


        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.MasterProgressBar.Value = 0
            ProgressControlBox.MasterProgressBar.Maximum = Seq.Length - SearchWindow
            ProgressControlBox.StatusLabel.Text = "Calculating GC-content..."
            ProgressControlBox.StatusLabel.Refresh()
        End If



        Dim GC_content(Seq.Length - 1) As Integer

        Dim GC_count As Integer = 0
        Dim GC_up As Integer = 0
        Dim GC_dn As Integer = 0


        If Topology Then 'True for circular

            If Not IsNothing(ProgressControlBox) Then
                ProgressControlBox.MasterProgressBar.Maximum += SearchWindow * 2
            End If


            Dim AuxSeq As String = ""


            For Pos = 0 To SearchWindow 'Beginning of the sequence

                GC_count = 0
                GC_up = 0
                GC_dn = 0

                AuxSeq = Seq.Substring(Seq.Length - SearchWindow + Pos) & Seq.Substring(0, Pos)

                For j = 0 To AuxSeq.Length - 1
                    If AuxSeq(j) = "G" Or AuxSeq(j) = "C" Then
                        GC_up += 1
                    End If
                Next j

                AuxSeq = Seq.Substring(Pos + 1, SearchWindow)

                For j = 0 To AuxSeq.Length - 1
                    If AuxSeq(j) = "G" Or AuxSeq(j) = "C" Then
                        GC_dn += 1
                    End If
                Next j


                GC_count += GC_dn
                GC_count += GC_up

                If Seq(Pos) = "G" Or Seq(Pos) = "C" Then
                    GC_count += 1
                End If

                If Derivative Then
                    If GC_up = 0 Then
                        GC_up = 1
                    End If
                    GC_content(Pos) = GC_dn / GC_up * 100
                Else

                    GC_content(Pos) = GC_count / (SearchWindow * 2 + 1) * 100
                End If

                If Not IsNothing(ProgressControlBox) Then
                    ProgressControlBox.MasterProgressBar.PerformStep()
                End If

            Next Pos

            For Pos = Seq.Length - SearchWindow To Seq.Length - 1  'End of the sequence
                GC_count = 0
                GC_up = 0
                GC_dn = 0


                AuxSeq = Seq.Substring(Pos - SearchWindow, SearchWindow) '& 

                For j = 0 To AuxSeq.Length - 1
                    If AuxSeq(j) = "G" Or AuxSeq(j) = "C" Then
                        GC_up += 1
                    End If
                Next j

                AuxSeq = Seq.Substring(Pos + 1) & Seq.Substring(0, SearchWindow - (Seq.Length - Pos) + 1)

                For j = 0 To AuxSeq.Length - 1
                    If AuxSeq(j) = "G" Or AuxSeq(j) = "C" Then
                        GC_dn += 1
                    End If
                Next j


                GC_count += GC_dn
                GC_count += GC_up

                If Seq(Pos) = "G" Or Seq(Pos) = "C" Then
                    GC_count += 1
                End If

                If Derivative Then
                    If GC_up = 0 Then
                        GC_up = 1
                    End If
                    GC_content(Pos) = GC_dn / GC_up * 100
                Else

                    GC_content(Pos) = GC_count / (SearchWindow * 2 + 1) * 100
                End If

                If Not IsNothing(ProgressControlBox) Then
                    ProgressControlBox.MasterProgressBar.PerformStep()
                End If

            Next Pos

        End If



        For Pos = SearchWindow To Seq.Length - SearchWindow
            GC_count = 0
            GC_up = 0
            GC_dn = 0


            'Collect GC upstream
            For j = 0 To SearchWindow - 1
                Try
                    If Seq(Pos - 1 - j) = "G" Or Seq(Pos - 1 - j) = "C" Then
                        GC_up += 1
                    End If
                Catch ex As Exception

                End Try


            Next j



            'Collect GC downstream
            For j = 0 To SearchWindow - 1
                Try
                    If Seq(Pos + 1 + j) = "G" Or Seq(Pos + 1 + j) = "C" Then
                        GC_dn += 1
                    End If
                Catch ex As Exception

                End Try


            Next j

            GC_count += GC_dn
            GC_count += GC_up

            If Seq(Pos) = "G" Or Seq(Pos) = "C" Then
                GC_count += 1
            End If

            If Derivative Then
                If GC_up = 0 Then
                    GC_up = 1
                End If
                GC_content(Pos) = GC_dn / GC_up * 100
            Else
                GC_content(Pos) = GC_count / (SearchWindow * 2 + 1) * 100
            End If

            If Not IsNothing(ProgressControlBox) Then
                ProgressControlBox.MasterProgressBar.PerformStep()
            End If

        Next Pos






        Return GC_content

    End Function

    Public Shared Function CalculateGCSkew(ByVal Seq As String, _
                                                  Optional ByVal SearchWindow As Integer = 100, _
                                                  Optional ByVal Topology As Boolean = False, _
                                                  Optional ByVal ProgressControlBox As SystemProgressBarBox = Nothing, Optional ByVal GCvsAT As Boolean = True)


        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.MasterProgressBar.Value = 0
            ProgressControlBox.MasterProgressBar.Maximum = Seq.Length - SearchWindow
            If GCvsAT Then
                ProgressControlBox.StatusLabel.Text = "Calculating GC-skew..."

            Else
                ProgressControlBox.StatusLabel.Text = "Calculating AT-skew..."

            End If
            ProgressControlBox.StatusLabel.Refresh()
        End If



        Dim GC_skew(Seq.Length - 1) As Integer
        Dim G_count As Integer = 0
        Dim C_count As Integer = 0

        Dim Purine As String = ""
        Dim Pyrimidine As String = ""

        If GCvsAT Then
            Purine = "G"
            Pyrimidine = "C"
        Else
            Purine = "A"
            Pyrimidine = "T"
        End If


        If Topology Then 'True for circular

            If Not IsNothing(ProgressControlBox) Then
                ProgressControlBox.MasterProgressBar.Maximum += SearchWindow * 2
            End If


            Dim AuxSeq As String = ""


            For Pos = 0 To SearchWindow 'Beginning of the sequence

                G_count = 0
                C_count = 0

                AuxSeq = Seq.Substring(Seq.Length - SearchWindow + Pos) & Seq.Substring(0, Pos)

                For j = 0 To AuxSeq.Length - 1
                    If AuxSeq(j) = Purine Then
                        G_count += 1
                    ElseIf AuxSeq(j) = Pyrimidine Then
                        C_count += 1
                    End If
                Next j

                AuxSeq = Seq.Substring(Pos + 1, SearchWindow)

                For j = 0 To AuxSeq.Length - 1
                    If AuxSeq(j) = Purine Then
                        G_count += 1
                    ElseIf AuxSeq(j) = Pyrimidine Then
                        C_count += 1
                    End If
                Next j


                If Seq(Pos) = Purine Then
                    G_count += 1
                ElseIf Seq(Pos) = Pyrimidine Then
                    C_count += 1
                End If


                If G_count = 0 And C_count = 0 Then
                    GC_skew(Pos) = 0
                Else
                    GC_skew(Pos) = G_count / (G_count + C_count) * 100
                End If


                If Not IsNothing(ProgressControlBox) Then
                    ProgressControlBox.MasterProgressBar.PerformStep()
                End If

            Next Pos

            For Pos = Seq.Length - SearchWindow To Seq.Length - 1  'End of the sequence

                G_count = 0
                C_count = 0

                AuxSeq = Seq.Substring(Pos - SearchWindow, SearchWindow) '& 

                For j = 0 To AuxSeq.Length - 1
                    If AuxSeq(j) = Purine Then
                        G_count += 1
                    ElseIf AuxSeq(j) = Pyrimidine Then
                        C_count += 1
                    End If
                Next j

                AuxSeq = Seq.Substring(Pos + 1) & Seq.Substring(0, SearchWindow - (Seq.Length - Pos) + 1)

                For j = 0 To AuxSeq.Length - 1
                    If AuxSeq(j) = Purine Then
                        G_count += 1
                    ElseIf AuxSeq(j) = Pyrimidine Then
                        C_count += 1
                    End If
                Next j


                If Seq(Pos) = Purine Then
                    G_count += 1
                ElseIf Seq(Pos) = Pyrimidine Then
                    C_count += 1
                End If


                If G_count = 0 And C_count = 0 Then
                    GC_skew(Pos) = 0
                Else
                    GC_skew(Pos) = G_count / (G_count + C_count) * 100
                End If


                If Not IsNothing(ProgressControlBox) Then
                    ProgressControlBox.MasterProgressBar.PerformStep()
                End If

            Next Pos

        End If



        For Pos = SearchWindow To Seq.Length - SearchWindow

            G_count = 0
            C_count = 0


            'Collect GC upstream
            For j = 0 To SearchWindow - 1
                Try
                    If Seq(Pos - 1 - j) = Purine Then
                        G_count += 1
                    ElseIf Seq(Pos - 1 - j) = Pyrimidine Then
                        C_count += 1
                    End If
                Catch ex As Exception

                End Try

            Next j



            'Collect GC downstream
            For j = 0 To SearchWindow - 1
                Try
                    If Seq(Pos + 1 + j) = Purine Then
                        G_count += 1
                    ElseIf Seq(Pos + 1 + j) = Pyrimidine Then
                        C_count += 1
                    End If
                Catch ex As Exception

                End Try

            Next j


            If Seq(Pos) = Purine Then
                G_count += 1
            ElseIf Seq(Pos) = Pyrimidine Then
                C_count += 1
            End If


            If G_count = 0 And C_count = 0 Then
                GC_skew(Pos) = 0
            Else
                GC_skew(Pos) = G_count / (G_count + C_count) * 100
            End If


            If Not IsNothing(ProgressControlBox) Then
                ProgressControlBox.MasterProgressBar.PerformStep()
            End If

        Next Pos






        Return GC_skew

    End Function

    Public Shared Function Get_dG_Distribution(ByVal Seq As String, ByVal SegmentL As Integer, ByVal T As Single)

        Dim dG_List As New List(Of Single)

        For i = 0 To Seq.Length - SegmentL
            dG_List.Add(CalculateOligoDG(Seq.Substring(i, SegmentL), T))
        Next i
        Return dG_List
    End Function



#End Region

#Region "Proteomics"

    Public Shared Function GetAminoacidMWList()
        Dim FilePath As String = String.Concat(My.Computer.FileSystem.CurrentDirectory, "\Translation\AA-MW.txt")
        Dim AminoacidMWList As New DataTable

        AminoacidMWList.Columns.Add("Name")
        AminoacidMWList.Columns.Add("MW")

        Dim ReadStream As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(ReadStream)
        Dim CurrentLine As String = ""
        Dim Values As String()

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            Values = CurrentLine.Split(Chr(9))
            AminoacidMWList.Rows.Add(Values(0), Values(1))
        End While

        Reader.Close()
        ReadStream.Close()
        Reader.Dispose()
        ReadStream.Dispose()

        Return AminoacidMWList
    End Function

    Public Shared Function GetAminoacidPIList()
        Dim FilePath As String = String.Concat(My.Computer.FileSystem.CurrentDirectory, "\Translation\AA-PI.txt")
        Dim AminoacidPIList As New DataTable

        AminoacidPIList.Columns.Add("Name")
        AminoacidPIList.Columns.Add("PI")

        Dim ReadStream As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(ReadStream)
        Dim CurrentLine As String = ""
        Dim Values As String()

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            Values = CurrentLine.Split(Chr(9))
            AminoacidPIList.Rows.Add(Values(0), Values(1))
        End While

        Reader.Close()
        ReadStream.Close()
        Reader.Dispose()
        ReadStream.Dispose()

        Return AminoacidPIList
    End Function

    Public Shared Function GetAminoacidHIList()
        Dim FilePath As String = String.Concat(My.Computer.FileSystem.CurrentDirectory, "\Translation\AA-HI.txt")
        Dim AminoacidHIList As New DataTable

        AminoacidHIList.Columns.Add("Name")
        AminoacidHIList.Columns.Add("HI")

        Dim ReadStream As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(ReadStream)
        Dim CurrentLine As String = ""
        Dim Values As String()

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            Values = CurrentLine.Split(Chr(9))
            AminoacidHIList.Rows.Add(Values(0), Values(1))
        End While

        Reader.Close()
        ReadStream.Close()
        Reader.Dispose()
        ReadStream.Dispose()

        Return AminoacidHIList
    End Function

    Public Shared Function GetAminoacidNamesList()
        Dim FilePath As String = String.Concat(My.Computer.FileSystem.CurrentDirectory, "\Translation\Table-AA.txt")
        Dim AminoacidNamesList As New DataTable

        AminoacidNamesList.Columns.Add("Name")
        AminoacidNamesList.Columns.Add("Code3")

        Dim ReadStream As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(ReadStream)
        Dim CurrentLine As String = ""
        Dim Values As String()

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            Values = CurrentLine.Split(Chr(9))
            AminoacidNamesList.Rows.Add(Values(0), Values(1))
        End While

        Reader.Close()
        ReadStream.Close()
        Reader.Dispose()
        ReadStream.Dispose()

        Return AminoacidNamesList
    End Function

    Public Shared Function Code1ToCode3(ByVal AA_Seq As Char(), ByVal CodeTable As DataTable, Optional ByVal AddSeparator As Boolean = True)

        Dim ResultString As String = ""

        Dim SeparatorChar As String = ""
        If AddSeparator Then
            SeparatorChar = "-"
        End If

        For Each AA As Char In AA_Seq
            For Each Row As DataRow In CodeTable.Rows
                If AA = Row.Item(0) Then
                    ResultString &= (Row.Item(1) & SeparatorChar)
                End If
            Next
        Next

        ResultString = ResultString.Remove(ResultString.Length - 1, 1)

        Return ResultString
    End Function

    Public Shared Function Calculate_Prot_pI(ByVal AA_Seq As String, ByVal PITable As DataTable)
        Dim DecimalFormat As System.Globalization.NumberFormatInfo = System.Globalization.CultureInfo.InstalledUICulture.NumberFormat.Clone
        DecimalFormat.NumberDecimalSeparator = "."

        Dim C_Num As Integer = 0 'Cysteine
        Dim D_Num As Integer = 0 'Aspartate
        Dim E_Num As Integer = 0 'Glutamate
        Dim H_Num As Integer = 0 'Histidine
        Dim K_Num As Integer = 0 'Lysine
        Dim R_Num As Integer = 0 'Arginine
        Dim Y_Num As Integer = 0 'Tyrosine

        Dim pK_C As Single = 0
        Dim pK_D As Single = 0
        Dim pK_E As Single = 0
        Dim pK_H As Single = 0
        Dim pK_K As Single = 0
        Dim pK_R As Single = 0
        Dim pK_Y As Single = 0

        Dim pK_NH2 As Single = 0
        Dim pK_COOH As Single = 0

        For Each Row As DataRow In PITable.Rows
            Select Case Row.Item(0)
                Case "C"
                    pK_C = Single.Parse(Row.Item(1), DecimalFormat)
                Case "D"
                    pK_D = Single.Parse(Row.Item(1), DecimalFormat)
                Case "E"
                    pK_E = Single.Parse(Row.Item(1), DecimalFormat)
                Case "H"
                    pK_H = Single.Parse(Row.Item(1), DecimalFormat)
                Case "K"
                    pK_K = Single.Parse(Row.Item(1), DecimalFormat)
                Case "R"
                    pK_R = Single.Parse(Row.Item(1), DecimalFormat)
                Case "Y"
                    pK_Y = Single.Parse(Row.Item(1), DecimalFormat)
                Case "NH2"
                    pK_NH2 = Single.Parse(Row.Item(1), DecimalFormat)
                Case "COOH"
                    pK_COOH = Single.Parse(Row.Item(1), DecimalFormat)
            End Select
        Next


        For Each AA As Char In AA_Seq.ToCharArray
            Select Case AA
                Case "C"
                    C_Num += 1
                Case "D"
                    D_Num += 1
                Case "E"
                    E_Num += 1
                Case "H"
                    H_Num += 1
                Case "K"
                    K_Num += 1
                Case "R"
                    R_Num += 1
                Case "Y"
                    Y_Num += 1
            End Select
        Next

        Dim current_pH As Single = 0

        Dim pI_precalc_den(1399, 8) As Single
        For i = 0 To 1399
            For j = 0 To 8
                Select Case j
                    Case 0 'NH2 pos
                        pI_precalc_den(i, j) = 1 + 10 ^ (current_pH - pK_NH2)
                    Case 1 'COOH neg
                        pI_precalc_den(i, j) = -(1 + 10 ^ (pK_COOH - current_pH))
                    Case 2 'C neg
                        pI_precalc_den(i, j) = -(1 + 10 ^ (pK_C - current_pH))
                    Case 3 'D neg
                        pI_precalc_den(i, j) = -(1 + 10 ^ (pK_D - current_pH))
                    Case 4 'E neg
                        pI_precalc_den(i, j) = -(1 + 10 ^ (pK_E - current_pH))
                    Case 5 'H 'pos
                        pI_precalc_den(i, j) = 1 + 10 ^ (current_pH - pK_H)
                    Case 6 'K 'pos
                        pI_precalc_den(i, j) = 1 + 10 ^ (current_pH - pK_K)
                    Case 7 'R 'pos
                        pI_precalc_den(i, j) = 1 + 10 ^ (current_pH - pK_R)
                    Case 8 'Y 'neg
                        pI_precalc_den(i, j) = -(1 + 10 ^ (pK_Y - current_pH))
                End Select
            Next
            current_pH += 0.01
        Next

        Dim current_pI As Single = 0
        Dim current_Step As Integer = 699
        Dim Iteration_Counter As Integer = 0

        Do

            If current_Step < 0 Or current_Step > 1399 Then
                MsgBox(String.Concat("pH step value reached limit! Current value = ", (current_Step + 1) / 100))
                Exit Do
            End If

            current_pI = 0

            For j = 0 To 8
                Select Case j
                    Case 0 'NH2 pos
                        current_pI += 1 / pI_precalc_den(current_Step, j)
                    Case 1 'COOH neg
                        current_pI += 1 / pI_precalc_den(current_Step, j)
                    Case 2 'C neg
                        current_pI += C_Num / pI_precalc_den(current_Step, j)
                    Case 3 'D neg
                        current_pI += D_Num / pI_precalc_den(current_Step, j)
                    Case 4 'E neg
                        current_pI += E_Num / pI_precalc_den(current_Step, j)
                    Case 5 'H 'pos
                        current_pI += H_Num / pI_precalc_den(current_Step, j)
                    Case 6 'K 'pos
                        current_pI += K_Num / pI_precalc_den(current_Step, j)
                    Case 7 'R 'pos
                        current_pI += R_Num / pI_precalc_den(current_Step, j)
                    Case 8 'Y 'neg
                        current_pI += Y_Num / pI_precalc_den(current_Step, j)
                End Select
            Next

            Dim precision_limit As Single = 0.01

            If current_pI < precision_limit And current_pI > -precision_limit Then
                Exit Do
            Else
                If current_pI < -precision_limit Then
                    current_Step -= 1
                Else
                    current_Step += 1
                End If
            End If

            Iteration_Counter += 1
            If Iteration_Counter > 702 Then
                Exit Do
            End If
        Loop

        Return (current_Step + 1) / 100

    End Function

    Public Shared Function Calculate_Prot_Mass(ByVal AA_Seq As String, ByVal MassTable As DataTable)
        Dim Mass As Single = 0

        Dim DecimalFormat As System.Globalization.NumberFormatInfo = System.Globalization.CultureInfo.InstalledUICulture.NumberFormat.Clone
        DecimalFormat.NumberDecimalSeparator = "."

        For Each AA As Char In AA_Seq.ToCharArray
            For Each Row As DataRow In MassTable.Rows
                If AA = Row.Item(0) Then
                    Mass += Single.Parse(Row.Item(1), DecimalFormat)
                End If
            Next
        Next

        Mass += 18
        Return Mass
    End Function

    Public Shared Function Calculate_Prot_Hydrophobisity(ByVal AA_Seq As String, ByVal ScoreTable As DataTable)
        Dim HydroScore As Single = 0

        Dim DecimalFormat As System.Globalization.NumberFormatInfo = System.Globalization.CultureInfo.InstalledUICulture.NumberFormat.Clone
        DecimalFormat.NumberDecimalSeparator = "."

        For Each AA As Char In AA_Seq.ToCharArray
            For Each Row As DataRow In ScoreTable.Rows
                If AA = Row.Item(0) Then
                    HydroScore += Single.Parse(Row.Item(1), DecimalFormat)
                End If
            Next
        Next

        Return HydroScore
    End Function

    Public Shared Function FindORFs(ByVal Sequence As String, ByVal InitiationListFor As List(Of String), ByVal TerminationListFor As List(Of String), ByVal MinimalLength As Integer)

        Dim FoundORFs As New List(Of Genome_Feature)
        Dim IsInitWordFor As Boolean = False
        Dim IsTerWordFor As Boolean = False

        Dim IsInitWordRev As Boolean = False
        Dim IsTerWordRev As Boolean = False

        Dim InitiationListRev As New List(Of String)
        Dim TerminationListRev As New List(Of String)

        For Each StartCodon As String In InitiationListFor
            InitiationListRev.Add(GetReverseComplement(StartCodon))
        Next

        For Each StopCodon As String In TerminationListFor
            TerminationListRev.Add(GetReverseComplement(StopCodon))
        Next

        Dim PepCount As Integer = 0
        Dim ElongationPos As Integer = 0
        Dim ElongationWord As String = ""
        Dim SeedWord As String = ""
        Dim ORFCounter As Integer = 0

        For i = 0 To Sequence.Length - 3
            'Seed  
            SeedWord = Sequence.Substring(i, 3)

            'Find if seed can initiate translation
            IsInitWordFor = False
            For Each StartCodon As String In InitiationListFor
                If SeedWord = StartCodon Then
                    IsInitWordFor = True
                    Exit For
                End If
            Next

            IsInitWordRev = False
            For Each StartCodon As String In InitiationListRev
                If SeedWord = StartCodon Then
                    IsInitWordRev = True
                    Exit For
                End If
            Next

            'If it can elongate in forward direction until stop and count peptide length
            If IsInitWordFor Then
                PepCount = 0
                ElongationPos = i

                Do

                    If ElongationPos >= Sequence.Length - 3 Then
                        Exit Do
                    End If

                    ElongationWord = Sequence.Substring(ElongationPos, 3)

                    IsTerWordFor = False
                    For Each StopCodon As String In TerminationListFor
                        If ElongationWord = StopCodon Then
                            IsTerWordFor = True
                            Exit For
                        End If
                    Next

                    If IsTerWordFor Then
                        If PepCount >= MinimalLength Then
                            Dim NewORF As New Genome_Feature
                            NewORF.Type = 11
                            NewORF.Direction = 1
                            NewORF.AbsoluteStart = i + 1
                            NewORF.AbsoluteEnd = ElongationPos + 3
                            NewORF.TAG = "New_ORF_" & ORFCounter
                            NewORF.Name = NewORF.TAG
                            FoundORFs.Add(NewORF)
                            ORFCounter += 1
                        End If
                        Exit Do
                    Else
                        ElongationPos += 3
                        PepCount += 1
                    End If


                Loop
            End If


            'If it can elongate in reverse direction until stop and count peptide length
            If IsInitWordRev Then
                PepCount = 0
                ElongationPos = i + 3

                Do
                    If ElongationPos <= 3 Then
                        Exit Do
                    End If

                    ElongationWord = Sequence.Substring(ElongationPos - 3, 3)

                    IsTerWordRev = False
                    For Each StopCodon As String In TerminationListRev
                        If ElongationWord = StopCodon Then
                            IsTerWordRev = True
                            Exit For
                        End If
                    Next

                    If IsTerWordRev Then
                        If PepCount >= MinimalLength Then
                            Dim NewORF As New Genome_Feature
                            NewORF.Type = 11
                            NewORF.Direction = 2
                            NewORF.AbsoluteStart = ElongationPos - 2
                            NewORF.AbsoluteEnd = i + 3
                            NewORF.TAG = "New_ORF_" & ORFCounter
                            NewORF.Name = NewORF.TAG
                            FoundORFs.Add(NewORF)
                            ORFCounter += 1
                        End If
                        Exit Do
                    Else
                        ElongationPos -= 3
                        PepCount += 1
                    End If

                Loop

            End If


        Next

        Return FoundORFs
    End Function

    Public Shared Function GetCodonUsage(ByVal Genome As Genome_Viewer, Optional ByVal ProgressReport As SystemProgressBarBox = Nothing)

        Dim ResultTable As New DataTable
        Dim CodeTable As DataTable = Bioinformatics.GetTranslationTable(Genome.Control_Box.TransComboBox.Text.Split("-")(0))

        For i = 0 To CodeTable.Rows.Count
            ResultTable.Columns.Add()
        Next

        ResultTable.Rows.Add()
        ResultTable.Rows.Add()

        For i = 1 To CodeTable.Rows.Count
            ResultTable.Rows(0).Item(i) = CodeTable.Rows(i - 1).Item(0)
            ResultTable.Rows(1).Item(i) = CodeTable.Rows(i - 1).Item(1)
        Next


        Dim FSeq As String = ""
        Dim FrameReader As Integer = 0
        Dim CurrentTripplete As String = ""
        Dim CurrentRowIndex As Integer = 2


        If Not IsNothing(SystemProgressBarBox) Then
            SystemProgressBarBox.Show()
            SystemProgressBarBox.Focus()
            SystemProgressBarBox.MasterProgressBar.Value = 0
            SystemProgressBarBox.MasterProgressBar.Maximum = Genome.Features_Groups_List(0).FeaturesList.Count
            SystemProgressBarBox.StatusLabel.Text = ""
            SystemProgressBarBox.Refresh()
        End If


        For Each Feature As Genome_Feature In Genome.Features_Groups_List(0).FeaturesList
            If Feature.Type = 1 Then

                FSeq = Genome.GetFeatureSequence(Feature)
                ResultTable.Rows.Add(Feature.TAG)
                For j = 1 To ResultTable.Columns.Count - 1
                    ResultTable.Rows(CurrentRowIndex).Item(j) = 0
                Next

                FrameReader = 0
                For i = 0 To (FSeq.Length / 3) - 1
                    CurrentTripplete = FSeq.Substring(FrameReader, 3)
                    FrameReader += 3

                    For j = 1 To ResultTable.Columns.Count - 1
                        If ResultTable.Rows(0).Item(j) = CurrentTripplete Then
                            ResultTable.Rows(CurrentRowIndex).Item(j) += 1
                        End If
                    Next
                Next

                CurrentRowIndex += 1

            End If
            If Not IsNothing(SystemProgressBarBox) Then
                SystemProgressBarBox.MasterProgressBar.PerformStep()
            End If
        Next

        If Not IsNothing(SystemProgressBarBox) Then
            SystemProgressBarBox.Close()
        End If

        Return ResultTable
    End Function

    Public Shared Function SumCodonUsage(ByRef CodonUsageTable As DataTable)

        Dim CodonSumList As New List(Of Integer)
        Dim TotalSum As Integer = 0
        Dim Val As Integer = 0

        For i = 1 To CodonUsageTable.Columns.Count - 1
            Dim LocalCount As Integer = 0
            For j = 2 To CodonUsageTable.Rows.Count - 1

                Val = CType(CodonUsageTable.Rows(j).Item(i), Integer)
                LocalCount += Val
                TotalSum += Val

            Next j

            CodonSumList.Add(LocalCount)

        Next i



        Dim TotalRow As DataRow = CodonUsageTable.NewRow
        Dim UsageRow As DataRow = CodonUsageTable.NewRow


        TotalRow.Item(0) = "Total count"
        UsageRow.Item(0) = "Codon usage"

        For i = 0 To CodonSumList.Count - 1
            TotalRow.Item(i + 1) = CodonSumList(i)
            UsageRow.Item(i + 1) = Math.Round(CodonSumList(i) / TotalSum, 4)
        Next i

        CodonUsageTable.Rows.InsertAt(TotalRow, 2)
        CodonUsageTable.Rows.InsertAt(UsageRow, 2)


        Return CodonUsageTable
    End Function

    Public Shared Function FormatCodonUsage(ByRef CodonUsageTable As DataTable)

        Dim FormattedTable As New DataTable
        FormattedTable.Columns.Add()
        FormattedTable.Columns.Add()
        FormattedTable.Columns.Add()

        For i = 1 To CodonUsageTable.Columns.Count - 1
            Dim NewRow As DataRow = FormattedTable.NewRow
            NewRow.Item(0) = CodonUsageTable.Rows(0).Item(i)
            NewRow.Item(1) = CodonUsageTable.Rows(1).Item(i)
            NewRow.Item(2) = CodonUsageTable.Rows(2).Item(i)
            FormattedTable.Rows.Add(NewRow)
        Next i

        Return FormattedTable
    End Function

    Public Shared Function GetReverseTranslation(ByVal Seq As String, ByVal CodonUsageTable As List(Of CodonUsageCell))
        Dim Gene As String = ""
        Dim AA_Seq As Char() = Seq.ToCharArray
        For Each AA As String In AA_Seq
            For Each CodonCell As CodonUsageCell In CodonUsageTable
                If AA = CodonCell.AA Then
                    Gene &= CodonCell.ReturnCodonByFreq
                    Exit For
                End If
            Next
        Next

        Return Gene
    End Function

    Public Shared Function MakeProteinList(ByVal Features As List(Of Genome_Feature), ByVal Sequence As String, ByVal CodeTable As DataTable, ByVal MassTable As DataTable, Optional ByVal ProgressControlBox As SystemProgressBarBox = Nothing)
        Dim Proteins As New List(Of ProtPeptide)
        Dim FeatureSeq As String = ""

        If Not IsNothing(ProgressControlBox) Then

            ProgressControlBox.Show()
            ProgressControlBox.Focus()
            ProgressControlBox.MasterProgressBar.Maximum = Features.Count
            ProgressControlBox.MasterProgressBar.Value = 0
            ProgressControlBox.StatusLabel.Text = "Preparing translated CDS's..."
            ProgressControlBox.StatusLabel.Refresh()

        End If


        For Each Feature As Genome_Feature In Features
            If Feature.Type = 1 Then


                If Feature.Direction = 1 Then
                    FeatureSeq = DataIO.RetrieveSeqFromCache(Sequence, Feature.AbsoluteStart, Feature.AbsoluteEnd)
                ElseIf Feature.Direction = 2 Then
                    FeatureSeq = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(Sequence, Feature.AbsoluteStart, Feature.AbsoluteEnd))
                Else
                    FeatureSeq = DataIO.RetrieveSeqFromCache(Sequence, Feature.AbsoluteStart, Feature.AbsoluteEnd)
                End If


                Dim NewProt As New ProtPeptide(Feature.AbsoluteStart, Feature.AbsoluteEnd, Feature.Direction, Bioinformatics.Translate(FeatureSeq, CodeTable), MassTable)
                NewProt.My_Feature = Feature
                Proteins.Add(NewProt)
            End If

            If Not IsNothing(ProgressControlBox) Then
                ProgressControlBox.MasterProgressBar.PerformStep()
            End If

        Next

        If Not IsNothing(ProgressControlBox) Then
            SystemProgressBarBox.Close()
        End If

        Return Proteins
    End Function

    Public Shared Function LookProteinForPeptide(ByVal Protein As ProtPeptide, ByVal Peptide As String)
        Dim PeptideFeature As Genome_Feature = Nothing
        Dim LocalPept As String = ""

        For i = 0 To Protein.AA_Seq.Length - Peptide.Length
            LocalPept = Protein.AA_Seq.Substring(i, Peptide.Length)
            If LocalPept = Peptide Then
                Dim NewPept As New Genome_Feature

                If Protein.Direction = 1 Then
                    NewPept.AbsoluteStart = Protein.AbsoluteStart + i * 3
                    NewPept.AbsoluteEnd = NewPept.AbsoluteStart + Peptide.Length * 3 - 1
                    NewPept.Direction = 1
                ElseIf Protein.Direction = 2 Then
                    NewPept.AbsoluteEnd = Protein.AbsoluteEnd - i * 3
                    NewPept.AbsoluteStart = NewPept.AbsoluteEnd - Peptide.Length * 3 + 1
                    NewPept.Direction = 2
                Else
                    NewPept.AbsoluteStart = Protein.AbsoluteStart + i * 3
                    NewPept.AbsoluteEnd = NewPept.AbsoluteStart + Peptide.Length * 3 - 1
                    NewPept.Direction = 1
                End If

                PeptideFeature = NewPept
            End If
        Next

        Return PeptideFeature
    End Function

    Public Shared Function Make6FrameTranslation(ByVal Seq As String, ByVal CodeTable As DataTable, Optional ByVal CircularTopology As Boolean = False, Optional ByVal AddSeparator As Boolean = False, Optional ByVal FormatTranslatedSeq As Boolean = False, Optional ByVal ProgressControlBox As SystemProgressBarBox = Nothing)

        Dim TranslationList As New List(Of String)
        Dim FrameF2 As String = Seq.Substring(1)
        Dim FrameF3 As String = Seq.Substring(2)
        Dim FrameR1 As String = GetReverseComplement(Seq)
        Dim FrameR2 As String = FrameR1.Substring(1)
        Dim FrameR3 As String = FrameR1.Substring(2)

        If CircularTopology Then
            FrameF2 = FrameF2 & Seq.Substring(0, 1)
            FrameF3 = FrameF3 & Seq.Substring(0, 2)
            FrameR2 = FrameR2 & FrameR1.Substring(0, 1)
            FrameR3 = FrameR3 & FrameR1.Substring(0, 2)
        End If


        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.Show()
            ProgressControlBox.Focus()
            ProgressControlBox.MasterProgressBar.Maximum = 6
            ProgressControlBox.MasterProgressBar.Value = 0
            ProgressControlBox.StatusLabel.Text = "Frame +1"
            ProgressControlBox.MasterProgressBar.PerformStep()
            ProgressControlBox.StatusLabel.Refresh()
        End If

        TranslationList.Add(Translate(Seq, CodeTable, AddSeparator))

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.MasterProgressBar.PerformStep()
            ProgressControlBox.StatusLabel.Text = "Frame +2"
            ProgressControlBox.StatusLabel.Refresh()
        End If

        TranslationList.Add(Translate(FrameF2, CodeTable, AddSeparator))

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.MasterProgressBar.PerformStep()
            ProgressControlBox.StatusLabel.Text = "Frame +3"
            ProgressControlBox.StatusLabel.Refresh()
        End If

        TranslationList.Add(Translate(FrameF3, CodeTable, AddSeparator))

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.MasterProgressBar.PerformStep()
            ProgressControlBox.StatusLabel.Text = "Frame -1"
            ProgressControlBox.StatusLabel.Refresh()
        End If

        TranslationList.Add(Translate(FrameR1, CodeTable, AddSeparator))

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.MasterProgressBar.PerformStep()
            ProgressControlBox.StatusLabel.Text = "Frame -2"
            ProgressControlBox.StatusLabel.Refresh()
        End If

        TranslationList.Add(Translate(FrameR2, CodeTable, AddSeparator))

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.MasterProgressBar.PerformStep()
            ProgressControlBox.StatusLabel.Text = "Frame -3"
            ProgressControlBox.StatusLabel.Refresh()
        End If

        TranslationList.Add(Translate(FrameR3, CodeTable, AddSeparator))


        If FormatTranslatedSeq Then

            ' Math.Truncate(Seq.Length / 3)
            Dim EqvCount As Integer = 0 ' Seq.Length - MaxAAPos * 3
            Dim MaxAA As Integer = Math.DivRem(Seq.Length, 3, EqvCount)

            ' MsgBox(EqvCount)

            Select Case EqvCount
                Case 0
                    TranslationList(1) = "-" & TranslationList(1)
                    TranslationList(2) = "--" & TranslationList(2)
                    TranslationList(4) = "-" & TranslationList(4)
                    TranslationList(5) = "--" & TranslationList(5)


                    TranslationList(1) = TranslationList(1) & "--"
                    TranslationList(2) = TranslationList(2) & "-"
                    TranslationList(4) = TranslationList(4) & "--"
                    TranslationList(5) = TranslationList(5) & "-"


                    Dim TmpString As String = TranslationList(3)
                    TranslationList.RemoveAt(3)
                    TranslationList.Add(TmpString)

                Case 1
                    TranslationList(1) = "-" & TranslationList(1)
                    TranslationList(2) = "--" & TranslationList(2)
                    TranslationList(4) = "-" & TranslationList(4)
                    TranslationList(5) = "--" & TranslationList(5)


                    TranslationList(0) = TranslationList(0) & "-"
                    TranslationList(2) = TranslationList(2) & "--"
                    TranslationList(3) = TranslationList(3) & "-"
                    TranslationList(5) = TranslationList(5) & "--"


                    Dim TmpString As String = TranslationList(5)
                    TranslationList.RemoveAt(5)
                    TranslationList.Insert(3, TmpString)

                Case 2
                    TranslationList(1) = "-" & TranslationList(1)
                    TranslationList(2) = "--" & TranslationList(2)
                    TranslationList(4) = "-" & TranslationList(4)
                    TranslationList(5) = "--" & TranslationList(5)


                    TranslationList(0) = TranslationList(0) & "--"
                    TranslationList(1) = TranslationList(1) & "-"
                    TranslationList(3) = TranslationList(3) & "--"
                    TranslationList(4) = TranslationList(4) & "-"
            End Select

            TranslationList(3) = ReverseStrand(TranslationList(3))
            TranslationList(4) = ReverseStrand(TranslationList(4))
            TranslationList(5) = ReverseStrand(TranslationList(5))
        End If

        If Not IsNothing(ProgressControlBox) Then
            SystemProgressBarBox.Close()
        End If


        Return TranslationList
    End Function

    Public Shared Function GetSynonimousTripplets(ByVal Aminoacid As String, ByVal CodeTable As DataTable)
        Dim Synonims As New List(Of String)

        For Each Row As DataRow In CodeTable.Rows
            If Row.Item(1) = Aminoacid Then
                Synonims.Add(Row.Item(0))
            End If
        Next Row

        Return Synonims
    End Function

#End Region

#Region "Projection"

    Public Shared Sub CalculateFeatureProjectionNormal(ByRef Feature As Genome_Feature, ByRef TargetDisplayedList As List(Of Genome_Feature), ByVal intRangeStart As Integer, ByVal intRangeEnd As Integer, ByVal SequenceLength As Integer, ByVal Projection_K As Single)
        Feature.InvertedView = False

        If Feature.Visible Then

            If Feature.AbsoluteStart <= Feature.AbsoluteEnd Then 'Feature does not overlap with mount point
                If Feature.AbsoluteEnd > intRangeStart And Feature.AbsoluteStart < intRangeEnd Then 'Otherwise it is not in view
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd - intRangeStart + 1) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                End If

            Else 'Feature overlaps with mount point
                Feature.InvertedView = True

                If Feature.AbsoluteStart > intRangeStart And Feature.AbsoluteStart <= intRangeEnd And Feature.AbsoluteEnd >= intRangeStart And Feature.AbsoluteEnd < intRangeEnd Then '-0--|--E----S--|--
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd - intRangeStart) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd - intRangeStart) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                ElseIf Feature.AbsoluteStart > intRangeStart And Feature.AbsoluteStart > intRangeEnd And Feature.AbsoluteEnd >= intRangeStart And Feature.AbsoluteEnd < intRangeEnd Then '-0--|--E----|----S-
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd - intRangeStart) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd - intRangeStart) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                ElseIf Feature.AbsoluteStart > intRangeStart And Feature.AbsoluteStart <= intRangeEnd And Feature.AbsoluteEnd < intRangeStart And Feature.AbsoluteEnd < intRangeEnd Then '-0--E----|----S--|-
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd - intRangeStart) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd - intRangeStart) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                ElseIf Feature.AbsoluteStart > intRangeStart And Feature.AbsoluteStart > intRangeEnd And Feature.AbsoluteEnd > intRangeStart And Feature.AbsoluteEnd >= intRangeEnd Then '-0--|----|--E----S--
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd - intRangeStart) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd - intRangeStart) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                ElseIf Feature.AbsoluteStart <= intRangeStart And Feature.AbsoluteStart < intRangeEnd And Feature.AbsoluteEnd < intRangeStart And Feature.AbsoluteEnd < intRangeEnd Then '-0--E----S--|----|--
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd - intRangeStart) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd - intRangeStart) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                End If

            End If



        End If
    End Sub

    Public Shared Sub CalculateFeatureProjectionOverlap(ByRef Feature As Genome_Feature, ByRef TargetDisplayedList As List(Of Genome_Feature), ByVal intRangeStart As Integer, ByVal intRangeEnd As Integer, ByVal SequenceLength As Integer, ByVal Projection_K As Single)
        Feature.InvertedView = False

        If Feature.Visible Then
            If Feature.AbsoluteStart <= Feature.AbsoluteEnd Then 'Feature does not overlap with mount point

                If Feature.AbsoluteStart < intRangeStart And Feature.AbsoluteEnd < intRangeStart And Feature.AbsoluteStart < intRangeEnd And Feature.AbsoluteEnd <= intRangeEnd Then '---0-|-S---E-|-
                    Feature.ProjectionStart = (Feature.AbsoluteStart + SequenceLength - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd + SequenceLength - intRangeStart + 1) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart + SequenceLength - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd + SequenceLength - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                ElseIf Feature.AbsoluteStart >= intRangeStart And Feature.AbsoluteEnd > intRangeStart And Feature.AbsoluteStart > intRangeEnd And Feature.AbsoluteEnd > intRangeEnd Then '-|-S---E-|-0---
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd - intRangeStart + 1) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                ElseIf Feature.AbsoluteStart < intRangeStart And Feature.AbsoluteStart <= intRangeEnd And Feature.AbsoluteEnd >= intRangeStart And Feature.AbsoluteEnd > intRangeEnd Then '-|--E--0--S--|-
                    Feature.ProjectionStart = (Feature.AbsoluteStart + SequenceLength - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd - intRangeStart + 1) * Projection_K
                    Feature.InvertedView = True

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart + SequenceLength - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                ElseIf Feature.AbsoluteStart < intRangeStart And Feature.AbsoluteStart <= intRangeEnd And Feature.AbsoluteEnd < intRangeStart And Feature.AbsoluteEnd > intRangeEnd Then '-E-|---0--S--|-
                    Feature.ProjectionStart = (Feature.AbsoluteStart + SequenceLength - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd + SequenceLength - intRangeStart + 1) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart + SequenceLength - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd + SequenceLength - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                ElseIf Feature.AbsoluteStart < intRangeStart And Feature.AbsoluteStart > intRangeEnd And Feature.AbsoluteEnd >= intRangeStart And Feature.AbsoluteEnd > intRangeEnd Then '-|--E--0---|-S-
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd - intRangeStart + 1) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                End If

            Else 'Feature overlaps with mount point

                If Feature.AbsoluteStart >= intRangeStart And Feature.AbsoluteEnd <= intRangeEnd And Feature.AbsoluteStart > intRangeEnd And Feature.AbsoluteEnd < intRangeStart Then '|--S--0--E--|
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd + SequenceLength - intRangeStart + 1) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd + SequenceLength - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                ElseIf Feature.AbsoluteStart < intRangeStart And Feature.AbsoluteEnd <= intRangeEnd And Feature.AbsoluteStart > intRangeEnd And Feature.AbsoluteEnd < intRangeStart Then 'S--|-----0--E--|
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd + SequenceLength - intRangeStart + 1) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd + SequenceLength - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                ElseIf Feature.AbsoluteStart >= intRangeStart And Feature.AbsoluteEnd > intRangeEnd And Feature.AbsoluteStart > intRangeEnd And Feature.AbsoluteEnd < intRangeStart Then '|--S--0-----|--E
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd + SequenceLength - intRangeStart + 1) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd + SequenceLength - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                ElseIf Feature.AbsoluteStart < intRangeStart And Feature.AbsoluteEnd > intRangeEnd And Feature.AbsoluteStart > intRangeEnd And Feature.AbsoluteEnd < intRangeStart Then 'S--|-----0-----|--E
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd + SequenceLength - intRangeStart + 1) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd + SequenceLength - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                ElseIf Feature.AbsoluteStart <= intRangeEnd And Feature.AbsoluteEnd <= intRangeEnd And Feature.AbsoluteStart < intRangeStart And Feature.AbsoluteEnd < intRangeStart Then '|------0-E-S--|
                    Feature.ProjectionStart = (Feature.AbsoluteStart + SequenceLength - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd + SequenceLength - intRangeStart + 1) * Projection_K
                    Feature.InvertedView = True

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd + SequenceLength - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                ElseIf Feature.AbsoluteStart >= intRangeStart And Feature.AbsoluteEnd >= intRangeStart And Feature.AbsoluteStart > intRangeEnd And Feature.AbsoluteEnd > intRangeEnd Then '|--E-S-0------|
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd - intRangeStart + 1) * Projection_K
                    Feature.InvertedView = True

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        Dim AdjustedStart As Integer = 0
                        Dim AdjustedEnd As Integer = 0

                        For Each ReadElement As ReadItem In Feature.ReadList

                            Select Case Feature.Direction
                                Case 1
                                    AdjustedStart = Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart
                                    AdjustedEnd = Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd
                                Case 2
                                    AdjustedStart = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteStart + 1
                                    AdjustedEnd = Feature.AbsoluteEnd - ReadElement.ReadAbsoluteEnd - 1
                            End Select

                            ReadElement.ReadProjectionStart = (AdjustedStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (AdjustedEnd - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    If Not IsNothing(TargetDisplayedList) Then
                        TargetDisplayedList.Add(Feature)
                    End If
                End If

            End If

        End If
    End Sub

    Private Shared Sub AssignPairedMarkerProjectionNormal( _
    ByRef Marker As SequenceMarker, _
    ByRef StartMarker As SequenceMarker, _
    ByRef EndMarker As SequenceMarker, _
    ByRef listDisplayedSequenceMarkers As List(Of SequenceMarker), _
    ByVal intRangeStart As Integer, ByVal intRangeEnd As Integer, ByVal SequenceLength As Integer, ByVal Projection_K As Single)

        'StartMarker.ProjectionPosition = (StartMarker.AbsolutePosition - intRangeStart) * Projection_K
        'EndMarker.ProjectionPosition = (EndMarker.AbsolutePosition - intRangeStart) * Projection_K


        If StartMarker.EndOfSeq And intRangeEnd = SequenceLength Then
            Marker.InvertedView = False
            Marker.MyPartner.InvertedView = False
            StartMarker.ProjectionPosition = (intRangeEnd - intRangeStart + 1) * Projection_K
        Else
            StartMarker.ProjectionPosition = (StartMarker.AbsolutePosition - intRangeStart) * Projection_K
        End If

        If EndMarker.EndOfSeq And intRangeEnd = SequenceLength Then
            Marker.InvertedView = False
            Marker.MyPartner.InvertedView = False
            EndMarker.ProjectionPosition = (intRangeEnd - intRangeStart + 1) * Projection_K
        Else
            EndMarker.ProjectionPosition = (EndMarker.AbsolutePosition - intRangeStart) * Projection_K
        End If

        Marker.Counted = True
        Marker.MyPartner.Counted = True
        listDisplayedSequenceMarkers.Add(Marker)
        listDisplayedSequenceMarkers.Add(Marker.MyPartner)

    End Sub

    Public Shared Sub CalculateMarkerProjectionNormal(ByRef Marker As SequenceMarker, ByRef listDisplayedSequenceMarkers As List(Of SequenceMarker), ByVal intRangeStart As Integer, ByVal intRangeEnd As Integer, ByVal SequenceLength As Integer, ByVal Projection_K As Single)

        If Not IsNothing(Marker.MyPartner) Then
            Dim StartMarker As SequenceMarker = Marker.GetStartMarker
            Dim EndMarker As SequenceMarker = Marker.GetEndMarker
            Dim StartPos As Integer = Marker.GetStartPos
            Dim EndPos As Integer = Marker.GetEndPos

            If StartPos < EndPos Then 'Marker does not overlap with mount point

                If EndPos > intRangeStart And StartPos < intRangeEnd Then
                    AssignPairedMarkerProjectionNormal(Marker, StartMarker, EndMarker, listDisplayedSequenceMarkers, intRangeStart, intRangeEnd, SequenceLength, Projection_K)
                End If

            Else 'Marker overlaps with mount point

                Marker.InvertedView = True
                Marker.MyPartner.InvertedView = True

                If StartPos > intRangeStart And StartPos <= intRangeEnd And EndPos >= intRangeStart And EndPos < intRangeEnd Then '-0--|--E----S--|--
                    AssignPairedMarkerProjectionNormal(Marker, StartMarker, EndMarker, listDisplayedSequenceMarkers, intRangeStart, intRangeEnd, SequenceLength, Projection_K)

                ElseIf StartPos > intRangeStart And StartPos > intRangeEnd And EndPos >= intRangeStart And EndPos < intRangeEnd Then '-0--|--E----|----S-
                    AssignPairedMarkerProjectionNormal(Marker, StartMarker, EndMarker, listDisplayedSequenceMarkers, intRangeStart, intRangeEnd, SequenceLength, Projection_K)

                ElseIf StartPos > intRangeStart And StartPos <= intRangeEnd And EndPos < intRangeStart And EndPos < intRangeEnd Then '-0--E----|----S--|-
                    AssignPairedMarkerProjectionNormal(Marker, StartMarker, EndMarker, listDisplayedSequenceMarkers, intRangeStart, intRangeEnd, SequenceLength, Projection_K)

                ElseIf StartPos > intRangeStart And StartPos > intRangeEnd And EndPos > intRangeStart And EndPos >= intRangeEnd Then '-0--|----|--E----S--
                    AssignPairedMarkerProjectionNormal(Marker, StartMarker, EndMarker, listDisplayedSequenceMarkers, intRangeStart, intRangeEnd, SequenceLength, Projection_K)

                ElseIf StartPos <= intRangeStart And StartPos < intRangeEnd And EndPos < intRangeStart And EndPos < intRangeEnd Then '-0--E----S--|----|--
                    AssignPairedMarkerProjectionNormal(Marker, StartMarker, EndMarker, listDisplayedSequenceMarkers, intRangeStart, intRangeEnd, SequenceLength, Projection_K)
                End If

            End If
        Else 'Single marker
            If Marker.AbsolutePosition >= intRangeStart And Marker.AbsolutePosition <= intRangeEnd Then
                Marker.ProjectionPosition = (Marker.AbsolutePosition - intRangeStart) * Projection_K
                Marker.Counted = True
                listDisplayedSequenceMarkers.Add(Marker)
            End If

            If Marker.EndOfSeq And intRangeEnd = SequenceLength Then 'Marker stands after the last nt of the sequence
                Marker.ProjectionPosition = (intRangeEnd - intRangeStart + 1) * Projection_K
                Marker.Counted = True
                listDisplayedSequenceMarkers.Add(Marker)
            End If
        End If

    End Sub

    Public Shared Sub CalculateMarkerProjectionOverlap(ByRef Marker As SequenceMarker, ByRef listDisplayedSequenceMarkers As List(Of SequenceMarker), ByVal intRangeStart As Integer, ByVal intRangeEnd As Integer, ByVal SequenceLength As Integer, ByVal Projection_K As Single)
        'Viewport overlaps with mount point

        If Not IsNothing(Marker.MyPartner) Then

            Dim StartMarker As SequenceMarker = Marker.GetStartMarker
            Dim EndMarker As SequenceMarker = Marker.GetEndMarker
            Dim StartPos As Integer = Marker.GetStartPos
            Dim EndPos As Integer = Marker.GetEndPos

            If StartPos < EndPos Then 'Marker does not overlap with mount point

                If StartPos < intRangeStart And EndPos < intRangeStart And StartPos < intRangeEnd And EndPos <= intRangeEnd Then '---0-|-S---E-|-
                    StartMarker.ProjectionPosition = (StartMarker.AbsolutePosition + SequenceLength - intRangeStart) * Projection_K
                    EndMarker.ProjectionPosition = (EndMarker.AbsolutePosition + SequenceLength - intRangeStart) * Projection_K
                    Marker.Counted = True
                    Marker.MyPartner.Counted = True
                    listDisplayedSequenceMarkers.Add(Marker)
                    listDisplayedSequenceMarkers.Add(Marker.MyPartner)
                ElseIf StartPos >= intRangeStart And EndPos > intRangeStart And StartPos > intRangeEnd And EndPos > intRangeEnd Then '-|-S---E-|-0---
                    StartMarker.ProjectionPosition = (StartMarker.AbsolutePosition - intRangeStart) * Projection_K
                    EndMarker.ProjectionPosition = (EndMarker.AbsolutePosition - intRangeStart) * Projection_K
                    Marker.Counted = True
                    Marker.MyPartner.Counted = True
                    listDisplayedSequenceMarkers.Add(Marker)
                    listDisplayedSequenceMarkers.Add(Marker.MyPartner)
                ElseIf (StartPos < intRangeStart And StartPos <= intRangeEnd) Or (EndPos >= intRangeStart And EndPos > intRangeEnd) Then '-|--E--0--S--|-
                    StartMarker.ProjectionPosition = (StartMarker.AbsolutePosition + SequenceLength - intRangeStart) * Projection_K
                    EndMarker.ProjectionPosition = (EndMarker.AbsolutePosition - intRangeStart) * Projection_K
                    Marker.InvertedView = True
                    Marker.MyPartner.InvertedView = True
                    Marker.Counted = True
                    Marker.MyPartner.Counted = True
                    listDisplayedSequenceMarkers.Add(Marker)
                    listDisplayedSequenceMarkers.Add(Marker.MyPartner)
                End If

            Else 'Marker overlaps with mount point

                If StartPos >= intRangeStart And EndPos <= intRangeEnd And StartPos > intRangeEnd And EndPos < intRangeStart Then '|--S--0--E--|
                    StartMarker.ProjectionPosition = (StartMarker.AbsolutePosition - intRangeStart) * Projection_K
                    EndMarker.ProjectionPosition = (EndMarker.AbsolutePosition + SequenceLength - intRangeStart) * Projection_K
                    Marker.Counted = True
                    Marker.MyPartner.Counted = True
                    listDisplayedSequenceMarkers.Add(Marker)
                    listDisplayedSequenceMarkers.Add(Marker.MyPartner)
                ElseIf StartPos < intRangeStart And EndPos <= intRangeEnd And StartPos > intRangeEnd And EndPos < intRangeStart Then 'S--|-----0--E--|
                    StartMarker.ProjectionPosition = (StartMarker.AbsolutePosition - intRangeStart) * Projection_K
                    EndMarker.ProjectionPosition = (EndMarker.AbsolutePosition + SequenceLength - intRangeStart) * Projection_K
                    Marker.Counted = True
                    Marker.MyPartner.Counted = True
                    listDisplayedSequenceMarkers.Add(Marker)
                    listDisplayedSequenceMarkers.Add(Marker.MyPartner)
                ElseIf StartPos >= intRangeStart And EndPos > intRangeEnd And StartPos > intRangeEnd And EndPos < intRangeStart Then '|--S--0-----|--E
                    StartMarker.ProjectionPosition = (StartMarker.AbsolutePosition - intRangeStart) * Projection_K
                    EndMarker.ProjectionPosition = (EndMarker.AbsolutePosition + SequenceLength - intRangeStart) * Projection_K
                    Marker.Counted = True
                    Marker.MyPartner.Counted = True
                    listDisplayedSequenceMarkers.Add(Marker)
                    listDisplayedSequenceMarkers.Add(Marker.MyPartner)
                ElseIf StartPos < intRangeStart And EndPos > intRangeEnd And StartPos > intRangeEnd And EndPos < intRangeStart Then 'S--|-----0-----|--E
                    StartMarker.ProjectionPosition = (StartMarker.AbsolutePosition - intRangeStart) * Projection_K
                    EndMarker.ProjectionPosition = (EndMarker.AbsolutePosition + SequenceLength - intRangeStart) * Projection_K
                    Marker.Counted = True
                    Marker.MyPartner.Counted = True
                    listDisplayedSequenceMarkers.Add(Marker)
                    listDisplayedSequenceMarkers.Add(Marker.MyPartner)
                ElseIf StartPos <= intRangeEnd And EndPos <= intRangeEnd And StartPos < intRangeStart And EndPos < intRangeStart Then '|------0-E-S--|
                    StartMarker.ProjectionPosition = (StartMarker.AbsolutePosition + SequenceLength - intRangeStart) * Projection_K
                    EndMarker.ProjectionPosition = (EndMarker.AbsolutePosition + SequenceLength - intRangeStart) * Projection_K
                    Marker.InvertedView = True
                    Marker.MyPartner.InvertedView = True
                    Marker.Counted = True
                    Marker.MyPartner.Counted = True
                    listDisplayedSequenceMarkers.Add(Marker)
                    listDisplayedSequenceMarkers.Add(Marker.MyPartner)
                ElseIf StartPos >= intRangeStart And EndPos >= intRangeStart And StartPos > intRangeEnd And EndPos > intRangeEnd Then '|--E-S-0------|
                    StartMarker.ProjectionPosition = (StartMarker.AbsolutePosition - intRangeStart) * Projection_K
                    EndMarker.ProjectionPosition = (EndMarker.AbsolutePosition - intRangeStart) * Projection_K
                    Marker.InvertedView = True
                    Marker.MyPartner.InvertedView = True
                    Marker.Counted = True
                    Marker.MyPartner.Counted = True
                    listDisplayedSequenceMarkers.Add(Marker)
                    listDisplayedSequenceMarkers.Add(Marker.MyPartner)
                End If

            End If

        Else 'Single marker

            If Marker.AbsolutePosition >= intRangeStart Then 'Left side relative to zero
                Marker.ProjectionPosition = (Marker.AbsolutePosition - intRangeStart) * Projection_K
                Marker.Counted = True
                listDisplayedSequenceMarkers.Add(Marker)
            End If

            If Marker.AbsolutePosition <= intRangeEnd Then 'Right side relative to zero
                Marker.ProjectionPosition = (Marker.AbsolutePosition + SequenceLength - intRangeStart) * Projection_K
                Marker.Counted = True
                listDisplayedSequenceMarkers.Add(Marker)
            End If

        End If


    End Sub

#End Region

#Region "Features topology"
    Public Shared Function IsTrueAntisenseFeature(ByVal MainFeature As Genome_Feature, ByVal QueryFeature As Genome_Feature)
        'Query is a potential antisense and is contained within Main and is in the opposite direction
        Dim Result As Boolean = False

        If QueryFeature.AbsoluteStart > MainFeature.AbsoluteStart And QueryFeature.AbsoluteEnd < MainFeature.AbsoluteEnd _
        And ((QueryFeature.Direction = 1 And MainFeature.Direction = 2) Or (QueryFeature.Direction = 2 And MainFeature.Direction = 1)) Then
            Result = True
        End If

        Return Result
    End Function

    Public Shared Sub FindTSSForGenes(ByVal GenomeSequence As String, ByVal TSS_container As List(Of Genome_Feature), ByVal Genes_container As List(Of Genome_Feature), ByVal MaxDistance As Integer, ByVal Overlap As Integer, ByVal SaveFileWindow As SaveFileDialog)

        If SaveFileWindow.ShowDialog = DialogResult.OK Then

            Dim WriteStream As New IO.FileStream(SaveFileWindow.FileName, IO.FileMode.Create)
            Dim Writer As New IO.StreamWriter(WriteStream)

            For Each Gene As Genome_Feature In Genes_container
                For Each TSS As Genome_Feature In TSS_container
                    If Gene.Direction = 1 Then
                        If Gene.AbsoluteStart - MaxDistance <= TSS.AbsoluteStart And _
                        Gene.AbsoluteStart + Overlap - 1 >= TSS.AbsoluteStart And _
                        Gene.Direction = TSS.Direction Then
                            Writer.WriteLine(Gene.TAG & Chr(9) & Gene.Name & Chr(9) & TSS.TAG & Chr(9) & TSS.Name & Chr(9) & Gene.AbsoluteStart - TSS.AbsoluteStart + 1 & Chr(9) & DataIO.RetrieveSeqFromCache(GenomeSequence, TSS.AbsoluteStart - 50, TSS.AbsoluteStart + 5))

                        End If
                    ElseIf Gene.Direction = 2 Then
                        If Gene.AbsoluteEnd + MaxDistance >= TSS.AbsoluteEnd And _
                        Gene.AbsoluteEnd - Overlap + 1 <= TSS.AbsoluteEnd And _
                        Gene.Direction = TSS.Direction Then
                            Writer.WriteLine(Gene.TAG & Chr(9) & Gene.Name & Chr(9) & TSS.TAG & Chr(9) & TSS.Name & Chr(9) & TSS.AbsoluteEnd - Gene.AbsoluteEnd + 1 & Chr(9) & Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(GenomeSequence, TSS.AbsoluteEnd - 5, TSS.AbsoluteEnd + 50)))

                        End If

                    End If


                Next

            Next




            Writer.Close()
            WriteStream.Close()
            Writer.Dispose()
            WriteStream.Dispose()

        End If

    End Sub


#End Region

#Region "Motif search"

    Public Shared Function UpstreamCut(ByVal Sequence As String, ByVal FeaturesList As List(Of Genome_Feature), Optional ByVal OperonLimit As Short = 31, Optional ByVal SearchOption As Short = 0)
        Dim StrList As New List(Of String)

        Dim Tmp As Genome_Feature = Nothing
        For i = 1 To FeaturesList.Count - 1
            For j = 0 To FeaturesList.Count - 1 - i
                If FeaturesList(j).AbsoluteStart > FeaturesList(j + 1).AbsoluteStart Then
                    Tmp = FeaturesList(j)
                    FeaturesList(j) = FeaturesList(j + 1)
                    FeaturesList(j + 1) = Tmp
                End If
            Next
        Next

        Select Case SearchOption
            Case 0
                For i = FeaturesList.Count - 1 To 0 Step -1
                    If Not FeaturesList(i).Type = 1 Then
                        FeaturesList.RemoveAt(i)
                    End If
                Next
        End Select

        For i = FeaturesList.Count - 1 To 0 Step -1
            If FeaturesList(i).Name.Contains("vlhA") Then
                FeaturesList.RemoveAt(i)
            End If
        Next

        For i = FeaturesList.Count - 1 To 0 Step -1
            If FeaturesList(i).Description.Contains("transposase") Then
                FeaturesList.RemoveAt(i)
            End If
        Next


        For i = 0 To FeaturesList.Count - 1

            Select Case FeaturesList(i).Direction
                Case 1
                    If i > 0 Then

                        If Not (FeaturesList(i - 1).Direction = FeaturesList(i).Direction And FeaturesList(i).AbsoluteStart - FeaturesList(i - 1).AbsoluteEnd < OperonLimit) Then
                            StrList.Add(">" & FeaturesList(i).TAG & "_" & FeaturesList(i).Name & "_" & FeaturesList(i).Description.Replace(" ", "_") & Environment.NewLine & Sequence.Substring(FeaturesList(i).AbsoluteStart - 130, 130))
                        End If

                    Else
                        If FeaturesList(i).AbsoluteStart < 100 Then
                            StrList.Add(">" & FeaturesList(i).TAG & "_" & FeaturesList(i).Name & "_" & FeaturesList(i).Description.Replace(" ", "_") & Environment.NewLine & Sequence.Substring(0, 130))
                        Else
                            StrList.Add(">" & FeaturesList(i).TAG & "_" & FeaturesList(i).Name & "_" & FeaturesList(i).Description.Replace(" ", "_") & Environment.NewLine & Sequence.Substring(FeaturesList(i).AbsoluteStart - 130, 130))
                        End If
                    End If
                Case 2

                    If i < FeaturesList.Count - 1 Then
                        If Not (FeaturesList(i + 1).Direction = FeaturesList(i).Direction And FeaturesList(i + 1).AbsoluteStart - FeaturesList(i).AbsoluteEnd < OperonLimit) Then
                            StrList.Add(">" & FeaturesList(i).TAG & "_" & FeaturesList(i).Name & "_" & FeaturesList(i).Description.Replace(" ", "_") & Environment.NewLine & Bioinformatics.GetReverseComplement(Sequence.Substring(FeaturesList(i).AbsoluteEnd - 0, 130)))
                        End If
                    Else
                        If FeaturesList(i).AbsoluteEnd < Sequence.Length - 100 Then
                            StrList.Add(">" & FeaturesList(i).TAG & "_" & FeaturesList(i).Name & "_" & FeaturesList(i).Description.Replace(" ", "_") & Environment.NewLine & Bioinformatics.GetReverseComplement(Sequence.Substring(Sequence.Length - 130, 130)))
                        Else
                            StrList.Add(">" & FeaturesList(i).TAG & "_" & FeaturesList(i).Name & "_" & FeaturesList(i).Description.Replace(" ", "_") & Environment.NewLine & Bioinformatics.GetReverseComplement(Sequence.Substring(FeaturesList(i).AbsoluteEnd - 0)))
                        End If
                    End If

            End Select




        Next

        Return StrList
    End Function

    Public Shared Function Calculate_T_Amount(ByVal Seq As Char(), ByVal ShoulderLength As Integer, Optional ByVal CircularView As Boolean = False, Optional ByVal ToolPBar As ToolStripProgressBar = Nothing)
        Dim FunctionResult As New List(Of Single)
        Dim T_count As Integer = 0
        Dim WindowLength As Integer = ShoulderLength + 1

        If Not IsNothing(ToolPBar) Then
            ToolPBar.Value = 0
            ToolPBar.Maximum = Seq.Length - WindowLength + 2
        End If

        For i = 0 To ShoulderLength - 1
            FunctionResult.Add(0)
        Next

        For i = 0 To Seq.Length - WindowLength

            T_count = 0
            For j = 0 To WindowLength - 1

                If Seq(i + j) = "T" Then
                    T_count += 1
                End If

            Next


            FunctionResult.Add(T_count / WindowLength)

            If Not IsNothing(ToolPBar) Then
                ToolPBar.Value += 1
            End If

        Next

        Return FunctionResult
    End Function

    Public Shared Function Calculate_A_Amount(ByVal Seq As Char(), ByVal ShoulderLength As Integer, Optional ByVal CircularView As Boolean = False, Optional ByVal ToolPBar As ToolStripProgressBar = Nothing)
        Dim FunctionResult As New List(Of Single)
        Dim A_count As Integer = 0
        Dim WindowLength As Integer = ShoulderLength + 1

        If Not IsNothing(ToolPBar) Then
            ToolPBar.Value = 0
            ToolPBar.Maximum = Seq.Length - WindowLength + 2
        End If

        For i = 0 To ShoulderLength - 1
            FunctionResult.Add(0)
        Next

        For i = 0 To Seq.Length - WindowLength

            A_count = 0
            For j = 0 To WindowLength - 1

                If Seq(i + j) = "A" Then
                    A_count += 1
                End If

            Next


            FunctionResult.Add(A_count / WindowLength)

            If Not IsNothing(ToolPBar) Then
                ToolPBar.Value += 1
            End If

        Next

        Return FunctionResult
    End Function

    Public Shared Function RepeatSearch(ByVal Seq As String, ByVal WordLength As Integer, ByVal SpacerLength As Integer, ByVal MismatchNumber As Integer, ByVal Inverted As Boolean)
        Dim MotifLength As Integer = WordLength * 2 + SpacerLength
        Dim LeftWord As String = ""
        Dim RightWord As String = ""
        Dim Repeats As New List(Of Genome_Feature)
        Dim MatchNumber As Integer = 0

        For i = 0 To Seq.Length - MotifLength

            LeftWord = Seq.Substring(i, WordLength)

            If Inverted Then
                RightWord = Bioinformatics.GetReverseComplement(Seq.Substring(i + WordLength + SpacerLength, WordLength))
            Else
                RightWord = Seq.Substring(i + WordLength + SpacerLength, WordLength)
            End If


            MatchNumber = 0
            For j = 0 To WordLength - 1
                If LeftWord(j) = RightWord(j) Then
                    MatchNumber += 1

                End If
            Next j

            If MatchNumber >= WordLength - MismatchNumber Then
                Dim Rep_1 As New Genome_Feature
                Rep_1.Type = 9

                Dim Rep_2 As New Genome_Feature
                Rep_2.Type = 9

                Rep_1.AbsoluteStart = i + 1
                Rep_1.AbsoluteEnd = i + WordLength
                Rep_1.Direction = 1

                Rep_2.AbsoluteStart = i + WordLength + SpacerLength + 1
                Rep_2.AbsoluteEnd = i + WordLength * 2 + SpacerLength
                If Inverted Then
                    Rep_2.Direction = 2
                Else
                    Rep_2.Direction = 1
                End If

                Repeats.Add(Rep_1)
                Repeats.Add(Rep_2)


            End If


        Next i

        Return Repeats
    End Function

    Public Shared Function MultiRepeatSearch(ByVal Seq As String, ByVal WordLength As Integer, ByVal SpacerLength As Integer, ByVal ThresholdScore As Single)
        Dim Repeats As New List(Of Genome_Feature)
        Dim MotifLength As Integer = WordLength * 3 + SpacerLength * 2
        Dim LeftWord As String = ""
        Dim MiddleWord As String = ""
        Dim RightWord As String = ""
        Dim CurrentPWM As PWM = Nothing
        Dim CurrentSeqList As New List(Of Char())
        Dim PWM_MaxWeight As Single = 0

        For i = 0 To Seq.Length - MotifLength
            LeftWord = Seq.Substring(i, WordLength)
            MiddleWord = Seq.Substring(i + WordLength + SpacerLength, WordLength)
            RightWord = Seq.Substring(i + WordLength * 2 + SpacerLength * 2, WordLength)

            CurrentSeqList.Clear()
            CurrentSeqList.Add(LeftWord)
            CurrentSeqList.Add(MiddleWord)
            CurrentSeqList.Add(RightWord)

            CurrentPWM = Bioinformatics.CalculateInformationContent(CurrentSeqList, True)

            PWM_MaxWeight = CurrentPWM.GetMaxWeight
            If PWM_MaxWeight >= ThresholdScore Then
                Dim NewFeature As New Genome_Feature
                NewFeature.AbsoluteStart = i + 1
                NewFeature.AbsoluteEnd = i + MotifLength

                NewFeature.Direction = 0
                Repeats.Add(NewFeature)
            End If

        Next i

        Return Repeats
    End Function

    Public Shared Function CalculateInformationContent(ByVal Sequences As List(Of Char()), ByVal SampleSizeCorrection As Boolean)
        Dim NewPWM As New PWM


        Dim A_Count As Integer = 0
        Dim T_Count As Integer = 0
        Dim G_Count As Integer = 0
        Dim C_Count As Integer = 0
        Dim TotalCount As Integer = 0

        Dim A_P As Single = 0
        Dim T_P As Single = 0
        Dim G_P As Single = 0
        Dim C_P As Single = 0

        Dim Bar_Y As Single = 0

        Dim Entropy_A As Single = 0
        Dim Entropy_T As Single = 0
        Dim Entropy_G As Single = 0
        Dim Entropy_C As Single = 0

        Dim ShannonEntropy As Single = 0

        Dim Correction As Single = 0

        If SampleSizeCorrection Then
            Correction = 3 / (2 * Math.Log(2) * Sequences.Count)
        End If

        For i = 0 To Sequences(0).Length - 1
            A_Count = 0
            T_Count = 0
            G_Count = 0
            C_Count = 0

            For j = 0 To Sequences.Count - 1
                Select Case Sequences(j)(i)
                    Case "A"
                        A_Count += 1
                    Case "T"
                        T_Count += 1
                    Case "G"
                        G_Count += 1
                    Case "C"
                        C_Count += 1
                End Select
            Next

            TotalCount = A_Count + T_Count + G_Count + C_Count


            A_P = A_Count / TotalCount
            T_P = T_Count / TotalCount
            G_P = G_Count / TotalCount
            C_P = C_Count / TotalCount


            If Not A_P = 0 Then
                Entropy_A = A_P * Math.Log(A_P) '/ Math.Log(2)
            Else
                Entropy_A = 0
            End If

            If Not T_P = 0 Then
                Entropy_T = T_P * Math.Log(T_P) '/ Math.Log(2)
            Else
                Entropy_T = 0
            End If

            If Not G_P = 0 Then
                Entropy_G = G_P * Math.Log(G_P) '/ Math.Log(2)
            Else
                Entropy_G = 0
            End If

            If Not C_P = 0 Then
                Entropy_C = C_P * Math.Log(C_P) '/ Math.Log(2)
            Else
                Entropy_C = 0
            End If


            ShannonEntropy = -(Entropy_A + _
                               Entropy_T + _
                               Entropy_G + _
                               Entropy_C)


            Bar_Y = 2 - ShannonEntropy - Correction

            Dim NewPWM_cell As New PWM_cell
            NewPWM_cell.A_Weight = Bar_Y * A_P
            NewPWM_cell.T_Weight = Bar_Y * T_P
            NewPWM_cell.G_Weight = Bar_Y * G_P
            NewPWM_cell.C_Weight = Bar_Y * C_P


            NewPWM.PWM_Table.Add(NewPWM_cell)

        Next

        Return NewPWM
    End Function

    Public Shared Function CalculatePWM(ByVal Sequences As List(Of Char()), ByVal BackgroundGC As Single, Optional ByVal SizeCorection As Boolean = False)
        Dim NewPWM As New PWM
        Dim A_count As Integer = 0
        Dim T_count As Integer = 0
        Dim G_count As Integer = 0
        Dim C_count As Integer = 0
        Dim TotalCount As Integer = 0
        Dim GC_P As Single = BackgroundGC / 2
        Dim AT_P As Single = (1 - BackgroundGC) / 2

        Dim CorrectionC As Single = 1
        If SizeCorection Then
            CorrectionC = Math.Log(Sequences.Count)
        End If

        Dim CurrentSeq As Char()

        For i = 0 To Sequences(0).Count - 1
            A_count = 0
            T_count = 0
            G_count = 0
            C_count = 0

            For j = 0 To Sequences.Count - 1

                CurrentSeq = Sequences(j)

                Select Case CurrentSeq(i)
                    Case "A"
                        A_count += 1
                    Case "T"
                        T_count += 1
                    Case "G"
                        G_count += 1
                    Case "C"
                        C_count += 1
                End Select


            Next

            TotalCount = A_count + T_count + G_count + C_count

            Dim NewPWM_cell As New PWM_cell

            If A_count = 0 Then
                NewPWM_cell.A_Weight = Math.Round(Math.Log((1 / TotalCount ^ 2) / AT_P) * CorrectionC, 2)
            Else
                NewPWM_cell.A_Weight = Math.Round(Math.Log((A_count / TotalCount) / AT_P) * CorrectionC, 2)
            End If
            If T_count = 0 Then
                NewPWM_cell.T_Weight = Math.Round(Math.Log((1 / TotalCount ^ 2) / AT_P) * CorrectionC, 2)
            Else
                NewPWM_cell.T_Weight = Math.Round(Math.Log((T_count / TotalCount) / AT_P) * CorrectionC, 2)
            End If
            If G_count = 0 Then
                NewPWM_cell.G_Weight = Math.Round(Math.Log((1 / TotalCount ^ 2) / GC_P) * CorrectionC, 2)
            Else
                NewPWM_cell.G_Weight = Math.Round(Math.Log((G_count / TotalCount) / GC_P) * CorrectionC, 2)
            End If
            If C_count = 0 Then
                NewPWM_cell.C_Weight = Math.Round(Math.Log((1 / TotalCount ^ 2) / GC_P) * CorrectionC, 2)
            Else
                NewPWM_cell.C_Weight = Math.Round(Math.Log((C_count / TotalCount) / GC_P) * CorrectionC, 2)
            End If




            NewPWM.PWM_Table.Add(NewPWM_cell)

        Next

        Return NewPWM
    End Function

    Public Shared Function CalculatePWM(ByVal Sequences As List(Of Char()), ByVal A_P As Single, ByVal T_P As Single, ByVal G_P As Single, ByVal C_P As Single, Optional ByVal SizeCorection As Boolean = False)
        Dim NewPWM As New PWM
        Dim A_count As Integer = 0
        Dim T_count As Integer = 0
        Dim G_count As Integer = 0
        Dim C_count As Integer = 0
        Dim TotalCount As Integer = 0


        Dim CorrectionC As Single = 1
        If SizeCorection Then
            CorrectionC = Math.Log(Sequences.Count)
        End If

        Dim CurrentSeq As Char()

        For i = 0 To Sequences(0).Count - 1
            A_count = 0
            T_count = 0
            G_count = 0
            C_count = 0

            For j = 0 To Sequences.Count - 1

                CurrentSeq = Sequences(j)

                Select Case CurrentSeq(i)
                    Case "A"
                        A_count += 1
                    Case "T"
                        T_count += 1
                    Case "G"
                        G_count += 1
                    Case "C"
                        C_count += 1
                End Select


            Next

            TotalCount = A_count + T_count + G_count + C_count

            Dim NewPWM_cell As New PWM_cell

            If A_count = 0 Then
                NewPWM_cell.A_Weight = Math.Round(Math.Log((1 / TotalCount ^ 2) / A_P) * CorrectionC, 2)
            Else
                NewPWM_cell.A_Weight = Math.Round(Math.Log((A_count / TotalCount) / A_P) * CorrectionC, 2)
            End If
            If T_count = 0 Then
                NewPWM_cell.T_Weight = Math.Round(Math.Log((1 / TotalCount ^ 2) / T_P) * CorrectionC, 2)
            Else
                NewPWM_cell.T_Weight = Math.Round(Math.Log((T_count / TotalCount) / T_P) * CorrectionC, 2)
            End If
            If G_count = 0 Then
                NewPWM_cell.G_Weight = Math.Round(Math.Log((1 / TotalCount ^ 2) / G_P) * CorrectionC, 2)
            Else
                NewPWM_cell.G_Weight = Math.Round(Math.Log((G_count / TotalCount) / G_P) * CorrectionC, 2)
            End If
            If C_count = 0 Then
                NewPWM_cell.C_Weight = Math.Round(Math.Log((1 / TotalCount ^ 2) / C_P) * CorrectionC, 2)
            Else
                NewPWM_cell.C_Weight = Math.Round(Math.Log((C_count / TotalCount) / C_P) * CorrectionC, 2)
            End If




            NewPWM.PWM_Table.Add(NewPWM_cell)

        Next

        Return NewPWM
    End Function

    Public Shared Function CalculateWeight(ByVal Sequence As String, ByVal Local_PWM As PWM)
        Dim Weight As Single = 0
        Dim SeqChr As Char() = Sequence.ToCharArray

        For i = 0 To SeqChr.GetUpperBound(0)
            Select Case SeqChr(i)
                Case "A"
                    Weight += Local_PWM.PWM_Table(i).A_Weight
                Case "T"
                    Weight += Local_PWM.PWM_Table(i).T_Weight
                Case "G"
                    Weight += Local_PWM.PWM_Table(i).G_Weight
                Case "C"
                    Weight += Local_PWM.PWM_Table(i).C_Weight
            End Select
        Next


        Return Weight
    End Function

    Public Shared Function GetReverseComplementPWM(ByVal TemplatePWM As PWM)
        Dim RevCompPWM As New PWM

        RevCompPWM.PWM_Table = TemplatePWM.PWM_Table
        RevCompPWM.PWM_Table.Reverse()

        Dim InitialA As Single = 0
        Dim InitialT As Single = 0
        Dim InitialG As Single = 0
        Dim InitialC As Single = 0
        For Each cell As PWM_cell In RevCompPWM.PWM_Table
            InitialA = cell.A_Weight
            InitialT = cell.T_Weight
            InitialG = cell.G_Weight
            InitialC = cell.C_Weight

            cell.A_Weight = InitialT
            cell.T_Weight = InitialA
            cell.G_Weight = InitialC
            cell.C_Weight = InitialG
        Next

        Return RevCompPWM
    End Function

    Public Shared Function SearchMotifWithPWM(ByVal QuerySequence As String, ByVal Motif_PWM As PWM)
        Dim Word_List As New List(Of K_Word_Weighted)
        Word_List = Bioinformatics.Make_K_Word_List_Weighted(QuerySequence, Motif_PWM.PWM_Table.Count)

        For Each Word As K_Word_Weighted In Word_List
            Word.Weight = Calculate_Word_Weight(Word.Word_Text, Motif_PWM)
        Next

        Return Word_List
    End Function

    Public Shared Function Make_K_Word_List_Weighted(ByVal QueryString As String, ByVal WordLength As Integer)
        Dim Weighted_K_Word_List As New List(Of K_Word_Weighted)

        For i = 0 To QueryString.Length - WordLength
            Dim KWord As New K_Word_Weighted
            KWord.Relative_Position = i
            KWord.Word_Text = QueryString.Substring(i, WordLength)
            Weighted_K_Word_List.Add(KWord)
        Next

        Return Weighted_K_Word_List
    End Function

    Public Shared Function Calculate_Word_Weight(ByVal Word As String, ByVal Motif_PWM As PWM)
        Dim ChrArr As Char() = Word.ToCharArray
        Dim CalculatedWeight As Single = 0

        For i = 0 To ChrArr.GetUpperBound(0)
            Select Case ChrArr(i)
                Case "A"
                    CalculatedWeight += Motif_PWM.PWM_Table(i).A_Weight
                Case "T"
                    CalculatedWeight += Motif_PWM.PWM_Table(i).T_Weight
                Case "G"
                    CalculatedWeight += Motif_PWM.PWM_Table(i).G_Weight
                Case "C"
                    CalculatedWeight += Motif_PWM.PWM_Table(i).C_Weight
            End Select
        Next

        Return CalculatedWeight
    End Function

    Public Shared Function Get_Min_PWM_Weight(ByVal Target_PWM As PWM, ByVal Threshold As Single)
        Dim Result As Single = Target_PWM.GetMinWeight + (Target_PWM.GetMaxWeight - Target_PWM.GetMinWeight) * Threshold

        Return Result
    End Function

    Public Shared Function FindBestPWMEntry(ByVal QuerySequence As String, ByVal Motif_PWM As PWM)
        Dim Word_List As New List(Of K_Word_Weighted)
        Word_List = SearchMotifWithPWM(QuerySequence, Motif_PWM)

        Dim Result As K_Word_Weighted = Nothing
        Result = Word_List(0)

        For Each Word As K_Word_Weighted In Word_List
            If Word.Weight >= Result.Weight Then
                Result = Word
            End If
        Next

        Return Result
    End Function

    Public Shared Sub FindBestPWMEntryInMultifasta(ByVal InputFile As String, ByVal PWMFile As String, Optional ByVal Use_Weight_Cutoff As Boolean = False, Optional ByVal Min_Weight As Single = 0)
        Dim MyPWM As New PWM
        MyPWM = DataIO.LoadPWM(PWMFile)

        Dim PWMNameArr As String() = PWMFile.Split("\")
        Dim PWMName As String = PWMNameArr(PWMNameArr.GetUpperBound(0)).Split(".")(0)

        Dim Result As New List(Of String)

        Dim RS As New IO.FileStream(InputFile, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(RS)
        Dim FilePathArr As String() = InputFile.Split("\")
        Dim AnalysisName As String = FilePathArr(FilePathArr.GetUpperBound(0)).Split(".")(0)
        Dim FileDir As String = ""
        For i = 0 To FilePathArr.GetUpperBound(0) - 1
            FileDir &= FilePathArr(i) & "\"
        Next

        Dim AdditionalInfo As String = ""
        If Use_Weight_Cutoff Then
            AdditionalInfo = "-minW-" & Min_Weight
        End If

        Dim WS As New IO.FileStream(FileDir & AnalysisName & "-best PWM entries-" & PWMName & AdditionalInfo & ".txt", IO.FileMode.Create)
        Dim Writer As New IO.StreamWriter(WS)

        Dim CurrentLine As String = ""
        Dim CurrentHeader As String = ""
        Dim BestWord As K_Word_Weighted = Nothing

        Dim PositionList As New List(Of K_Word_Weighted)
        Writer.WriteLine("Name" & Chr(9) & "Full_Seq" & Chr(9) & "Best_Seq" & Chr(9) & "Best_Weight" & Chr(9) & "Best_Position")

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            If CurrentLine.StartsWith(">") Then 'This is fasta header
                CurrentHeader = CurrentLine.Substring(1)
            Else 'This is sequence
                BestWord = FindBestPWMEntry(CurrentLine, MyPWM)
                If Use_Weight_Cutoff Then
                    If BestWord.Weight >= Min_Weight Then
                        Writer.WriteLine(CurrentHeader & Chr(9) & CurrentLine & Chr(9) & BestWord.Word_Text & Chr(9) & BestWord.Weight & Chr(9) & BestWord.Relative_Position)
                        PositionList.Add(BestWord)
                    End If
                Else
                    Writer.WriteLine(CurrentHeader & Chr(9) & CurrentLine & Chr(9) & BestWord.Word_Text & Chr(9) & BestWord.Weight & Chr(9) & BestWord.Relative_Position)
                    PositionList.Add(BestWord)
                End If

            End If

        End While




        Reader.Close()
        RS.Close()
        Reader.Dispose()
        RS.Dispose()
        Writer.Close()
        WS.Close()
        Writer.Dispose()
        WS.Dispose()


        Dim ReportStream As New IO.FileStream(FileDir & AnalysisName & "-integrated-" & PWMName & AdditionalInfo & ".txt", IO.FileMode.Create)
        Dim ReportWriter As New IO.StreamWriter(ReportStream)

        Dim MaxPos As Integer = 0
        Dim MinPos As Integer = 0

        MaxPos = PositionList(0).Relative_Position
        MinPos = PositionList(0).Relative_Position

        For Each Word As K_Word_Weighted In PositionList
            If Word.Relative_Position > MaxPos Then
                MaxPos = Word.Relative_Position
            End If
            If Word.Relative_Position < MinPos Then
                MinPos = Word.Relative_Position
            End If
        Next

        Dim count As Integer = 0
        For i = MinPos To MaxPos
            count = 0
            For Each Word As K_Word_Weighted In PositionList
                If Word.Relative_Position = i Then
                    count += 1
                End If
            Next
            ReportWriter.WriteLine(i & Chr(9) & count)
        Next


        ReportWriter.Close()
        ReportStream.Close()
        ReportWriter.Dispose()
        ReportStream.Dispose()

        MsgBox("Files have been created!")

    End Sub

    Public Shared Function GetWordHitTable(ByVal QuerySequence As String, ByVal Word As String, Optional ByVal MismatchCount As Integer = 2)

        Dim MotifHitTable(QuerySequence.Length - Word.Length, MismatchCount) As Integer

        Dim SubQ As String = ""
        Dim MatchCounter As Integer = 0
        Dim CurrentMismatches As Integer = 0

        For i = 0 To QuerySequence.Length - Word.Length
            MatchCounter = 0

            SubQ = QuerySequence.Substring(i, Word.Length)
            For j = 0 To SubQ.Length - 1
                If SubQ(j) = Word(j) Then
                    MatchCounter += 1
                End If
            Next
            CurrentMismatches = Word.Length - MatchCounter


            If CurrentMismatches <= MismatchCount Then
                MotifHitTable(i, CurrentMismatches) += 1

            End If



        Next

        Return MotifHitTable
    End Function

    Public Shared Function GetPWMHitTable(ByVal QuerySequence As String, ByVal Motif_PWM As PWM, Optional ByVal ApproxDensity As Integer = 10)
        Dim Word_List As New List(Of K_Word_Weighted)
        Word_List = SearchMotifWithPWM(QuerySequence, Motif_PWM)
        Dim ReportString As String = ""

        Dim PWM_Hit_Table(Word_List.Count - 1, ApproxDensity - 1) As Integer

        Dim MaxVal As Single = Motif_PWM.GetMaxWeight
        Dim MinVal As Single = Motif_PWM.GetMinWeight

        Dim IntervalStep As Single = (MaxVal - MinVal) / ApproxDensity
        Dim MinBorder As Single = 0
        Dim MaxBorder As Single = 0

        Dim Wcount As Integer = 0


        For Each Word As K_Word_Weighted In Word_List

            For i = 0 To ApproxDensity
                MinBorder = MinVal + IntervalStep * i
                MaxBorder = MinVal + IntervalStep * (i + 1)

                If i = ApproxDensity - 1 Then
                    MaxBorder = MaxVal
                End If

                If Word.Weight <= MaxBorder And Word.Weight >= MinBorder Then
                    PWM_Hit_Table(Wcount, i) += 1

                    Exit For
                End If
            Next

            Wcount += 1
        Next


        Return PWM_Hit_Table
    End Function

    Public Shared Sub GetPWMSpaceFromMultifasta(ByVal InputFile As String, ByVal PWMFile As String, Optional ByVal ApproxDensity As Integer = 10)
        Dim MyPWM As New PWM
        MyPWM = DataIO.LoadPWM(PWMFile)

        Dim PWMNameArr As String() = PWMFile.Split("\")
        Dim PWMName As String = PWMNameArr(PWMNameArr.GetUpperBound(0)).Split(".")(0)


        Dim RS As New IO.FileStream(InputFile, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(RS)
        Dim FilePathArr As String() = InputFile.Split("\")
        Dim AnalysisName As String = FilePathArr(FilePathArr.GetUpperBound(0)).Split(".")(0)
        Dim FileDir As String = ""
        For i = 0 To FilePathArr.GetUpperBound(0) - 1
            FileDir &= FilePathArr(i) & "\"
        Next

        Dim WS As New IO.FileStream(FileDir & AnalysisName & "-PWM_space-" & PWMName & ".txt", IO.FileMode.Create)
        Dim Writer As New IO.StreamWriter(WS)

        Dim CurrentLine As String = ""
        Dim CurrentHeader As String = ""

        Dim HitTable(0, 0) As Integer
        Dim GlobalHitTable(0, 0) As Integer

        Dim Init As Boolean = True


        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            If CurrentLine.StartsWith(">") Then 'This is fasta header
                CurrentHeader = CurrentLine.Substring(1)
            Else 'This is sequence
                HitTable = Bioinformatics.GetPWMHitTable(CurrentLine, MyPWM, ApproxDensity)

                If Init = True Then
                    ReDim GlobalHitTable(HitTable.GetUpperBound(0), HitTable.GetUpperBound(1))
                    Init = False
                End If

                For NtPos = 0 To HitTable.GetUpperBound(0)
                    For ValuePos = 0 To HitTable.GetUpperBound(1)
                        GlobalHitTable(NtPos, ValuePos) += HitTable(NtPos, ValuePos)
                    Next
                Next


            End If
        End While


        Dim DataLine As String = ""

        For NtPos = 0 To GlobalHitTable.GetUpperBound(0)
            DataLine = NtPos & Chr(9)
            For ValuePos = 0 To GlobalHitTable.GetUpperBound(1)
                DataLine &= GlobalHitTable(NtPos, ValuePos) & Chr(9)
            Next
            Writer.WriteLine(DataLine)
        Next

        Reader.Close()
        RS.Close()
        Reader.Dispose()
        RS.Dispose()
        Writer.Close()
        WS.Close()
        Writer.Dispose()
        WS.Dispose()

        MsgBox("File have been created!")

    End Sub

    Public Shared Sub GetWordSpaceFromMultifasta(ByVal InputFile As String, ByVal Word As String)


        Dim RS As New IO.FileStream(InputFile, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(RS)
        Dim FilePathArr As String() = InputFile.Split("\")
        Dim AnalysisName As String = FilePathArr(FilePathArr.GetUpperBound(0)).Split(".")(0)
        Dim FileDir As String = ""
        For i = 0 To FilePathArr.GetUpperBound(0) - 1
            FileDir &= FilePathArr(i) & "\"
        Next

        Dim WS As New IO.FileStream(FileDir & AnalysisName & "-Word_Table-" & Word & ".xls", IO.FileMode.Create)
        Dim Writer As New IO.StreamWriter(WS)

        Dim CurrentLine As String = ""
        Dim CurrentHeader As String = ""

        Dim HitTable(0, 0) As Integer
        Dim GlobalHitTable(0, 0) As Integer

        Dim Init As Boolean = True


        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            If CurrentLine.StartsWith(">") Then 'This is fasta header
                CurrentHeader = CurrentLine.Substring(1)
            Else 'This is sequence
                HitTable = Bioinformatics.GetWordHitTable(CurrentLine, Word)

                If Init = True Then
                    ReDim GlobalHitTable(HitTable.GetUpperBound(0), HitTable.GetUpperBound(1))
                    Init = False
                End If

                For NtPos = 0 To HitTable.GetUpperBound(0)
                    For ValuePos = 0 To HitTable.GetUpperBound(1)
                        GlobalHitTable(NtPos, ValuePos) += HitTable(NtPos, ValuePos)
                    Next
                Next


            End If
        End While


        Dim DataLine As String = ""

        For NtPos = 0 To GlobalHitTable.GetUpperBound(0)
            DataLine = NtPos & Chr(9)
            For ValuePos = 0 To GlobalHitTable.GetUpperBound(1)
                DataLine &= GlobalHitTable(NtPos, ValuePos) & Chr(9)
            Next
            Writer.WriteLine(DataLine)
        Next

        Reader.Close()
        RS.Close()
        Reader.Dispose()
        RS.Dispose()
        Writer.Close()
        WS.Close()
        Writer.Dispose()
        WS.Dispose()
    End Sub

    Public Shared Sub GetWordSpaceFromMultifasta(ByVal InputFile As String, ByVal WordList As List(Of String), Optional ByVal ToolProgressBar As ToolStripProgressBar = Nothing)


        Dim Sequences As New List(Of String)

        If Not IsNothing(ToolProgressBar) Then
            ToolProgressBar.Maximum = WordList.Count + 1
            ToolProgressBar.Value = 0
        End If

        Dim RS As New IO.FileStream(InputFile, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(RS)
        Dim FilePathArr As String() = InputFile.Split("\")
        Dim AnalysisName As String = FilePathArr(FilePathArr.GetUpperBound(0)).Split(".")(0)
        Dim FileDir As String = ""
        For i = 0 To FilePathArr.GetUpperBound(0) - 1
            FileDir &= FilePathArr(i) & "\"
        Next


        Dim CurrentLine As String = ""
        Dim CurrentHeader As String = ""

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            If CurrentLine.StartsWith(">") Then 'This is fasta header
                CurrentHeader = CurrentLine.Substring(1)
            Else 'This is sequence
                Sequences.Add(CurrentLine)
            End If
        End While
        CurrentLine = ""

        Reader.Close()
        RS.Close()
        Reader.Dispose()
        RS.Dispose()

        Dim Init As Boolean = True
        Dim DataLine As String = ""

        For Each Word As String In WordList

            Init = True

            Dim HitTable(0, 0) As Integer
            Dim GlobalHitTable(0, 0) As Integer

            For Each Sequence As String In Sequences


                HitTable = Bioinformatics.GetWordHitTable(Sequence, Word)


                If Init = True Then
                    ReDim GlobalHitTable(HitTable.GetUpperBound(0), HitTable.GetUpperBound(1))
                    Init = False
                End If

                For NtPos = 0 To HitTable.GetUpperBound(0)
                    For ValuePos = 0 To HitTable.GetUpperBound(1)
                        GlobalHitTable(NtPos, ValuePos) += HitTable(NtPos, ValuePos)
                    Next
                Next

                'Dim ReportString As String = ""
                'For NtPos = 0 To HitTable.GetUpperBound(0)
                'ReportString &= NtPos & Chr(9)
                'For ValuePos = 0 To HitTable.GetUpperBound(1)
                'ReportString &= HitTable(NtPos, ValuePos) & Chr(9)
                'Next
                'ReportString &= vbNewLine
                'Next
                'MsgBox(ReportString)

            Next Sequence


            Dim WS As New IO.FileStream(FileDir & AnalysisName & "-Word_Table-" & Word & ".xls", IO.FileMode.Create)
            Dim Writer As New IO.StreamWriter(WS)

            DataLine = ""
            For NtPos = 0 To GlobalHitTable.GetUpperBound(0)
                DataLine = NtPos & Chr(9)
                For ValuePos = 0 To GlobalHitTable.GetUpperBound(1)
                    DataLine &= GlobalHitTable(NtPos, ValuePos) & Chr(9)
                Next
                Writer.WriteLine(DataLine)
            Next


            Writer.Close()
            WS.Close()
            Writer.Dispose()
            WS.Dispose()

            If Not IsNothing(ToolProgressBar) Then
                ToolProgressBar.Value += 1
            End If

        Next Word

        If Not IsNothing(ToolProgressBar) Then
            ToolProgressBar.Value = 0
        End If

    End Sub

    Public Shared Function DecomposeBacterialPromoter(ByVal Seq As String, _
                                                      ByVal PWM_10 As PWM, ByVal PWM_Ext As PWM, _
                                                      ByVal PWM_35 As PWM, ByVal PWM_35alt As PWM, _
                                                      ByVal PWM_Up As PWM, _
                                                      ByVal PWM_TSS_Spacer As PWM, ByVal PWM_m10_m35_Spacer As PWM, _
                                                      ByVal PWM_TSS As PWM, ByVal PWM_TSSalt As PWM, _
                                                      ByVal Spacer_ToTSS As Integer, _
                                                      ByVal Spacer_10To35_Min As Integer, ByVal Spacer_10To35_Max As Integer, _
                                                      ByVal Spacer_ToExt_Min As Integer, ByVal Spacer_ToExt_Max As Integer, _
                                                      ByVal m10_Pos As Integer, ByVal m10Defined As Boolean, ByVal EnableAlt35 As Boolean)

        Dim PromoterParts As New List(Of K_Word_Weighted)

        Dim m10 As New K_Word_Weighted
        Dim MaxUpstream As Integer = PWM_10.PWM_Table.Count + Spacer_10To35_Max + PWM_35.PWM_Table.Count + PWM_Up.PWM_Table.Count + 1


        If m10Defined Then

            m10.Word_Text = Seq.Substring(m10_Pos, PWM_10.PWM_Table.Count)
            m10.Weight = Calculate_Word_Weight(m10.Word_Text, PWM_10)


        Else

            m10 = FindBestPWMEntry(Seq.Substring(MaxUpstream), PWM_10)
            m10_Pos = MaxUpstream + m10.Relative_Position
        End If

        Dim ExtPosMax As Integer = m10_Pos - Spacer_ToExt_Max - PWM_Ext.PWM_Table.Count
        Dim ExtPosMin As Integer = m10_Pos - Spacer_ToExt_Min

        Dim Ext As K_Word_Weighted = FindBestPWMEntry(Seq.Substring(ExtPosMax, ExtPosMin - ExtPosMax), PWM_Ext)

        Dim m35PosMax As Integer = m10_Pos - Spacer_10To35_Max - PWM_35.PWM_Table.Count
        Dim m35PosMin As Integer = m10_Pos - Spacer_10To35_Min

        Dim m35 As K_Word_Weighted = FindBestPWMEntry(Seq.Substring(m35PosMax, m35PosMin - m35PosMax), PWM_35)

        Dim m35alt As New K_Word_Weighted
        If EnableAlt35 Then
            m35alt = FindBestPWMEntry(Seq.Substring(m35PosMax, m35PosMin - m35PosMax), PWM_35alt)
        End If

        Dim Up As New K_Word_Weighted
        Up.Word_Text = Seq.Substring(m35PosMax + m35.Relative_Position - PWM_Up.PWM_Table.Count, PWM_Up.PWM_Table.Count)
        Up.Weight = Calculate_Word_Weight(Up.Word_Text, PWM_Up)

        Dim PrimaryTSS As New K_Word_Weighted
        PrimaryTSS.Word_Text = Seq.Substring(m10_Pos + PWM_10.PWM_Table.Count + Spacer_ToTSS, 1)
        PrimaryTSS.Weight = Calculate_Word_Weight(PrimaryTSS.Word_Text, PWM_TSS)

        Dim SecondaryTSSDown As New K_Word_Weighted
        SecondaryTSSDown.Word_Text = Seq.Substring(m10_Pos + PWM_10.PWM_Table.Count + Spacer_ToTSS + 1, 1)
        SecondaryTSSDown.Weight = Calculate_Word_Weight(SecondaryTSSDown.Word_Text, PWM_TSSalt)

        Dim SecondaryTSSUp As New K_Word_Weighted
        SecondaryTSSUp.Word_Text = Seq.Substring(m10_Pos + PWM_10.PWM_Table.Count + Spacer_ToTSS - 1, 1)
        SecondaryTSSUp.Weight = Calculate_Word_Weight(SecondaryTSSUp.Word_Text, PWM_TSSalt)


        Dim Nucleotides As Char()
        Dim CalculatedWeight As Single = 0

        Dim SpacerToTSS As New K_Word_Weighted
        SpacerToTSS.Word_Text = Seq.Substring(m10_Pos + PWM_10.PWM_Table.Count, Spacer_ToTSS)
        Nucleotides = SpacerToTSS.Word_Text.ToCharArray

        For i = 0 To Nucleotides.GetUpperBound(0)
            Select Case Nucleotides(i)
                Case "A"
                    CalculatedWeight += PWM_TSS_Spacer.PWM_Table(0).A_Weight
                Case "T"
                    CalculatedWeight += PWM_TSS_Spacer.PWM_Table(0).T_Weight
                Case "G"
                    CalculatedWeight += PWM_TSS_Spacer.PWM_Table(0).G_Weight
                Case "C"
                    CalculatedWeight += PWM_TSS_Spacer.PWM_Table(0).C_Weight
            End Select
        Next i
        SpacerToTSS.Weight = CalculatedWeight


        Dim Spacer10_35 As New K_Word_Weighted
        Spacer10_35.Word_Text = Seq.Substring(m10_Pos - Spacer_10To35_Min, Spacer_10To35_Min)
        CalculatedWeight = 0
        Nucleotides = Spacer10_35.Word_Text.ToCharArray

        For i = 0 To Nucleotides.GetUpperBound(0)
            Select Case Nucleotides(i)
                Case "A"
                    CalculatedWeight += PWM_m10_m35_Spacer.PWM_Table(0).A_Weight
                Case "T"
                    CalculatedWeight += PWM_m10_m35_Spacer.PWM_Table(0).T_Weight
                Case "G"
                    CalculatedWeight += PWM_m10_m35_Spacer.PWM_Table(0).G_Weight
                Case "C"
                    CalculatedWeight += PWM_m10_m35_Spacer.PWM_Table(0).C_Weight
            End Select
        Next i
        Spacer10_35.Weight = CalculatedWeight

        PromoterParts.Add(SecondaryTSSDown)
        PromoterParts.Add(PrimaryTSS)
        PromoterParts.Add(SecondaryTSSUp)
        PromoterParts.Add(SpacerToTSS)
        PromoterParts.Add(m10)
        PromoterParts.Add(Ext)
        PromoterParts.Add(Spacer10_35)
        PromoterParts.Add(m35)
        PromoterParts.Add(m35alt)
        PromoterParts.Add(Up)



        Return PromoterParts
    End Function


#End Region

#Region "Matrix-Based Motif Discovery"

    Public Shared Function PrimePWM(ByVal WordText As String, ByVal MatchScore As Single, ByVal MismatchScore As Single, ByVal A_P As Single, ByVal T_P As Single, ByVal G_P As Single, ByVal C_P As Single)
        Dim NewPWM As New PWM

        For i = 0 To WordText.Length - 1
            Dim NewPWMcell As New PWM_cell

            Select Case WordText(i)
                Case "A"
                    NewPWMcell.A_Weight = Math.Log(MatchScore / A_P)
                    NewPWMcell.T_Weight = Math.Log(MismatchScore / T_P)
                    NewPWMcell.G_Weight = Math.Log(MismatchScore / G_P)
                    NewPWMcell.C_Weight = Math.Log(MismatchScore / C_P)
                Case "T"
                    NewPWMcell.A_Weight = Math.Log(MismatchScore / A_P)
                    NewPWMcell.T_Weight = Math.Log(MatchScore / T_P)
                    NewPWMcell.G_Weight = Math.Log(MismatchScore / G_P)
                    NewPWMcell.C_Weight = Math.Log(MismatchScore / C_P)
                Case "G"
                    NewPWMcell.A_Weight = Math.Log(MismatchScore / A_P)
                    NewPWMcell.T_Weight = Math.Log(MismatchScore / T_P)
                    NewPWMcell.G_Weight = Math.Log(MatchScore / G_P)
                    NewPWMcell.C_Weight = Math.Log(MismatchScore / C_P)
                Case "C"
                    NewPWMcell.A_Weight = Math.Log(MismatchScore / A_P)
                    NewPWMcell.T_Weight = Math.Log(MismatchScore / T_P)
                    NewPWMcell.G_Weight = Math.Log(MismatchScore / G_P)
                    NewPWMcell.C_Weight = Math.Log(MatchScore / C_P)
                Case Else
                    NewPWMcell.A_Weight = Math.Log(MismatchScore / A_P)
                    NewPWMcell.T_Weight = Math.Log(MismatchScore / T_P)
                    NewPWMcell.G_Weight = Math.Log(MismatchScore / G_P)
                    NewPWMcell.C_Weight = Math.Log(MismatchScore / C_P)
            End Select
            NewPWM.PWM_Table.Add(NewPWMcell)
        Next

        Return NewPWM
    End Function

    Public Shared Function ReCalcPWM(ByVal CurrentPWMHits As List(Of K_Word_PWM_Hit), ByVal A_P As Single, ByVal T_P As Single, ByVal G_P As Single, ByVal C_P As Single)
        'Select top hits

        Dim WordSeqList As New List(Of Char())

        For Each WordHit As K_Word_PWM_Hit In CurrentPWMHits
            WordSeqList.Add(WordHit.Word_Text.ToCharArray)
        Next

        'Rebuild PWM based on these sequences
        Return Bioinformatics.CalculatePWM(WordSeqList, A_P, T_P, G_P, C_P, True)

    End Function

    Public Shared Function DiscoverMotifsByBestOccurence(ByVal PrimePWMList As List(Of PWM), ByVal SeqWords As List(Of List(Of K_Word_MBMD)), _
                                         ByVal A_P As Single, ByVal T_P As Single, ByVal G_P As Single, ByVal C_P As Single, _
                                         ByVal Prime_PWM_Cutoff_Percent As Single, ByVal ReCalc_PWM_Cutoff_Percent As Single, _
                                         ByVal MinPWMRange As Single, ByVal MinimumMotifHits As Integer)

        Dim TopRatedHits As New List(Of MBMD_Result)

        Dim CurrentPWMCutoffScore As Single = 0
        Dim CurrentPWMMax As Single = 0
        Dim CurrentPWMMin As Single = 0
        Dim CurrentPWMRange As Single = 0
        Dim CurrentPWMHits As New List(Of K_Word_PWM_Hit)

        Dim CurrentScore As Single = 0
        Dim SeqBestScore As Single = 0
        Dim SeqBestWord As K_Word_MBMD = Nothing

        Dim counter As Integer = 0
        Dim PrevScore As Single = 0
        Dim NextScore As Single = 0

        Dim PrevRange As Single = 0
        Dim NextRange As Single = 0


        'Now align each word vs each and calculate score
        For Each QueryPWM As PWM In PrimePWMList 'This PWM is aligned to all words
            CurrentPWMMax = QueryPWM.GetMaxWeight
            CurrentPWMMin = QueryPWM.GetMinWeight
            CurrentPWMRange = CurrentPWMMax - CurrentPWMMin
            CurrentPWMCutoffScore = CurrentPWMMax - CurrentPWMRange * Prime_PWM_Cutoff_Percent

            Do 'Now iterate PWM through words until best matches are found

                CurrentPWMHits.Clear()

                For Each Seq As List(Of K_Word_MBMD) In SeqWords 'Iterate trough sequences to find best occurence per sequence
                    SeqBestScore = Bioinformatics.Calculate_Word_Weight(Seq(0).Word_Text, QueryPWM)
                    SeqBestWord = Nothing

                    'Find the best occurence of the PWM in a sequence
                    For Each Word As K_Word_MBMD In Seq
                        Word.Is_Restricted = False
                        CurrentScore = Bioinformatics.Calculate_Word_Weight(Word.Word_Text, QueryPWM)

                        If CurrentScore >= SeqBestScore And Not Word.Is_Blocked Then
                            SeqBestScore = CurrentScore
                            SeqBestWord = Word
                        End If

                    Next Word

                    'Now decide if this occurence is above cutoff
                    If SeqBestScore >= CurrentPWMCutoffScore And Not IsNothing(SeqBestWord) Then
                        Dim NewHit As New K_Word_PWM_Hit
                        NewHit.Aligned_Seq_ID = SeqBestWord.Seq_ID
                        NewHit.Aligned_Pos = SeqBestWord.Relative_Position
                        NewHit.Aligned_Score = CurrentScore
                        NewHit.Word_Text = SeqBestWord.Word_Text
                        SeqBestWord.Is_Restricted = True 'This word is not a seed anymore
                        CurrentPWMHits.Add(NewHit)
                    End If

                Next Seq

                'Rebuild PWM for query word or exit if nothing was found
                If CurrentPWMHits.Count < MinimumMotifHits Then  'Nothing was found
                    Exit Do
                End If

                QueryPWM = Bioinformatics.ReCalcPWM(CurrentPWMHits, A_P, T_P, G_P, C_P)
                CurrentPWMMax = QueryPWM.GetMaxWeight
                CurrentPWMMin = QueryPWM.GetMinWeight
                CurrentPWMRange = CurrentPWMMax - CurrentPWMMin
                CurrentPWMCutoffScore = CurrentPWMMax - CurrentPWMRange * ReCalc_PWM_Cutoff_Percent

                PrevScore = NextScore
                NextScore = CurrentPWMMax
                PrevRange = NextRange
                NextRange = CurrentPWMRange
                If NextRange < MinPWMRange Then
                    Exit Do
                End If
                If NextRange < PrevRange Then
                    Exit Do
                End If

                If NextRange = PrevRange Or NextRange - PrevRange <= NextRange * 0.2 Or counter > 20 Then

                    Dim NewTopResult As New MBMD_Result
                    NewTopResult.Original_PWM = QueryPWM
                    NewTopResult.Weight = CurrentPWMRange

                    For Each CurrentHit As K_Word_PWM_Hit In CurrentPWMHits
                        Dim NewHit As New K_Word_PWM_Hit
                        NewHit.Aligned_Seq_ID = CurrentHit.Aligned_Seq_ID
                        NewHit.Aligned_Pos = CurrentHit.Aligned_Pos
                        NewHit.Word_Text = CurrentHit.Word_Text
                        NewTopResult.Motif_Hits.Add(NewHit)
                    Next


                    TopRatedHits.Add(NewTopResult)

                    For Each Seq As List(Of K_Word_MBMD) In SeqWords
                        For Each Word As K_Word_MBMD In Seq
                            If Word.Is_Restricted Then
                                Word.Is_Blocked = True
                            End If
                        Next Word
                    Next Seq


                    Exit Do
                End If


                counter += 1
            Loop

        Next QueryPWM


        'Sort results by MaxRange
        Dim Tmp As MBMD_Result = Nothing
        For i = 0 To TopRatedHits.Count - 1
            For j = 0 To TopRatedHits.Count - 2 - i
                If TopRatedHits(j).Weight < TopRatedHits(j + 1).Weight Then
                    Tmp = TopRatedHits(j)
                    TopRatedHits(j) = TopRatedHits(j + 1)
                    TopRatedHits(j + 1) = Tmp
                End If
            Next
        Next


        Return TopRatedHits
    End Function


    Public Shared Function DiscoverMotifs(ByVal TotalWordList As List(Of K_Word_PWM), _
                                          ByVal A_P As Single, ByVal T_P As Single, ByVal G_P As Single, ByVal C_P As Single, _
                                          ByVal Prime_PWM_Cutoff_Percent As Single, ByVal ReCalc_PWM_Cutoff_Percent As Single, _
                                          ByVal MinPWMRange As Single)

        Dim TopRatedHits As New List(Of MBMD_Result)


        For Each KWord As K_Word_PWM In TotalWordList
            KWord.PrimePWM(A_P, T_P, G_P, C_P)
            KWord.CalculateCutoff(Prime_PWM_Cutoff_Percent)
        Next


        Dim CurrentScore As Single = 0
        Dim counter As Integer = 0
        Dim PrevScore As Single = 0
        Dim NextScore As Single = 0

        Dim PrevRange As Single = 0
        Dim NextRange As Single = 0

        'Now align each word vs each and calculate score
        For Each QueryWord As K_Word_PWM In TotalWordList 'This word is aligned to all other words

            If Not QueryWord.Is_Blocked Then 'If Not QueryWord.Is_Restricted Then


                'Iterate until PWM score reaches plateau or just several times
                'Code for iteration
                counter = 0
                PrevScore = 0
                PrevRange = 0
                NextScore = QueryWord.Word_PWM.GetMaxWeight
                NextRange = QueryWord.Word_PWM.GetMaxWeight - QueryWord.Word_PWM.GetMinWeight


                Do

                    'Align Query word to each word in the list
                    For Each ReferenceWord As K_Word_PWM In TotalWordList
                        ReferenceWord.Is_Restricted = False

                        If Not (QueryWord.Seq_ID = ReferenceWord.Seq_ID And QueryWord.Word_Position = ReferenceWord.Word_Position) Then 'Word is not the same


                            CurrentScore = Bioinformatics.Calculate_Word_Weight(ReferenceWord.Word_Text, QueryWord.Word_PWM)

                            If CurrentScore >= QueryWord.Score_Cutoff And Not ReferenceWord.Is_Blocked Then
                                Dim NewHit As New K_Word_PWM_Hit
                                NewHit.Aligned_Seq_ID = ReferenceWord.Seq_ID
                                NewHit.Aligned_Pos = ReferenceWord.Word_Position
                                NewHit.Aligned_Score = CurrentScore
                                NewHit.Word_Text = ReferenceWord.Word_Text

                                ReferenceWord.Is_Restricted = True 'This word is not a seed anymore
                                QueryWord.Is_Restricted = True

                                QueryWord.Hit_Positions.Add(NewHit)
                            End If


                        End If
                    Next ReferenceWord

                    'Rebuild PWM for query word

                    If QueryWord.Hit_Positions.Count = 0 Then 'Nothing was found
                        Exit Do
                    End If

                    QueryWord.ReCalcPWM(A_P, T_P, G_P, C_P)
                    QueryWord.CalculateCutoff(ReCalc_PWM_Cutoff_Percent)

                    counter += 1

                    PrevScore = NextScore
                    NextScore = QueryWord.Word_PWM.GetMaxWeight

                    PrevRange = NextRange
                    NextRange = QueryWord.Word_PWM.GetMaxWeight - QueryWord.Word_PWM.GetMinWeight

                    If NextRange < MinPWMRange Then
                        Exit Do
                    End If
                    If NextRange < PrevRange Then
                        Exit Do
                    End If

                    If NextRange = PrevRange Or NextRange - PrevRange <= NextRange * 0.2 Or counter > 20 Then
                        Dim NewTopPWM As New PWM
                        For i = 0 To QueryWord.Word_PWM.PWM_Table.Count - 1
                            Dim NewCell As New PWM_cell
                            NewCell.A_Weight = QueryWord.Word_PWM.PWM_Table(i).A_Weight
                            NewCell.T_Weight = QueryWord.Word_PWM.PWM_Table(i).T_Weight
                            NewCell.G_Weight = QueryWord.Word_PWM.PWM_Table(i).G_Weight
                            NewCell.C_Weight = QueryWord.Word_PWM.PWM_Table(i).C_Weight
                            NewTopPWM.PWM_Table.Add(NewCell)
                        Next

                        Dim NewTopResult As New MBMD_Result
                        NewTopResult.Original_PWM = NewTopPWM
                        NewTopResult.Weight = QueryWord.Word_PWM.GetMaxWeight - QueryWord.Word_PWM.GetMinWeight

                        Dim MyselfHit As New K_Word_PWM_Hit
                        MyselfHit.Aligned_Seq_ID = QueryWord.Seq_ID
                        MyselfHit.Aligned_Pos = QueryWord.Word_Position
                        MyselfHit.Word_Text = QueryWord.Word_Text
                        NewTopResult.Motif_Hits.Add(MyselfHit)
                        For i = 0 To QueryWord.Hit_Positions.Count - 1
                            Dim NewHit As New K_Word_PWM_Hit
                            NewHit.Aligned_Seq_ID = QueryWord.Hit_Positions(i).Aligned_Seq_ID
                            NewHit.Aligned_Pos = QueryWord.Hit_Positions(i).Aligned_Pos
                            NewHit.Word_Text = QueryWord.Hit_Positions(i).Word_Text
                            NewTopResult.Motif_Hits.Add(NewHit)
                        Next

                        TopRatedHits.Add(NewTopResult)

                        For Each ReferenceWord As K_Word_PWM In TotalWordList
                            If ReferenceWord.Is_Restricted Then
                                ReferenceWord.Is_Blocked = True
                            End If
                        Next


                        Exit Do
                    End If

                    QueryWord.Hit_Positions.Clear()
                Loop


                QueryWord.Hit_Positions.Clear()
                QueryWord.PrimePWM(A_P, T_P, G_P, C_P)
                QueryWord.CalculateCutoff(Prime_PWM_Cutoff_Percent)

            End If 'Is_Restricted
        Next QueryWord


        'Sort results by MaxRange
        Dim Tmp As MBMD_Result = Nothing
        For i = 0 To TopRatedHits.Count - 1
            For j = 0 To TopRatedHits.Count - 2 - i
                If TopRatedHits(j).Weight < TopRatedHits(j + 1).Weight Then
                    Tmp = TopRatedHits(j)
                    TopRatedHits(j) = TopRatedHits(j + 1)
                    TopRatedHits(j + 1) = Tmp
                End If
            Next
        Next


        Return TopRatedHits
    End Function

    Public Shared Function MBMDtoPWM(ByVal Data As MBMD_Result)
        Dim NewPWM As New PWM
        Dim CurrentSeqList As New List(Of Char())
        For Each Hit As K_Word_PWM_Hit In Data.Motif_Hits
            CurrentSeqList.Add(Hit.Word_Text.ToCharArray)
        Next
        NewPWM = Bioinformatics.CalculateInformationContent(CurrentSeqList, True)

        Return NewPWM
    End Function

    Public Shared Function TrimMotifs(ByVal Motifs As List(Of MBMD_Result), ByVal TrimThreshold As Single, ByVal MimimalLength As Integer)

        Dim MotifIndex As Integer = 0
        Dim MaxIndex As Integer = Motifs.Count - 1
        Dim TrimmedMotifs As New List(Of MBMD_Result)

        Do
            Dim Seq As New List(Of Char())
            For Each Hit As K_Word_PWM_Hit In Motifs(MotifIndex).Motif_Hits
                Seq.Add(Hit.Word_Text.ToCharArray)
            Next
            Dim ShannonPWM As New PWM
            ShannonPWM = Bioinformatics.CalculateInformationContent(Seq, True)

            Dim ShannonH As Single = 0
            Dim ShannonH_2 As Single = 0


            'Trim Left
            Dim LeftTrimCount As Integer = 0
            For i = 0 To ShannonPWM.PWM_Table.Count - 2
                ShannonH = _
                ShannonPWM.PWM_Table(i).A_Weight + _
                ShannonPWM.PWM_Table(i).T_Weight + _
                ShannonPWM.PWM_Table(i).G_Weight + _
                ShannonPWM.PWM_Table(i).C_Weight

                If ShannonH < TrimThreshold Then
                    LeftTrimCount += 1
                Else 'Check Next position

                    ShannonH_2 = _
                               ShannonPWM.PWM_Table(i + 1).A_Weight + _
                               ShannonPWM.PWM_Table(i + 1).T_Weight + _
                               ShannonPWM.PWM_Table(i + 1).G_Weight + _
                               ShannonPWM.PWM_Table(i + 1).C_Weight

                    If ShannonH_2 < TrimThreshold Then
                        LeftTrimCount += 1
                    End If

                End If

            Next i

            'Trim Right
            Dim RightTrimCount As Integer = 0
            For i = ShannonPWM.PWM_Table.Count - 1 To 1 Step -1
                ShannonH = _
                ShannonPWM.PWM_Table(i).A_Weight + _
                ShannonPWM.PWM_Table(i).T_Weight + _
                ShannonPWM.PWM_Table(i).G_Weight + _
                ShannonPWM.PWM_Table(i).C_Weight

                If ShannonH < TrimThreshold Then
                    RightTrimCount += 1
                Else 'Check Next position

                    ShannonH_2 = _
                             ShannonPWM.PWM_Table(i - 1).A_Weight + _
                             ShannonPWM.PWM_Table(i - 1).T_Weight + _
                             ShannonPWM.PWM_Table(i - 1).G_Weight + _
                             ShannonPWM.PWM_Table(i - 1).C_Weight

                    If ShannonH_2 < TrimThreshold Then
                        RightTrimCount += 1
                    End If
                End If

            Next i


            If LeftTrimCount > 0 Or RightTrimCount > 0 Then
                If Motifs(MotifIndex).Original_PWM.PWM_Table.Count - LeftTrimCount - RightTrimCount < MimimalLength Then
                    'Remove motif
                    'Motifs.RemoveAt(MotifIndex)
                    'MotifIndex -= 1
                    'MaxIndex -= 1
                Else
                    'Trim motif
                    'For Each Hit As K_Word_PWM_Hit In Motifs(MotifIndex).Motif_Hits
                    'Hit.Word_Text = Hit.Word_Text.Substring(LeftTrimCount)
                    'Hit.Aligned_Pos += LeftTrimCount
                    'Hit.Word_Text = Hit.Word_Text.Substring(0, Hit.Word_Text.Length - RightTrimCount)
                    'Next

                    Dim NewMBMD As New MBMD_Result
                    For Each Hit As K_Word_PWM_Hit In Motifs(MotifIndex).Motif_Hits
                        Dim NewHit As New K_Word_PWM_Hit
                        NewHit.Word_Text = Hit.Word_Text.Substring(LeftTrimCount)
                        NewHit.Word_Text = NewHit.Word_Text.Substring(0, Hit.Word_Text.Length - RightTrimCount)
                        NewHit.Aligned_Pos += LeftTrimCount
                        'Recalc Score!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                        NewMBMD.Motif_Hits.Add(NewHit)
                    Next
                    TrimmedMotifs.Add(NewMBMD)

                End If
            Else
                'Leave motif in peace
                TrimmedMotifs.Add(Motifs(MotifIndex))

            End If


            MotifIndex += 1

            If MotifIndex > MaxIndex Then
                Exit Do
            End If
        Loop

        Return TrimmedMotifs
    End Function

    Public Shared Function AlignPWMs(ByVal PWM_1 As PWM, ByVal PWM_2 As PWM, ByVal DistanceThreshold As Single)

        Dim Max_L As Integer = PWM_1.PWM_Table.Count + PWM_2.PWM_Table.Count - 1
        Dim N_Max As Integer = Math.Max(PWM_1.PWM_Table.Count, PWM_2.PWM_Table.Count)
        Dim N_Min As Integer = Math.Min(PWM_1.PWM_Table.Count, PWM_2.PWM_Table.Count)
        Dim Intersection_L As Integer = 0
        Dim Start_i As Integer = 0 'PWM1
        Dim Start_j As Integer = 0 'PWM2
        Dim SeqVectorDistance As Single = 0
        Dim MatchCounter As Integer = 0

        Dim BestMatchCounter As Integer = 0
        Dim BestAlignment As Integer = 0

        For FrameShift = 1 To Max_L

            If FrameShift < N_Min Then
                Intersection_L = FrameShift
            ElseIf N_Min <= FrameShift And FrameShift <= N_Max Then
                Intersection_L = N_Min
            ElseIf N_Max < FrameShift Then
                Intersection_L = Max_L - FrameShift + 1
            End If

            If FrameShift <= PWM_2.PWM_Table.Count Then
                Start_i = 1
                Start_j = PWM_2.PWM_Table.Count - FrameShift + 1
            Else
                Start_i = FrameShift - PWM_2.PWM_Table.Count + 1
                Start_j = 1
            End If


            MatchCounter = 0
            For PWMTablePos = 1 To Intersection_L

                SeqVectorDistance = Math.Sqrt( _
                (PWM_1.PWM_Table(Start_i - 1).A_Weight - PWM_2.PWM_Table(Start_j - 1).A_Weight) ^ 2 + _
                (PWM_1.PWM_Table(Start_i - 1).T_Weight - PWM_2.PWM_Table(Start_j - 1).T_Weight) ^ 2 + _
                (PWM_1.PWM_Table(Start_i - 1).G_Weight - PWM_2.PWM_Table(Start_j - 1).G_Weight) ^ 2 + _
                (PWM_1.PWM_Table(Start_i - 1).C_Weight - PWM_2.PWM_Table(Start_j - 1).C_Weight) ^ 2)


                If SeqVectorDistance <= DistanceThreshold Then
                    MatchCounter += 1
                Else
                End If

                Start_i += 1
                Start_j += 1

            Next PWMTablePos


            If MatchCounter > BestMatchCounter Then
                BestMatchCounter = MatchCounter
                BestAlignment = FrameShift
            End If

        Next FrameShift

        Dim ReportArray(1) As Integer
        '0 - Best Frame
        '1 - Best number of matched positions

        ReportArray(0) = BestAlignment
        ReportArray(1) = BestMatchCounter

        Return ReportArray
    End Function

    Public Shared Function RemoveDuplicatesInMotifsList(ByVal Motifs As List(Of K_Word_PWM_Hit))
        Dim ClearedList As New List(Of K_Word_PWM_Hit)
        Dim Found As Boolean = False
        Dim TerminateMerger As Boolean = False

        Dim MergedSeq As String = ""


        For i = 0 To Motifs.Count - 1
            Found = False

            If Not Motifs(i).Is_Blocked Then

                Dim MergedMotif As New K_Word_PWM_Hit

                MergedMotif.Word_Text = Motifs(i).Word_Text
                MergedMotif.Aligned_Seq_ID = Motifs(i).Aligned_Seq_ID
                MergedMotif.Aligned_Pos = Motifs(i).Aligned_Pos

                For j = 0 To Motifs.Count - 1
                    If Motifs(i).Aligned_Seq_ID = Motifs(j).Aligned_Seq_ID Then

                        MergedSeq = ""
                        TerminateMerger = False
                        For counter = 0 To MergedMotif.Word_Text.Length - 1
                            If MergedMotif.Word_Text(counter) = SpaceChar Then
                                MergedSeq &= Motifs(j).Word_Text(counter)
                            ElseIf Motifs(j).Word_Text(counter) = SpaceChar Then
                                MergedSeq &= MergedMotif.Word_Text(counter)
                            Else

                                If MergedMotif.Word_Text(counter) = Motifs(j).Word_Text(counter) Then
                                    MergedSeq &= MergedMotif.Word_Text(counter)
                                Else 'This are two different subsequences from one sequence
                                    TerminateMerger = True
                                    Exit For
                                End If

                            End If
                        Next

                        If Not TerminateMerger Then
                            Motifs(i).Is_Blocked = True
                            Motifs(j).Is_Blocked = True
                            MergedMotif.Word_Text = MergedSeq
                            Found = True
                        End If

                    End If
                Next

                If Not Found Then
                    'Motif is unique
                    ClearedList.Add(Motifs(i))
                Else
                    ClearedList.Add(MergedMotif)
                End If 'Not Found

            End If 'Not Motifs(i).Is_Blocked

        Next


        Return ClearedList
    End Function

    Public Shared Function CombineMotifs(ByVal Motifs As List(Of MBMD_Result), ByVal DistanceThreshold As Single, ByVal MinimalMotifLength As Integer)

        Dim UniqueMBMDList As New List(Of MBMD_Result)
        Dim CombinedMBMDList As New List(Of MBMD_Result)

        Dim MasterIndex As Integer = 0
        Dim CurrentIndex As Integer = 0

        Dim MaxIndex As Integer = Motifs.Count - 1

        Dim MasterPWM As PWM = Nothing
        Dim CurrentPWM As PWM = Nothing
        Dim CurrentResult(1) As Integer

        Dim AlignedMotifsList As New List(Of MBMD_Result)


        Dim Master_add5 As Integer = 0
        Dim Master_add3 As Integer = 0
        Dim Current_add5 As Integer = 0
        Dim Current_add3 As Integer = 0

        Dim Master_add5_list As New List(Of Integer)
        Dim Master_add3_list As New List(Of Integer)
        Dim Current_add5_list As New List(Of Integer)
        Dim Current_add3_list As New List(Of Integer)



        Dim LocalFrames As New List(Of Integer)

        Dim Max_add5 As Integer = 0
        Dim Max_add3 As Integer = 0

        Dim ReportString As String = ""


        Do
            If Not Motifs(MasterIndex).Blocked Then

                LocalFrames.Clear()
                Master_add5_list.Clear()
                Master_add3_list.Clear()
                Current_add5_list.Clear()
                Current_add3_list.Clear()
                AlignedMotifsList.Clear()

                MasterPWM = Bioinformatics.MBMDtoPWM(Motifs(MasterIndex))

                CurrentIndex = MasterIndex

                Do
                    CurrentIndex += 1
                    If CurrentIndex > MaxIndex Then
                        Exit Do
                    End If

                    If Not Motifs(CurrentIndex).Blocked Then

                        CurrentPWM = Bioinformatics.MBMDtoPWM(Motifs(CurrentIndex))

                        CurrentResult = Bioinformatics.AlignPWMs(MasterPWM, CurrentPWM, DistanceThreshold)
                        '0 - Best Frame
                        '1 - Best number of matched positions

                        If CurrentResult(1) >= MinimalMotifLength Then

                            LocalFrames.Add(CurrentResult(0))
                            AlignedMotifsList.Add(Motifs(CurrentIndex))

                            Master_add5 = CurrentPWM.PWM_Table.Count - CurrentResult(0)
                            Master_add3 = CurrentResult(0) - MasterPWM.PWM_Table.Count
                            Current_add5 = CurrentResult(0) - CurrentPWM.PWM_Table.Count
                            Current_add3 = MasterPWM.PWM_Table.Count - CurrentResult(0)
                            If Master_add5 < 0 Then Master_add5 = 0
                            If Master_add3 < 0 Then Master_add3 = 0
                            If Current_add5 < 0 Then Current_add5 = 0
                            If Current_add3 < 0 Then Current_add3 = 0


                            Master_add5_list.Add(Master_add5)
                            Master_add3_list.Add(Master_add3)
                            Current_add5_list.Add(Current_add5)
                            Current_add3_list.Add(Current_add3)

                            Motifs(MasterIndex).Blocked = True
                            Motifs(CurrentIndex).Blocked = True
                        End If

                    End If


                Loop


                'If something was found
                If LocalFrames.Count > 0 Then
                    'Here all aligned frames are known
                    'Calculate the number of space characters
                    Max_add5 = Maximum(Master_add5_list)
                    Max_add3 = Maximum(Master_add3_list)

                    Dim NewMotifsList As New List(Of K_Word_PWM_Hit)
                    For Each Hit As K_Word_PWM_Hit In Motifs(MasterIndex).Motif_Hits
                        Dim NewHit As New K_Word_PWM_Hit
                        NewHit.Word_Text = GetSpace(Max_add5) & Hit.Word_Text & GetSpace(Max_add3)
                        NewHit.Aligned_Pos = Hit.Aligned_Pos
                        NewHit.Aligned_Seq_ID = Hit.Aligned_Seq_ID
                        NewMotifsList.Add(NewHit)

                        'ReportString &= NewHit.Word_Text & vbTab & Hit.Aligned_Seq_ID & vbTab & Hit.Aligned_Pos & vbNewLine
                    Next

                    For i = 0 To AlignedMotifsList.Count - 1
                        If Current_add5_list(i) = 0 Then
                            Current_add5 = Max_add5 - Master_add5_list(i)
                        Else
                            Current_add5 = Max_add5 + Current_add5_list(i)
                        End If

                        If Current_add3_list(i) = 0 Then
                            Current_add3 = Max_add3 - Master_add3_list(i)
                        Else
                            Current_add3 = Max_add3 + Current_add3_list(i)
                        End If


                        For Each Hit As K_Word_PWM_Hit In AlignedMotifsList(i).Motif_Hits
                            Dim NewHit As New K_Word_PWM_Hit
                            NewHit.Word_Text = GetSpace(Current_add5) & Hit.Word_Text & GetSpace(Current_add3)
                            NewHit.Aligned_Pos = Hit.Aligned_Pos
                            NewHit.Aligned_Seq_ID = Hit.Aligned_Seq_ID
                            NewMotifsList.Add(NewHit)

                            'ReportString &= NewHit.Word_Text & vbTab & Hit.Aligned_Seq_ID & vbTab & Hit.Aligned_Pos & vbNewLine
                        Next
                    Next

                    'Remove duplicates
                    Dim ClearedList As List(Of K_Word_PWM_Hit) = RemoveDuplicatesInMotifsList(NewMotifsList)
                    Dim NewMBMD As New MBMD_Result
                    NewMBMD.Motif_Hits = ClearedList
                    CombinedMBMDList.Add(NewMBMD)



                Else 'Motif is unique
                    CombinedMBMDList.Add(Motifs(MasterIndex))

                End If 'LocalFrames.Count > 0

            End If 'Not Motifs(MasterIndex).Blocked


            MasterIndex += 1
            If MasterIndex > MaxIndex Then
                Exit Do
            End If
        Loop


        'ReportString &= vbNewLine
        'ReportString &= vbNewLine
        For Each MBMD As MBMD_Result In CombinedMBMDList
            For Each Hit As K_Word_PWM_Hit In MBMD.Motif_Hits
                ReportString &= Hit.Word_Text & vbNewLine
            Next
            ReportString &= vbNewLine
            ReportString &= vbNewLine
        Next


        'Replace spaces with letters from original sequences
        'Recalculate scores and positions of motifs within original sequences

        Clipboard.SetText(ReportString)

        Return CombinedMBMDList
    End Function

#End Region

#Region "Reference-Based Local Alignment Search Tool"


    Public Shared Function HashSeqQuick(ByVal Seq As String)
        Dim Hash As Int32
        If Seq.Length > 16 Then
            Hash = 0
            MsgBox("Can not get Int32 hash for more than 16-mer seq!")
        Else
            Dim ByteString As String = ""
            For i = 0 To Seq.Length - 1
                Select Case Seq(i)
                    Case "A"
                        ByteString &= "00"
                    Case "T"
                        ByteString &= "01"
                    Case "G"
                        ByteString &= "10"
                    Case "C"
                        ByteString &= "11"
                End Select
            Next i

            Hash = Convert.ToInt32(ByteString, 2)

        End If



        Return Hash
    End Function

    Public Shared Function Make_K_Word_Hash(ByVal QueryString As String, ByVal WordLength As Integer)
        Dim K_Word_List As New List(Of K_Word_Hashed)

        For i = 0 To QueryString.Length - WordLength
            Dim KWord As New K_Word_Hashed
            KWord.Relative_Position = i
            KWord.Word_Text = QueryString.Substring(i, WordLength)
            KWord.Hash = HashSeqQuick(KWord.Word_Text)
            K_Word_List.Add(KWord)
        Next

        Return K_Word_List
    End Function

    Public Shared Function Make_Hashed_Hit_List(ByVal SubjectSequence As String, ByVal QuerySequence As String, ByVal WordLength As Integer, Optional ByVal ProgressMonitor As ProgressBar = Nothing, Optional ByVal ToolStripProgressMonitor As ToolStripProgressBar = Nothing, Optional ByVal ProgressLabel As Label = Nothing)

        Dim K_Word_Subject As New List(Of K_Word_Hashed)
        Dim K_Word_Query As New List(Of K_Word_Hashed)

        If Not IsNothing(ProgressLabel) Then
            ProgressLabel.Text = "Indexing reference sequence"
            ProgressLabel.Refresh()
        End If

        K_Word_Subject = Make_K_Word_Hash(SubjectSequence, WordLength)

        If Not IsNothing(ProgressLabel) Then
            ProgressLabel.Text = "Indexing query sequence"
            ProgressLabel.Refresh()
        End If

        K_Word_Query = Make_K_Word_Hash(QuerySequence, WordLength)

        If Not IsNothing(ProgressMonitor) Then
            ProgressMonitor.Value = 0
            ProgressMonitor.Maximum = K_Word_Subject.Count
        End If

        If Not IsNothing(ToolStripProgressMonitor) Then
            ToolStripProgressMonitor.Value = 0
            ToolStripProgressMonitor.Maximum = K_Word_Subject.Count
        End If

        If Not IsNothing(ProgressLabel) Then
            ProgressLabel.Text = "Making hit map"
            ProgressLabel.Refresh()
        End If


        For i = 0 To K_Word_Subject.Count - 1
            For j = 0 To K_Word_Query.Count - 1
                If K_Word_Subject(i).Hash = K_Word_Query(j).Hash Then
                    K_Word_Subject(i).Aligned_Positions.Add(K_Word_Query(j).Relative_Position)
                End If
            Next

            If Not IsNothing(ProgressMonitor) Then
                If ProgressMonitor.Value = ProgressMonitor.Maximum Then
                    ProgressMonitor.Value = 0
                End If
                ProgressMonitor.Value += 1
            End If

            If Not IsNothing(ToolStripProgressMonitor) Then
                If ToolStripProgressMonitor.Value = ToolStripProgressMonitor.Maximum Then
                    ToolStripProgressMonitor.Value = 0
                End If
                ToolStripProgressMonitor.Value += 1
            End If

        Next

        Return K_Word_Subject
    End Function

    Public Shared Sub AddAlignment(ByRef AssemblyList As List(Of Subject_Based_Assembly), ByRef Pre_Alignment As List(Of K_Word_Hashed), ByVal MinimumHits As Integer, ByVal MinimumAssenblyLength As Integer)
        'Look if the number of words in pre-assembly is adequate
        If Pre_Alignment.Count >= MinimumHits Then
            If Pre_Alignment(Pre_Alignment.Count - 1).Relative_Position - Pre_Alignment(0).Relative_Position + Pre_Alignment(0).Word_Text.Length >= MinimumAssenblyLength Then


                'Save pre-alignment
                Dim NewAssembly As New Subject_Based_Assembly


                'Add first seed manualy
                NewAssembly.Subject_Positions.Add(Pre_Alignment(0))
                NewAssembly.Query_Positions.Add(Pre_Alignment(0).Aligned_Positions(0))
                Dim ContinuityMarker As Integer = Pre_Alignment(0).Aligned_Positions(0)

                'Continue adding seeds
                For k = 1 To Pre_Alignment.Count - 1


                    'If possible take next query word with larger index
                    'Dim b As Boolean = False
                    For q = 0 To Pre_Alignment(k).Aligned_Positions.Count - 1
                        If Pre_Alignment(k).Aligned_Positions(q) > ContinuityMarker Then
                            NewAssembly.Subject_Positions.Add(Pre_Alignment(k))
                            ContinuityMarker = Pre_Alignment(k).Aligned_Positions(q)
                            NewAssembly.Query_Positions.Add(Pre_Alignment(k).Aligned_Positions(q))
                            'b = True
                            Exit For
                        End If
                    Next q

                    'If b = False Then 'Add first aligned position
                    'ContinuityMarker = Pre_Alignment(k).Aligned_Positions(0)
                    'NewAssembly.Query_Positions.Add(Pre_Alignment(k).Aligned_Positions(0))
                    'End If

                Next k

                If NewAssembly.Subject_Positions.Count >= MinimumHits Then
                    AssemblyList.Add(NewAssembly)
                End If


            End If 'Alignment length is sufficient
        End If 'Pre_Alignment.Count >= MinimumHits
    End Sub

    Public Shared Function Assemble_Indexed_Map(ByVal SubjectIndex As List(Of K_Word_Hashed), ByVal QueryIndex As List(Of K_Word_Hashed), ByVal TerminationDistance As Integer, ByVal MinimumHits As Integer, ByVal MinimumAssemblyLength As Integer, Optional ByVal ProgressLabel As Label = Nothing)

        If Not IsNothing(ProgressLabel) Then
            ProgressLabel.Text = "Making hit map"
            ProgressLabel.Refresh()
        End If

        For i = 0 To SubjectIndex.Count - 1
            For j = 0 To QueryIndex.Count - 1
                If SubjectIndex(i).Hash = QueryIndex(j).Hash Then
                    SubjectIndex(i).Aligned_Positions.Add(QueryIndex(j).Relative_Position)
                End If
            Next j
        Next i

        If Not IsNothing(ProgressLabel) Then
            ProgressLabel.Text = "Assembling alignment"
            ProgressLabel.Refresh()
        End If

        Dim AssemblyList As New List(Of Subject_Based_Assembly)
        Dim SpacerCounter As Integer = 0
        Dim Pre_Alignment_Initiated As Boolean = False


        'Get regions of concentrated hits
        For i = 0 To SubjectIndex.Count - 1


            If SubjectIndex(i).Aligned_Positions.Count > 0 Then
                'There is some aligned hits from query, mapped to subject

                Dim Pre_Alignment As New List(Of K_Word_Hashed)
                Pre_Alignment_Initiated = True
                Pre_Alignment.Add(SubjectIndex(i))
                SpacerCounter = 0


                'Collect all words with hits located not further that minimal distance
                For j = i + 1 To SubjectIndex.Count - 1

                    If SubjectIndex(j).Aligned_Positions.Count > 0 Then
                        'Collect
                        Pre_Alignment.Add(SubjectIndex(j))
                        SpacerCounter = 0
                    Else
                        SpacerCounter += 1
                    End If


                    'Terminate pre_assemply if there is no hits for certain steps
                    If SpacerCounter > TerminationDistance Then
                        If Pre_Alignment_Initiated Then
                            AddAlignment(AssemblyList, Pre_Alignment, MinimumHits, MinimumAssemblyLength)
                        End If

                        Pre_Alignment_Initiated = False
                        i = j 'Return to scanning sequence for new hits. Aligned zone is skipped.
                        Exit For
                    End If


                    'The last pre-alignment close to sequence end may not be terminated inside the cycle
                    If j = SubjectIndex.Count - 1 Then
                        If Pre_Alignment_Initiated Then
                            AddAlignment(AssemblyList, Pre_Alignment, MinimumHits, MinimumAssemblyLength)
                        End If

                        Pre_Alignment_Initiated = False
                        i = j 'Return to scanning sequence for new hits. Aligned zone is skipped.
                        Exit For
                    End If

                Next j



            End If 'Aligned_Hit_List(i).Aligned_Positions.Count > 0

        Next i


        Return AssemblyList
    End Function

    Public Shared Function Assemble_Hashed_Map(ByVal SubjectSequence As String, ByVal QuerySequence As String, ByVal WordLength As Integer, ByVal TerminationDistance As Integer, ByVal MinimumHits As Integer, ByVal MinimumAssenblyLength As Integer, Optional ByVal ProgressMonitor As ProgressBar = Nothing, Optional ByVal ToolStripProgressMonitor As ToolStripProgressBar = Nothing, Optional ByVal ProgressLabel As Label = Nothing)
        Dim Aligned_Hit_List As New List(Of K_Word_Hashed)
        Aligned_Hit_List = Make_Hashed_Hit_List(SubjectSequence, QuerySequence, WordLength, ProgressMonitor, ToolStripProgressMonitor, ProgressLabel) 'Make_Nucleotide_Hit_List


        'Dim ReportFile As String = "C:\Users\User\Documents\GB test\blast-test.txt"


        'Dim FS As New IO.FileStream(ReportFile, IO.FileMode.Create, IO.FileAccess.Write)
        'Dim Writer As New IO.StreamWriter(FS)

        'For i = 0 To Aligned_Hit_List.Count - 1

        'Writer.WriteLine(Aligned_Hit_List(i).Aligned_Positions.Count)

        'Next
        'Writer.Close()
        'FS.Close()
        'Writer.Dispose()
        'FS.Dispose()

        Dim AssemblyList As New List(Of Subject_Based_Assembly)
        Dim SpacerCounter As Integer = 0
        Dim Pre_Alignment_Initiated As Boolean = False

        'Get regions of concentrated hits
        For i = 0 To Aligned_Hit_List.Count - 1

            If Aligned_Hit_List(i).Aligned_Positions.Count > 0 Then
                'There is some aligned hits from query, mapped to subject

                Dim Pre_Alignment As New List(Of K_Word_Hashed)
                Pre_Alignment_Initiated = True
                Pre_Alignment.Add(Aligned_Hit_List(i))
                SpacerCounter = 0

                'Collect all words with hits located not further that minimal distance
                For j = i + 1 To Aligned_Hit_List.Count - 1

                    If Aligned_Hit_List(j).Aligned_Positions.Count > 0 Then
                        'Collect
                        Pre_Alignment.Add(Aligned_Hit_List(j))
                        SpacerCounter = 0
                    Else
                        SpacerCounter += 1
                    End If


                    'Terminate pre_assemply if there is no hits for certain steps
                    If SpacerCounter > TerminationDistance Then
                        If Pre_Alignment_Initiated Then
                            AddAlignment(AssemblyList, Pre_Alignment, MinimumHits, MinimumAssenblyLength)
                        End If

                        Pre_Alignment_Initiated = False
                        i = j 'Return to scanning sequence for new hits. Aligned zone is skipped.
                        Exit For
                    End If


                    'The last pre-alignment close to sequence end may not be terminated inside the cycle
                    If j = Aligned_Hit_List.Count - 1 Then
                        If Pre_Alignment_Initiated Then
                            AddAlignment(AssemblyList, Pre_Alignment, MinimumHits, MinimumAssenblyLength)
                        End If
                    End If

                Next j



            End If 'Aligned_Hit_List(i).Aligned_Positions.Count > 0

        Next i



        'For Each A As Subject_Based_Assembly In AssemblyList
        'ReportForm.ReportTextBox.Text &= "Subject: " & A.Subject_Positions(0).Relative_Position & " - " & A.Subject_Positions(A.Subject_Positions.Count - 1).Relative_Position & vbNewLine
        'ReportForm.ReportTextBox.Text &= "Query: " & A.Query_Positions(0) & " - " & A.Query_Positions(A.Subject_Positions.Count - 1) & vbNewLine
        'ReportForm.ReportTextBox.Text &= vbNewLine
        'Next A
        'ReportForm.ReportTextBox.Refresh()


        Return AssemblyList
    End Function



    Public Shared Function Make_K_Word_List_Simple(ByVal QueryString As String, ByVal WordLength As Integer, Optional ByVal Add_RC As Boolean = False)
        Dim K_Word_List As New List(Of String)
        Dim K_Word As String = ""
        For i = 0 To QueryString.Length - WordLength
            K_Word = QueryString.Substring(i, WordLength)
            K_Word_List.Add(K_Word)
            If Add_RC Then
                K_Word_List.Add(GetReverseComplement(K_Word))
            End If
        Next
        Return K_Word_List
    End Function

    Public Shared Function Make_K_Word_List(ByVal QueryString As String, ByVal WordLength As Integer)
        Dim K_Word_List As New List(Of K_Word)

        For i = 0 To QueryString.Length - WordLength
            Dim KWord As New K_Word
            KWord.Relative_Position = i
            KWord.Word_Text = QueryString.Substring(i, WordLength)
            K_Word_List.Add(KWord)
        Next

        Return K_Word_List
    End Function

    Public Shared Function Make_Nucleotide_Hit_List(ByVal SubjectSequence As String, ByVal QuerySequence As String, ByVal WordLength As Integer, Optional ByVal ProgressMonitor As ProgressBar = Nothing, Optional ByVal ToolStripProgressMonitor As ToolStripProgressBar = Nothing, Optional ByVal ProgressLabel As Label = Nothing)

        Dim K_Word_Subject As New List(Of K_Word)
        Dim K_Word_Query As New List(Of K_Word)

        If Not IsNothing(ProgressLabel) Then
            ProgressLabel.Text = "Preparing reference sequence"
            ProgressLabel.Refresh()
        End If

        K_Word_Subject = Make_K_Word_List(SubjectSequence, WordLength)

        If Not IsNothing(ProgressLabel) Then
            ProgressLabel.Text = "Preparing query sequence"
            ProgressLabel.Refresh()
        End If

        K_Word_Query = Make_K_Word_List(QuerySequence, WordLength)

        If Not IsNothing(ProgressMonitor) Then
            ProgressMonitor.Value = 0
            ProgressMonitor.Maximum = K_Word_Subject.Count
        End If

        If Not IsNothing(ToolStripProgressMonitor) Then
            ToolStripProgressMonitor.Value = 0
            ToolStripProgressMonitor.Maximum = K_Word_Subject.Count
        End If

        If Not IsNothing(ProgressLabel) Then
            ProgressLabel.Text = "Making hit map"
            ProgressLabel.Refresh()
        End If


        For i = 0 To K_Word_Subject.Count - 1
            For j = 0 To K_Word_Query.Count - 1
                If K_Word_Subject(i).Word_Text = K_Word_Query(j).Word_Text Then
                    K_Word_Subject(i).Aligned_Positions.Add(K_Word_Query(j).Relative_Position)
                End If
            Next

            If Not IsNothing(ProgressMonitor) Then
                If ProgressMonitor.Value = ProgressMonitor.Maximum Then
                    ProgressMonitor.Value = 0
                End If
                ProgressMonitor.Value += 1
            End If

            If Not IsNothing(ToolStripProgressMonitor) Then
                If ToolStripProgressMonitor.Value = ToolStripProgressMonitor.Maximum Then
                    ToolStripProgressMonitor.Value = 0
                End If
                ToolStripProgressMonitor.Value += 1
            End If

        Next

        Return K_Word_Subject
    End Function

    Public Shared Sub Add_Assembly_Subject_Based(ByRef HitList As List(Of Subject_Based_Assembly), ByRef Assembly As Subject_Based_Assembly, ByVal MinimumHits As Integer, ByVal MinimumQueryCoverage As Integer, ByVal WordLength As Integer, ByVal MinimumSubjectCoverage As Integer)
        If Assembly.Subject_Positions.Count >= MinimumHits And _
        Assembly.Query_Positions.Last - Assembly.Query_Positions.First + WordLength >= MinimumQueryCoverage And _
        Assembly.Subject_Positions.Last.Relative_Position - Assembly.Subject_Positions.First.Relative_Position + WordLength >= MinimumSubjectCoverage Then
            HitList.Add(Assembly)
        End If
    End Sub

    Public Shared Function Assemble_Hit_Map_Subject_Based(ByVal SubjectSequence As String, ByVal QuerySequence As String, ByVal WordLength As Integer, ByVal TerminationDistance As Integer, ByVal MinimumHits As Integer, ByVal MinimumQueryCoverage As Integer, ByVal MinimumSubjectCoverage As Integer, Optional ByVal ProgressMonitor As ProgressBar = Nothing, Optional ByVal ToolStripProgressMonitor As ToolStripProgressBar = Nothing, Optional ByVal ProgressLabel As Label = Nothing)

        Dim Aligned_Hit_List As New List(Of K_Word_Hashed)
        Aligned_Hit_List = Make_Hashed_Hit_List(SubjectSequence, QuerySequence, WordLength, ProgressMonitor, ToolStripProgressMonitor, ProgressLabel) 'Make_Nucleotide_Hit_List

        If Not IsNothing(ProgressMonitor) Then
            ProgressMonitor.Value = 0
            ProgressMonitor.Maximum = Aligned_Hit_List.Count + 1
        End If

        If Not IsNothing(ToolStripProgressMonitor) Then
            ToolStripProgressMonitor.Value = 0
            ToolStripProgressMonitor.Maximum = Aligned_Hit_List.Count + 1
        End If


        Dim NewAssembly As Subject_Based_Assembly = Nothing

        Dim AssemblyList As New List(Of Subject_Based_Assembly)

        Dim CurrentQueryContinuityPos As Integer = 0 'This is to account for insertions and deleteions
        Dim CurrentStep As Integer = 0
        Dim ContinuityBroken As Boolean = False
        Dim AssemblyStarted As Boolean = False
        Dim Q_Counter As Integer = 0
        Dim Subject_Iterator As Integer = 0

        If Not IsNothing(ProgressLabel) Then
            ProgressLabel.Text = "Assembling alignment"
            ProgressLabel.Refresh()
        End If


        Do
            CurrentStep += 1



            If Aligned_Hit_List(Subject_Iterator).Aligned_Positions.Count > 0 Then 'There is some aligned hits for the particular word

                If AssemblyStarted Then
                    'Try to elongate existing assemble

                    If CurrentStep < TerminationDistance Then 'To decide if it is the same alignment or two different ones

                        ContinuityBroken = True
                        For Q_Counter = 0 To Aligned_Hit_List(Subject_Iterator).Aligned_Positions.Count - 1 'Scan all query words aligned to this position in subject sequence to have index more that last one query word, e.g. to make order 1-2-3, not 1-2-2-3
                            If Aligned_Hit_List(Subject_Iterator).Aligned_Positions(Q_Counter) > CurrentQueryContinuityPos Then

                                If Aligned_Hit_List(Subject_Iterator).Aligned_Positions(Q_Counter) - CurrentQueryContinuityPos < TerminationDistance Then
                                    CurrentQueryContinuityPos = Aligned_Hit_List(Subject_Iterator).Aligned_Positions(Q_Counter)
                                    ContinuityBroken = False
                                End If

                                Exit For
                            End If
                        Next

                        If ContinuityBroken Then
                            'Terminate and begin new assembly
                            Add_Assembly_Subject_Based(AssemblyList, NewAssembly, MinimumHits, MinimumQueryCoverage, WordLength, MinimumSubjectCoverage)
                            AssemblyStarted = False
                            NewAssembly = Nothing
                            Subject_Iterator -= 1
                            Continue Do
                        Else
                            'Extend assembly
                            NewAssembly.Subject_Positions.Add(Aligned_Hit_List(Subject_Iterator))
                            NewAssembly.Query_Positions.Add(Aligned_Hit_List(Subject_Iterator).Aligned_Positions(Q_Counter))
                            CurrentStep = 0
                        End If

                    Else
                        'Terminate and begin new assembly
                        Add_Assembly_Subject_Based(AssemblyList, NewAssembly, MinimumHits, MinimumQueryCoverage, WordLength, MinimumSubjectCoverage)
                        AssemblyStarted = False
                        NewAssembly = Nothing
                        Subject_Iterator -= 1
                        Continue Do
                    End If

                Else
                    'Start new assemble
                    NewAssembly = New Subject_Based_Assembly
                    NewAssembly.Subject_Positions.Add(Aligned_Hit_List(Subject_Iterator))
                    CurrentQueryContinuityPos = Aligned_Hit_List(Subject_Iterator).Aligned_Positions(0)
                    NewAssembly.Query_Positions.Add(Aligned_Hit_List(Subject_Iterator).Aligned_Positions(0))
                    CurrentStep = 0
                    AssemblyStarted = True
                End If 'Assembly started
            End If


            Subject_Iterator += 1

            If Not IsNothing(ProgressMonitor) Then
                If ProgressMonitor.Value = ProgressMonitor.Maximum Then
                    ProgressMonitor.Value = 0
                End If
                ProgressMonitor.Value += 1
            End If

            If Not IsNothing(ToolStripProgressMonitor) Then
                If ToolStripProgressMonitor.Value = ToolStripProgressMonitor.Maximum Then
                    ToolStripProgressMonitor.Value = 0
                End If
                ToolStripProgressMonitor.Value += 1
            End If

        Loop Until Subject_Iterator = Aligned_Hit_List.Count

        If Not IsNothing(NewAssembly) Then
            Add_Assembly_Subject_Based(AssemblyList, NewAssembly, MinimumHits, MinimumQueryCoverage, WordLength, MinimumSubjectCoverage)
        End If

        Return AssemblyList
    End Function

    Public Shared Function AssembleAlignment(ByVal Assembly As Subject_Based_Assembly, ByVal SubjectSeq As String, ByVal QuerySeq As String, ByVal K_Word_Length As Integer)

        Dim GapChar As Char = "-"
        Dim MatchChar As Char = "|"
        Dim MismatchChar As Char = " "

        Dim Alignment_Iterator As Integer = 0
        Dim deltaSubject As Integer = 0
        Dim deltaQuery As Integer = 0

        Dim InsStrS As String = ""
        Dim InsStrQ As String = ""
        Dim VarSubjectL As Integer = 0
        Dim VarQueryL As Integer = 0

        Dim SubjectAlignment As String = Assembly.Subject_Positions(0).Word_Text
        Dim QueryAlignment As String = Assembly.Subject_Positions(0).Word_Text
        Dim MatchString As String = GetCharString(K_Word_Length, MatchChar)

        Dim IntermediateAlignment(2) As String

        Do Until Alignment_Iterator = Assembly.Subject_Positions.Count - 1


            deltaSubject = Assembly.Subject_Positions(Alignment_Iterator + 1).Relative_Position - Assembly.Subject_Positions(Alignment_Iterator).Relative_Position
            deltaQuery = Assembly.Query_Positions(Alignment_Iterator + 1) - Assembly.Query_Positions(Alignment_Iterator)


            If deltaQuery = deltaSubject Then 'No insertions or deletions

                If Assembly.Subject_Positions(Alignment_Iterator).Relative_Position + 1 = Assembly.Subject_Positions(Alignment_Iterator + 1).Relative_Position Then
                    'Continuous homology
                    'Extend assembly with one char
                    SubjectAlignment &= Assembly.Subject_Positions(Alignment_Iterator + 1).Word_Text.Substring(K_Word_Length - 1)
                    QueryAlignment &= Assembly.Subject_Positions(Alignment_Iterator + 1).Word_Text.Substring(K_Word_Length - 1)
                    MatchString &= MatchChar

                Else 'Mutation

                    'Get mismatch region
                    VarSubjectL = Assembly.Subject_Positions(Alignment_Iterator + 1).Relative_Position - (Assembly.Subject_Positions(Alignment_Iterator).Relative_Position + K_Word_Length) 'Length of mismatch region, same for subject and query
                    InsStrS = SubjectSeq.Substring(Assembly.Subject_Positions(Alignment_Iterator).Relative_Position + K_Word_Length, VarSubjectL)
                    InsStrQ = QuerySeq.Substring(Assembly.Query_Positions(Alignment_Iterator) + K_Word_Length, VarSubjectL)

                    'Align ambigous region by Needleman-Wunsch algorithm
                    IntermediateAlignment = Bioinformatics.Get_Needleman_Wunsch_Alignment(InsStrS, InsStrQ)

                    'Assemble mismatch region and next word to alignment
                    SubjectAlignment &= IntermediateAlignment(0) & Assembly.Subject_Positions(Alignment_Iterator + 1).Word_Text
                    QueryAlignment &= IntermediateAlignment(1) & Assembly.Subject_Positions(Alignment_Iterator + 1).Word_Text
                    MatchString &= IntermediateAlignment(2) & GetCharString(K_Word_Length, MatchChar)

                End If

                'There are insertions or deletions

            ElseIf deltaSubject > K_Word_Length And deltaQuery > K_Word_Length Then 'Variable region in both sequences, it may contain insertions, deletions and mutations

                'Get variable region
                VarSubjectL = Assembly.Subject_Positions(Alignment_Iterator + 1).Relative_Position - (Assembly.Subject_Positions(Alignment_Iterator).Relative_Position + K_Word_Length)
                VarQueryL = Assembly.Query_Positions(Alignment_Iterator + 1) - (Assembly.Query_Positions(Alignment_Iterator) + K_Word_Length)
                InsStrS = SubjectSeq.Substring(Assembly.Subject_Positions(Alignment_Iterator).Relative_Position + K_Word_Length, VarSubjectL)
                InsStrQ = QuerySeq.Substring(Assembly.Query_Positions(Alignment_Iterator) + K_Word_Length, VarQueryL)

                'Align ambigous region by Needleman-Wunsch algorithm
                IntermediateAlignment = Bioinformatics.Get_Needleman_Wunsch_Alignment(InsStrS, InsStrQ)

                SubjectAlignment &= IntermediateAlignment(0) & Assembly.Subject_Positions(Alignment_Iterator + 1).Word_Text
                QueryAlignment &= IntermediateAlignment(1) & Assembly.Subject_Positions(Alignment_Iterator + 1).Word_Text
                MatchString &= IntermediateAlignment(2) & GetCharString(K_Word_Length, MatchChar)

            Else 'Single insertion or deletion


                If deltaSubject > deltaQuery Then
                    VarSubjectL = deltaSubject - K_Word_Length
                    If VarSubjectL > 0 Then
                        InsStrS = SubjectSeq.Substring(Assembly.Subject_Positions(Alignment_Iterator).Relative_Position + K_Word_Length, VarSubjectL)
                    Else
                        InsStrS = ""
                    End If

                    SubjectAlignment &= InsStrS & GetLastChars(Assembly.Subject_Positions(Alignment_Iterator + 1).Word_Text, deltaSubject)
                    QueryAlignment &= GetCharString(deltaSubject - deltaQuery, GapChar) & GetLastChars(Assembly.Subject_Positions(Alignment_Iterator + 1).Word_Text, deltaQuery)
                    MatchString &= GetCharString(deltaSubject - deltaQuery, MismatchChar) & GetCharString(deltaQuery, MatchChar)

                Else

                    VarQueryL = deltaQuery - K_Word_Length
                    If VarQueryL > 0 Then
                        InsStrQ = QuerySeq.Substring(Assembly.Query_Positions(Alignment_Iterator) + K_Word_Length, VarQueryL)
                    Else
                        InsStrQ = ""
                    End If

                    SubjectAlignment &= GetCharString(deltaQuery - deltaSubject, GapChar) & GetLastChars(Assembly.Subject_Positions(Alignment_Iterator + 1).Word_Text, deltaSubject)
                    QueryAlignment &= InsStrQ & GetLastChars(Assembly.Subject_Positions(Alignment_Iterator + 1).Word_Text, deltaQuery)
                    MatchString &= GetCharString(deltaQuery - deltaSubject, MismatchChar) & GetCharString(deltaSubject, MatchChar)

                End If

            End If


            Alignment_Iterator += 1
        Loop


        Dim Alignment As RBLAST_Result = New RBLAST_Result
        Alignment.SubjectStartPos = Assembly.Subject_Positions.First.Relative_Position
        Alignment.SubjectEndPos = Assembly.Subject_Positions.Last.Relative_Position + K_Word_Length
        Alignment.QueryStartPos = Assembly.Query_Positions.First
        Alignment.QueryEndPos = Assembly.Query_Positions.Last + K_Word_Length

        'Add end extension algorithm here
        Dim Score As Short = 3
        Dim DroppOffEdge As Short = 0
        Dim SubjectIterator As Integer = 0
        Dim QueryIterator As Integer = 0
        Dim MatchIterationString As String = ""
        Dim LastMatchPos As Integer = 0
        Dim AddS As String = ""
        Dim AddQ As String = ""

        If Not Assembly.Query_Positions.First = 0 Then 'Some nucleotides may be added to start of alignment

            QueryIterator = Assembly.Query_Positions.First 'Set Iterators to the very first char of alignment
            SubjectIterator = Assembly.Subject_Positions.First.Relative_Position

            Do

                QueryIterator -= 1
                SubjectIterator -= 1

                If QueryIterator < 0 Or SubjectIterator < 0 Then
                    Exit Do
                End If

                AddS &= SubjectSeq(SubjectIterator)
                AddQ &= QuerySeq(QueryIterator)

                If SubjectSeq(SubjectIterator) = QuerySeq(QueryIterator) Then
                    Score += 1
                    MatchIterationString &= MatchChar
                Else
                    Score -= 2
                    MatchIterationString &= MismatchChar
                End If

            Loop Until Score <= DroppOffEdge

            If MatchIterationString.Contains(MatchChar) Then
                LastMatchPos = MatchIterationString.LastIndexOf(MatchChar)
                MatchIterationString = Bioinformatics.ReverseStrand(MatchIterationString.Substring(0, LastMatchPos + 1))
                AddS = Bioinformatics.ReverseStrand(AddS.Substring(0, LastMatchPos + 1))
                AddQ = Bioinformatics.ReverseStrand(AddQ.Substring(0, LastMatchPos + 1))

                SubjectAlignment = AddS & SubjectAlignment
                QueryAlignment = AddQ & QueryAlignment
                MatchString = MatchIterationString & MatchString

                Alignment.SubjectStartPos -= LastMatchPos + 1
                Alignment.QueryStartPos -= LastMatchPos + 1

            End If

        End If

        Score = 3
        DroppOffEdge = 0
        SubjectIterator = 0
        QueryIterator = 0
        MatchIterationString = ""
        LastMatchPos = 0
        AddS = ""
        AddQ = ""


        If Not Assembly.Query_Positions.Last = QuerySeq.Length - 1 Then  'Some nucleotides may be added to end of alignment

            QueryIterator = Assembly.Query_Positions.Last + K_Word_Length - 1 'Set Iterators to the very last char of alignment
            SubjectIterator = Assembly.Subject_Positions.Last.Relative_Position + K_Word_Length - 1

            Do

                QueryIterator += 1
                SubjectIterator += 1

                If QueryIterator > QuerySeq.Length - 1 Or SubjectIterator > SubjectSeq.Length - 1 Then
                    Exit Do
                End If

                AddS &= SubjectSeq(SubjectIterator)
                AddQ &= QuerySeq(QueryIterator)


                If SubjectSeq(SubjectIterator) = QuerySeq(QueryIterator) Then
                    Score += 1
                    MatchIterationString &= MatchChar
                Else
                    Score -= 2
                    MatchIterationString &= MismatchChar
                End If

            Loop Until Score <= DroppOffEdge

            If MatchIterationString.Contains(MatchChar) Then
                LastMatchPos = MatchIterationString.LastIndexOf(MatchChar)
                MatchIterationString = MatchIterationString.Substring(0, LastMatchPos + 1)
                AddS = AddS.Substring(0, LastMatchPos + 1)
                AddQ = AddQ.Substring(0, LastMatchPos + 1)

                SubjectAlignment &= AddS
                QueryAlignment &= AddQ
                MatchString &= MatchIterationString

                Alignment.SubjectEndPos += LastMatchPos + 1
                Alignment.QueryEndPos += LastMatchPos + 1

            End If

        End If


        Alignment.SubjectSequence = SubjectAlignment
        Alignment.QuerySequence = QueryAlignment
        Alignment.MatchString = MatchString


        Dim MatchCounter As Integer = 0
        For Each Chr As Char In MatchString
            If Chr = MatchChar Then
                MatchCounter += 1
            End If
        Next

        Alignment.IdentityNumber = MatchCounter

        Return Alignment
    End Function

    Public Shared Function GetLastChars(ByVal Seq As String, ByVal Num As Integer)
        Dim LastString As String = ""

        If Num >= Seq.Length Then
            LastString = Seq
        Else
            LastString = Seq.Substring(Seq.Length - Num)
        End If

        Return LastString
    End Function

    Public Shared Function GetCharString(ByVal Length As Integer, ByVal Symbol As Char)
        Dim Str As String = ""

        For i = 0 To Length - 1
            Str &= Symbol
        Next

        Return Str
    End Function

    Public Shared Function FindInternalHomology(ByVal Sequence As String, Optional ByVal Writer As IO.StreamWriter = Nothing, Optional ByVal Word_Length As Integer = 10)


        Dim ForQueryIndex As List(Of K_Word_Hashed) = Bioinformatics.Make_K_Word_Hash(Sequence, Word_Length)
        Dim RevQueryIndex As List(Of K_Word_Hashed) = Bioinformatics.Make_K_Word_Hash(Bioinformatics.GetReverseComplement(Sequence), Word_Length)

        'Scan for For repeats
        For i = 0 To ForQueryIndex.Count - 1
            For j = 0 To ForQueryIndex.Count - 1
                If Not i = j Then 'Exclude self-alignment
                    If ForQueryIndex(i).Hash = ForQueryIndex(j).Hash Then
                        ForQueryIndex(i).Aligned_Positions.Add(ForQueryIndex(j).Relative_Position)
                    End If
                End If
            Next j
        Next i

        Dim AssemblyListFor As New List(Of Subject_Based_Assembly)
        Dim Pre_Alignment_Initiated As Boolean = False

        'Get regions of concentrated hits
        For i = 0 To ForQueryIndex.Count - 1
            If ForQueryIndex(i).Aligned_Positions.Count > 0 Then

                Dim Pre_Alignment As New List(Of K_Word_Hashed)
                Pre_Alignment_Initiated = True
                Pre_Alignment.Add(ForQueryIndex(i))

                'Collect all words with hits located not further that zero distance
                For j = i + 1 To ForQueryIndex.Count - 1
                    If ForQueryIndex(j).Aligned_Positions.Count > 0 Then
                        'Collect
                        Pre_Alignment.Add(ForQueryIndex(j))

                    Else 'Gaps are not allowed
                        If Pre_Alignment_Initiated Then

                            AddAlignment(AssemblyListFor, Pre_Alignment, 1, Word_Length)

                        End If

                        Pre_Alignment_Initiated = False
                        i = j 'Return to scanning sequence for new hits. Aligned zone is skipped.
                        Exit For
                    End If

                    'The last pre-alignment close to sequence end may not be terminated inside the cycle
                    If j = ForQueryIndex.Count - 1 Then
                        If Pre_Alignment_Initiated Then
                            AddAlignment(AssemblyListFor, Pre_Alignment, 1, Word_Length)
                        End If

                        Pre_Alignment_Initiated = False
                        i = j 'Return to scanning sequence for new hits. Aligned zone is skipped.
                        Exit For
                    End If

                Next j

            End If
        Next i







        'Reverse strand
        For i = 0 To ForQueryIndex.Count - 1
            ForQueryIndex(i).Aligned_Positions.Clear()
        Next i

        'Scan for For repeats
        For i = 0 To ForQueryIndex.Count - 1
            For j = 0 To RevQueryIndex.Count - 1
                If ForQueryIndex(i).Hash = RevQueryIndex(j).Hash Then
                    ForQueryIndex(i).Aligned_Positions.Add(RevQueryIndex(j).Relative_Position)
                End If
            Next j
        Next i

        Dim AssemblyListRev As New List(Of Subject_Based_Assembly)
        Pre_Alignment_Initiated = False




        'Get regions of concentrated hits
        For i = 0 To ForQueryIndex.Count - 1
            If ForQueryIndex(i).Aligned_Positions.Count > 0 Then

                Dim Pre_Alignment As New List(Of K_Word_Hashed)
                Pre_Alignment_Initiated = True
                Pre_Alignment.Add(ForQueryIndex(i))

                'Collect all words with hits located not further that zero distance
                For j = i + 1 To ForQueryIndex.Count - 1
                    If ForQueryIndex(j).Aligned_Positions.Count > 0 Then
                        'Collect
                        Pre_Alignment.Add(ForQueryIndex(j))

                    Else 'Gaps are not allowed
                        If Pre_Alignment_Initiated Then

                            AddAlignment(AssemblyListFor, Pre_Alignment, 1, Word_Length)

                        End If

                        Pre_Alignment_Initiated = False
                        i = j 'Return to scanning sequence for new hits. Aligned zone is skipped.
                        Exit For
                    End If

                    'The last pre-alignment close to sequence end may not be terminated inside the cycle
                    If j = ForQueryIndex.Count - 1 Then
                        If Pre_Alignment_Initiated Then
                            AddAlignment(AssemblyListFor, Pre_Alignment, 1, Word_Length)
                        End If

                        Pre_Alignment_Initiated = False
                        i = j 'Return to scanning sequence for new hits. Aligned zone is skipped.
                        Exit For
                    End If

                Next j

            End If
        Next i







        'Output results


        Dim Results As New List(Of RBLAST_Result)
        For i = 0 To AssemblyListFor.Count - 1
            Try
                Dim NewResult As RBLAST_Result = Bioinformatics.AssembleAlignment(AssemblyListFor(i), Sequence, Sequence, Word_Length)
                Results.Add(NewResult)
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Next i

        Return Results

    End Function

#End Region

#Region "Needleman–Wunsch alignment"
    Public Shared Function Get_Needleman_Wunsch_Alignment(ByVal SubjectSeq As Char(), ByVal QuerySeq As Char(), Optional ByVal MatchBonus As Short = 1, Optional ByVal MismatchPenalty As Short = -1, Optional ByVal GapPenalty As Short = -1)
        Dim Needleman_Wunsch_Matrix(SubjectSeq.Length, QuerySeq.Length) As Needleman_Wunsch_Cell

        Dim x As Integer = 0
        Dim y As Integer = 0

        For y = 0 To QuerySeq.Length
            For x = 0 To SubjectSeq.Length
                Needleman_Wunsch_Matrix(x, y) = New Needleman_Wunsch_Cell
            Next
        Next

        Needleman_Wunsch_Matrix(0, 0).Score = 0
        Needleman_Wunsch_Matrix(0, 0).Direction = 0

        '0 - Upper left cell
        '1 - Diagonal
        '2 - Left
        '3 - Up

        Dim Scores(2) As Short
        Dim ResultScore As Short = 0



        For x = 1 To SubjectSeq.Length
            Needleman_Wunsch_Matrix(x, 0).Score = x * GapPenalty
            Needleman_Wunsch_Matrix(x, 0).Direction = 2
        Next

        For y = 1 To QuerySeq.Length
            Needleman_Wunsch_Matrix(0, y).Score = y * GapPenalty
            Needleman_Wunsch_Matrix(0, y).Direction = 3
        Next

        For y = 1 To QuerySeq.Length
            For x = 1 To SubjectSeq.Length
                Scores(0) = Needleman_Wunsch_Matrix(x - 1, y - 1).Score 'Match
                If QuerySeq(y - 1) = SubjectSeq(x - 1) Then
                    Scores(0) += MatchBonus
                    Needleman_Wunsch_Matrix(x, y).Match = 1
                Else
                    Scores(0) += MismatchPenalty
                End If

                Scores(1) = Needleman_Wunsch_Matrix(x - 1, y).Score + GapPenalty 'Horizontal gap
                Scores(2) = Needleman_Wunsch_Matrix(x, y - 1).Score + GapPenalty 'Vertical gap
                ResultScore = Maximum(Scores)

                Needleman_Wunsch_Matrix(x, y).Score = ResultScore

                Select Case ResultScore
                    Case Scores(0) 'Match
                        Needleman_Wunsch_Matrix(x, y).Direction = 1
                    Case Scores(1) 'Horizontal gap
                        Needleman_Wunsch_Matrix(x, y).Direction = 2
                    Case Scores(2) 'Vertical gap
                        Needleman_Wunsch_Matrix(x, y).Direction = 3
                End Select

            Next
        Next


        Dim SubjectAlignment As String = ""
        Dim QueryAlignment As String = ""
        Dim MatchString As String = ""
        Dim GapChar As Char = "-"

        Dim Alignment(2) As String

        x = SubjectSeq.Length
        y = QuerySeq.Length

        Do
            Select Case Needleman_Wunsch_Matrix(x, y).Direction
                Case 1 'Diagonal
                    SubjectAlignment &= SubjectSeq(x - 1)
                    QueryAlignment &= QuerySeq(y - 1)
                    If Needleman_Wunsch_Matrix(x, y).Match Then
                        MatchString &= "|"
                    Else
                        MatchString &= " "
                    End If
                    x -= 1
                    y -= 1

                Case 2 'Left
                    SubjectAlignment &= SubjectSeq(x - 1)
                    QueryAlignment &= GapChar
                    MatchString &= " "
                    x -= 1
                Case 3 'Up
                    SubjectAlignment &= GapChar
                    QueryAlignment &= QuerySeq(y - 1)
                    MatchString &= " "
                    y -= 1
                Case 0 'End
                    Exit Do
            End Select

        Loop Until (x = 0 And y = 0)


        Alignment(0) = ReverseStrand(SubjectAlignment)
        Alignment(1) = ReverseStrand(QueryAlignment)
        Alignment(2) = ReverseStrand(MatchString)

        Return Alignment
    End Function
#End Region

#Region "Smith-Waterman alignment"
    Public Shared Function Get_Best_Smith_Waterman_Alignment(ByVal Seq1 As String, ByVal Seq2 As String, Optional ByVal MatchScore As Integer = 2, Optional ByVal MismatchScore As Integer = -1, Optional ByVal GapScore As Integer = -2)
        Dim Alignment(2) As String

        Dim SmithWatermanMatrix(Seq1.Length, Seq2.Length) As Integer

        Dim SeqX As Char() = Seq1.ToCharArray
        Dim SeqY As Char() = Seq2.ToCharArray


        'x - seq1 goes horizontal
        'y - seq2 goes vertical

        For x = 0 To Seq1.Length
            SmithWatermanMatrix(x, 0) = 0
        Next

        For y = 0 To Seq2.Length
            SmithWatermanMatrix(0, y) = 0
        Next



        Dim Weights(3) As Integer
        Weights(0) = 0

        'W(0)=0
        'W(1)=match/mismatch weight
        'W(2)=insert gap to X
        'W(3)=insert gap to Y

        For x = 1 To Seq1.Length 'Now fill Smith-Waterman matrix
            For y = 1 To Seq2.Length

                If SeqX(x - 1) = SeqY(y - 1) Then
                    Weights(1) = MatchScore + SmithWatermanMatrix(x - 1, y - 1)
                Else
                    Weights(1) = MismatchScore + SmithWatermanMatrix(x - 1, y - 1)
                End If

                Weights(2) = GapScore + SmithWatermanMatrix(x - 1, y)
                Weights(3) = GapScore + SmithWatermanMatrix(x, y - 1)

                SmithWatermanMatrix(x, y) = Bioinformatics.Maximum(Weights)
            Next
        Next


        Dim MatchChar As Char = "|"
        Dim MismatchChar As Char = "+"
        Dim GapChar As Char = "-"
        Dim OutOfAlignmentChar As Char = " "

        'Now search for a seed cell to prime an alignment
        Dim SeedX_Pos As Integer = 0
        Dim SeedY_Pos As Integer = 0

        Dim SeedVal As Integer = 0

        Dim X_StartAppend As String = ""
        Dim X_EndAppend As String = ""
        Dim Y_StartAppend As String = ""
        Dim Y_EndAppend As String = ""
        Dim Match_StartAppend As String = ""
        Dim Match_EndAppend As String = ""

        For x = 0 To Seq1.Length
            For y = 0 To Seq2.Length
                If SmithWatermanMatrix(x, y) > SeedVal Then
                    SeedVal = SmithWatermanMatrix(x, y)
                    SeedX_Pos = x
                    SeedY_Pos = y
                End If
            Next
        Next


        If Seq1.Length > SeedX_Pos Then
            X_EndAppend = Seq1.Substring(SeedX_Pos)
        End If

        If Seq2.Length > SeedY_Pos Then
            Y_EndAppend = Seq2.Substring(SeedY_Pos)
        End If

        If X_EndAppend.Length > Y_EndAppend.Length Then
            Y_EndAppend = AppendCharacters(Y_EndAppend, GapChar, X_EndAppend.Length - Y_EndAppend.Length, True)
            Match_EndAppend = GetCharacters(OutOfAlignmentChar, X_EndAppend.Length)
        ElseIf Y_EndAppend > X_EndAppend Then
            X_EndAppend = AppendCharacters(X_EndAppend, GapChar, Y_EndAppend.Length - X_EndAppend.Length, True)
            Match_EndAppend = GetCharacters(OutOfAlignmentChar, Y_EndAppend.Length)
        Else
            Match_EndAppend = GetCharacters(OutOfAlignmentChar, X_EndAppend.Length)
        End If


        'Now trace back
        Dim currentX As Integer = SeedX_Pos
        Dim currentY As Integer = SeedY_Pos
        Dim XY As Integer = 0
        Dim XG As Integer = 0
        Dim GY As Integer = 0
        Dim Max As Integer = 0
        Dim Aligned_X As String = ""
        Dim Aligned_Y As String = ""
        Dim MatchString As String = ""
        Dim TermX As Integer = 0
        Dim TermY As Integer = 0



        'Prime alignment

        Aligned_X &= SeqX(currentX - 1)
        Aligned_Y &= SeqY(currentY - 1)
        If SeqX(currentX - 1) = SeqY(currentY - 1) Then
            MatchString &= MatchChar
        Else
            MatchString &= MismatchChar
        End If


        Do

            XY = SmithWatermanMatrix(currentX - 1, currentY - 1)
            XG = SmithWatermanMatrix(currentX, currentY - 1)
            GY = SmithWatermanMatrix(currentX - 1, currentY)
            Max = Bioinformatics.Maximum(XY, XG, GY)

            If Max = 0 Then
                TermX = currentX - 1
                TermY = currentY - 1


                If TermX > 0 Then
                    X_StartAppend = Seq1.Substring(0, TermX)
                End If

                If TermY > 0 Then
                    Y_StartAppend = Seq2.Substring(0, TermY)
                End If

                If X_StartAppend.Length > Y_StartAppend.Length Then
                    Y_StartAppend = AppendCharacters(Y_StartAppend, GapChar, X_StartAppend.Length - Y_StartAppend.Length, False)
                    Match_StartAppend = GetCharacters(OutOfAlignmentChar, X_StartAppend.Length)
                ElseIf Y_StartAppend.Length > X_StartAppend.Length Then
                    X_StartAppend = AppendCharacters(X_StartAppend, GapChar, Y_StartAppend.Length - X_StartAppend.Length, False)
                    Match_StartAppend = GetCharacters(OutOfAlignmentChar, Y_StartAppend.Length)
                Else
                    Match_StartAppend = GetCharacters(OutOfAlignmentChar, X_StartAppend.Length)
                End If


                Exit Do
            End If

            If Max = XY Then

                currentX -= 1
                currentY -= 1

                Aligned_X &= SeqX(currentX - 1)
                Aligned_Y &= SeqY(currentY - 1)

                If SeqX(currentX - 1) = SeqY(currentY - 1) Then
                    MatchString &= MatchChar
                Else
                    MatchString &= MismatchChar
                End If


            ElseIf Max = XG Then
                currentY -= 1

                Aligned_X &= GapChar
                Aligned_Y &= SeqY(currentY - 1)
                MatchString &= MismatchChar

            ElseIf Max = GY Then
                currentX -= 1

                Aligned_X &= SeqX(currentX - 1)
                Aligned_Y &= GapChar
                MatchString &= MismatchChar

            End If

        Loop

        Alignment(0) = X_StartAppend & ReverseStrand(Aligned_X) & X_EndAppend
        Alignment(1) = Y_StartAppend & ReverseStrand(Aligned_Y) & Y_EndAppend
        Alignment(2) = Match_StartAppend & ReverseStrand(MatchString) & Match_EndAppend


        Return Alignment
    End Function

    Public Shared Function SW_adapter_cut(ByVal ReadSeq As String, ByVal AdapterSeq As String, Optional ByVal MatchScore As Integer = 2, Optional ByVal MismatchScore As Integer = -1, Optional ByVal GapScore As Integer = -2, Optional ByVal MaxMismatches As Integer = 2, Optional ByVal MaxGaps As Integer = 2)
        'Function to cut adapters

        Dim CutSeq As String = ""

        Dim SmithWatermanMatrix(ReadSeq.Length, AdapterSeq.Length) As Integer

        Dim SeqX As Char() = ReadSeq.ToCharArray
        Dim SeqY As Char() = AdapterSeq.ToCharArray


        'x - seq1 goes horizontal
        'y - seq2 goes vertical

        For x = 0 To ReadSeq.Length
            SmithWatermanMatrix(x, 0) = 0
        Next

        For y = 0 To AdapterSeq.Length
            SmithWatermanMatrix(0, y) = 0
        Next



        Dim Weights(3) As Integer
        Weights(0) = 0

        'W(0)=0
        'W(1)=match/mismatch weight
        'W(2)=insert gap to X
        'W(3)=insert gap to Y

        For x = 1 To ReadSeq.Length 'Now fill Smith-Waterman matrix
            For y = 1 To AdapterSeq.Length

                If SeqX(x - 1) = SeqY(y - 1) Then
                    Weights(1) = MatchScore + SmithWatermanMatrix(x - 1, y - 1)
                Else
                    Weights(1) = MismatchScore + SmithWatermanMatrix(x - 1, y - 1)
                End If

                Weights(2) = GapScore + SmithWatermanMatrix(x - 1, y)
                Weights(3) = GapScore + SmithWatermanMatrix(x, y - 1)

                SmithWatermanMatrix(x, y) = Bioinformatics.Maximum(Weights)
            Next
        Next

        'Now search for a seed cell to prime an alignment
        Dim SeedX_Pos As Integer = 0
        Dim SeedY_Pos As Integer = 0
        Dim SeedVal As Integer = 0

        For x = 0 To ReadSeq.Length
            For y = 0 To AdapterSeq.Length
                If SmithWatermanMatrix(x, y) > SeedVal Then
                    SeedVal = SmithWatermanMatrix(x, y)
                    SeedX_Pos = x
                    SeedY_Pos = y
                End If
            Next
        Next

        'Now trace back
        Dim currentX As Integer = SeedX_Pos
        Dim currentY As Integer = SeedY_Pos
        Dim XY As Integer = 0
        Dim XG As Integer = 0
        Dim GY As Integer = 0
        Dim Max As Integer = 0

        Dim MatchesCount As Integer = 0
        Dim GapsCount As Integer = 0
        Dim MismatchesCount As Integer = 0

        Dim Terminated As Boolean = False

        Do

            XY = SmithWatermanMatrix(currentX - 1, currentY - 1)
            XG = SmithWatermanMatrix(currentX, currentY - 1)
            GY = SmithWatermanMatrix(currentX - 1, currentY)
            Max = Bioinformatics.Maximum(XY, XG, GY)

            If Max = 0 Then
                Exit Do
            End If

            If Max = XY Then
                currentX -= 1
                currentY -= 1

                If SeqX(currentX - 1) = SeqY(currentY - 1) Then
                    MatchesCount += 1
                Else
                    MismatchesCount += 1
                End If

                If MismatchesCount > MaxMismatches Then
                    Terminated = True
                    Exit Do
                End If

            ElseIf Max = XG Then
                currentY -= 1
                GapsCount += 1

                If GapsCount > MaxGaps Then
                    Terminated = True
                    Exit Do
                End If

            ElseIf Max = GY Then
                currentX -= 1
                GapsCount += 1

                If GapsCount > MaxGaps Then
                    Terminated = True
                    Exit Do
                End If

            End If

        Loop


        If AdapterSeq.Length - MatchesCount <= MaxMismatches And Not Terminated Then
            CutSeq = ReadSeq.Substring(SeedX_Pos)
        End If


        Return CutSeq
    End Function

#End Region

#Region "Alignment representation"

    Public Shared Function FormatAlignment(ByVal Alignment As RBLAST_Result, ByVal ReverseDirection As Boolean, Optional ByVal StringLength As Integer = 100)
        Dim ResultString As String = ""
        Dim MaxSections As Integer = Math.Truncate(Alignment.SubjectSequence.Length / StringLength) - 1
        Dim CurrentPos As Integer = 0
        Dim SubjectStr As String = Alignment.SubjectSequence
        Dim QueryStr As String = Alignment.QuerySequence
        Dim MatchStr As String = Alignment.MatchString

        If ReverseDirection Then
            SubjectStr = Bioinformatics.GetReverseComplement(SubjectStr)
            QueryStr = Bioinformatics.GetReverseComplement(QueryStr)
            MatchStr = Bioinformatics.ReverseStrand(MatchStr)
        End If

        For i = 0 To MaxSections
            ResultString &= "Subject: " & SubjectStr.Substring(CurrentPos, StringLength) & Environment.NewLine
            ResultString &= "         " & MatchStr.Substring(CurrentPos, StringLength) & Environment.NewLine
            ResultString &= "Query:   " & QueryStr.Substring(CurrentPos, StringLength) & Environment.NewLine & Environment.NewLine
            CurrentPos += StringLength
        Next

        If CurrentPos <= Alignment.SubjectSequence.Length - 1 Then
            ResultString &= "Subject: " & SubjectStr.Substring(CurrentPos) & Environment.NewLine
            ResultString &= "         " & MatchStr.Substring(CurrentPos) & Environment.NewLine
            ResultString &= "Query:   " & QueryStr.Substring(CurrentPos) & Environment.NewLine & Environment.NewLine
        End If

        Return ResultString
    End Function

    Public Shared Function FormatOligoSeq(ByVal Alignment As RBLAST_Result, ByVal ReverseDirection As Boolean)
        Dim SubjectStr As String = Alignment.SubjectSequence
        Dim QueryStr As String = Alignment.QuerySequence
        Dim FormattedOligoSeq As String = ""


        If ReverseDirection Then
            SubjectStr = Bioinformatics.GetReverseComplement(SubjectStr)
            QueryStr = Bioinformatics.GetReverseComplement(QueryStr)
        End If

        For i = 0 To SubjectStr.Length - 1
            If SubjectStr(i) = "-" Then
                FormattedOligoSeq &= "#"
            Else
                FormattedOligoSeq &= QueryStr(i)
            End If
        Next

        Return FormattedOligoSeq
    End Function

#End Region

#Region "Consensus finder"

    Public Shared Function CalculateConsensus(ByVal Seq As List(Of String))
        Dim max As Integer = Seq(0).Length 'Limit is the shortest sequence length

        For Each nSeq As String In Seq
            If nSeq.Length < max Then
                max = nSeq.Length
            End If
        Next

        Dim A_count As Integer = 0
        Dim G_count As Integer = 0
        Dim C_count As Integer = 0
        Dim T_count As Integer = 0

        Dim Consensus As ConsensusSequence = New ConsensusSequence

        For i = 0 To max - 1
            A_count = 0
            G_count = 0
            C_count = 0
            T_count = 0

            For Each nSeq As String In Seq
                Select Case nSeq(i)
                    Case "A"
                        A_count += 1
                    Case "G"
                        G_count += 1
                    Case "C"
                        C_count += 1
                    Case "T"
                        T_count += 1
                End Select
            Next

            Consensus.A_list.Add(A_count / Seq.Count)
            Consensus.G_list.Add(G_count / Seq.Count)
            Consensus.C_list.Add(C_count / Seq.Count)
            Consensus.T_list.Add(T_count / Seq.Count)
        Next


        Return Consensus
    End Function

    Public Shared Function CalculateCumulative(ByVal Consensus As ConsensusSequence, ByVal WindowLength As Integer, ByVal Chr As Short)
        Dim FunctionResult As New List(Of Single)


        Dim T_count As Single = 0
        Dim G_count As Single = 0
        Dim C_count As Single = 0
        Dim A_count As Single = 0

        For i = 0 To Consensus.A_list.Count - WindowLength
            T_count = 0
            G_count = 0
            C_count = 0
            A_count = 0


            For j = 0 To WindowLength - 1
                T_count += Consensus.T_list(i + j)
                G_count += Consensus.G_list(i + j)
                C_count += Consensus.C_list(i + j)
                A_count += Consensus.A_list(i + j)

            Next

            Select Case Chr
                Case 0
                    T_count /= WindowLength
                    FunctionResult.Add(T_count)
                Case 1
                    G_count /= WindowLength
                    FunctionResult.Add(G_count)
                Case 2
                    C_count /= WindowLength
                    FunctionResult.Add(C_count)
                Case 3
                    A_count /= WindowLength
                    FunctionResult.Add(A_count)
            End Select


        Next


        Return FunctionResult
    End Function

#End Region

#Region "Transcriptomics"

    Public Shared Function GetPileUpSum(ByVal FeatureStart As Integer, ByVal FeatureEnd As Integer, ByVal PileUp As List(Of Integer))
        Dim Sum As Integer = 0

        Try
            For i = FeatureStart To FeatureEnd

                Sum += PileUp(i)

            Next i
        Catch ex As Exception
            MsgBox("Feature out of range: " & FeatureStart & "-" & FeatureEnd & vbNewLine & ex.Message)
        End Try

        Return Sum
    End Function

    Public Shared Function GetPileUpSumPerLength(ByVal FeatureStart As Integer, ByVal FeatureEnd As Integer, ByVal PileUp As List(Of Integer))
        Dim CovPerL As Single = GetPileUpSum(FeatureStart, FeatureEnd, PileUp) / (FeatureEnd - FeatureStart + 1)
        Return CovPerL
    End Function

    Public Shared Function GetTotalCountOfCoding(ByVal PileUpFor As List(Of Integer), ByVal PileUpRev As List(Of Integer), ByVal Features As List(Of Genome_Feature), ByVal Directional As Boolean)

        Dim Count As Integer = 0

        For Each Feature As Genome_Feature In Features
            If Feature.Type = 1 Then
                If Directional Then
                    Select Case Feature.Direction
                        Case 1
                            Count += GetPileUpSum(Feature.AbsoluteStart, Feature.AbsoluteEnd, PileUpFor)
                        Case 2
                            Count += GetPileUpSum(Feature.AbsoluteStart, Feature.AbsoluteEnd, PileUpRev)
                    End Select
                Else
                    Count += GetPileUpSum(Feature.AbsoluteStart, Feature.AbsoluteEnd, PileUpFor)
                End If
            End If
        Next

        Return Count
    End Function

    Public Shared Function GetCodingCoverage_SingleStrand(ByVal Coverage As List(Of Integer), ByVal Features As List(Of Genome_Feature))
        Dim Count As Integer = 0

        For Each Feature As Genome_Feature In Features
            If Feature.Type = 1 Then

                Count += GetPileUpSum(Feature.AbsoluteStart, Feature.AbsoluteEnd, Coverage)

            End If
        Next

        Return Count
    End Function

    Public Shared Function GetAggregatedCoverage(ByVal Pileup As List(Of Integer))
        Dim Count As Integer = 0
        For Each Pile As Integer In Pileup
            Count += Pile
        Next

        Return Count
    End Function

    Public Shared Sub GetNormalizedCoverage(ByVal NormalizerCount As Long, ByVal QueryFeatures As List(Of Genome_Feature), ByVal PileUpFor As List(Of Integer), ByVal PileUpRev As List(Of Integer), ByVal SaveFileName As String, ByVal Directional As Boolean)

        Dim WriteStream As New IO.FileStream(SaveFileName, IO.FileMode.Create)
        Dim Writer As New IO.StreamWriter(WriteStream)

        Dim NormalizedCoverage As Single = 0
        Dim PileupAggregate As Integer = 0

        Writer.WriteLine("Normalizer Count" & Chr(9) & NormalizerCount)
        Writer.WriteLine("TAG" & Chr(9) & "Name" & Chr(9) & "RPKM" & Chr(9) & "Count")
        For Each Feature As Genome_Feature In QueryFeatures

            If Directional Then
                Select Case Feature.Direction
                    Case 1
                        NormalizedCoverage = GetPileUpSumPerLength(Feature.AbsoluteStart + 1, Feature.AbsoluteEnd + 1, PileUpFor) / NormalizerCount * 10000000
                        PileupAggregate = Bioinformatics.GetPileUpSum(Feature.AbsoluteStart + 1, Feature.AbsoluteEnd + 1, PileUpFor)
                    Case 2
                        NormalizedCoverage = GetPileUpSumPerLength(Feature.AbsoluteStart + 1, Feature.AbsoluteEnd + 1, PileUpRev) / NormalizerCount * 10000000
                        PileupAggregate = Bioinformatics.GetPileUpSum(Feature.AbsoluteStart + 1, Feature.AbsoluteEnd + 1, PileUpRev)
                End Select
            Else
                NormalizedCoverage = GetPileUpSumPerLength(Feature.AbsoluteStart + 1, Feature.AbsoluteEnd + 1, PileUpFor) / NormalizerCount * 10000000
                PileupAggregate = Bioinformatics.GetPileUpSum(Feature.AbsoluteStart + 1, Feature.AbsoluteEnd + 1, PileUpFor)
            End If

            Writer.WriteLine(Feature.TAG & Chr(9) & Feature.Name & Chr(9) & NormalizedCoverage & Chr(9) & PileupAggregate)
        Next

        Writer.Close()
        WriteStream.Close()
        Writer.Dispose()
        WriteStream.Dispose()


    End Sub

    Public Shared Function ScaleLibrary_Int(ByVal Coverage As List(Of Integer), ByVal ScaleFactor As Single)
        Dim ScaledCoverage As New List(Of Integer)

        For Each Value As Integer In Coverage
            ScaledCoverage.Add(Math.Round(Value * ScaleFactor, 0))
        Next

        Return ScaledCoverage
    End Function

    Public Shared Function MeasureSAMLength(ByVal SAM_File As String)

        Dim FS As New IO.FileStream(SAM_File, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)

        Dim Max As Integer = 0
        While Reader.Peek > -1
            Reader.ReadLine()
            Max += 1
        End While
        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()

        Return Max
    End Function


    Public Shared Sub ConvertSAMtoCoverage(ByVal GenomeViewer As Genome_Viewer, ByVal SAM_File As String, _
                                              Optional ByVal PlusStrandShift As Integer = 0, _
                                              Optional ByVal MinusStrandShift As Integer = 0, _
                                              Optional ByVal FirstNTCov As Boolean = False, _
                                              Optional ByVal ProgressControlBox As SystemProgressBarBox = Nothing)





        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.Show()
            ProgressControlBox.Focus()

            ProgressControlBox.StatusLabel.Text = "Counting length: " & SAM_File
            ProgressControlBox.Refresh()


            Dim Max As Integer = MeasureSAMLength(SAM_File)

            ProgressControlBox.MasterProgressBar.Value = 0
            ProgressControlBox.MasterProgressBar.Maximum = Max

            ProgressControlBox.StatusLabel.Text = "Reading: " & SAM_File
            ProgressControlBox.Refresh()
        End If


        Dim FS As New IO.FileStream(SAM_File, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)

        Dim CurrentLine As String = ""
        Dim CurrentDataArray() As String
        Dim CurrentPos As Integer = 0
        Dim CurrentDir As Integer = 0
        Dim CurrentReadLength As Integer = 0

        'False - plus strand, True - minus strand

        Dim Plus_Array(GenomeViewer.Genome_Sequence.Length - 1) As Integer
        Dim Minus_Array(GenomeViewer.Genome_Sequence.Length - 1) As Integer

        Dim FirstNtMark As String = ""

        If FirstNTCov Then
            FirstNtMark = "_5'ERS"

            While Reader.Peek > -1
                CurrentLine = Reader.ReadLine

                If Not CurrentLine.StartsWith("@") Then

                    CurrentDataArray = CurrentLine.Split(Chr(9))

                    CurrentPos = CType(CurrentDataArray(3), Integer)
                    CurrentDir = CType(CurrentDataArray(1), Integer)
                    CurrentReadLength = CurrentDataArray(9).Length

                    If CurrentDir = 0 Then
                        Try
                            Plus_Array(CurrentPos + PlusStrandShift) += 1

                        Catch ex As Exception

                        End Try

                    ElseIf CurrentDir = 16 Then
                        Try
                            Minus_Array(CurrentPos + MinusStrandShift + CurrentReadLength - 1) += 1

                        Catch ex As Exception

                        End Try

                    Else 'Transcriptome is probably non-directional
                        Plus_Array(CurrentPos + PlusStrandShift) += 1
                    End If

                End If 'Not CurrentLine.StartsWith("@")

                If Not IsNothing(ProgressControlBox) Then
                    ProgressControlBox.MasterProgressBar.PerformStep()
                End If

            End While

        Else

            'Try


            While Reader.Peek > -1
                CurrentLine = Reader.ReadLine

                If Not CurrentLine.StartsWith("@") Then

                    CurrentDataArray = CurrentLine.Split(Chr(9))

                    CurrentPos = CType(CurrentDataArray(3), Integer)
                    CurrentDir = CType(CurrentDataArray(1), Integer)
                    CurrentReadLength = CurrentDataArray(9).Length

                    If CurrentDir = 0 Then

                        Try
                            For i = 0 To CurrentReadLength - 1
                                Plus_Array(CurrentPos + i + PlusStrandShift) += 1
                            Next i

                        Catch ex As Exception

                        End Try


                    ElseIf CurrentDir = 16 Then

                        Try
                            For i = 0 To CurrentReadLength - 1
                                Minus_Array(CurrentPos + i + MinusStrandShift) += 1
                            Next i

                        Catch ex As Exception

                        End Try

                    Else 'Transcriptome is probably non-directional

                        Try
                            For i = 0 To CurrentReadLength - 1
                                Plus_Array(CurrentPos + i + PlusStrandShift) += 1
                            Next i

                        Catch ex As Exception

                        End Try

                    End If

                End If 'Not CurrentLine.StartsWith("@")

                If Not IsNothing(ProgressControlBox) Then
                    ProgressControlBox.MasterProgressBar.PerformStep()
                End If

            End While

            'Catch ex As Exception

            'End Try

        End If 'FirstNTCov




        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()


        Dim SAMFileName As String = SAM_File.Split(".")(0)
        Dim PlusArrayName As String = SAMFileName & FirstNtMark & "_Plus"
        Dim MinusArrayName As String = SAMFileName & FirstNtMark & "_Minus"

        Dim ValuesPlus As New List(Of Integer)
        For Each V As Integer In Plus_Array
            ValuesPlus.Add(V)
        Next V

        Dim PlusPositionalHolder As New PositionalValuesHolder(PlusArrayName, 1, ValuesPlus, Color.Black, 1)
        PlusPositionalHolder.Group = SAMFileName
        PlusPositionalHolder.Visible = False

        GenomeViewer.Positional_Values_Collection.Add(PlusPositionalHolder)

        GenomeViewer.PositionalValuesDataGridView.Rows.Add(False, PlusPositionalHolder.Holder_Name, "Plus", "", "Logarithm", PlusPositionalHolder.Group)
        GenomeViewer.PositionalValuesDataGridView.Rows(GenomeViewer.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = Color.Black

        Dim ValuesMinus As New List(Of Integer)
        For Each V As Integer In Minus_Array
            ValuesMinus.Add(V)
        Next V

        Dim MinusPositionalHolder As New PositionalValuesHolder(MinusArrayName, 2, ValuesMinus, Color.Black, 1)
        MinusPositionalHolder.Group = SAMFileName
        MinusPositionalHolder.Visible = False

        GenomeViewer.Positional_Values_Collection.Add(MinusPositionalHolder)

        GenomeViewer.PositionalValuesDataGridView.Rows.Add(False, MinusPositionalHolder.Holder_Name, "Minus", "", "Logarithm", MinusPositionalHolder.Group)
        GenomeViewer.PositionalValuesDataGridView.Rows(GenomeViewer.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = Color.Black

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.Close()
        End If

    End Sub

    Public Shared Sub ConvertSAMtoCoverage(ByVal SAM_File As String, ByVal ReferenceLength As Integer, _
                                           Optional ByVal PlusStrandShift As Integer = 0, _
                                           Optional ByVal MinusStrandShift As Integer = 0, _
                                           Optional ByVal FirstNTCov As Boolean = False)

        Dim FS As New IO.FileStream(SAM_File, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)

        Dim CurrentLine As String = ""
        Dim CurrentDataArray() As String
        Dim CurrentPos As Integer = 0
        Dim CurrentDir As Integer = 0
        Dim CurrentReadLength As Integer = 0

        'False - plus strand, True - minus strand

        Dim Plus_Array(ReferenceLength - 1) As Integer
        Dim Minus_Array(ReferenceLength - 1) As Integer


        If FirstNTCov Then
            While Reader.Peek > -1
                CurrentLine = Reader.ReadLine

                If Not CurrentLine.StartsWith("@") Then

                    CurrentDataArray = CurrentLine.Split(Chr(9))

                    CurrentPos = CType(CurrentDataArray(3), Integer)
                    CurrentDir = CType(CurrentDataArray(1), Integer)
                    CurrentReadLength = CurrentDataArray(9).Length

                    If CurrentDir = 0 Then

                        Plus_Array(CurrentPos + PlusStrandShift) += 1

                    ElseIf CurrentDir = 16 Then

                        Minus_Array(CurrentPos + MinusStrandShift + CurrentReadLength - 1) += 1

                    Else

                        'Sequence is probably non-directional
                        Plus_Array(CurrentPos + PlusStrandShift) += 1

                    End If

                End If 'Not CurrentLine.StartsWith("@")

            End While

        Else

            'Try


            While Reader.Peek > -1
                CurrentLine = Reader.ReadLine

                If Not CurrentLine.StartsWith("@") Then

                    CurrentDataArray = CurrentLine.Split(Chr(9))

                    CurrentPos = CType(CurrentDataArray(3), Integer)
                    CurrentDir = CType(CurrentDataArray(1), Integer)
                    CurrentReadLength = CurrentDataArray(9).Length

                    If CurrentDir = 0 Then

                        Try
                            For i = 0 To CurrentReadLength - 1
                                Plus_Array(CurrentPos + i + PlusStrandShift) += 1
                            Next i

                        Catch ex As Exception

                        End Try


                    ElseIf CurrentDir = 16 Then

                        Try
                            For i = 0 To CurrentReadLength - 1
                                Minus_Array(CurrentPos + i + MinusStrandShift) += 1
                            Next i

                        Catch ex As Exception

                        End Try
                    Else
                        'Sequence is probably non-directional

                        For i = 0 To CurrentReadLength - 1
                            Plus_Array(CurrentPos + i + PlusStrandShift) += 1
                        Next i

                    End If

                End If 'Not CurrentLine.StartsWith("@")

            End While

            'Catch ex As Exception

            'End Try

        End If 'FirstNTCov







        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()



        Dim SaveFileName As String = SAM_File.Split(".")(0)
        Dim PlusArrayName As String = SaveFileName & "_Plus.txt"
        Dim MinusArrayName As String = SaveFileName & "_Minus.txt"



        Dim PlusWriteStream As New IO.FileStream(PlusArrayName, IO.FileMode.Create, IO.FileAccess.Write)
        Dim PlusWriter As New IO.StreamWriter(PlusWriteStream)

        For Each Data As Integer In Plus_Array
            PlusWriter.WriteLine(Data)
        Next Data


        PlusWriter.Close()
        PlusWriteStream.Close()
        PlusWriter.Dispose()
        PlusWriteStream.Dispose()


        Dim MinusWriteStream As New IO.FileStream(MinusArrayName, IO.FileMode.Create, IO.FileAccess.Write)
        Dim MinusWriter As New IO.StreamWriter(MinusWriteStream)

        For Each Data As Integer In Minus_Array
            MinusWriter.WriteLine(Data)
        Next Data


        MinusWriter.Close()
        MinusWriteStream.Close()
        MinusWriter.Dispose()
        MinusWriteStream.Dispose()




    End Sub

    '\\\\\\\\\\\\\\\\\\\\\\\There is a set of functions for transcription units identification

    Public Shared Function SumIntLists(ByVal Data() As List(Of Integer))
        Dim SumList As New List(Of Integer)

        'Initialize integrated list
        Dim MaxL As Integer = 0
        For Each IntList As List(Of Integer) In Data
            If IntList.Count > MaxL Then
                MaxL = IntList.Count
            End If
        Next

        For i = 0 To MaxL - 1
            SumList.Add(0)
        Next

        For Each IntList As List(Of Integer) In Data
            For i = 0 To IntList.Count - 1
                SumList(i) += IntList(i)
            Next
        Next



        Return SumList
    End Function

    Public Shared Function ReverseIntList(ByVal Data As List(Of Integer))
        Dim Result As New List(Of Integer)

        For i = Data.Count - 1 To 0 Step -1
            Result.Add(Data(i))
        Next

        Return Result
    End Function

    Public Shared Function GetCoverageDerivativeList(ByVal Coverage As List(Of Integer), Optional ByVal Smoothing As Integer = 100)

        Dim DerivativeUp As New List(Of Integer)
        Dim DerivativeDown As New List(Of Integer)

        If Coverage.Count > 0 Then

            Dim StartPos As Integer = 0
            Dim EndPos As Integer = 0

            Dim PrevSum As Integer = 0
            Dim NextSum As Integer = 0



            Dim MaxIndex As Integer = Coverage.Count - 1

            For i = 0 To MaxIndex
                Try
                    PrevSum = 0
                    NextSum = 0

                    If i + Smoothing <= MaxIndex And i - Smoothing >= 0 Then

                        For SubIndex = i - Smoothing To i
                            PrevSum += Coverage(SubIndex)
                        Next

                        For SubIndex = i To i + Smoothing
                            NextSum += Coverage(SubIndex)
                        Next

                    ElseIf i + Smoothing <= MaxIndex And i - Smoothing < 0 Then

                        For SubIndex = 0 To i
                            PrevSum += Coverage(SubIndex)
                        Next

                        For SubIndex = MaxIndex - Smoothing + i + 1 To MaxIndex
                            PrevSum += Coverage(SubIndex)
                        Next

                        For SubIndex = i To i + Smoothing
                            NextSum += Coverage(SubIndex)
                        Next

                    ElseIf i + Smoothing > MaxIndex And i - Smoothing >= 0 Then

                        For SubIndex = i - Smoothing To i
                            PrevSum += Coverage(SubIndex)
                        Next

                        For SubIndex = i To MaxIndex
                            NextSum += Coverage(SubIndex)
                        Next

                        For SubIndex = 0 To Smoothing - MaxIndex + i - 1
                            NextSum += Coverage(SubIndex)
                        Next

                    End If

                    If PrevSum = 0 Then
                        DerivativeUp.Add(NextSum / 1)
                    Else
                        DerivativeUp.Add(NextSum / PrevSum)
                    End If

                    If NextSum = 0 Then
                        DerivativeDown.Add(PrevSum / 1)
                    Else
                        DerivativeDown.Add(PrevSum / NextSum)
                    End If

                Catch ex As Exception

                    DerivativeUp.Add(0)
                    DerivativeDown.Add(0)

                    MsgBox(ex.Message)
                End Try

            Next

        End If

        Dim Result(1) As List(Of Integer)

        Result(0) = DerivativeUp
        Result(1) = DerivativeDown

        Return Result
    End Function

    Public Shared Sub SortCoverageSteps(ByRef Steps As List(Of CoverageStep))
        'Sort steps by start
        Dim Tmp As CoverageStep = Nothing
        For i = 1 To Steps.Count - 1
            For j = 0 To Steps.Count - 1 - i
                If Steps(j).Position > Steps(j + 1).Position Then
                    Tmp = Steps(j)
                    Steps(j) = Steps(j + 1)
                    Steps(j + 1) = Tmp
                End If
            Next
        Next
    End Sub

    Public Shared Sub SortCoverageBlocks(ByRef BlocksHolder As QuantBlockHolder)
        'Sort blocks by start
        Dim Tmp As QuantitationBlock = Nothing
        For i = 1 To BlocksHolder.BlocksList.Count - 1
            For j = 0 To BlocksHolder.BlocksList.Count - 1 - i
                If BlocksHolder.BlocksList(j).AbsoluteStart > BlocksHolder.BlocksList(j + 1).AbsoluteStart Then
                    Tmp = BlocksHolder.BlocksList(j)
                    BlocksHolder.BlocksList(j) = BlocksHolder.BlocksList(j + 1)
                    BlocksHolder.BlocksList(j + 1) = Tmp
                End If
            Next
        Next
    End Sub

    Public Shared Sub SortCoverageBlocks(ByRef BlocksList As List(Of QuantitationBlock))
        'Sort blocks by start
        Dim Tmp As QuantitationBlock = Nothing
        For i = 1 To BlocksList.Count - 1
            For j = 0 To BlocksList.Count - 1 - i
                If BlocksList(j).AbsoluteStart > BlocksList(j + 1).AbsoluteStart Then
                    Tmp = BlocksList(j)
                    BlocksList(j) = BlocksList(j + 1)
                    BlocksList(j + 1) = Tmp
                End If
            Next
        Next
    End Sub

    Public Shared Sub FilterStepsByStandartDeviation(ByRef Steps As List(Of CoverageStep), _
                                                 ByVal Coverage As List(Of Integer), _
                                                 Optional ByVal SD_multiplier As Single = 1)

        If Steps.Count < 3 Then
            Exit Sub
        End If

        Dim PrevStepsAmount As Integer = 0
        Dim CurrentStepsAmount As Integer = 0

        Dim Coverage_A As New List(Of Integer)
        Dim Coverage_B As New List(Of Integer)

        Dim Comparer_A() As Single
        Dim Comparer_B() As Single
        Dim RemoveBorder As Boolean = False

        Dim CurrentIndex As Integer = 1 'Index of the current interval

        Try


            Do

                Coverage_A.Clear()
                Coverage_B.Clear()


                RemoveBorder = False

                If CurrentIndex > Steps.Count - 2 Then 'Max possible index
                    CurrentStepsAmount = Steps.Count

                    If CurrentStepsAmount = PrevStepsAmount Then 'If no steps can be further removed
                        Exit Do
                    End If

                    PrevStepsAmount = CurrentStepsAmount
                    CurrentIndex = 1

                End If

                For i = Steps(CurrentIndex - 1).Position To Steps(CurrentIndex).Position
                    Coverage_A.Add(Coverage(i))
                Next

                For i = Steps(CurrentIndex).Position To Steps(CurrentIndex + 1).Position
                    Coverage_B.Add(Coverage(i))
                Next

                Comparer_A = Bioinformatics.StandartDeviationAndMeanValue(Coverage_A) 'Bioinformatics.SD_corridor(Coverage_A, SD_multiplier)
                Comparer_B = Bioinformatics.StandartDeviationAndMeanValue(Coverage_B) 'Bioinformatics.SD_corridor(Coverage_B, SD_multiplier)

                If Math.Abs(Comparer_A(0) - Comparer_B(0)) > (Comparer_A(1) + Comparer_B(1)) * SD_multiplier Then 'Comparer_A(2) > Comparer_B(0) Or Comparer_A(0) < Comparer_B(2) Then 'Values do not intersect
                    RemoveBorder = False
                Else
                    RemoveBorder = True
                End If

                If RemoveBorder Then
                    Steps.RemoveAt(CurrentIndex)
                    CurrentIndex -= 1
                End If

                CurrentIndex += 1

            Loop

        Catch ex As Exception
            MsgBox("Error in step filtration cycle!")
        End Try

    End Sub

    Public Shared Function RemoveStepDuplicates(ByVal Steps As List(Of CoverageStep), _
                                                Optional ByVal FiltrationWindow As Integer = 10)

        Dim FilteredList As New List(Of CoverageStep)


        Dim ClusterList As New List(Of Integer)

        Dim AveragePos As Integer = 0

        For i = 0 To Steps.Count - 1

            If i < Steps.Count - 1 Then


                If Steps(i + 1).Position < Steps(i).Position + FiltrationWindow And Steps(i + 1).Type = Steps(i).Type Then
                    'Add to cluster

                    ClusterList.Add(Steps(i).Position) 'Add previous
                Else

                    'it may be end of cluster or lonely step

                    If ClusterList.Count = 0 Then 'This was lonely step

                        FilteredList.Add(Steps(i)) 'This is a lonely step

                    Else 'This was last step of the cluster
                        ClusterList.Add(Steps(i).Position)

                        'Analyze cluster
                        AveragePos = 0
                        For Each ClusterStep As Integer In ClusterList
                            AveragePos += ClusterStep
                        Next
                        AveragePos = Math.Round(AveragePos / ClusterList.Count, 0)
                        Dim NewStep As New CoverageStep
                        NewStep.Position = AveragePos
                        NewStep.Type = Steps(i).Type
                        FilteredList.Add(NewStep)

                        ClusterList.Clear()
                    End If

                End If


            Else

                If Steps(i).Position < Steps(i - 1).Position + FiltrationWindow And Steps(i).Type = Steps(i - 1).Type Then
                    ClusterList.Add(Steps(i).Position)

                    'Analyze cluster
                    AveragePos = 0
                    For Each ClusterStep As Integer In ClusterList
                        AveragePos += ClusterStep
                    Next
                    AveragePos = Math.Round(AveragePos / ClusterList.Count, 0)
                    Dim NewStep As New CoverageStep
                    NewStep.Position = AveragePos
                    NewStep.Type = Steps(i).Type
                    FilteredList.Add(NewStep)

                    ClusterList.Clear()
                Else

                    FilteredList.Add(Steps(i)) 'This is a lonely step

                End If


            End If
        Next



        Return FilteredList
    End Function

    Public Shared Function FindPeaks(ByVal Derivative As List(Of Integer), _
                                     ByVal DerivativeType As Boolean, _
                                     Optional ByVal Background As Integer = 10, _
                                     Optional ByVal WindowWidth As Integer = 10, _
                                     Optional ByVal PeakFilterWindowWidth As Integer = 20, _
                                     Optional ByVal SearchDrops As Boolean = True, _
                                     Optional ByVal DropExtensionLength As Integer = 50, _
                                     Optional ByVal DropThreshold As Single = 0.7)


        'Here we search for local maximums associated with abrupt drop of window coverage/coverage function as they are associated with TSS's
        Dim Result As New List(Of Integer)


        If Derivative.Count > 0 Then


            Dim MaximumList As New List(Of Integer) 'Coordinates of local maximums


            'We search local maximums in a window

            Dim LocalMax As Integer = 0

            For i = WindowWidth To Derivative.Count - 1 - WindowWidth

                If Derivative(i) > Background Then 'We don't care about background

                    LocalMax = 0
                    For j = i - WindowWidth To i + WindowWidth
                        If Derivative(j) > LocalMax Then
                            LocalMax = Derivative(j)
                        End If
                    Next

                    If Derivative(i) = LocalMax Then 'Here is local maximum
                        MaximumList.Add(i)
                    End If

                End If
            Next




            'Here filter local maximums of repetitive values, leave the latest maximum

            Dim CurrentIndex As Integer = MaximumList.Count - 1
            Dim SubIndex As Integer = 0

            Do

                SubIndex = CurrentIndex - 1


                If SubIndex < 0 Or CurrentIndex < 0 Then
                    Exit Do
                End If


                Do


                    If MaximumList(SubIndex) >= MaximumList(CurrentIndex) - PeakFilterWindowWidth Then
                        MaximumList.RemoveAt(SubIndex)
                        CurrentIndex -= 1
                    End If

                    If SubIndex = 0 Then
                        Exit Do
                    Else
                        SubIndex -= 1
                    End If

                Loop


                If CurrentIndex = 0 Then
                    Exit Do
                Else
                    CurrentIndex -= 1
                End If
            Loop


            If SearchDrops Then

                Dim LocalStepSize As Single = 0
                Dim DropFound As Boolean = False
                Dim DropPosition As Integer = 0

                Dim CuratedMaximumList As New List(Of Integer)

                For Each LocalMaximum As Integer In MaximumList 'Now search for the first point of abrupt function drop
                    DropFound = False


                    Try

                        For i = LocalMaximum To LocalMaximum + DropExtensionLength
                            If i + 1 > Derivative.Count - 1 Then
                                Exit For
                            End If

                            LocalStepSize = Derivative(i + 1) / Derivative(i)
                            If LocalStepSize <= DropThreshold Then
                                DropFound = True
                                DropPosition = i
                                Exit For
                            End If
                        Next


                    Catch ex As Exception

                        MsgBox("ERROR in local maximum position correction!" & vbNewLine & ex.Message)

                    End Try

                    If DropFound Then
                        CuratedMaximumList.Add(DropPosition)
                    Else
                        CuratedMaximumList.Add(LocalMaximum)
                    End If

                Next

                Dim Found As Boolean = False

                For Each Value As Integer In CuratedMaximumList
                    Found = False

                    For Each ResultValue As Integer In Result
                        If ResultValue = Value Then
                            Found = True
                        End If
                    Next

                    If Not Found Then
                        Result.Add(Value)
                    End If

                Next


            Else
                Result = MaximumList
            End If

        End If


        Dim Peaks As New List(Of CoverageStep)
        For Each Peak As Integer In Result
            Dim NewPeak As New CoverageStep
            NewPeak.Position = Peak
            NewPeak.Type = DerivativeType
            Peaks.Add(NewPeak)
        Next

        Return Peaks
    End Function

    Public Shared Function AnalyzeCoverage(ByVal Coverage As List(Of Integer), _
                                                 Optional ByVal CoverageSmoothing As Integer = 100, _
                                                 Optional ByVal TSS_DerivativeBackground As Integer = 10, _
                                                 Optional ByVal TSS_LocalMaxWindow As Integer = 20, _
                                                 Optional ByVal TSS_FiltrationWindow As Integer = 50, _
                                                 Optional ByVal TSS_Asymmetry As Boolean = True, _
                                                 Optional ByVal TSS_AsymmetryWindow As Integer = 50, _
                                                 Optional ByVal TSS_AsymmetryThreshold As Single = 0.7, _
                                                 Optional ByVal Term_DerivativeBackground As Integer = 20, _
                                                 Optional ByVal Term_LocalMaxWindow As Integer = 20, _
                                                 Optional ByVal Term_FiltrationWindow As Integer = 20, _
                                                 Optional ByVal FilterBackgroungPeaks As Boolean = False, _
                                                 Optional ByVal CoverageBackgroundWindow As Integer = 200, _
                                                 Optional ByVal ThresholdCoverage As Single = 1, _
                                                 Optional ByVal UseCDSCorrection As Boolean = False, _
                                                 Optional ByVal AnnotationDirectionPlus As Boolean = True, _
                                                 Optional ByVal Annotation As FeaturesAssembly = Nothing, _
                                                 Optional ByVal CDS_Correction_Window As Integer = 100, _
                                                 Optional ByVal StatisticalFiltrationMethod As Short = 0, _
                                                 Optional ByVal FiltrationValue As Single = 1, _
                                                 Optional ByRef StatusLabel As Label = Nothing)



        If Not IsNothing(StatusLabel) Then
            StatusLabel.Text = "Preparing derivative..."
            StatusLabel.Refresh()
        End If

        Dim Derivative() As List(Of Integer) = Bioinformatics.GetCoverageDerivativeList(Coverage, CoverageSmoothing)

        If Not IsNothing(StatusLabel) Then
            StatusLabel.Text = "Analyzing coverage..."
            StatusLabel.Refresh()
        End If


        Dim TSS_position_list As List(Of CoverageStep) = Bioinformatics.FindPeaks(Derivative(0), True, TSS_DerivativeBackground, TSS_LocalMaxWindow, TSS_FiltrationWindow, TSS_Asymmetry, TSS_AsymmetryWindow, TSS_AsymmetryThreshold)
        Dim Term_position_list As List(Of CoverageStep) = Bioinformatics.FindPeaks(Derivative(1), False, Term_DerivativeBackground, Term_LocalMaxWindow, Term_FiltrationWindow, False)


        If FilterBackgroungPeaks Then 'Here we remove steps with low coverage

            If Not IsNothing(StatusLabel) Then
                StatusLabel.Text = "Filtering background..."
                StatusLabel.Refresh()
            End If



            Dim LocalCoverageSum As Integer = 0
            Dim LocalAverageCoverage As Single = 0
            Dim Counter As Integer = 0


            Do 'Filter TSS

                LocalCoverageSum = 0

                If Counter > TSS_position_list.Count - 1 Then
                    Exit Do
                End If

                If TSS_position_list(Counter).Position + CoverageBackgroundWindow <= Coverage.Count Then

                    For i = 0 To CoverageBackgroundWindow - 1
                        LocalCoverageSum += Coverage(TSS_position_list(Counter).Position + i)
                    Next

                End If


                LocalAverageCoverage = LocalCoverageSum / CoverageBackgroundWindow


                If LocalAverageCoverage <= ThresholdCoverage Then
                    TSS_position_list.RemoveAt(Counter)
                    Counter -= 1

                End If



                Counter += 1
            Loop


            Counter = 0

            Do 'Filter Terminators

                LocalCoverageSum = 0

                If Counter > Term_position_list.Count - 1 Then
                    Exit Do
                End If


                If Term_position_list(Counter).Position >= CoverageBackgroundWindow - 1 Then
                    For i = 0 To CoverageBackgroundWindow - 1
                        LocalCoverageSum += Coverage(Term_position_list(Counter).Position - i)

                    Next
                End If


                LocalAverageCoverage = LocalCoverageSum / CoverageBackgroundWindow

                If LocalAverageCoverage <= ThresholdCoverage Then
                    Term_position_list.RemoveAt(Counter)
                    Counter -= 1
                End If

                Counter += 1
            Loop

            Counter = 0

        End If 'Remove background peaks




        'Annotation
        If UseCDSCorrection And Not IsNothing(Annotation) Then

            If Not IsNothing(StatusLabel) Then
                StatusLabel.Text = "Terminators correction..."
                StatusLabel.Refresh()
            End If

            If AnnotationDirectionPlus Then
                For TerminatorPos = 0 To Term_position_list.Count - 1
                    For Each Feature As Genome_Feature In Annotation.FeaturesList
                        If Feature.Type = 1 And Feature.Direction = 1 Then
                            If Term_position_list(TerminatorPos).Position < Feature.AbsoluteEnd And _
                            Term_position_list(TerminatorPos).Position >= Feature.AbsoluteEnd - CDS_Correction_Window Then
                                Term_position_list(TerminatorPos).Position = Feature.AbsoluteEnd

                            End If
                        End If
                    Next
                Next TerminatorPos
            Else

                For TerminatorPos = 0 To Term_position_list.Count - 1
                    For Each Feature As Genome_Feature In Annotation.FeaturesList
                        If Feature.Type = 1 And Feature.Direction = 2 Then 'Minus list is reversed to annotation
                            If Coverage.Count - Term_position_list(TerminatorPos).Position > Feature.AbsoluteStart And _
                           Coverage.Count - Term_position_list(TerminatorPos).Position <= Feature.AbsoluteStart + CDS_Correction_Window Then
                                Term_position_list(TerminatorPos).Position = Feature.AbsoluteEnd

                            End If
                        End If
                    Next
                Next TerminatorPos



            End If



        End If



        If Not IsNothing(StatusLabel) Then
            StatusLabel.Text = "TSS's: " & TSS_position_list.Count & ", Terminators: " & Term_position_list.Count
            StatusLabel.Refresh()
        End If




        Dim Steps As New List(Of CoverageStep)

        Steps.AddRange(TSS_position_list)
        Steps.AddRange(Term_position_list)
        SortCoverageSteps(Steps)


        Select Case StatisticalFiltrationMethod
            Case 1
                If Not IsNothing(StatusLabel) Then
                    StatusLabel.Text &= ", Steps before: " & Steps.Count
                End If

                FilterStepsByStandartDeviation(Steps, Coverage, FiltrationValue)

                If Not IsNothing(StatusLabel) Then
                    StatusLabel.Text &= ", Steps after: " & Steps.Count
                End If

        End Select



        Return Steps
    End Function

    Public Shared Function MakeTranscriptionBlocksFromSteps(Optional ByVal Steps_Plus As List(Of CoverageStep) = Nothing, _
                                                            Optional ByVal Steps_Minus As List(Of CoverageStep) = Nothing, _
                                                 Optional ByVal Coverage_Plus As List(Of Integer) = Nothing, _
                                                 Optional ByVal Coverage_Minus As List(Of Integer) = Nothing, _
                                                 Optional ByVal ExperimentName As String = "", _
                                                 Optional ByVal Normalizer As Integer = 1000000)

        If Not IsNothing(Steps_Plus) Then
            SortCoverageSteps(Steps_Plus)
        End If

        If Not IsNothing(Steps_Minus) Then
            SortCoverageSteps(Steps_Minus)
        End If


        Dim TotalCoverage As Long = 1 'Normalizer

        If Not IsNothing(Coverage_Plus) Then
            For Each Value As Integer In Coverage_Plus
                TotalCoverage += Value
            Next
        End If

        If Not IsNothing(Coverage_Minus) Then
            For Each Value As Integer In Coverage_Minus
                TotalCoverage += Value
            Next
        End If


        ' Dim NormalizerC As Single = Normalizer / TotalCoverage
        Dim BlocksHolder As New QuantBlockHolder
        BlocksHolder.Name = ExperimentName

        Dim RelativeCoverage As Single = 0


        If Not IsNothing(Coverage_Plus) And Not IsNothing(Steps_Plus) Then
            For i = 0 To Steps_Plus.Count - 2 'Use only intervals between
                RelativeCoverage = GetPileUpSumPerLength(Steps_Plus(i).Position, Steps_Plus(i + 1).Position, Coverage_Plus)
                Dim NewBlock As New QuantitationBlock
                NewBlock.Holder_Name = ExperimentName
                NewBlock.AbsoluteStart = Steps_Plus(i).Position + 1
                NewBlock.AbsoluteEnd = Steps_Plus(i + 1).Position
                NewBlock.Direction = 1
                NewBlock.TAG = BlocksHolder.Name & "-plus-" & i
                NewBlock.Value = RelativeCoverage / TotalCoverage '* NormalizerC
                NewBlock.Aux_Value = RelativeCoverage
                BlocksHolder.BlocksList.Add(NewBlock)
            Next
        End If


        If Not IsNothing(Coverage_Minus) And Not IsNothing(Steps_Minus) Then
            For i = 0 To Steps_Minus.Count - 2 'Use only intervals between
                RelativeCoverage = GetPileUpSumPerLength(Steps_Minus(i).Position, Steps_Minus(i + 1).Position, Coverage_Minus)
                Dim NewBlock As New QuantitationBlock
                NewBlock.Holder_Name = ExperimentName
                NewBlock.AbsoluteStart = Coverage_Minus.Count - Steps_Minus(i + 1).Position + 1
                NewBlock.AbsoluteEnd = Coverage_Minus.Count - Steps_Minus(i).Position
                NewBlock.Direction = 2
                NewBlock.TAG = BlocksHolder.Name & "-minus-" & i
                NewBlock.Value = RelativeCoverage / TotalCoverage ' * NormalizerC
                NewBlock.Aux_Value = RelativeCoverage
                BlocksHolder.BlocksList.Add(NewBlock)
            Next
        End If


        SortCoverageBlocks(BlocksHolder)

        Return BlocksHolder
    End Function

    Public Shared Function MakeTranscriptionSitesFromSteps(Optional ByVal Steps_Plus As List(Of CoverageStep) = Nothing, _
                                                            Optional ByVal Steps_Minus As List(Of CoverageStep) = Nothing, _
                                                            Optional ByVal ExperimentName As String = "", _
                                                            Optional ByVal MaxLength As Integer = 0)

        Dim counter As Integer = 0
        Dim NewAsm As New FeaturesAssembly
        NewAsm.AssemblyName = ExperimentName
        NewAsm.Visible = True

        If Not IsNothing(Steps_Plus) Then
            For Each C_Step As CoverageStep In Steps_Plus
                Dim NewFeature As New Genome_Feature
                If C_Step.Type Then
                    NewFeature.Type = 5
                Else
                    NewFeature.Type = 6
                End If
                NewFeature.Direction = 1
                NewFeature.AbsoluteStart = C_Step.Position + 1
                NewFeature.AbsoluteEnd = C_Step.Position + 1
                NewFeature.TAG = ExperimentName & "-" & counter
                NewFeature.Name = NewFeature.TAG
                NewAsm.FeaturesList.Add(NewFeature)
                counter += 1
            Next
        End If

        If Not IsNothing(Steps_Minus) Then
            For Each C_Step As CoverageStep In Steps_Minus
                Dim NewFeature As New Genome_Feature
                If C_Step.Type Then
                    NewFeature.Type = 5
                Else
                    NewFeature.Type = 6
                End If
                NewFeature.Direction = 2
                NewFeature.AbsoluteStart = MaxLength - C_Step.Position
                NewFeature.AbsoluteEnd = MaxLength - C_Step.Position
                NewFeature.TAG = ExperimentName & "-" & counter
                NewFeature.Name = NewFeature.TAG
                NewAsm.FeaturesList.Add(NewFeature)
                counter += 1
            Next
        End If

        Return NewAsm
    End Function

    Public Shared Function MakeTSSFromERS(Optional ByVal TSS_Plus As List(Of Integer) = Nothing, _
                                          Optional ByVal TSS_Minus As List(Of Integer) = Nothing, _
                                          Optional ByVal ExperimentName As String = "")


        Dim counter As Integer = 0
        Dim NewAsm As New FeaturesAssembly
        NewAsm.AssemblyName = ExperimentName
        NewAsm.Visible = True

        If Not IsNothing(TSS_Plus) Then
            For Each TSS As Integer In TSS_Plus
                Dim NewFeature As New Genome_Feature
                NewFeature.Type = 5
                NewFeature.Direction = 1
                NewFeature.AbsoluteStart = TSS + 1
                NewFeature.AbsoluteEnd = TSS + 1
                NewFeature.TAG = ExperimentName & "-" & counter
                NewFeature.Name = NewFeature.TAG
                NewAsm.FeaturesList.Add(NewFeature)
                counter += 1
            Next TSS
        End If

        If Not IsNothing(TSS_Minus) Then
            For Each TSS As Integer In TSS_Minus
                Dim NewFeature As New Genome_Feature
                NewFeature.Type = 5
                NewFeature.Direction = 2
                NewFeature.AbsoluteStart = TSS + 1
                NewFeature.AbsoluteEnd = TSS + 1
                NewFeature.TAG = ExperimentName & "-" & counter
                NewFeature.Name = NewFeature.TAG
                NewAsm.FeaturesList.Add(NewFeature)
                counter += 1
            Next TSS
        End If

        Return NewAsm
    End Function

    Public Shared Function CalculateValuesForIntervals(ByVal ReferenceHolder As QuantBlockHolder, _
                                                 Optional ByVal Coverage_Plus As List(Of Integer) = Nothing, _
                                                 Optional ByVal Coverage_Minus As List(Of Integer) = Nothing, _
                                                 Optional ByVal ExperimentName As String = "", _
                                                 Optional ByVal Normalizer As Single = 1000000)

        Dim NewHolder As New QuantBlockHolder
        NewHolder.Name = ReferenceHolder.Name & "-" & ExperimentName


        Dim TotalCoverage As Long = 1 'Normalizer


        If Not IsNothing(Coverage_Plus) Then
            For Each Value As Integer In Coverage_Plus
                TotalCoverage += Value
            Next
        End If

        If Not IsNothing(Coverage_Minus) Then
            For Each Value As Integer In Coverage_Minus
                TotalCoverage += Value
            Next
        End If


        Dim RelativeCoverage As Single = 0


        For Each Block As QuantitationBlock In ReferenceHolder.BlocksList
            Dim NewBlock As New QuantitationBlock
            NewBlock.Holder_Name = NewHolder.Name
            NewBlock.Visible = True
            NewBlock.Draw_Color = Block.Draw_Color
            NewBlock.TAG = Block.TAG
            NewBlock.AbsoluteStart = Block.AbsoluteStart
            NewBlock.AbsoluteEnd = Block.AbsoluteEnd
            NewBlock.Direction = Block.Direction
            NewBlock.Description = Block.Description

            Select Case Block.Direction
                Case 1

                    If Not IsNothing(Coverage_Plus) Then
                        RelativeCoverage = GetPileUpSumPerLength(Block.AbsoluteStart - 1, Block.AbsoluteEnd - 1, Coverage_Plus)
                        NewBlock.Value = RelativeCoverage / TotalCoverage * Normalizer
                    End If

                Case 2

                    If Not IsNothing(Coverage_Minus) Then
                        RelativeCoverage = GetPileUpSumPerLength(Block.AbsoluteStart - 1, Block.AbsoluteEnd - 1, Coverage_Minus)
                        NewBlock.Value = RelativeCoverage / TotalCoverage * Normalizer
                    End If

            End Select

            NewHolder.BlocksList.Add(NewBlock)
        Next







        Return NewHolder
    End Function

    Public Shared Function FindDifExpressingIntervals(ByVal BlocksControl As List(Of QuantitationBlock), ByVal BlocksCase As List(Of QuantitationBlock), Optional ByVal Increase As Boolean = True, Optional ByVal MinFC As Single = 2)
        Dim ResultBlocks As New List(Of QuantitationBlock)

        If Increase Then
            For i = 0 To BlocksControl.Count - 1
                If BlocksCase(i).Value / BlocksControl(i).Value >= MinFC Then
                    ResultBlocks.Add(BlocksCase(i))
                End If
            Next
        Else
            For i = 0 To BlocksControl.Count - 1
                If BlocksControl(i).Value / BlocksCase(i).Value >= MinFC Then
                    ResultBlocks.Add(BlocksCase(i))
                End If
            Next
        End If


        Return ResultBlocks
    End Function

    '\\Identification of slippering 2 new algorithm
    Public Shared Function CountCDSInBlock(ByVal Block As QuantitationBlock, ByVal Annotation As List(Of Genome_Feature), Optional ByVal MinIntersection As Single = 0.5)
        Dim CDS_count As Integer = 0

        For Each Feature As Genome_Feature In Annotation
            If Feature.Type = 1 And Feature.Direction = Block.Direction And IsFeatureInBlock(Feature, Block, MinIntersection) Then
                CDS_count += 1
            End If
        Next


        Return CDS_count
    End Function

    Public Shared Function FindCDSInBlockToString(ByVal Block As QuantitationBlock, ByVal Annotation As List(Of Genome_Feature), Optional ByVal MinIntersection As Single = 0.5)
        Dim CDS_IDs As String = ""

        For Each Feature As Genome_Feature In Annotation
            If Feature.Type = 1 And Feature.Direction = Block.Direction And IsFeatureInBlock(Feature, Block, MinIntersection) Then
                CDS_IDs &= Feature.TAG & ";"
            End If
        Next

        Return CDS_IDs
    End Function

    Public Shared Function IntervalContainsGenes(ByVal Block As QuantitationBlock, ByVal Annotation As List(Of Genome_Feature), Optional ByVal MinIntersection As Single = 0.5)

        For Each Feature As Genome_Feature In Annotation
            If IsFeatureInBlock(Feature, Block, MinIntersection) Then
                Return True
                Exit For
            End If
        Next

        Return False
    End Function

    Public Shared Function IsFeatureInBlock(ByVal Feature As Genome_Feature, ByVal Block As QuantitationBlock, Optional ByVal MinIntersect As Single = 0.5)
        Dim Result As Boolean = False
        Dim Intersection As Integer = 0
        If Feature.AbsoluteStart >= Block.AbsoluteStart And Feature.AbsoluteEnd <= Block.AbsoluteEnd Then 'Feature is within block
            Result = True

        ElseIf Feature.AbsoluteEnd > Block.AbsoluteStart And Feature.AbsoluteStart < Block.AbsoluteStart Then
            Intersection = (Feature.AbsoluteEnd - Block.AbsoluteStart + 1) / (Feature.AbsoluteEnd - Feature.AbsoluteStart + 1)
            If Intersection >= MinIntersect Then
                Result = True
            End If

        ElseIf Feature.AbsoluteStart < Block.AbsoluteEnd And Feature.AbsoluteEnd > Block.AbsoluteEnd Then
            Intersection = (Block.AbsoluteEnd - Feature.AbsoluteStart + 1) / (Feature.AbsoluteEnd - Feature.AbsoluteStart + 1)
            If Intersection >= MinIntersect Then
                Result = True
            End If

        ElseIf Feature.AbsoluteStart < Block.AbsoluteStart And Feature.AbsoluteEnd > Block.AbsoluteEnd Then 'Block is within feature
            Intersection = (Block.AbsoluteEnd - Block.AbsoluteStart + 1) / (Feature.AbsoluteEnd - Feature.AbsoluteStart + 1)
            If Intersection >= MinIntersect Then
                Result = True
            End If

        End If



        Return Result
    End Function

    Public Shared Function GetTerminatorsEfficiency(ByVal Blocks As QuantBlockHolder, ByVal Annotation As List(Of Genome_Feature))

        SortCoverageBlocks(Blocks)

        Dim EfficiencyTable As New DataTable
        EfficiencyTable.Columns.Add("PreviousBlock")
        EfficiencyTable.Columns.Add("NextBlock")
        EfficiencyTable.Columns.Add("Direction")
        EfficiencyTable.Columns.Add("TerminatorEfficiency")
        EfficiencyTable.Columns.Add("TermStepSize")
        EfficiencyTable.Columns.Add("CDSInBlock")
        EfficiencyTable.Columns.Add("CDSID")
        EfficiencyTable.Columns.Add("TSSEfficiency")
        EfficiencyTable.Columns.Add("TSSStepSize")

        Dim Blocks_Plus As New List(Of QuantitationBlock)
        Dim Blocks_Minus As New List(Of QuantitationBlock)

        For Each Block As QuantitationBlock In Blocks.BlocksList
            Select Case Block.Direction
                Case 1
                    Blocks_Plus.Add(Block)
                Case 2
                    Blocks_Minus.Add(Block)
            End Select
        Next


        For i = 1 To Blocks_Plus.Count - 1
            If IsIntersectedFor(Blocks_Plus(i - 1), Blocks_Plus(i)) Then
                EfficiencyTable.Rows.Add(Blocks_Plus(i - 1).TAG, _
                                         Blocks_Plus(i).TAG, _
                                         1, _
                                         (Blocks_Plus(i - 1).Value - Blocks_Plus(i).Value) / Blocks_Plus(i - 1).Value, _
                                         Blocks_Plus(i - 1).Value / Blocks_Plus(i).Value, _
                                         CountCDSInBlock(Blocks_Plus(i), Annotation), _
                                         FindCDSInBlockToString(Blocks_Plus(i), Annotation), _
                                         (Blocks_Plus(i).Value - Blocks_Plus(i - 1).Value) / Blocks_Plus(i).Value, _
                                         Blocks_Plus(i).Value / Blocks_Plus(i - 1).Value)
            End If
        Next

        For i = Blocks_Minus.Count - 2 To 0 Step -1
            If IsIntersectedRev(Blocks_Minus(i + 1), Blocks_Minus(i)) Then
                EfficiencyTable.Rows.Add(Blocks_Minus(i + 1).TAG, _
                                         Blocks_Minus(i).TAG, _
                                         2, _
                                         (Blocks_Minus(i + 1).Value - Blocks_Minus(i).Value) / Blocks_Minus(i + 1).Value, _
                                         Blocks_Minus(i + 1).Value / Blocks_Minus(i).Value, _
                                         CountCDSInBlock(Blocks_Minus(i), Annotation), _
                                         FindCDSInBlockToString(Blocks_Minus(i), Annotation), _
                                         (Blocks_Minus(i).Value - Blocks_Minus(i + 1).Value) / Blocks_Minus(i).Value, _
                                         Blocks_Minus(i).Value / Blocks_Minus(i + 1).Value)
            End If
        Next

        Return EfficiencyTable
    End Function

    '\\Identification of terminator slippering
    Public Shared Function FindSlipperingIntervals(ByVal BlocksControl As List(Of QuantitationBlock), ByVal BlocksCase As List(Of QuantitationBlock), Optional ByVal MinDeltaCov As Single = 2, Optional ByVal IntersectionWindow As Integer = 10)

        Dim SlipperingBlocks As New List(Of QuantitationBlock)

        Dim Control_Blocks_Plus As New List(Of QuantitationBlock)
        Dim Control_Blocks_Minus As New List(Of QuantitationBlock)

        Dim Case_Blocks_Plus As New List(Of QuantitationBlock)
        Dim Case_Blocks_Minus As New List(Of QuantitationBlock)

        For i = 0 To BlocksControl.Count - 1

            Select Case BlocksControl(i).Direction
                Case 1
                    Control_Blocks_Plus.Add(BlocksControl(i))
                Case 2
                    Control_Blocks_Minus.Add(BlocksControl(i))
            End Select

            Select Case BlocksCase(i).Direction
                Case 1
                    Case_Blocks_Plus.Add(BlocksCase(i))
                Case 2
                    Case_Blocks_Minus.Add(BlocksCase(i))
            End Select

        Next

        SortCoverageBlocks(Control_Blocks_Plus)
        SortCoverageBlocks(Control_Blocks_Minus)
        SortCoverageBlocks(Case_Blocks_Plus)
        SortCoverageBlocks(Case_Blocks_Minus)


        ScanSlipperingFor(Control_Blocks_Plus, Case_Blocks_Plus, SlipperingBlocks, MinDeltaCov, IntersectionWindow)
        ScanSlipperingRev(Control_Blocks_Minus, Case_Blocks_Minus, SlipperingBlocks, MinDeltaCov, IntersectionWindow)


        Return SlipperingBlocks
    End Function

    Public Shared Sub ScanSlipperingFor(ByVal ControlBlocks As List(Of QuantitationBlock), ByVal CaseBlocks As List(Of QuantitationBlock), ByRef SlipperingBlocks As List(Of QuantitationBlock), Optional ByVal MinDeltaCov As Single = 2, Optional ByVal IntersectionWindow As Integer = 10)
        For i = 1 To ControlBlocks.Count - 1 'start from second block - first must have own promoter for sure

            If IsIntersectedFor(ControlBlocks(i - 1), ControlBlocks(i), IntersectionWindow) And _
            IsDownCS(ControlBlocks(i - 1), ControlBlocks(i), MinDeltaCov) And _
            Not IsUpCS(CaseBlocks(i - 1), CaseBlocks(i), MinDeltaCov) And _
            CaseBlocks(i).Value / ControlBlocks(i).Value >= MinDeltaCov Then

                'Blocks are next to each other in control
                'Blocks make down-CS in control, there is a terminator
                'Blocks do not make up-CS in case, otherwise there is an inducible promoter
                'REMOVED Previous block increases expression in case - CaseBlocks(i - 1).Value / ControlBlocks(i - 1).Value >= MinDeltaCov And _
                'Next block also increases expression in case
                SlipperingBlocks.Add(ControlBlocks(i))
            End If

        Next
    End Sub

    Public Shared Sub ScanSlipperingRev(ByVal ControlBlocks As List(Of QuantitationBlock), ByVal CaseBlocks As List(Of QuantitationBlock), ByRef SlipperingBlocks As List(Of QuantitationBlock), Optional ByVal MinDeltaCov As Single = 2, Optional ByVal IntersectionWindow As Integer = 10)
        For i = ControlBlocks.Count - 2 To 0 Step -1 'start from second block - first must have own promoter for sure

            If IsIntersectedRev(ControlBlocks(i + 1), ControlBlocks(i), IntersectionWindow) And _
            IsDownCS(ControlBlocks(i + 1), ControlBlocks(i), MinDeltaCov) And _
            Not IsUpCS(CaseBlocks(i + 1), CaseBlocks(i), MinDeltaCov) And _
            CaseBlocks(i).Value / ControlBlocks(i).Value >= MinDeltaCov Then



                SlipperingBlocks.Add(ControlBlocks(i))
            End If

        Next
    End Sub

    Public Shared Function IsIntersectedFor(ByVal Block_A As QuantitationBlock, ByVal Block_B As QuantitationBlock, Optional ByVal IntersectionWindow As Integer = 10)
        Dim Result As Boolean = False
        If Block_A.AbsoluteEnd + IntersectionWindow >= Block_B.AbsoluteStart Then
            Result = True
        End If
        Return Result
    End Function

    Public Shared Function IsIntersectedRev(ByVal Block_A As QuantitationBlock, ByVal Block_B As QuantitationBlock, Optional ByVal IntersectionWindow As Integer = 10)
        Dim Result As Boolean = False
        If Block_A.AbsoluteStart - IntersectionWindow <= Block_B.AbsoluteEnd Then
            Result = True
        End If
        Return Result
    End Function

    Public Shared Function IsDownCS(ByVal Block_A As QuantitationBlock, ByVal Block_B As QuantitationBlock, Optional ByVal MinDeltaCov As Single = 2)
        Dim Result As Boolean = False
        Dim CovFC As Single = Block_A.Value / Block_B.Value
        If CovFC >= MinDeltaCov Then
            Result = True
        End If
        Return Result
    End Function

    Public Shared Function IsUpCS(ByVal Block_A As QuantitationBlock, ByVal Block_B As QuantitationBlock, Optional ByVal MinDeltaCov As Single = 2)
        Dim Result As Boolean = False
        Dim CovFC As Single = Block_B.Value / Block_A.Value
        If CovFC >= MinDeltaCov Then
            Result = True
        End If
        Return Result
    End Function

    Public Shared Function SplitBlock(ByVal Block As QuantitationBlock, ByVal AbsoluteSplitPosition As Integer)
        Dim SplitBlocks(1) As QuantitationBlock

        If AbsoluteSplitPosition > Block.AbsoluteStart And AbsoluteSplitPosition < Block.AbsoluteEnd Then
            Dim Block_1 As New QuantitationBlock
            Block_1.Holder_Name = Block.Holder_Name
            Block_1.TAG = Block.TAG & "_split1"
            Block_1.AbsoluteStart = Block.AbsoluteStart
            Block_1.AbsoluteEnd = AbsoluteSplitPosition
            Block_1.Value = Block.Value
            Block_1.Direction = Block.Direction
            Block_1.Visible = True
            Block_1.Draw_Color = Block.Draw_Color

            Dim Block_2 As New QuantitationBlock
            Block_2.Holder_Name = Block.Holder_Name
            Block_2.TAG = Block.TAG & "_split2"
            Block_2.AbsoluteStart = AbsoluteSplitPosition + 1
            Block_2.AbsoluteEnd = Block.AbsoluteEnd
            Block_2.Value = Block.Value
            Block_2.Direction = Block.Direction
            Block_2.Visible = True
            Block_2.Draw_Color = Block.Draw_Color

            SplitBlocks(0) = Block_1
            SplitBlocks(1) = Block_2

        End If

        Return SplitBlocks
    End Function

    Public Shared Function MergeBlocks(ByVal Block_1 As QuantitationBlock, ByVal Block_2 As QuantitationBlock)
        If Block_1.Direction = Block_2.Direction Then
            Dim MergedBlock As New QuantitationBlock
            MergedBlock.Holder_Name = Block_1.Holder_Name
            MergedBlock.TAG = Block_1.TAG & " + " & Block_2.TAG
            MergedBlock.AbsoluteStart = Math.Min(Block_1.AbsoluteStart, Block_2.AbsoluteStart)
            MergedBlock.AbsoluteEnd = Math.Max(Block_1.AbsoluteEnd, Block_2.AbsoluteEnd)

            Dim Block_1_L As Single = Block_1.AbsoluteEnd - Block_1.AbsoluteStart + 1
            Dim Block_2_L As Single = Block_2.AbsoluteEnd - Block_2.AbsoluteStart + 1

            MergedBlock.Value = Block_1.Value * Block_1_L / (Block_1_L + Block_2_L) + Block_2.Value * Block_2_L / (Block_1_L + Block_2_L)
            MergedBlock.Direction = Block_1.Direction
            MergedBlock.Visible = True
            MergedBlock.Draw_Color = Block_1.Draw_Color

            Return MergedBlock
        Else
            Return Nothing
        End If

    End Function

    Public Shared Function NormalizeCoverageByCDS(ByVal Coverage As List(Of PositionalValuesHolder), _
                                             ByVal Annotation As List(Of Genome_Feature))



        Dim NormalizingSums As New List(Of Integer)

        Dim Groups As New List(Of String)
        Dim Found As Boolean = False

        For i = 0 To Coverage.Count - 1
            Found = False

            For Each Group As String In Groups
                If Coverage(i).Group = Group Then
                    Found = True
                    Exit For
                End If
            Next

            If Not Found Then
                Groups.Add(Coverage(i).Group)
            End If
        Next


        Dim CurrentSum As Integer = 0
        For Each Group As String In Groups

            CurrentSum = 0
            For Each Cov As PositionalValuesHolder In Coverage
                If Cov.Group = Group Then
                    For Each Feature As Genome_Feature In Annotation
                        If Feature.Type = 1 And Feature.Direction = Cov.Strand Then
                            CurrentSum += Bioinformatics.GetPileUpSum(Feature.AbsoluteStart - 1, Feature.AbsoluteEnd - 1, Cov.Positional_Values)
                        End If
                    Next
                End If
            Next

            NormalizingSums.Add(CurrentSum)

        Next

        Dim MaxSum As Integer = 0 'Find the largest library
        For Each Val As Integer In NormalizingSums
            If Val > MaxSum Then
                MaxSum = Val
            End If
        Next


        Dim ScaleFactors As New List(Of Single)
        For Each Sum As Integer In NormalizingSums
            ScaleFactors.Add(MaxSum / Sum)
        Next


        Dim NormalizedCoverage As New List(Of PositionalValuesHolder)

        Dim GroupCounter As Integer = 0
        Dim NormPos As Single = 0
        For Each Group As String In Groups
            For Each Cov As PositionalValuesHolder In Coverage
                If Cov.Group = Group Then
                    Dim NormCov As New PositionalValuesHolder(Cov.Holder_Name, Cov.Strand, New List(Of Integer), Cov.Draw_Color, 0)
                    For Each Pos As Integer In Cov.Positional_Values
                        NormPos = Pos * ScaleFactors(GroupCounter)
                        NormCov.Positional_Values.Add(NormPos)
                        NormCov.Log_Values.Add(NormPos)
                    Next
                    NormalizedCoverage.Add(NormCov)
                End If
            Next

            GroupCounter += 1
        Next Group


        Return NormalizedCoverage
    End Function

    Public Shared Function CreateAnnotationTable(ByVal Coverage As List(Of PositionalValuesHolder), _
                                                 ByVal Blocks As List(Of QuantitationBlock))

        Dim ResultTable As New DataTable
        ResultTable.Columns.Add("IntervalsPlus")
        ResultTable.Columns.Add("IntervalsMinus")

        For Each Cov As PositionalValuesHolder In Coverage
            ResultTable.Columns.Add(Cov.Holder_Name)
        Next



        Dim MaxPosIndex As Integer = Coverage(0).Positional_Values.Count - 1
        Dim CurrentIntervalPlusID As String = ""
        Dim CurrentIntervalMinusID As String = ""


        For PosIndex = 0 To MaxPosIndex 'Iterate through rows

            For Each Block As QuantitationBlock In Blocks 'Now find the block which corresponds to the particular position, find CurrentIntervalID
                If Block.Direction = 1 And PosIndex + 1 >= Block.AbsoluteStart And PosIndex + 1 <= Block.AbsoluteEnd Then 'Position is within block
                    CurrentIntervalPlusID = Block.TAG
                End If

                If Block.Direction = 2 And PosIndex + 1 >= Block.AbsoluteStart And PosIndex + 1 <= Block.AbsoluteEnd Then 'Position is within block
                    CurrentIntervalMinusID = Block.TAG
                End If
            Next Block

            ResultTable.Rows.Add(CurrentIntervalPlusID, CurrentIntervalMinusID) 'The row to be filled
            For HolderIndex = 0 To Coverage.Count - 1 'Iterate through columns
                ResultTable.Rows(ResultTable.Rows.Count - 1).Item(HolderIndex + 2) = Coverage(HolderIndex).Log_Values(PosIndex)
            Next HolderIndex
        Next PosIndex

        Return ResultTable
    End Function


    '\\\\\\\\\\\\\\\\\\\\\\\There is a set of functions for analysis of ERS libraries

    Public Shared Function GetIntRange(ByVal RangeStart As Integer, ByVal RangeEnd As Integer, ByVal PileUp As List(Of Integer))
        Dim Range As New List(Of Integer)

        Try
            For i = RangeStart To RangeEnd

                Range.Add(PileUp(i))

            Next
        Catch ex As Exception
            MsgBox("Feature out of range: " & RangeStart & "-" & RangeEnd & vbNewLine & ex.Message)
        End Try

        Return Range
    End Function

    Public Shared Function FindTSSinERS(ByVal Coverage As List(Of Integer), _
                                        Optional ByVal SearchWindow As Integer = 5, _
                                        Optional ByVal MinSignalToNoiseRatio As Single = 10, _
                                        Optional ByVal MinTSSCoverage As Single = 10, _
                                        Optional ByRef StatusLabel As Label = Nothing)

        Dim TSS_List As New List(Of Integer)

        If Not IsNothing(StatusLabel) Then
            StatusLabel.Text = "Analyzing coverage..."
            StatusLabel.Refresh()
        End If

        Dim LocalBackground As Single = 0
        Dim CurrentSignalToNoiseRatio As Single = 0

        For i = SearchWindow To Coverage.Count - SearchWindow
            If Coverage(i) >= MinTSSCoverage Then

                LocalBackground = 0

                'Collect coverage upstream
                For j = 0 To SearchWindow - 1
                    LocalBackground += Coverage(i - 1 - j)
                Next j


                'Collect coverage downstream
                For j = 0 To SearchWindow - 1
                    LocalBackground += Coverage(i + 1 + j)
                Next j

                If LocalBackground = 0 Then
                    LocalBackground = 1
                End If

                CurrentSignalToNoiseRatio = Coverage(i) / LocalBackground

                If CurrentSignalToNoiseRatio >= MinSignalToNoiseRatio Then

                    TSS_List.Add(i)

                End If


            End If 'Coverage(i) >= MinTSSCoverage


        Next i

        Return TSS_List

    End Function

    Public Shared Function AnalyzeERS(ByVal Coverage As List(Of Integer), _
                                                 Optional ByVal SearchWindow As Integer = 15, _
                                                 Optional ByVal ERS_Read_Length As Integer = 25, _
                                                 Optional ByVal TSS_DerivativeBackground As Integer = 10, _
                                                 Optional ByVal TSS_LocalMaxWindow As Integer = 20, _
                                                 Optional ByVal TSS_FiltrationWindow As Integer = 50, _
                                                 Optional ByVal TSS_Asymmetry As Boolean = True, _
                                                 Optional ByVal TSS_AsymmetryWindow As Integer = 50, _
                                                 Optional ByVal TSS_AsymmetryThreshold As Single = 0.7, _
                                                 Optional ByVal MinTSSCoverage As Single = 10, _
                                                 Optional ByVal TSS_StepCoverageFoldIncrease As Single = 50, _
                                                 Optional ByVal TSS_StepCoverageFoldDecrease As Single = 5, _
                                                 Optional ByVal MaxStepCoverageVariation As Single = 1, _
                                                 Optional ByRef StatusLabel As Label = Nothing)

        Dim Steps As New List(Of CoverageStep)

        If Not IsNothing(StatusLabel) Then
            StatusLabel.Text = "Preparing derivative..."
            StatusLabel.Refresh()
        End If

        'Get derivative in a small window
        Dim Derivative() As List(Of Integer) = Bioinformatics.GetCoverageDerivativeList(Coverage, SearchWindow)


        'Dim FS As New IO.FileStream("C:\Users\User\Documents\Транскриптомика\DeepSeq\Acholeplasma TSS\test-der.txt", IO.FileMode.Create)
        'Dim Writer As New IO.StreamWriter(FS)

        'For Each Int As Integer In Derivative(0)
        'Writer.WriteLine(Int)
        'Next Int

        'Writer.Close()
        'FS.Close()
        'Writer.Dispose()
        'FS.Dispose()



        If Not IsNothing(StatusLabel) Then
            StatusLabel.Text = "Analyzing coverage..."
            StatusLabel.Refresh()
        End If

        'Identify srong increases in coverage
        Dim TSS_position_list As List(Of CoverageStep) = Bioinformatics.FindPeaks(Derivative(0), True, TSS_DerivativeBackground, TSS_LocalMaxWindow, TSS_FiltrationWindow, TSS_Asymmetry, TSS_AsymmetryWindow, TSS_AsymmetryThreshold)


        'Now calculate coverage at +25, +50 and -25 regions
        Dim QuantSteps As New List(Of QuantitativeCoverageStep)

        For Each CovStep As CoverageStep In TSS_position_list
            Dim NewQStep As New QuantitativeCoverageStep
            NewQStep.Position = CovStep.Position
            NewQStep.Type = CovStep.Type
            NewQStep.CoverageInStep = GetPileUpSumPerLength(NewQStep.Position, NewQStep.Position + ERS_Read_Length - 1, Coverage)
            NewQStep.CoverageBeforeStep = GetPileUpSumPerLength(NewQStep.Position - ERS_Read_Length, NewQStep.Position, Coverage)
            NewQStep.CoverageAfterStep = GetPileUpSumPerLength(NewQStep.Position + ERS_Read_Length - 1, NewQStep.Position + ERS_Read_Length * 2 - 1, Coverage)
            NewQStep.StepCoverageVariation = Bioinformatics.StandartDeviation(GetIntRange(NewQStep.Position, NewQStep.Position + ERS_Read_Length - 1, Coverage)) / NewQStep.CoverageInStep
            QuantSteps.Add(NewQStep)
        Next CovStep

        If Not IsNothing(StatusLabel) Then
            StatusLabel.Text = "Steps before filtration..." & TSS_position_list.Count
            StatusLabel.Refresh()
        End If

        TSS_position_list.Clear()

        'Now filter steps
        Dim QFoldIncrease As Single = 0 'How sharp is coverage increase
        Dim QFoldDecrease As Single = 0 'How sharp is coverage decrease
        For Each QStep As QuantitativeCoverageStep In QuantSteps
            QFoldIncrease = QStep.CoverageInStep / QStep.CoverageBeforeStep
            QFoldDecrease = QStep.CoverageInStep / QStep.CoverageAfterStep

            If QStep.CoverageInStep >= MinTSSCoverage And _
                QFoldIncrease >= TSS_StepCoverageFoldIncrease And _
                QFoldDecrease >= TSS_StepCoverageFoldDecrease And _
                QStep.StepCoverageVariation <= MaxStepCoverageVariation Then
                Dim NewResultStep As New CoverageStep

                NewResultStep.Position = QStep.Position
                NewResultStep.Type = QStep.Type

                TSS_position_list.Add(NewResultStep)
            End If

        Next QStep

        If Not IsNothing(StatusLabel) Then
            StatusLabel.Text = "Steps after filtration..." & TSS_position_list.Count
            StatusLabel.Refresh()
        End If


        Steps.AddRange(TSS_position_list)

        Return Steps
    End Function


    '\\\\\\\\\\\\\\\\\\\\\\\

    Public Shared Function GetBestPeakEntry(ByVal CoverageData As PositionalValuesHolder, ByVal MinPos As Integer, ByVal MaxPos As Integer, ByVal BackgroundWindow As Integer)
        Dim Data(2) As Single
        '0 - Peak Pos
        '1 - Peak Height
        '2 - Peak Background

        Dim PeakHeight As New List(Of Single)
        Dim Background As New List(Of Single)
        Dim LocalBackground As Single = 0

        Try


            For i = MinPos To MaxPos

                PeakHeight.Add(CoverageData.Positional_Values(i))

                LocalBackground = 0
                For j = i - BackgroundWindow To i + BackgroundWindow
                    LocalBackground += CoverageData.Positional_Values(j)
                Next j

                LocalBackground /= BackgroundWindow * 2 + 1
                Background.Add(LocalBackground)

            Next i

            Dim Max As Single = 0
            Dim HighestPeakPos As Integer = 0
            For i = 0 To PeakHeight.Count - 1
                If PeakHeight(i) > Max Then
                    Max = PeakHeight(i)
                    HighestPeakPos = i
                End If
            Next i

            Data(0) = HighestPeakPos
            Data(1) = Max
            Data(2) = Background(HighestPeakPos)

        Catch ex As Exception

            Data(0) = -1
            Data(1) = -1
            Data(2) = -1
        End Try



        Return Data
    End Function

    Public Shared Function GetPromotersPowerDistribution(ByVal GenomeSequence As String, ByVal PromoterPWM As PWM, ByVal PWM_Threshold As Single, _
                                                         ByVal CoverageData As List(Of PositionalValuesHolder), _
                                                         Optional ByVal BackgroundWindow As Integer = 10, _
                                                         Optional ByVal MedianPeakDistance As Integer = 3, _
                                                         Optional ByVal PeakDistanceDev As Integer = 1)

        Dim WordList_For As New List(Of K_Word_Weighted)
        WordList_For = Bioinformatics.SearchMotifWithPWM(GenomeSequence, PromoterPWM)
        Dim WordList_Rev As New List(Of K_Word_Weighted)
        WordList_Rev = Bioinformatics.SearchMotifWithPWM(GenomeSequence, Bioinformatics.GetReverseComplementPWM(PromoterPWM))

        Dim For_Weight_Filtered_List As New List(Of K_Word_WW)
        Dim Rev_Weight_Filtered_List As New List(Of K_Word_WW)


        For Each Word As K_Word_Weighted In WordList_For
            If Word.Weight >= PWM_Threshold Then
                Dim NewWordWW As New K_Word_WW
                NewWordWW.Relative_Position = Word.Relative_Position
                NewWordWW.Word_Text = Word.Word_Text
                NewWordWW.Weight = Word.Weight

                For_Weight_Filtered_List.Add(NewWordWW)
            End If
        Next Word

        For Each Word As K_Word_Weighted In WordList_Rev
            If Word.Weight >= PWM_Threshold Then
                Dim NewWordWW As New K_Word_WW
                NewWordWW.Relative_Position = Word.Relative_Position
                NewWordWW.Word_Text = Word.Word_Text
                NewWordWW.Weight = Word.Weight

                Rev_Weight_Filtered_List.Add(NewWordWW)
            End If
        Next Word



        'Scan coverage data for peaks

        Dim PeakPos As Integer = 0
        Dim PeakHeight As Single = 0
        Dim PeakBackground As Single = 0

        Dim LocalData() As Single

        For Each Word As K_Word_WW In For_Weight_Filtered_List

            For Each Data As PositionalValuesHolder In CoverageData

                If Data.Strand = 1 Then

                    LocalData = GetBestPeakEntry(Data, Word.Relative_Position + Word.Word_Text.Length + MedianPeakDistance - PeakDistanceDev, _
                                                 Word.Relative_Position + Word.Word_Text.Length + MedianPeakDistance + PeakDistanceDev, BackgroundWindow)

                    Word.BestPos.Add(LocalData(0))
                    Word.PeakData.Add(LocalData(1))
                    Word.BackgroundData.Add(LocalData(2))

                End If

            Next Data


        Next Word

        For Each Word As K_Word_WW In Rev_Weight_Filtered_List

            For Each Data As PositionalValuesHolder In CoverageData

                If Data.Strand = 2 Then


                    LocalData = GetBestPeakEntry(Data, Word.Relative_Position - MedianPeakDistance - 1 - PeakDistanceDev, _
                                                 Word.Relative_Position - MedianPeakDistance - 1 + PeakDistanceDev, BackgroundWindow)

                    Word.BestPos.Add(LocalData(0))
                    Word.PeakData.Add(LocalData(1))
                    Word.BackgroundData.Add(LocalData(2))

                End If

            Next Data


        Next Word




        Dim NewResult As New PromoterPowerScanData
        NewResult.ForData = For_Weight_Filtered_List
        NewResult.RevData = Rev_Weight_Filtered_List

        Return NewResult
    End Function

    Public Shared Function GetCharCumulativeWeightForSeq(ByVal Seq As String, ByVal CharPWM As PWM)

        Dim Score As Single = 0

        Dim CharSeq As Char() = Seq.ToCharArray
        For Each LocalChar As Char In CharSeq
            Score += Bioinformatics.Calculate_Word_Weight(LocalChar.ToString, CharPWM)
        Next LocalChar

        Return Score
    End Function

    Public Shared Function SearchPromoters(ByVal Seq As String, _
                                           ByVal CoverageData As List(Of PositionalValuesHolder), _
                                           ByVal minus10_PWM As PWM, _
                                           ByVal minus10_Threshold As Single, _
                                           ByVal EXT_PWM As PWM, _
                                           ByVal EXT_Threshold As Single, _
                                           ByVal minus35_PWM As PWM, _
                                           ByVal minus35_Threshold As Single, _
                                           ByVal PromoterSurrounding As PWM, _
                                           ByVal Inter10_35SpacerLength As Integer, _
                                           ByVal Inter10_35SpacerDiv As Integer, _
                                           ByVal SpacerToInitiatorLength As Integer, _
                                           ByVal SpacerToInitiatorDiv As Integer, _
                                           ByVal ExtMinDistance As Integer, _
                                           ByVal EXT_Div As Integer, _
                                           Optional ByVal BackgroundWindow As Integer = 10)


        Dim minus10_L As Integer = minus10_PWM.PWM_Table.Count
        Dim minus35_L As Integer = minus35_PWM.PWM_Table.Count
        Dim extL As Integer = EXT_PWM.PWM_Table.Count

        'Identify core regions: -10 and -35


        Dim minus10_Data_For As New List(Of K_Word_Weighted)
        minus10_Data_For = Bioinformatics.SearchMotifWithPWM(Seq, minus10_PWM)
        Dim minus10_Data_Rev As New List(Of K_Word_Weighted)
        minus10_Data_Rev = Bioinformatics.SearchMotifWithPWM(Seq, Bioinformatics.GetReverseComplementPWM(minus10_PWM))
        Bioinformatics.GetReverseComplementPWM(minus10_PWM)

        'Dim minus35_Data_For As New List(Of K_Word_Weighted)
        'minus35_Data_For = Bioinformatics.SearchMotifWithPWM(Seq, minus35_PWM)
        'Dim minus35_Data_Rev As New List(Of K_Word_Weighted)
        'minus35_Data_Rev = Bioinformatics.SearchMotifWithPWM(Seq, Bioinformatics.GetReverseComplementPWM(minus35_PWM))
        ' Bioinformatics.GetReverseComplementPWM(minus35_PWM)



        'Analyze promoter power distribution

        Dim FilteredListFor As New List(Of PromoterAssembly)
        Dim FilteredListRev As New List(Of PromoterAssembly)

        Dim reg10_35dist As Integer = 0
        Dim minus35Collection As New List(Of K_Word_Weighted)
        Dim LocalScore As Single = 0
        Dim Current_minus35 As K_Word_Weighted = Nothing
        Dim Current_Ext As K_Word_Weighted = Nothing

        Dim ExtCollection As New List(Of K_Word_Weighted)

        Dim LocalData() As Single

        'For seq data



        'Since -10 is the primary determinant start from it
        For Each minus10 As K_Word_Weighted In minus10_Data_For
            If minus10.Relative_Position > 50 And minus10.Relative_Position < Seq.Length - 50 Then
                If minus10.Weight >= minus10_Threshold Then
                    minus10.Bool_TAG = True 'Already used within a promoter

                    Dim NewPromoter As New PromoterAssembly
                    NewPromoter.minus10 = minus10

                    'Search for respective -35

                    minus35Collection.Clear()

                    For i = Inter10_35SpacerLength - Inter10_35SpacerDiv To Inter10_35SpacerLength + Inter10_35SpacerDiv

                        Dim New_minus35 As New K_Word_Weighted
                        New_minus35.Relative_Position = NewPromoter.minus10.Relative_Position - minus35_L - i
                        New_minus35.Word_Text = Seq.Substring(New_minus35.Relative_Position, minus35_L)
                        New_minus35.Weight = Bioinformatics.Calculate_Word_Weight(New_minus35.Word_Text, minus35_PWM)
                        minus35Collection.Add(New_minus35)
                    Next i


                    'Get the strongest -35 within the range

                    LocalScore = minus35Collection(0).Weight
                    Current_minus35 = minus35Collection(0)

                    For Each Local_minus35 As K_Word_Weighted In minus35Collection
                        If Local_minus35.Weight > LocalScore Then
                            LocalScore = Local_minus35.Weight
                            Current_minus35 = Local_minus35
                        End If
                    Next Local_minus35

                    NewPromoter.minus35 = Current_minus35


                    'Now score the rest of the promoter


                    'Get and evaluate Ext sequence
                    ExtCollection.Clear()
                    For i = ExtMinDistance To EXT_Div

                        Dim NewExt As New K_Word_Weighted
                        NewExt.Relative_Position = NewPromoter.minus10.Relative_Position - extL - i
                        NewExt.Word_Text = Seq.Substring(NewExt.Relative_Position, extL)
                        NewExt.Weight = Bioinformatics.Calculate_Word_Weight(NewExt.Word_Text, EXT_PWM)
                        ExtCollection.Add(NewExt)
                    Next i

                    LocalScore = ExtCollection(0).Weight
                    Current_Ext = ExtCollection(0)
                    For Each Ext As K_Word_Weighted In ExtCollection
                        If Ext.Weight > LocalScore Then
                            LocalScore = Ext.Weight
                            Current_Ext = Ext
                        End If
                    Next Ext

                    NewPromoter.Extension = Current_Ext


                    'Evaluate region between -10 and -35
                    NewPromoter.minus10_To_minus35_SpacerWeight = GetCharCumulativeWeightForSeq(Seq.Substring(NewPromoter.minus10.Relative_Position - 17, 17), _
                                                                                                PromoterSurrounding)



                    'Evaluate region between -10 and TSS
                    NewPromoter.minus10_To_TSS_SpacerWeight = GetCharCumulativeWeightForSeq(Seq.Substring(NewPromoter.minus10.Relative_Position + minus10_L, 6), _
                                                                                               PromoterSurrounding)



                    'Go to sequence data and find TSS

                    For Each Data As PositionalValuesHolder In CoverageData

                        If Data.Strand = 1 Then

                            LocalData = GetBestPeakEntry(Data, NewPromoter.minus10.Relative_Position + minus10_L + SpacerToInitiatorLength - SpacerToInitiatorDiv, NewPromoter.minus10.Relative_Position + minus10_L + SpacerToInitiatorLength + SpacerToInitiatorDiv, 10)
                            NewPromoter.BestPos.Add(LocalData(0))
                            NewPromoter.PeakData.Add(LocalData(1))
                            NewPromoter.BackgroundData.Add(LocalData(2))
                            NewPromoter.Initiator.Add(Seq.Substring(NewPromoter.minus10.Relative_Position + minus10_L + SpacerToInitiatorLength - SpacerToInitiatorDiv + LocalData(0), 1))



                        End If

                    Next Data


                    NewPromoter.PromoterSequence = Seq.Substring(NewPromoter.minus10.Relative_Position - 25, 40)
                    FilteredListFor.Add(NewPromoter)
                End If
            End If
        Next minus10




        'Continue with -35-based promoters
        'For Each minus35 As K_Word_Weighted In minus35_Data_For
        'Next minus35


        '//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        'Rev seq data

        'Since -10 is the primary determinant start from it
        For Each minus10 As K_Word_Weighted In minus10_Data_Rev
            If minus10.Relative_Position > 50 And minus10.Relative_Position < Seq.Length - 50 Then

                If minus10.Weight >= minus10_Threshold Then
                    minus10.Bool_TAG = True 'Already used within a promoter

                    Dim NewPromoter As New PromoterAssembly
                    NewPromoter.minus10 = minus10
                    NewPromoter.minus10.Word_Text = Bioinformatics.GetReverseComplement(NewPromoter.minus10.Word_Text)

                    'Search for respective -35

                    minus35Collection.Clear()

                    For i = Inter10_35SpacerLength - Inter10_35SpacerDiv To Inter10_35SpacerLength + Inter10_35SpacerDiv

                        Dim New_minus35 As New K_Word_Weighted
                        New_minus35.Relative_Position = NewPromoter.minus10.Relative_Position + minus10_L + i
                        New_minus35.Word_Text = Bioinformatics.GetReverseComplement(Seq.Substring(New_minus35.Relative_Position, minus35_L))
                        New_minus35.Weight = Bioinformatics.Calculate_Word_Weight(New_minus35.Word_Text, minus35_PWM)
                        minus35Collection.Add(New_minus35)

                    Next i


                    'Get the strongest -35 within the range

                    LocalScore = minus35Collection(0).Weight
                    Current_minus35 = minus35Collection(0)

                    For Each Local_minus35 As K_Word_Weighted In minus35Collection
                        If Local_minus35.Weight > LocalScore Then
                            LocalScore = Local_minus35.Weight
                            Current_minus35 = Local_minus35
                        End If
                    Next Local_minus35

                    NewPromoter.minus35 = Current_minus35


                    'Now score the rest of the promoter


                    'Get and evaluate Ext sequence
                    ExtCollection.Clear()
                    For i = ExtMinDistance To EXT_Div

                        Dim NewExt As New K_Word_Weighted
                        NewExt.Relative_Position = NewPromoter.minus10.Relative_Position + minus10_L + i
                        NewExt.Word_Text = Bioinformatics.GetReverseComplement(Seq.Substring(NewExt.Relative_Position, extL))
                        NewExt.Weight = Bioinformatics.Calculate_Word_Weight(NewExt.Word_Text, EXT_PWM)
                        ExtCollection.Add(NewExt)
                    Next i

                    LocalScore = ExtCollection(0).Weight
                    Current_Ext = ExtCollection(0)
                    For Each Ext As K_Word_Weighted In ExtCollection
                        If Ext.Weight > LocalScore Then
                            LocalScore = Ext.Weight
                            Current_Ext = Ext
                        End If
                    Next Ext

                    NewPromoter.Extension = Current_Ext



                    'Evaluate region between -10 and -35
                    NewPromoter.minus10_To_minus35_SpacerWeight = GetCharCumulativeWeightForSeq(Bioinformatics.GetReverseComplement(Seq.Substring(NewPromoter.minus10.Relative_Position + minus10_L, 17)), _
                                                                                                PromoterSurrounding)




                    'Evaluate region between -10 and TSS
                    NewPromoter.minus10_To_TSS_SpacerWeight = GetCharCumulativeWeightForSeq(Bioinformatics.GetReverseComplement(Seq.Substring(NewPromoter.minus10.Relative_Position - 6, 6)), _
                                                                                               PromoterSurrounding)



                    'Go to sequence data and find TSS

                    For Each Data As PositionalValuesHolder In CoverageData

                        If Data.Strand = 2 Then

                            LocalData = GetBestPeakEntry(Data, NewPromoter.minus10.Relative_Position - (SpacerToInitiatorLength + SpacerToInitiatorDiv + 1), NewPromoter.minus10.Relative_Position - (SpacerToInitiatorLength - SpacerToInitiatorDiv + 1), 10)
                            NewPromoter.BestPos.Add(LocalData(0))
                            NewPromoter.PeakData.Add(LocalData(1))
                            NewPromoter.BackgroundData.Add(LocalData(2))
                            NewPromoter.Initiator.Add(Bioinformatics.GetReverseComplement(Seq.Substring(NewPromoter.minus10.Relative_Position - (SpacerToInitiatorLength + SpacerToInitiatorDiv + 1) + LocalData(0), 1)))



                        End If

                    Next Data


                    NewPromoter.PromoterSequence = Bioinformatics.GetReverseComplement(Seq.Substring(NewPromoter.minus10.Relative_Position - 9, 40))
                    FilteredListRev.Add(NewPromoter)
                End If
            End If
        Next minus10









        Dim Result As New List(Of List(Of PromoterAssembly))
        Result.Add(FilteredListFor)
        Result.Add(FilteredListRev)

        Return Result
    End Function


    '\\\\\\\\\\\\\\\\\\\\\\\ New normalization methods
    Public Shared Function NormalizeCoverage(ByVal Data As List(Of PositionalValuesHolder))
        Dim NormalizedCoverage As New List(Of PositionalValuesHolder)

        Dim GeometricAverageData As New List(Of Single)

        Dim MaxPos As Integer = Data(0).Positional_Values.Count - 1
        Dim MaxCov As Integer = Data.Count - 1

        Dim GeomAv As Single = 1


        For Pos = 0 To MaxPos

            GeomAv = 1
            For Each Cov As PositionalValuesHolder In Data
                GeomAv *= Cov.Positional_Values(Pos)
            Next Cov
            GeomAv = GeomAv ^ (1 / Data.Count)

            GeometricAverageData.Add(GeomAv)



        Next Pos




        Dim IntermediateData(MaxCov) As List(Of Single)

        For CovIndex = 0 To MaxCov

            Dim NewIntermediateList As New List(Of Single)


            For Pos = 0 To MaxPos

                If GeometricAverageData(Pos) <> 0 Then

                    NewIntermediateList.Add(Data(CovIndex).Positional_Values(Pos) / GeometricAverageData(Pos))

                Else

                    NewIntermediateList.Add(0)

                End If


            Next Pos

            IntermediateData(CovIndex) = NewIntermediateList

        Next CovIndex


        Dim MedianK(MaxCov) As Single

        For CovIndex = 0 To MaxCov
            MedianK(CovIndex) = Median(IntermediateData(CovIndex), True)



            Dim NewNormValues As New List(Of Integer)

            For Pos = 0 To MaxPos
                NewNormValues.Add(Data(CovIndex).Positional_Values(Pos) / MedianK(CovIndex))
            Next Pos


            Dim NewNormalizedCoverage As New PositionalValuesHolder(Data(CovIndex).Holder_Name & "-Normalized", Data(CovIndex).Strand, NewNormValues, Color.Black, Data(CovIndex).Scale)
            NewNormalizedCoverage.Group = "Normalized"

            NormalizedCoverage.Add(NewNormalizedCoverage)

        Next CovIndex




        Return NormalizedCoverage
    End Function

#End Region

#Region "Batch calculator"

    Public Shared Sub CalculateSeqFunctions(ByVal InputFile As String, Optional ByVal T As Single = 37, Optional ByVal CalculateSelfAnnealing As Boolean = True)

        Dim RS As New IO.FileStream(InputFile, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(RS)

        Dim FilePathArr As String() = InputFile.Split("\")
        Dim AnalysisName As String = FilePathArr(FilePathArr.GetUpperBound(0)).Split(".")(0)
        Dim FileDir As String = ""
        For i = 0 To FilePathArr.GetUpperBound(0) - 1
            FileDir &= FilePathArr(i) & "\"
        Next

        Dim FileName As String = FileDir & AnalysisName & "-thermodynamics.txt"

        Dim WS As New IO.FileStream(FileName, IO.FileMode.Create)
        Dim Writer As New IO.StreamWriter(WS)

        Dim CurrentLine As String = ""
        Dim CurrentGC As Single = 0
        Dim CurrentDG As Single = 0
        Dim CurrentTm As Single = 0

        Writer.WriteLine("Name" & Chr(9) & "Seq" & Chr(9) & "%GC" & Chr(9) & "dG" & Chr(9) & "self-complimentarity dG" & Chr(9) & "Tm")
        Dim AlignList As New List(Of OligoAlignment)
        Dim MinHairpinDG As Single = 0

        Dim Name As String = ""
        Dim Seq As String = ""


        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            Name = CurrentLine.Split(Chr(9))(0)
            Seq = CurrentLine.Split(Chr(9))(1)

            CurrentGC = CalculateCGContent(Seq)
            CurrentDG = CalculateOligoDG(Seq, T)
            CurrentTm = CalculateOligoTm(Seq, 200, 20, 0, 0) '200, 20, 0, 
            If CalculateSelfAnnealing Then
                AlignList.Clear()
                AlignList = Bioinformatics.CreateHairpinList(Seq, T, , True, )
                MinHairpinDG = 0
                For Each Alignment As OligoAlignment In AlignList
                    If Alignment.SumDG < MinHairpinDG Then
                        MinHairpinDG = Alignment.SumDG
                    End If
                Next
            End If

            Writer.WriteLine(Name & Chr(9) & Seq & Chr(9) & CurrentGC & Chr(9) & CurrentDG & Chr(9) & MinHairpinDG & Chr(9) & CurrentTm)
        End While


        Reader.Close()
        RS.Close()
        Reader.Dispose()
        RS.Dispose()
        Writer.Close()
        WS.Close()
        Writer.Dispose()
        WS.Dispose()

        MsgBox("File has been created: " & vbNewLine & FileName)

    End Sub

    Public Shared Sub BatchCalculateOligoC(ByVal InputFile As String)
        Dim RS As New IO.FileStream(InputFile, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(RS)

        Dim FilePathArr As String() = InputFile.Split("\")
        Dim AnalysisName As String = FilePathArr(FilePathArr.GetUpperBound(0)).Split(".")(0)
        Dim FileDir As String = ""
        For i = 0 To FilePathArr.GetUpperBound(0) - 1
            FileDir &= FilePathArr(i) & "\"
        Next

        Dim FileName As String = FileDir & AnalysisName & "-concentration.txt"

        Dim WS As New IO.FileStream(FileName, IO.FileMode.Create)
        Dim Writer As New IO.StreamWriter(WS)

        Dim CurrentLine As String = ""
        Dim CurrentC As Single = 0

        Dim Seq As String = ""
        Dim OD As String = ""
        Dim Name As String = ""

        Writer.WriteLine("Name" & Chr(9) & "Seq" & Chr(9) & "Concentration (pmol/mcL)")

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            Name = CurrentLine.Split(Chr(9))(0)
            Seq = CurrentLine.Split(Chr(9))(1)
            OD = CurrentLine.Split(Chr(9))(2)
            CurrentC = Bioinformatics.CalculateOligoC(Seq.ToCharArray, OD, 0)
            Writer.WriteLine(Name & Chr(9) & Seq & Chr(9) & CurrentC)
        End While

        Reader.Close()
        RS.Close()
        Reader.Dispose()
        RS.Dispose()
        Writer.Close()
        WS.Close()
        Writer.Dispose()
        WS.Dispose()

        MsgBox("File has been created: " & vbNewLine & FileName)

    End Sub

    Public Shared Sub CalculateBatchPWM(ByVal InputFile As String, ByVal PWMFile As String)

        Dim MyPWM As New PWM
        MyPWM = DataIO.LoadPWM(PWMFile)

        Dim RS As New IO.FileStream(InputFile, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(RS)

        Dim FilePathArr As String() = InputFile.Split("\")
        Dim AnalysisName As String = FilePathArr(FilePathArr.GetUpperBound(0)).Split(".")(0)
        Dim FileDir As String = ""
        For i = 0 To FilePathArr.GetUpperBound(0) - 1
            FileDir &= FilePathArr(i) & "\"
        Next

        Dim FileName As String = FileDir & AnalysisName & "-weight.txt"

        Dim WS As New IO.FileStream(FileName, IO.FileMode.Create)
        Dim Writer As New IO.StreamWriter(WS)

        Dim CurrentLine As String = ""
        Dim CurentWeight As Single = 0

        Writer.WriteLine("Seq" & Chr(9) & "Weight")

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            CurentWeight = CalculateWeight(CurrentLine, MyPWM)
            Writer.WriteLine(CurrentLine & Chr(9) & CurentWeight)
        End While


        Reader.Close()
        RS.Close()
        Reader.Dispose()
        RS.Dispose()
        Writer.Close()
        WS.Close()
        Writer.Dispose()
        WS.Dispose()

        MsgBox("File has been created: " & vbNewLine & FileName)

    End Sub

    Public Shared Sub CalculateProteinProperties(ByVal InputFile As String, ByVal MWlist As DataTable, ByVal PIlist As DataTable, ByVal Hlist As DataTable)
        Dim RS As New IO.FileStream(InputFile, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(RS)

        Dim FilePathArr As String() = InputFile.Split("\")
        Dim AnalysisName As String = FilePathArr(FilePathArr.GetUpperBound(0)).Split(".")(0)
        Dim FileDir As String = ""
        For i = 0 To FilePathArr.GetUpperBound(0) - 1
            FileDir &= FilePathArr(i) & "\"
        Next

        Dim FileName As String = FileDir & AnalysisName & "-thermodynamics.txt"


        Dim WS As New IO.FileStream(FileName, IO.FileMode.Create)
        Dim Writer As New IO.StreamWriter(WS)

        Dim Name As String = ""
        Dim Seq As String = ""

        Dim CurrentLine As String = ""
        Dim CurrentMW As Single = 0
        Dim CurrentpI As Single = 0
        Dim CurrentH As Single = 0

        Writer.WriteLine("Name" & Chr(9) & "Seq" & Chr(9) & "MW" & Chr(9) & "pI" & Chr(9) & "Hydrophobicity")

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine

            Name = CurrentLine.Split(Chr(9))(0)
            Seq = CurrentLine.Split(Chr(9))(1)

            CurrentMW = Calculate_Prot_Mass(Seq, MWlist)
            CurrentpI = Calculate_Prot_pI(Seq, PIlist)
            CurrentH = Calculate_Prot_Hydrophobisity(Seq, Hlist)
            Writer.WriteLine(Name & Chr(9) & Seq & Chr(9) & CurrentMW & Chr(9) & CurrentpI & Chr(9) & CurrentH)
        End While

        Reader.Close()
        RS.Close()
        Reader.Dispose()
        RS.Dispose()
        Writer.Close()
        WS.Close()
        Writer.Dispose()
        WS.Dispose()

        MsgBox("File has been created: " & vbNewLine & FileName)

    End Sub

#End Region

#Region "Reads mapping"

    Public Shared Function ReadFASTQtoString(ByVal SourceFile As String)
        Dim Seq As New List(Of String)
        Dim ReadStream As New IO.FileStream(SourceFile, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(ReadStream)

        Dim CurrentLine As String = ""
        Dim PrimeRead As Boolean = False

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine

            If PrimeRead Then
                If Not CurrentLine.StartsWith("@") Then
                    Seq.Add(CurrentLine)
                End If
                PrimeRead = False
            End If

            If CurrentLine.StartsWith("@") Then
                PrimeRead = True
            End If

        End While


        Reader.Close()
        ReadStream.Close()
        Reader.Dispose()
        ReadStream.Dispose()

        Return Seq
    End Function

    Public Shared Function CutAdapterUngapped(ByVal SeqList As List(Of String), ByVal AdapterSeq As String, _
                                      ByVal AdapterIdentityCutoff As Single, Optional ByVal EnablePolyTail As Boolean = False, _
                                      Optional ByVal PolyN As String = "N", Optional ByVal MaxDropoff As Integer = 2, Optional ByVal MinCutLength As Integer = 25)


        Dim CutSeq As New List(Of String)
        Dim counter As Integer = 0
        Dim CurrentCutSeq As String = ""


        For Each Seq As String In SeqList
            Dim AdapterCoordList As List(Of CoordHit) = Bioinformatics.UngappedSequenceSearch(Seq, AdapterSeq, AdapterIdentityCutoff)

            If AdapterCoordList.Count > 0 Then
                Dim BestPos As CoordHit = AdapterCoordList(0)
                For Each AdapterPosition As CoordHit In AdapterCoordList
                    If AdapterPosition.Identity > BestPos.Identity Then
                        BestPos = AdapterPosition
                    End If
                Next

                Dim BestPosEnd As Integer = BestPos.Position + AdapterSeq.Length - 1 'First N after adapter`s tail

                If Not BestPosEnd >= Seq.Length - 1 Then

                    If EnablePolyTail Then
                        Dim CurrentN As String = ""
                        Dim CurrentDropOff As Integer = MaxDropoff
                        Dim PolyCut As Integer = 0

                        For PolyCut = BestPosEnd To Seq.Length - 1
                            CurrentN = Seq.Substring(PolyCut, 1)

                            If CurrentN = PolyN And CurrentDropOff < MaxDropoff Then
                                CurrentDropOff += 1
                            End If

                            If Not CurrentN = PolyN Then
                                CurrentDropOff -= 1
                            End If

                            If CurrentDropOff = 0 Then
                                Exit For
                            End If

                        Next
                        BestPosEnd = PolyCut - 1

                    End If

                    CurrentCutSeq = Seq.Substring(BestPosEnd)
                    If CurrentCutSeq.Length >= MinCutLength Then
                        CutSeq.Add(CurrentCutSeq)
                    End If


                End If

            End If

            counter += 1
        Next


        Return CutSeq
    End Function


    Public Shared Function CutAdapterGapped(ByVal SeqList As List(Of String), ByVal AdapterSeq As String, _
                                            Optional ByVal MinSeqLenght As Integer = 25, _
                                            Optional ByVal MaxMismatches As Integer = 2, _
                                            Optional ByVal MaxGaps As Integer = 2, _
                                            Optional ByVal MatchBonus As Integer = 2, _
                                            Optional ByVal MismatchPenalty As Integer = -1, _
                                            Optional ByVal GapPenalty As Integer = -2, _
                                            Optional ByVal TrimPoly As Boolean = False, _
                                            Optional ByVal PolyChar As Char = "", _
                                            Optional ByVal MaxPolyDropoff As Integer = 2, _
                                            Optional ByVal MiniProgressBar As ToolStripProgressBar = Nothing)

        Dim CutSeq As New List(Of String)
        Dim CurrentSeq As String = ""

        If Not IsNothing(MiniProgressBar) Then
            MiniProgressBar.Value = 0
            MiniProgressBar.Maximum = SeqList.Count + 1
        End If



        For Each Seq As String In SeqList
            CurrentSeq = SW_adapter_cut(Seq, AdapterSeq, MatchBonus, MismatchPenalty, GapPenalty, MaxMismatches, MaxGaps)

            If CurrentSeq.Length > 0 Then

                If TrimPoly Then
                    CurrentSeq = TrimChars(CurrentSeq, PolyChar, MaxPolyDropoff, False)
                End If

                If CurrentSeq.Length >= MinSeqLenght Then
                    CutSeq.Add(CurrentSeq)
                End If

            End If

            If Not IsNothing(MiniProgressBar) Then
                MiniProgressBar.Value += 1
            End If


        Next

        If Not IsNothing(MiniProgressBar) Then
            MiniProgressBar.Value = 0
        End If


        Return CutSeq
    End Function


#End Region

#Region "Array design"
    Public Shared Function CalculateWordsDistance(ByVal Word_1 As K_Word_Thermodynamics, _
                                                 ByVal Word_2 As K_Word_Thermodynamics)

        Return _
        Math.Max(Word_1.Relative_Position, Word_2.Relative_Position) - _
        Math.Min(Word_1.Relative_Position, Word_2.Relative_Position) - _
        Word_1.Word_Text.Length

    End Function

    Public Shared Function CreateProbesForSeq(ByVal Seq As String, _
                                              ByVal ProbeLength As Integer, _
                                              ByVal ProbeDG As Single, _
                                              ByVal ProbeDGSpan As Single, _
                                              ByVal MinSelfDG As Single, _
                                              Optional ByVal T As Single = 37, _
                                              Optional ByVal MaxProbes As Integer = 0, _
                                              Optional ByVal SeqName As String = "")

        Dim ReportString As String = ""

        Dim ProbesList As New List(Of K_Word_Thermodynamics)
        Dim WordList As New List(Of K_Word_Thermodynamics)
        Dim AlignList As New List(Of OligoAlignment)
        Dim MinHairpinDG As Single

        Dim MinDG As Single = ProbeDG - ProbeDGSpan
        Dim MaxDG As Single = ProbeDG + ProbeDGSpan

        For i = 0 To Seq.Length - ProbeLength
            Dim KWord As New K_Word_Thermodynamics
            KWord.SeqName = SeqName
            KWord.Relative_Position = i
            KWord.Word_Text = Seq.Substring(i, ProbeLength)
            KWord.DG = Bioinformatics.CalculateOligoDG(KWord.Word_Text, T)

            AlignList.Clear()
            AlignList = Bioinformatics.CreateHairpinList(KWord.Word_Text, T, , True, )
            MinHairpinDG = 0
            For Each Alignment As OligoAlignment In AlignList
                If Alignment.SumDG < MinHairpinDG Then
                    MinHairpinDG = Alignment.SumDG
                End If
            Next
            KWord.SelfDG = MinHairpinDG


            If KWord.DG >= MinDG And KWord.DG <= MaxDG And KWord.SelfDG >= MinSelfDG Then '

                WordList.Add(KWord)
            End If

        Next i

        If WordList.Count < 2 Then
            Return ProbesList
            Exit Function
        End If

        'Find two words that are the most distant (minimmal and maximal positions)
        'Use this words to establish coordinates and iteratively look for the most spread configuration
        Dim FirstWord As K_Word_Thermodynamics = WordList(0)
        Dim LastWord As K_Word_Thermodynamics = WordList(WordList.Count - 1)

        FirstWord.IsBlocked = True
        LastWord.IsBlocked = True

        ProbesList.Add(FirstWord)
        ProbesList.Add(LastWord)

        Dim Counter As Integer = 2

        Dim Max As Integer = 0
        If MaxProbes = 0 Then
            Max = WordList.Count
        Else
            If MaxProbes < WordList.Count Then
                Max = MaxProbes
            Else
                Max = WordList.Count
            End If
        End If

        Dim MaxLocalDistance As Integer = 0
        Dim MinLocalDistance As Integer = 0
        Dim LocalDistance As Integer = 0
        Dim LocalBestWord As K_Word_Thermodynamics = Nothing
        Dim MaxPossibleDistance As Integer = LastWord.Relative_Position - FirstWord.Relative_Position - ProbeLength

        Do

            For Each Word As K_Word_Thermodynamics In WordList 'Iterate trough words and find the dost distant from reference words
                If Not Word.IsBlocked Then 'For words that are not in probes list
                    MinLocalDistance = MaxPossibleDistance  'Maximal distance
                    For Each QWord As K_Word_Thermodynamics In WordList
                        If QWord.IsBlocked Then 'Search vs reference words, which are in the probes list
                            LocalDistance = CalculateWordsDistance(Word, QWord)
                            If LocalDistance < MinLocalDistance Then
                                MinLocalDistance = LocalDistance
                            End If
                        End If
                    Next QWord
                    Word.Overlap = MinLocalDistance
                End If
            Next Word



            'Find the least overlapping word
            MaxLocalDistance = -ProbeLength 'minimal distance
            For Each Word As K_Word_Thermodynamics In WordList
                If Not Word.IsBlocked Then
                    If Word.Overlap > MaxLocalDistance Then
                        MaxLocalDistance = Word.Overlap
                        LocalBestWord = Word
                    End If
                End If
            Next

            LocalBestWord.IsBlocked = True
            ProbesList.Add(LocalBestWord)

            Counter += 1
            If Counter = Max Then
                Exit Do
            End If
        Loop


        'For Each Word As K_Word_Thermodynamics In ProbesList
        'ReportString &= Word.Word_Text & Chr(9) & Word.DG & Chr(9) & Word.SelfDG & Chr(9) & Word.Relative_Position & Chr(9) & Word.IsBlocked & vbNewLine
        'Next Word
        'ReportString &= vbNewLine
        'Clipboard.SetText(ReportString)

        Return ProbesList
    End Function

    Public Shared Sub FindProbesForGenome(ByVal Seq As String, _
                                               ByVal Annotation As List(Of Genome_Feature), _
                                               ByVal ProbeLength As Integer, _
                                               ByVal ProbeDG As Single, _
                                               ByVal ProbeDGSpan As Single, _
                                               ByVal MinSelfDG As Single, _
                                               Optional ByVal FindXhyb As Boolean = False, _
                                               Optional ByVal XHyb As Single = 0.8, _
                                               Optional ByVal FinalProbesCount As Integer = 4, _
                                               Optional ByVal SearchProbesCount As Integer = 0, _
                                               Optional ByVal MinFeatureLength As Integer = 100, _
                                               Optional ByVal T As Single = 37, _
                                               Optional ByVal CDS_only As Boolean = True, _
                                               Optional ByVal ReportLabel As Label = Nothing)


        'Dim ProbesList As New List(Of K_Word_Thermodynamics)

        If Not IsNothing(ReportLabel) Then
            ReportLabel.Text = "Started"
            ReportLabel.Refresh()
        End If

        If Master.SaveFileDialog.ShowDialog = DialogResult.OK Then
            Dim ReportWS As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.OpenOrCreate)
            Dim ReportWriter As New IO.StreamWriter(ReportWS)

            Dim LocalProbesList As New List(Of K_Word_Thermodynamics)
            Dim ProbesAllowed As Boolean = False
            Dim FeatureLength As Integer = 0
            Dim FeatureSequence As String = ""
            Dim XhybeList As List(Of Integer) = Nothing
            Dim Counter As Integer = 0

            Dim C As Integer = 1

            Dim ReportString As String = ""
            Dim ErrorReportString As String = ""

            For Each Feature As Genome_Feature In Annotation
                Try

                    ProbesAllowed = False
                    FeatureLength = Feature.AbsoluteEnd - Feature.AbsoluteStart + 1
                    If FeatureLength >= MinFeatureLength Then
                        If CDS_only Then
                            If Feature.Type = 1 Or Feature.Type = 4 Then
                                ProbesAllowed = True
                            End If
                        Else
                            ProbesAllowed = True
                        End If
                    End If

                    If ProbesAllowed Then
                        If Feature.Direction = 1 Then
                            FeatureSequence = DataIO.RetrieveSeqFromCache(Seq, Feature.AbsoluteStart, Feature.AbsoluteEnd)
                        ElseIf Feature.Direction = 2 Then
                            FeatureSequence = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(Seq, Feature.AbsoluteStart, Feature.AbsoluteEnd))
                        Else
                            FeatureSequence = DataIO.RetrieveSeqFromCache(Seq, Feature.AbsoluteStart, Feature.AbsoluteEnd)
                        End If

                        LocalProbesList.Clear()
                        LocalProbesList = Bioinformatics.CreateProbesForSeq(FeatureSequence, ProbeLength, ProbeDG, ProbeDGSpan, MinSelfDG, T, SearchProbesCount, Feature.TAG)


                        If FindXhyb Then


                            'Look for cross-hybridization vs genome
                            Counter = 0
                            For Each Probe As K_Word_Thermodynamics In LocalProbesList
                                XhybeList = FindXhybe(Seq, Probe.Word_Text, XHyb)

                                If XhybeList.Count = 1 Then
                                    'Add to final list
                                    'ProbesList.Add(Probe)
                                    Counter += 1
                                    ReportString = Probe.SeqName & Chr(9) & Probe.Word_Text
                                Else
                                    ReportString = Probe.SeqName & Chr(9) & Probe.Word_Text & Chr(9) & "Xhybe" & Chr(9) & XhybeList.Count
                                End If

                                ReportWriter.WriteLine(ReportString)

                                If Counter >= FinalProbesCount Then
                                    Exit For
                                End If

                            Next Probe

                        Else
                            For Each Probe As K_Word_Thermodynamics In LocalProbesList
                                ReportString = Probe.SeqName & Chr(9) & Probe.Word_Text
                                ReportWriter.WriteLine(ReportString)
                            Next Probe
                        End If

                    End If

                Catch ex As Exception
                    ' MsgBox(ex.Message, , Feature.TAG)
                    ErrorReportString &= Feature.TAG & Chr(9) & ex.Message & vbNewLine

                End Try

                If Not IsNothing(ReportLabel) Then
                    ReportLabel.Text = "Features: " & C & "/" & Annotation.Count
                    ReportLabel.Refresh()
                End If

                C += 1
            Next Feature

            If Not ErrorReportString = "" Then
                MsgBox(ErrorReportString)
            End If

            ReportWriter.Close()
            ReportWS.Close()
            ReportWriter.Dispose()
            ReportWS.Dispose()
        End If

        If Not IsNothing(ReportLabel) Then
            ReportLabel.Text = "Ready"
            ReportLabel.Refresh()
        End If

        ' Return ProbesList
    End Sub

    Public Shared Function FindProbesForGene(ByVal Seq As String, _
                                               ByVal Annotation As List(Of Genome_Feature), _
                                               ByVal Gene_ID As String, _
                                               ByVal ProbeLength As Integer, _
                                               ByVal ProbeDG As Single, _
                                               ByVal ProbeDGSpan As Single, _
                                               ByVal MinSelfDG As Single, _
                                               Optional ByVal XHyb As Single = 0.8, _
                                               Optional ByVal FinalProbesCount As Integer = 4, _
                                               Optional ByVal SearchProbesCount As Integer = 0, _
                                               Optional ByVal MinFeatureLength As Integer = 100, _
                                               Optional ByVal T As Single = 37)

        Dim ProbesList As New List(Of K_Word_Thermodynamics)

        If Master.SaveFileDialog.ShowDialog = DialogResult.OK Then
            Try


                Dim ReportWS As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.OpenOrCreate)
                Dim ReportWriter As New IO.StreamWriter(ReportWS)
                Dim LocalProbesList As New List(Of K_Word_Thermodynamics)
                Dim FeatureSequence As String = ""
                Dim XhybeList As List(Of Integer) = Nothing
                Dim Counter As Integer = 0
                Dim ReportString As String = ""

                For Each Feature As Genome_Feature In Annotation
                    If Feature.TAG = Gene_ID Then
                        If Feature.Direction = 1 Then
                            FeatureSequence = DataIO.RetrieveSeqFromCache(Seq, Feature.AbsoluteStart, Feature.AbsoluteEnd)
                        ElseIf Feature.Direction = 2 Then
                            FeatureSequence = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(Seq, Feature.AbsoluteStart, Feature.AbsoluteEnd))
                        Else
                            FeatureSequence = DataIO.RetrieveSeqFromCache(Seq, Feature.AbsoluteStart, Feature.AbsoluteEnd)
                        End If
                        LocalProbesList = Bioinformatics.CreateProbesForSeq(FeatureSequence, ProbeLength, ProbeDG, ProbeDGSpan, MinSelfDG, T, SearchProbesCount, Feature.TAG)

                        Counter = 0
                        For Each Probe As K_Word_Thermodynamics In LocalProbesList
                            XhybeList = FindXhybe(Seq, Probe.Word_Text, XHyb)

                            If XhybeList.Count = 1 Then
                                'Add to final list
                                ProbesList.Add(Probe)
                                Counter += 1
                                ReportString = Probe.SeqName & Chr(9) & Probe.Word_Text
                            Else
                                ReportString = Probe.SeqName & Chr(9) & Probe.Word_Text & Chr(9) & "Xhybe" & Chr(9) & XhybeList.Count
                            End If

                            ReportWriter.WriteLine(ReportString)

                            If Counter >= FinalProbesCount Then
                                Exit For
                            End If

                        Next Probe

                    End If
                Next


                ReportWriter.Close()
                ReportWS.Close()
                ReportWriter.Dispose()
                ReportWS.Dispose()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If

        Return ProbesList
    End Function

    Public Shared Function FindXhybe(ByVal Seq As String, ByVal Probe As String, ByVal Identity As Single)
        Dim CurrentSeq As String = ""
        Dim Result As New List(Of Integer)
        Dim Hits As Integer = 0
        Dim RevC_Probe As String = Bioinformatics.GetReverseComplement(Probe)

        For i = 0 To Seq.Length - Probe.Length
            CurrentSeq = Seq.Substring(i, Probe.Length)
            Hits = 0

            For j = 0 To Probe.Length - 1
                If CurrentSeq(j) = Probe(j) Then
                    Hits += 1
                End If
            Next

            If Hits / Probe.Length >= Identity Then
                Result.Add(i + 1)
            End If
        Next

        For i = 0 To Seq.Length - Probe.Length
            CurrentSeq = Seq.Substring(i, Probe.Length)
            Hits = 0

            For j = 0 To Probe.Length - 1
                If CurrentSeq(j) = RevC_Probe(j) Then
                    Hits += 1
                End If
            Next

            If Hits / Probe.Length >= Identity Then
                Result.Add(i + 1)
            End If
        Next

        Return Result
    End Function

    Public Shared Function DesignProbesForSNPList(ByVal Seq As String, ByVal SNP_List As List(Of Integer), ByVal SNP_ID_List As List(Of String), Optional ByVal Optimal_dG As Single = -28, Optional ByVal dG_Dev As Single = 1, Optional ByVal MinSpreadL As Integer = 10, Optional ByVal MaxSpreadL As Integer = 17, Optional ByVal T As Single = 37, Optional ByVal Make_Reverse_Complement As Boolean = False, Optional ByVal dG_Recursion_Count As Integer = 3, Optional ByVal EqualizeProbesDG As Boolean = False)
        Dim ProbesList As New List(Of ProbesBundle)
        Dim CurrentBundle As ProbesBundle = Nothing
        Dim ReportMessage As String = ""
        Dim ErrorCounter As Integer = 0

        For i = 0 To SNP_List.Count - 1
            CurrentBundle = Nothing

            For j = 1 To dG_Recursion_Count
                CurrentBundle = Design4ProbesPerSNP(Seq, SNP_List(i), Optimal_dG, dG_Dev * j, MinSpreadL, MaxSpreadL, T, Make_Reverse_Complement, EqualizeProbesDG)
                If Not IsNothing(CurrentBundle) Then
                    CurrentBundle.SNP_ID = SNP_ID_List(i)
                    ProbesList.Add(CurrentBundle)
                    Exit For
                End If
            Next j

            If IsNothing(CurrentBundle) Then
                ReportMessage &= SNP_List(i) & vbNewLine
                ErrorCounter += 1
            End If

        Next i

        If ErrorCounter > 0 Then
            MsgBox("No probes found for " & ErrorCounter & " positions:" & vbNewLine & ReportMessage)
        End If

        Return ProbesList
    End Function

    Public Shared Function Design4ProbesPerSNP(ByVal Seq As String, ByVal SNP_Pos As Integer, Optional ByVal Optimal_dG As Single = -28, Optional ByVal dG_Dev As Single = 2, Optional ByVal MinSpreadL As Integer = 10, Optional ByVal MaxSpreadL As Integer = 17, Optional ByVal T As Single = 37, Optional ByVal Make_Reverse_Complement As Boolean = False, Optional ByVal EqualizeProbesDG As Boolean = False)
        Dim Probes As ProbesBundle = Nothing

        'Cut all possible oligos
        Dim CandidateOligoList As New List(Of ProbesBundle)
        Dim StartPos As Integer = 0
        Dim EndPos As Integer = 0
        Dim CurrentDG As Single = 0
        Dim MinDG As Single = Optimal_dG - dG_Dev
        Dim MaxDG As Single = Optimal_dG + dG_Dev

        ' Dim ReportString As String = ""

        'Generate list of oligos
        For i = MinSpreadL To MaxSpreadL
            StartPos = SNP_Pos - i
            For j = MinSpreadL To MaxSpreadL
                EndPos = SNP_Pos + j
                Dim NewCandidateProbe As New ProbesBundle

                NewCandidateProbe.RefStart = StartPos
                NewCandidateProbe.RefEnd = EndPos

                NewCandidateProbe.Sequence = Seq.Substring(StartPos - 1, EndPos - StartPos + 1)
                NewCandidateProbe.LeftPart = Seq.Substring(StartPos - 1, i) 'changed SNP_Pos - StartPos to i
                NewCandidateProbe.RightPart = Seq.Substring(SNP_Pos, j)
                NewCandidateProbe.PolymorphRegion = Seq.Substring(SNP_Pos - 1, 1)


                CurrentDG = Bioinformatics.CalculateOligoDG(NewCandidateProbe.Sequence, T)

                'ReportString &= NewCandidateProbe.Sequence & Chr(9) & _
                'SNP_Pos & Chr(9) & _
                'NewCandidateProbe.LeftPart & Chr(9) & _
                'NewCandidateProbe.SNP & Chr(9) & _
                'NewCandidateProbe.RightPart & vbNewLine

                If CurrentDG >= MinDG And CurrentDG <= MaxDG Then
                    NewCandidateProbe.RefDG = CurrentDG
                    'NewCandidateProbe.CreateBundle(Make_Reverse_Complement)
                    CandidateOligoList.Add(NewCandidateProbe)
                End If

            Next j
            'ReportString &= vbNewLine
        Next i

        'Clipboard.SetText(ReportString)

        'Find shortest probe
        If CandidateOligoList.Count > 0 Then
            Dim MinLength As Integer = CandidateOligoList(0).Sequence.Length
            For Each Bundle As ProbesBundle In CandidateOligoList
                If Bundle.Sequence.Length < MinLength Then
                    MinLength = Bundle.Sequence.Length
                End If
            Next Bundle

            'Find the most SNP-centered probe
            Dim MinLDiff As Single = MaxSpreadL / MinSpreadL
            Dim CurrentLDiff As Single = 0

            Probes = CandidateOligoList(0)

            For Each Bundle As ProbesBundle In CandidateOligoList
                If Bundle.Sequence.Length = MinLength Then

                    CurrentLDiff = Math.Max(Bundle.LeftPart.Length, Bundle.RightPart.Length) / Math.Min(Bundle.LeftPart.Length, Bundle.RightPart.Length)
                    If CurrentLDiff < MinLDiff Then
                        MinLDiff = CurrentLDiff
                        Probes = Bundle
                    End If
                End If
            Next Bundle

            'From here it should work faster as we don't spend time to create other probes on each seq but only on the best
            Probes.CreateBundleForSNP(Make_Reverse_Complement)

            If EqualizeProbesDG Then
                EqualizeDG(Probes, Seq, , T)
            End If

        End If



        Return Probes
    End Function

    Public Shared Function DesignProbesPerPolymorphList(ByVal Seq As String, _
                                                        ByVal StartList As List(Of Integer), _
                                                        ByVal EndList As List(Of Integer), _
                                                        ByVal PolymorphList As List(Of String), _
                                                        ByVal IDList As List(Of String), _
                                                        Optional ByVal Optimal_dG As Single = -28, Optional ByVal dG_Dev As Single = 1, Optional ByVal MinSpreadL As Integer = 10, Optional ByVal MaxSpreadL As Integer = 17, Optional ByVal T As Single = 37, Optional ByVal Make_Reverse_Complement As Boolean = False, Optional ByVal dG_Recursion_Count As Integer = 3, Optional ByVal EqualizeProbesDG As Boolean = False)
        Dim ProbesList As New List(Of ProbesBundle)
        Dim CurrentBundle As ProbesBundle = Nothing
        Dim ReportMessage As String = ""
        Dim ErrorCounter As Integer = 0

        Dim PolymorphArray() As String

        For i = 0 To StartList.Count - 1
            CurrentBundle = Nothing
            PolymorphArray = PolymorphList(i).Split("/")

            For j = 1 To dG_Recursion_Count
                CurrentBundle = DesignProbesPerPolymorphRegion(Seq, StartList(i), EndList(i), PolymorphArray, Optimal_dG, dG_Dev * j, MinSpreadL, MaxSpreadL, T, Make_Reverse_Complement, EqualizeProbesDG)
                If Not IsNothing(CurrentBundle) Then
                    CurrentBundle.SNP_ID = IDList(i)
                    ProbesList.Add(CurrentBundle)
                    Exit For
                End If
            Next j

            If IsNothing(CurrentBundle) Then
                ReportMessage &= StartList(i) & " - " & EndList(i) & vbNewLine
                ErrorCounter += 1
            End If

        Next i

        If ErrorCounter > 0 Then
            MsgBox("No probes found for " & ErrorCounter & " positions:" & vbNewLine & ReportMessage)
        End If

        Return ProbesList
    End Function

    Public Shared Function DesignProbesPerPolymorphRegion(ByVal Seq As String, ByVal Polymorph_Reg_Start As Integer, ByVal Polymorph_Reg_End As Integer, ByVal Polymorph_Seq() As String, Optional ByVal Optimal_dG As Single = -28, Optional ByVal dG_Dev As Single = 2, Optional ByVal MinSpreadL As Integer = 10, Optional ByVal MaxSpreadL As Integer = 17, Optional ByVal T As Single = 37, Optional ByVal Make_Reverse_Complement As Boolean = False, Optional ByVal EqualizeProbesDG As Boolean = False)
        'Deletion in reference means that polymorph region has to be placed to start from Reg_Start.
        'Polymorph_Seq contains variants of the region. First item is always reference sequence. If it is "-", this is a deletion in reference.
        Dim Probes As ProbesBundle = Nothing


        'Cut all possible oligos
        Dim CandidateOligoList As New List(Of ProbesBundle)
        Dim StartPos As Integer = 0
        Dim EndPos As Integer = 0
        Dim CurrentDG As Single = 0
        Dim MinDG As Single = Optimal_dG - dG_Dev
        Dim MaxDG As Single = Optimal_dG + dG_Dev

        'Dim ReportString As String = ""

        'Generate list of oligos
        For i = MinSpreadL To MaxSpreadL
            StartPos = Polymorph_Reg_Start - i
            For j = MinSpreadL To MaxSpreadL
                EndPos = Polymorph_Reg_End + j
                Dim NewCandidateProbe As New ProbesBundle

                NewCandidateProbe.RefStart = StartPos
                NewCandidateProbe.RefEnd = EndPos

                NewCandidateProbe.Sequence = Seq.Substring(StartPos - 1, EndPos - StartPos + 1)
                NewCandidateProbe.LeftPart = Seq.Substring(StartPos - 1, i)

                If Polymorph_Seq(0) = "-" Then
                    NewCandidateProbe.PolymorphRegion = ""
                    NewCandidateProbe.RightPart = Seq.Substring(Polymorph_Reg_End - 1, j + 1)
                Else
                    NewCandidateProbe.PolymorphRegion = Seq.Substring(Polymorph_Reg_Start - 1, Polymorph_Reg_End - Polymorph_Reg_Start + 1)
                    NewCandidateProbe.RightPart = Seq.Substring(Polymorph_Reg_End, j)
                End If



                CurrentDG = Bioinformatics.CalculateOligoDG(NewCandidateProbe.Sequence, T, )

                'ReportString &= NewCandidateProbe.Sequence & Chr(9) & _
                'NewCandidateProbe.LeftPart & Chr(9) & _
                'NewCandidateProbe.PolymorphRegion & Chr(9) & _
                'NewCandidateProbe.RightPart & vbNewLine

                If CurrentDG >= MinDG And CurrentDG <= MaxDG Then
                    NewCandidateProbe.RefDG = CurrentDG
                    CandidateOligoList.Add(NewCandidateProbe)
                End If

            Next j
            'ReportString &= vbNewLine
        Next i

        'Clipboard.SetText(ReportString)


        'Find shortest probe
        If CandidateOligoList.Count > 0 Then
            Dim MinLength As Integer = CandidateOligoList(0).Sequence.Length
            For Each Bundle As ProbesBundle In CandidateOligoList
                If Bundle.Sequence.Length < MinLength Then
                    MinLength = Bundle.Sequence.Length
                End If
            Next Bundle

            'Find the most SNP-centered probe
            Dim MinLDiff As Single = MaxSpreadL / MinSpreadL
            Dim CurrentLDiff As Single = 0

            Probes = CandidateOligoList(0)

            For Each Bundle As ProbesBundle In CandidateOligoList
                If Bundle.Sequence.Length = MinLength Then
                    CurrentLDiff = Math.Max(Bundle.LeftPart.Length, Bundle.RightPart.Length) / Math.Min(Bundle.LeftPart.Length, Bundle.RightPart.Length)
                    If CurrentLDiff < MinLDiff Then
                        MinLDiff = CurrentLDiff
                        Probes = Bundle
                    End If
                End If
            Next Bundle



            'Make probes bundle for the chosen oligo
            Probes.Probes.Add(Probes.Sequence)
            Dim CurrentPolymorphSeq As String = ""

            For SeqCounter = 1 To Polymorph_Seq.GetUpperBound(0)
                CurrentPolymorphSeq = Polymorph_Seq(SeqCounter)
                If CurrentPolymorphSeq = "-" Then
                    CurrentPolymorphSeq = ""
                End If
                Probes.Probes.Add(Probes.LeftPart & CurrentPolymorphSeq & Probes.RightPart)
            Next SeqCounter



            If Make_Reverse_Complement = True Then
                For SeqCounter = 0 To Probes.Probes.Count - 1
                    Probes.Probes.Add(Bioinformatics.GetReverseComplement(Probes.Probes(SeqCounter)))
                Next SeqCounter
            End If

            If EqualizeProbesDG Then
                EqualizeDG(Probes, Seq, , T)
            End If

        End If



        'Dim ReportString As String = ""

        'For SeqCounter = 0 To Probes.Probes.Count - 1
        'ReportString &= Probes.Probes(SeqCounter) & vbNewLine
        'Next SeqCounter

        'Clipboard.SetText(ReportString)


        Return Probes
    End Function

    Public Shared Sub EqualizeDG(ByRef Probes As ProbesBundle, ByVal Seq As String, Optional ByVal EqualizerBounds As Integer = 5, Optional ByVal T As Single = 37)
        'For each oligo calculate dG and if different than reference try to shorten or englarge the oligo to compensate

        Dim CurrentDG As Single = 0
        Dim RefRC As String = GetReverseComplement(Probes.Sequence)
        Dim CandidateSeqList As New List(Of String)
        Dim CandidateRemediumDGList As New List(Of String)

        Dim StartPos As Integer = 0
        Dim StartAddition As String = ""
        Dim EndAddition As String = ""
        Dim NewProbe As String = ""

        For ProbeCounter = 0 To Probes.Probes.Count - 1
            If Not Probes.Probes(ProbeCounter) = Probes.Sequence And Not Probes.Probes(ProbeCounter) = RefRC Then

                CandidateSeqList.Clear()
                CandidateRemediumDGList.Clear()

                CurrentDG = CalculateOligoDG(Probes.Probes(ProbeCounter), T, )

                CandidateSeqList.Add(Probes.Probes(ProbeCounter))
                CandidateRemediumDGList.Add(Math.Abs(Probes.RefDG - CurrentDG))

                If CurrentDG > Probes.RefDG Then
                    'Englarge the probe
                    For i = 0 To EqualizerBounds
                        StartPos = Probes.RefStart - i
                        For j = 0 To EqualizerBounds

                            If i = 0 And j = 0 Then
                                Continue For
                            End If

                            If i = 0 Then
                                StartAddition = ""
                            Else
                                StartAddition = Seq.Substring(StartPos - 1, i)
                            End If

                            If j = 0 Then
                                EndAddition = ""
                            Else
                                EndAddition = Seq.Substring(Probes.RefEnd, j)
                            End If



                            NewProbe = StartAddition & Probes.Probes(ProbeCounter) & EndAddition
                            CandidateSeqList.Add(NewProbe)
                            CandidateRemediumDGList.Add(Math.Abs(Probes.RefDG - CalculateOligoDG(NewProbe, T, )))
                        Next j


                    Next i
                ElseIf CurrentDG < Probes.RefDG Then
                    'Shorten the probe

                    For i = 0 To EqualizerBounds

                        For j = 0 To EqualizerBounds

                            If i = 0 And j = 0 Then
                                Continue For
                            End If

                            NewProbe = Probes.Probes(ProbeCounter).Substring(i, Probes.Probes(ProbeCounter).Length - i - j)
                            CandidateSeqList.Add(NewProbe)
                            CandidateRemediumDGList.Add(Math.Abs(Probes.RefDG - CalculateOligoDG(NewProbe, T, )))
                        Next j
                    Next i

                Else
                    Continue For
                End If


                Dim MinIndex As Integer = 0
                Dim MinRemDG As Single = CandidateRemediumDGList(MinIndex)
                For i = 0 To CandidateRemediumDGList.Count - 1
                    If CandidateRemediumDGList(i) < MinRemDG Then
                        MinRemDG = CandidateRemediumDGList(i)
                        MinIndex = i
                    End If
                Next i


                Probes.Probes(ProbeCounter) = CandidateSeqList(MinIndex)


            End If 'Not Probe = Probes.Sequence And Not Probe = RefRC 


        Next ProbeCounter


    End Sub




#End Region

#Region "Genetic engineering"
    Public Shared Function MakeOligoSetPerSequence(ByVal Seq As String, ByVal OligoLength As Integer)
        Dim Oligos As New List(Of String)

        Dim MaxOligos As Integer = Math.Ceiling(Seq.Length / OligoLength)
        Dim CurrentIndex As Integer = 0
        Dim ReportString As String = ""

        'Cut seq in forward direction
        For i = 0 To MaxOligos - 2
            'If Seq.Length - CurrentIndex - 1 < OligoLength Then
            'Oligos.Add(Seq.Substring(CurrentIndex))
            'Exit For
            'Else
            Oligos.Add(Seq.Substring(CurrentIndex, OligoLength))
            CurrentIndex += OligoLength
            'End If
        Next i

        'Cut seq in reverse direction
        Dim Half_Oligo As Integer = Math.Truncate(OligoLength / 2)
        CurrentIndex = Half_Oligo  'Shift the start psition for overlap

        For i = 0 To MaxOligos - 1
            If Seq.Length - CurrentIndex - 1 < OligoLength Then
                Oligos.Add(Seq.Substring(CurrentIndex - Half_Oligo))
                Exit For
            Else
                Oligos.Add(GetReverseComplement(Seq.Substring(CurrentIndex, OligoLength)))
                CurrentIndex += OligoLength
            End If
        Next i

        For Each Oligo As String In Oligos
            ReportString &= Oligo & vbNewLine
        Next Oligo

        Clipboard.SetText(ReportString)

        Return Oligos
    End Function


    Public Shared Function RegularDisassembly(ByVal OligoLength As Integer, ByVal Overlap As Integer, ByVal StartPos As Integer, ByVal EndPos As Integer)
        Dim OligoNumber As Integer = 0

        Dim Result As New List(Of Genome_Feature)

        Dim CurrentPos As Integer = StartPos
        Dim CurrentDir As Short = 1

        Dim ExitDo As Boolean = False


        Do
            'Add oligo
            Dim NewOligo As New Genome_Feature()
            NewOligo.AbsoluteStart = CurrentPos
            NewOligo.AbsoluteEnd = CurrentPos + OligoLength - 1

            If NewOligo.AbsoluteEnd >= EndPos Then
                NewOligo.AbsoluteEnd = EndPos
                ExitDo = True
            End If

            NewOligo.Direction = CurrentDir
            NewOligo.Type = 8
            NewOligo.TAG = "Segment" & OligoNumber
            NewOligo.Name = NewOligo.TAG
            OligoNumber += 1
            Result.Add(NewOligo)

            If ExitDo Then

                'Add code for finising oligo



                Exit Do
            End If


            'Shift position
            CurrentPos += OligoLength - Overlap


            'Reverse strand for each step
            Select Case CurrentDir
                Case 1
                    CurrentDir = 2
                Case 2
                    CurrentDir = 1
            End Select



        Loop


        Return Result
    End Function

    Public Shared Function SegmentedTmDisassembly(ByVal Seq As String, ByVal StartPos As Integer, ByVal EndPos As Integer, ByVal SegmentLength As Integer, ByVal SegmentVariation As Integer, ByVal Assembly_T As Single, ByVal dG_Variation As Single, ByVal Oligo_C As Single, ByVal Mg_C As Single, ByVal Na_C As Single, _
                                                  Optional ByRef dG_List As List(Of Single) = Nothing, Optional ByRef PrescanList As List(Of Single) = Nothing, Optional ByRef Tm_List As List(Of Single) = Nothing)

        Dim dG_res As New List(Of Single)
        Dim Tm_res As New List(Of Single)

        Dim TargetSeq As String = DataIO.RetrieveSeqFromCache(Seq, StartPos, EndPos - 1)


        'Find target dG from sequence
        Dim Prescan_dG_List As List(Of Single) = Get_dG_Distribution(TargetSeq, SegmentLength, Assembly_T)

        If Not IsNothing(PrescanList) Then
            PrescanList = Prescan_dG_List
        End If

        Dim Sum_dG As Single = 0
        For Each dG As Single In Prescan_dG_List
            Sum_dG += dG
        Next dG

        Dim Av_dG As Single = Sum_dG / Prescan_dG_List.Count


        Disassembler.ReportTextBox.Text &= "Target dG for the sequence: " & Av_dG & vbNewLine _
        & "Max dG: " & Bioinformatics.Maximum(Prescan_dG_List) _
        & vbNewLine & "Min dG: " & Bioinformatics.Minimum(Prescan_dG_List)



        'Split sequence into segments with equal dG
        Dim Result As New List(Of Genome_Feature)
        Dim OligoNumber As Integer = 0

        Dim Target_dG_Min As Single = Av_dG - dG_Variation
        Dim Target_dG_Max As Single = Av_dG + dG_Variation


        Dim CurrentPos As Integer = 0 'Current position to split sequence
        Dim CurrentEnd As Integer = 0
        Dim CurrentL As Integer = 0

        Dim End_Of_Iteration As Boolean = False


        Dim CurrentSeq As String = ""
        Dim Current_dG As Single = 0
        Dim Current_Tm As Single = 0

        Do

            'Scan the space of oligo length
            End_Of_Iteration = False
            CurrentEnd = CurrentPos + SegmentLength - SegmentVariation
            CurrentL = CurrentEnd - CurrentPos + 1
            For i = 0 To SegmentVariation + 1

                'Check if current end is higher than the end of the sequence
                If CurrentEnd + StartPos + 1 > EndPos Then 'Check +1 length correction!!!!!
                    Disassembler.ReportTextBox.Text &= vbNewLine & "End of sequence reached!"

                    Dim NewOligo As New Genome_Feature()
                    NewOligo.AbsoluteStart = CurrentPos + StartPos
                    NewOligo.AbsoluteEnd = EndPos
                    NewOligo.Direction = 1
                    NewOligo.Type = 11
                    NewOligo.TAG = "Segment" & OligoNumber
                    Current_dG = CalculateOligoDG(TargetSeq.Substring(CurrentPos), Assembly_T)
                    NewOligo.Name = NewOligo.TAG
                    NewOligo.Description = Current_dG & "; [E !]"
                    OligoNumber += 1
                    Result.Add(NewOligo)
                    dG_res.Add(Current_dG)
                    Tm_res.Add(Current_Tm)

                    End_Of_Iteration = True
                    Exit For
                End If

                CurrentSeq = TargetSeq.Substring(CurrentPos, CurrentL + i)
                Current_dG = CalculateOligoDG(CurrentSeq, Assembly_T)
                Current_Tm = CalculateOligoTm(CurrentSeq, Oligo_C, Na_C, 0, Mg_C)


                If Current_dG >= Target_dG_Min And Current_dG <= Target_dG_Max Then


                    'Add oligo with current parameters
                    Dim NewOligo As New Genome_Feature()
                    NewOligo.AbsoluteStart = CurrentPos + StartPos
                    NewOligo.AbsoluteEnd = CurrentEnd + StartPos
                    NewOligo.Direction = 1
                    NewOligo.Type = 11
                    NewOligo.TAG = "Segment" & OligoNumber
                    NewOligo.Name = NewOligo.TAG
                    NewOligo.Description = Current_dG
                    OligoNumber += 1
                    Result.Add(NewOligo)
                    dG_res.Add(Current_dG)
                    Tm_res.Add(Current_Tm)

                    End_Of_Iteration = True
                    Exit For

                Else
                    CurrentEnd += 1
                End If


                If Current_dG < Target_dG_Min Then
                    'Add oligo
                    Dim NewOligo As New Genome_Feature()
                    NewOligo.AbsoluteStart = CurrentPos + StartPos
                    NewOligo.AbsoluteEnd = CurrentEnd + StartPos
                    NewOligo.Direction = 1
                    NewOligo.Type = 11
                    NewOligo.TAG = "Segment" & OligoNumber
                    NewOligo.Name = NewOligo.TAG
                    NewOligo.Description = Current_dG & "; [< !]"
                    OligoNumber += 1
                    Result.Add(NewOligo)
                    dG_res.Add(Current_dG)
                    Tm_res.Add(Current_Tm)

                    End_Of_Iteration = True
                    Exit For
                End If



            Next i

            If Not End_Of_Iteration Then
                'Add oligo with current parameters
                'and mark it as out of range
                Dim NewOligo As New Genome_Feature()
                NewOligo.AbsoluteStart = CurrentPos + StartPos
                NewOligo.AbsoluteEnd = CurrentEnd + StartPos
                NewOligo.Direction = 1
                NewOligo.Type = 11
                NewOligo.TAG = "Segment" & OligoNumber
                NewOligo.Name = NewOligo.TAG
                NewOligo.Description = Current_dG & "; [> !]"
                OligoNumber += 1
                Result.Add(NewOligo)
                dG_res.Add(Current_dG)
                Tm_res.Add(Current_Tm)

            End If



            CurrentPos = CurrentEnd + 1


            If CurrentPos + StartPos > EndPos Then
                Exit Do
            End If

        Loop


        If Not IsNothing(dG_List) Then
            dG_List = dG_res
        End If

        If Not IsNothing(Tm_List) Then
            Tm_List = Tm_res
        End If


        Return Result
    End Function

    Public Shared Function PCRDisassembly(ByVal Seq As String, ByVal StartPos As Integer, ByVal EndPos As Integer, ByVal SegmentLength As Integer, ByVal SegmentVariation As Integer, ByVal MaxOligoLength As Integer, ByVal Assembly_T As Single, ByVal dG_Variation As Single, ByVal Oligo_C As Single, ByVal Mg_C As Single, ByVal Na_C As Single, _
                                                  Optional ByRef dG_List As List(Of Single) = Nothing, Optional ByRef PrescanList As List(Of Single) = Nothing, Optional ByRef Tm_List As List(Of Single) = Nothing, Optional ByVal PriorityToLength As Boolean = True)


        Dim dG_res As New List(Of Single)
        Dim Tm_res As New List(Of Single)

        Dim TargetSeq As String = DataIO.RetrieveSeqFromCache(Seq, StartPos, EndPos - 1)


        'Find target dG from sequence
        Dim Prescan_dG_List As List(Of Single) = Get_dG_Distribution(TargetSeq, SegmentLength, Assembly_T)

        If Not IsNothing(PrescanList) Then
            PrescanList = Prescan_dG_List
        End If

        Dim Sum_dG As Single = 0
        For Each dG As Single In Prescan_dG_List
            Sum_dG += dG
        Next dG

        Dim Av_dG As Single = Sum_dG / Prescan_dG_List.Count

        Disassembler.ReportTextBox.Text &= "Target dG for the sequence: " & Av_dG & vbNewLine _
       & "Max dG: " & Bioinformatics.Maximum(Prescan_dG_List) _
       & vbNewLine & "Min dG: " & Bioinformatics.Minimum(Prescan_dG_List)



        'Split sequence into segments with equal dG
        Dim Result As New List(Of Genome_Feature)
        Dim OligoNumber As Integer = 0

        Dim CurrentStart As Integer = 0
        Dim PrevOligoLength As Integer = 0
        Dim CurrentEndLim As Integer = 0


        Dim CurrentBlock As Aligned_dG_block = Nothing
        Dim PosIterationLock As Boolean = True
        Dim EndOfSequence As Boolean = False


        'Dim TestCounter As Integer = 0

        Do
            CurrentEndLim = CurrentStart + MaxOligoLength - PrevOligoLength


            CurrentBlock = FindOptimalBlock_dG(Seq, CurrentStart, SegmentLength, SegmentVariation, CurrentEndLim, Assembly_T, Av_dG, dG_Variation, Oligo_C, Mg_C, Na_C, PosIterationLock, PriorityToLength)

            If IsNothing(CurrentBlock) Then
                Exit Do
            End If

            PrevOligoLength = CurrentBlock.BlockEnd - CurrentBlock.BlockStart + 1

            CurrentStart = CurrentBlock.BlockEnd + 1






            'Add oligo with current parameters
            Dim NewOligo As New Genome_Feature()
            NewOligo.AbsoluteStart = CurrentBlock.BlockStart + StartPos
            NewOligo.AbsoluteEnd = CurrentBlock.BlockEnd + StartPos
            NewOligo.Direction = 1
            NewOligo.Type = 11
            NewOligo.TAG = "Segment" & OligoNumber
            NewOligo.Name = NewOligo.TAG
            NewOligo.Description = CurrentBlock.dG
            OligoNumber += 1
            Result.Add(NewOligo)
            dG_res.Add(CurrentBlock.dG)
            Tm_res.Add(CurrentBlock.Tm)





            PosIterationLock = False

            If CurrentEndLim > TargetSeq.Length Then
                EndOfSequence = True
                Exit Do
            End If


            'TestCounter += 1
            'If TestCounter > 20 Then
            '    ' Exit Do
            'End If
        Loop


        If Not IsNothing(dG_List) Then
            dG_List = dG_res
        End If

        If Not IsNothing(Tm_List) Then
            Tm_List = Tm_res
        End If


        Return Result
    End Function

    Public Shared Function FindOptimalBlock_dG(ByVal Seq As String, ByVal InitStartPos As Integer, ByVal BaseLength As Integer, ByVal LengthStepsLim As Integer, ByVal MaxEnd As Integer, ByVal Assembly_T As Single, ByVal Target_dG As Single, ByVal dG_Difference As Single, ByVal Oligo_C As Single, ByVal Mg_C As Single, ByVal Na_C As Single, ByVal StopPosIteration As Boolean, Optional ByVal PriorityToLength As Boolean = True)



        Dim dG_Max As Integer = Target_dG + dG_Difference
        Dim dG_Min As Integer = Target_dG - dG_Difference


        Dim dG_list As New List(Of Aligned_dG_block)
        Dim OptimalBlock As Aligned_dG_block = Nothing

        Dim CurrentEnd As Integer = 0
        Dim CurrentSeq As String = ""
        Dim CurrentdG As Single = 0
        Dim StartPos As Integer = InitStartPos

        Dim EndOfSequence As Boolean = False

        Dim ReportString As String = ""

        Do


            For i = 0 To LengthStepsLim
                CurrentEnd = StartPos + BaseLength - 1 + i
                If CurrentEnd >= MaxEnd Then
                    EndOfSequence = True
                    Exit For
                End If

                If CurrentEnd >= Seq.Length Then
                    EndOfSequence = True
                    Exit For
                End If


                CurrentSeq = Seq.Substring(StartPos, BaseLength + i)

                CurrentdG = CalculateOligoDG(CurrentSeq, Assembly_T)

                ReportString &= CurrentdG & vbNewLine

                Dim NewBlock As New Aligned_dG_block
                NewBlock.dG = CurrentdG
                NewBlock.dG_Distance = Math.Abs(CurrentdG - Target_dG)
                NewBlock.Tm = CalculateOligoTm(CurrentSeq, Oligo_C, Na_C, 0, Mg_C)
                NewBlock.BlockStart = StartPos
                NewBlock.BlockEnd = CurrentEnd
                dG_list.Add(NewBlock)

            Next i


            If EndOfSequence Then
                Exit Do
            End If

            StartPos += 1

        Loop While StopPosIteration = False

        If StopPosIteration = False Then 'Find the furthest block


            'Arrange blocks by distance from the previous
            Dim Tmp As Aligned_dG_block = Nothing
            For i = 1 To dG_list.Count - 1
                For j = 0 To dG_list.Count - 1 - i
                    If dG_list(j).BlockStart < dG_list(j + 1).BlockStart Then
                        Tmp = dG_list(j)
                        dG_list(j) = dG_list(j + 1)
                        dG_list(j + 1) = Tmp
                    End If
                Next j
            Next i




            If PriorityToLength Then
                'Alternatively scan for dG that falls into the certain thresholds and if no blocks are found than take the closest by dG irrespectively of position
                If dG_list.Count = 0 Then
                    Return Nothing
                End If

                Dim BlockFound As Boolean = False

                For i = 0 To dG_list.Count - 1
                    If dG_list(i).dG >= dG_Min And dG_list(i).dG <= dG_Max Then
                        BlockFound = True
                        OptimalBlock = dG_list(i)
                        Exit For
                    End If
                Next i

                If Not BlockFound Then
                    'Arrange blocks by dG distance
                    For i = 1 To dG_list.Count - 1
                        For j = 0 To dG_list.Count - 1 - i
                            If dG_list(j).dG_Distance > dG_list(j + 1).dG_Distance Then
                                Tmp = dG_list(j)
                                dG_list(j) = dG_list(j + 1)
                                dG_list(j + 1) = Tmp
                            End If
                        Next j
                    Next i
                    OptimalBlock = dG_list(0)
                End If


            Else

                'Arrange blocks by dG distance
                For i = 1 To dG_list.Count - 1
                    For j = 0 To dG_list.Count - 1 - i
                        If dG_list(j).dG_Distance > dG_list(j + 1).dG_Distance Then
                            Tmp = dG_list(j)
                            dG_list(j) = dG_list(j + 1)
                            dG_list(j + 1) = Tmp
                        End If
                    Next j
                Next i
            End If

            If dG_list.Count = 0 Then
                Return Nothing
            Else
                OptimalBlock = dG_list(0)
            End If

        Else


            'Arrange blocks by distance from the previous
            Dim Tmp As Aligned_dG_block = Nothing
            For i = 1 To dG_list.Count - 1
                For j = 0 To dG_list.Count - 1 - i
                    If dG_list(j).BlockStart < dG_list(j + 1).BlockStart Then
                        Tmp = dG_list(j)
                        dG_list(j) = dG_list(j + 1)
                        dG_list(j + 1) = Tmp
                    End If
                Next j
            Next i

            If dG_list.Count = 0 Then
                Return Nothing
            Else
                OptimalBlock = dG_list(0)
            End If

        End If




        'Try

        'Catch ex As Exception
        '    MsgBox(ex.Message & vbNewLine & "dG_list count = " & dG_list.Count & vbNewLine & "Start position = " & InitStartPos & vbNewLine & "Sequence length = " & Seq.Length)
        '    OptimalBlock = Nothing
        'End Try

        Return OptimalBlock
    End Function

    Public Shared Function GetTarget_dG(ByVal Sequence As String, ByVal SegmentLength As Integer, ByVal Assembly_T As Single, Optional ByRef ReportList_dG As List(Of Single) = Nothing, Optional ByVal ReportBox As TextBox = Nothing)
        Dim dG_res As New List(Of Single)
        Dim Tm_res As New List(Of Single)

        'Find target dG from sequence
        Dim Prescan_dG_List As List(Of Single) = Get_dG_Distribution(Sequence, SegmentLength, Assembly_T)

        If Not IsNothing(ReportList_dG) Then
            ReportList_dG = Prescan_dG_List
        End If

        Dim Sum_dG As Single = 0
        For Each dG As Single In Prescan_dG_List
            Sum_dG += dG
        Next dG

        Dim Av_dG As Single = Sum_dG / Prescan_dG_List.Count

        If Not IsNothing(ReportBox) Then
            ReportBox.Text &= "Target dG for the sequence: " & Av_dG & vbNewLine _
            & "Max dG: " & Bioinformatics.Maximum(Prescan_dG_List) & vbNewLine _
            & "Min dG: " & Bioinformatics.Minimum(Prescan_dG_List)
        End If

        Return Av_dG
    End Function

    Public Shared Function DesignOligos(ByVal Sequence As String, _
                                        ByVal Assembly_T As Single, _
                                        ByVal dG_Target As Single, _
                                        ByVal SegmentLength As Integer, ByVal SegmentVariation As Integer, _
                                        ByVal SpacerLength As Integer, _
                                        ByVal Oligo_C As Single, ByVal Mg_C As Single, ByVal Na_C As Single, ByVal dNTPC As Single, _
                                        Optional ByVal Optimize_Tm_InsteadOf_dG As Boolean = False, _
                                        Optional ByVal AutoTarget_dG As Boolean = True, _
                                        Optional ByRef ReportSeq_dG_Distr As List(Of Single) = Nothing, _
                                        Optional ByRef ReportOligo_dG_Distr As List(Of Single) = Nothing, _
                                        Optional ByRef ReportOligo_Tm_Distr As List(Of Single) = Nothing, _
                                        Optional ByRef ReportBox As TextBox = Nothing, _
                                        Optional ByRef ReportSegmentList As List(Of Genome_Feature) = Nothing, _
                                        Optional ByVal FragmentName As String = "")




        Dim Tg_dG As Single = 0

        If AutoTarget_dG Then
            Tg_dG = GetTarget_dG(Sequence, SegmentLength, Assembly_T, ReportSeq_dG_Distr, ReportBox)
        Else
            Tg_dG = dG_Target
        End If


        Dim CurrentSubsequence As String = ""
        Dim MinL As Integer = SegmentLength - SegmentVariation
        Dim MaxL As Integer = SegmentLength + SegmentVariation
        Dim AllowSpacer As Boolean = False

        Dim StickySegments As New List(Of Genome_Feature)
        Dim CurrentStickySegment As Genome_Feature = Nothing

        Dim CurrentL As Integer = MaxL
        Dim CurrentStart As Integer = 0
        Dim SegmentCounter As Integer = 0

        'Design first segment, spacer is not allowed
        CurrentSubsequence = Sequence.Substring(CurrentStart, CurrentL)
        CurrentStickySegment = DesignStickyRegionForOligos(CurrentSubsequence, Assembly_T, MaxL, MinL, dG_Target, Oligo_C, Mg_C, Na_C, dNTPC, AllowSpacer, False, ReportOligo_dG_Distr, ReportOligo_Tm_Distr)
        CurrentStickySegment.TAG = "Seg" & SegmentCounter
        CurrentStickySegment.Name = CurrentStickySegment.TAG
        SegmentCounter += 1
        StickySegments.Add(CurrentStickySegment)


        'Set gapped or ungapped design
        If SpacerLength > 0 Then
            AllowSpacer = True
            CurrentL = MaxL + SpacerLength
        Else
            AllowSpacer = False
            CurrentL = MaxL
        End If


        Do

            'Increment current start and length
            CurrentStart = CurrentStickySegment.AbsoluteEnd + 1


            'Check if the end of sequence reached
            If CurrentStart + CurrentL > Sequence.Length Then
                'Find optimal end segment

                Dim SeqRem As String = Sequence.Substring(CurrentStart)

                If SeqRem.Length >= MinL Then
                    'Design sticky segment
                    CurrentStickySegment = DesignStickyRegionForOligos(SeqRem, Assembly_T, MaxL, MinL, dG_Target, Oligo_C, Mg_C, Na_C, dNTPC, AllowSpacer, False, ReportOligo_dG_Distr, ReportOligo_Tm_Distr)
                    'Transform coordinates
                    CurrentStickySegment.AbsoluteStart += CurrentStart
                    CurrentStickySegment.AbsoluteEnd += CurrentStart
                    CurrentStickySegment.TAG = "Seg" & SegmentCounter
                    CurrentStickySegment.Name = CurrentStickySegment.TAG
                    SegmentCounter += 1
                    StickySegments.Add(CurrentStickySegment)
                Else
                    'Add sequence to the last segment
                    CurrentStickySegment.AbsoluteEnd = Sequence.Length - 1
                End If

                'Terminate
                Exit Do

            End If


            'Design further segments
            CurrentSubsequence = Sequence.Substring(CurrentStart, CurrentL)
            CurrentStickySegment = DesignStickyRegionForOligos(CurrentSubsequence, Assembly_T, MaxL, MinL, dG_Target, Oligo_C, Mg_C, Na_C, dNTPC, AllowSpacer, False, ReportOligo_dG_Distr, ReportOligo_Tm_Distr)
            'Transform coordinates
            CurrentStickySegment.AbsoluteStart += CurrentStart
            CurrentStickySegment.AbsoluteEnd += CurrentStart
            CurrentStickySegment.TAG = "Seg" & SegmentCounter
            CurrentStickySegment.Name = CurrentStickySegment.TAG
            SegmentCounter += 1
            StickySegments.Add(CurrentStickySegment)


        Loop


        'Coordinates correction
        For Each Segment As Genome_Feature In StickySegments
            Segment.AbsoluteStart += 1
            Segment.AbsoluteEnd += 1
        Next Segment


        'Last segment should always end on the sequnce end
        If Not StickySegments(StickySegments.Count - 1).AbsoluteEnd = Sequence.Length Then
            StickySegments(StickySegments.Count - 1).AbsoluteEnd = Sequence.Length
        End If


        If Not IsNothing(ReportSegmentList) Then
            ReportSegmentList = StickySegments
        End If


        'Assemble segments into oligos
        Dim Oligos As New List(Of Genome_Feature)
        Dim OligoCounter As Integer = 0

        Dim StartOligo As New Genome_Feature
        StartOligo.TAG = FragmentName & "-" & OligoCounter
        StartOligo.Name = StartOligo.TAG
        StartOligo.Type = 8
        StartOligo.Direction = 2
        StartOligo.AbsoluteStart = StickySegments(0).AbsoluteStart
        StartOligo.AbsoluteEnd = StickySegments(0).AbsoluteEnd
        OligoCounter += 1
        Oligos.Add(StartOligo)


        Dim CurrentDir As Boolean = False
        For i = 0 To StickySegments.Count - 2
            Dim NewOligo As New Genome_Feature
            NewOligo.AbsoluteStart = StickySegments(i).AbsoluteStart
            NewOligo.AbsoluteEnd = StickySegments(i + 1).AbsoluteEnd
            NewOligo.Type = 8

            If CurrentDir = False Then
                NewOligo.Direction = 1
            Else
                NewOligo.Direction = 2
            End If

            NewOligo.TAG = FragmentName & "-" & OligoCounter
            NewOligo.Name = NewOligo.TAG

            CurrentDir = Not CurrentDir
            OligoCounter += 1
            Oligos.Add(NewOligo)
        Next i

        Dim EndOligo As New Genome_Feature
        EndOligo.TAG = FragmentName & "-" & OligoCounter
        EndOligo.Name = EndOligo.TAG
        EndOligo.Type = 8

        If StickySegments.Count / 2 - Math.Floor(StickySegments.Count / 2) = 0 Then 'Even
            EndOligo.Direction = 2
        Else 'Odd
            EndOligo.Direction = 1
        End If


        EndOligo.AbsoluteStart = StickySegments(StickySegments.Count - 1).AbsoluteStart
        EndOligo.AbsoluteEnd = StickySegments(StickySegments.Count - 1).AbsoluteEnd
        OligoCounter += 1
        Oligos.Add(EndOligo)


        Return Oligos
    End Function

    Public Shared Function DesignFragments(ByVal Sequence As String, _
                                           ByVal TargetFragmentLength As Integer, _
                                           ByVal MaxL As Integer, ByVal MinL As Integer, _
                                           ByVal MinTm As Single, ByVal MaxTm As Single, _
                                           ByVal Oligo_C As Single, ByVal Mg_C As Single, ByVal Na_C As Single, ByVal dNTPC As Single, _
                                           Optional ByVal ScanLength As Integer = 100, _
                                           Optional ByRef ReportBox As TextBox = Nothing, _
                                           Optional ByRef StickyEndsTm As List(Of Single) = Nothing, Optional ByVal ByPass As Boolean = False)

        Dim FragmentList As New List(Of Genome_Feature)
        'Find sticky blocks

        If ByPass Then
            'Whole sequence represents one fragment
            Dim NewFrag As New Genome_Feature
            NewFrag.Type = 7
            NewFrag.TAG = "F0"
            NewFrag.Name = NewFrag.TAG
            NewFrag.AbsoluteStart = 1
            NewFrag.AbsoluteEnd = Sequence.Length '+1-1=0, where +1 is sequence start
            NewFrag.Sequence = DataIO.RetrieveSeqFromCache(Sequence, NewFrag.AbsoluteStart, NewFrag.AbsoluteEnd)

            FragmentList.Add(NewFrag)

            If Not IsNothing(ReportBox) Then
                ReportBox.Text &= "Fragments number: 1; Auto design disabled" & vbNewLine

            End If

            Return FragmentList
            Exit Function
        End If


        'Identify optimal fragment number
        Dim AverageStepLength As Integer = TargetFragmentLength
        Dim CompleteFragmentsNumber As Single = Math.Floor(Sequence.Length / TargetFragmentLength)
        Dim MaxStickyEnds As Integer = CompleteFragmentsNumber - 1
        Dim FragmentsNumber As Single = 0 ' Sequence.Length / TargetFragmentLength
        Dim RemFrag As Single = 0 ' FragmentsNumber - CompleteFragmentsNumber


        For FL = TargetFragmentLength To 0 Step -10
            FragmentsNumber = Sequence.Length / TargetFragmentLength
            CompleteFragmentsNumber = Math.Floor(Sequence.Length / TargetFragmentLength)
            RemFrag = FragmentsNumber - CompleteFragmentsNumber

            If RemFrag <= 0.1 Then
                AverageStepLength = FL
                MaxStickyEnds = CompleteFragmentsNumber - 1
                Exit For
            End If

            If RemFrag >= 0.7 Then
                AverageStepLength = FL
                MaxStickyEnds = CompleteFragmentsNumber
                Exit For
            End If

        Next FL

        'If Not IsNothing(ReportBox) Then
        'ReportBox.Text &= "Complete fragments: " & CompleteFragmentsNumber & vbNewLine '& _
        '"Fragments: " & FragmentsNumber & vbNewLine & _
        '"Sticky ends: " & MaxStickyEnds & vbNewLine
        ' End If


        Dim StickyBlocks As New List(Of Genome_Feature)

        Dim CurrentStickyRegionStart As Integer = AverageStepLength - ScanLength
        If CurrentStickyRegionStart < 0 Then
            CurrentStickyRegionStart = 0
        End If

        Dim CurrentStickyRegionEnd As Integer = AverageStepLength + ScanLength
        If CurrentStickyRegionEnd > Sequence.Length Then
            CurrentStickyRegionEnd = Sequence.Length
        End If



        For i = 1 To MaxStickyEnds
            Dim AnnealSequence As String = DataIO.RetrieveSeqFromCache(Sequence, CurrentStickyRegionStart, CurrentStickyRegionEnd)
            Dim BestStickyRegion As Genome_Feature = Bioinformatics.DesignStickyRegionsForFragments(AnnealSequence, MaxL, MinL, MinTm, MaxTm, Oligo_C, Mg_C, Na_C, dNTPC)

            BestStickyRegion.TAG = "Overlap" & i
            BestStickyRegion.Name = BestStickyRegion.TAG
            BestStickyRegion.AbsoluteStart += CurrentStickyRegionStart
            BestStickyRegion.AbsoluteEnd += CurrentStickyRegionStart

            StickyBlocks.Add(BestStickyRegion)

            CurrentStickyRegionStart += AverageStepLength
            CurrentStickyRegionEnd += AverageStepLength
        Next i



        If StickyBlocks.Count = 0 Then
            'Whole sequence represents one fragment
            Dim NewFrag As New Genome_Feature
            NewFrag.Type = 7
            NewFrag.TAG = "F0"
            NewFrag.Name = NewFrag.TAG
            NewFrag.AbsoluteStart = 1
            NewFrag.AbsoluteEnd = Sequence.Length '+1-1=0, where +1 is sequence start
            NewFrag.Sequence = DataIO.RetrieveSeqFromCache(Sequence, NewFrag.AbsoluteStart, NewFrag.AbsoluteEnd)

            FragmentList.Add(NewFrag)
        End If

        Dim FragCounter As Integer = 1

        If StickyBlocks.Count > 0 Then
            Dim HeadingFrag As New Genome_Feature
            HeadingFrag.Type = 7
            HeadingFrag.TAG = "F" & FragCounter
            HeadingFrag.Name = HeadingFrag.TAG
            HeadingFrag.AbsoluteStart = 1
            HeadingFrag.AbsoluteEnd = StickyBlocks(0).AbsoluteEnd
            HeadingFrag.Sequence = DataIO.RetrieveSeqFromCache(Sequence, HeadingFrag.AbsoluteStart, HeadingFrag.AbsoluteEnd)

            FragmentList.Add(HeadingFrag)
            FragCounter += 1
        End If

        If StickyBlocks.Count > 1 Then
            'There are fragments, assemble them
            For i = 0 To StickyBlocks.Count - 2
                Dim NewFrag As New Genome_Feature
                NewFrag.Type = 7
                NewFrag.TAG = "F" & FragCounter
                NewFrag.Name = NewFrag.TAG
                NewFrag.AbsoluteStart = StickyBlocks(i).AbsoluteStart
                NewFrag.AbsoluteEnd = StickyBlocks(i + 1).AbsoluteEnd
                NewFrag.Sequence = DataIO.RetrieveSeqFromCache(Sequence, NewFrag.AbsoluteStart, NewFrag.AbsoluteEnd)

                FragmentList.Add(NewFrag)
                FragCounter += 1
            Next i
        End If

        If StickyBlocks.Count > 0 Then
            Dim TrailingFrag As New Genome_Feature
            TrailingFrag.Type = 7
            TrailingFrag.TAG = "F" & FragCounter
            TrailingFrag.Name = TrailingFrag.TAG
            TrailingFrag.AbsoluteStart = StickyBlocks(StickyBlocks.Count - 1).AbsoluteStart
            TrailingFrag.AbsoluteEnd = Sequence.Length
            TrailingFrag.Sequence = DataIO.RetrieveSeqFromCache(Sequence, TrailingFrag.AbsoluteStart, TrailingFrag.AbsoluteEnd)

            FragmentList.Add(TrailingFrag)
            FragCounter += 1
        End If


        If Not IsNothing(ReportBox) Then
            ReportBox.Text &= "Fragments number: " & FragmentList.Count & "; Auto design enabled" & vbNewLine '& "Sticky blocks number: " & StickyBlocks.Count & vbNewLine

        End If


        Return FragmentList
    End Function

    Public Shared Function DesignStickyRegionsForFragments(ByVal Sequence As String, ByVal MaxL As Integer, ByVal MinL As Integer, ByVal MinTm As Single, ByVal MaxTm As Single, ByVal Oligo_C As Single, ByVal Mg_C As Single, ByVal Na_C As Single, ByVal dNTPC As Single, Optional ByVal MinGC As Single = 20, Optional ByVal MaxGC As Single = 80)
        Dim BestStickyRegion As New Genome_Feature
        Dim Primers As New List(Of Primer)
        Dim OptimalTm As Single = (MinTm + MaxTm) * 0.5

        Dim CurrentSeq As String = ""
        Dim CurrentTm As Single = 0
        Dim CurrentGC As Single = 0

        For i = 0 To MaxL - MinL
            For j = 0 To Sequence.Length - (MinL + i)

                CurrentSeq = Sequence.Substring(j, MinL + i)
                CurrentTm = Bioinformatics.CalculateOligoTm(CurrentSeq, Oligo_C, Na_C, dNTPC, Mg_C)
                CurrentGC = Bioinformatics.CalculateCGContent(CurrentSeq)

                If CurrentTm >= MinTm And CurrentTm <= MaxTm And CurrentGC >= MinGC And CurrentGC <= MaxGC Then
                    Dim NewPrimer As New Primer
                    NewPrimer.Location = j
                    NewPrimer.Sequence = CurrentSeq
                    NewPrimer.Tm = CurrentTm
                    NewPrimer.GC = CurrentGC
                    Primers.Add(NewPrimer)

                End If

            Next j
        Next i



        If Primers.Count > 0 Then

            Dim OptimalP As Primer = Primers(0)
            Dim BestTm_Dif As Single = Math.Abs(OptimalP.Tm - OptimalTm)
            Dim Tm_Dif As Single = 0 'Math.Abs(OptimalP.Tm - OptimalTm)

            For Each P As Primer In Primers
                Tm_Dif = Math.Abs(P.Tm - OptimalTm)
                If Tm_Dif < BestTm_Dif Then
                    OptimalP = P
                    BestTm_Dif = Tm_Dif
                End If
            Next P

            BestStickyRegion.Type = 11
            BestStickyRegion.AbsoluteStart = OptimalP.Location
            BestStickyRegion.AbsoluteEnd = OptimalP.Location + OptimalP.Sequence.Length - 1
            BestStickyRegion.Description = "Tm=" & OptimalP.Tm
        Else

            BestStickyRegion.Type = 11
            BestStickyRegion.AbsoluteStart = 0
            BestStickyRegion.AbsoluteEnd = MaxL - 1
            BestStickyRegion.Description = "Default"
        End If


        Return BestStickyRegion
    End Function

    Public Shared Function DesignStickyRegionForOligos(ByVal Sequence As String, _
                                                       ByVal Assembly_T As Single, _
                                                       ByVal MaxL As Integer, ByVal MinL As Integer, _
                                                       ByVal Target_dG As Single, _
                                                       ByVal Oligo_C As Single, ByVal Mg_C As Single, ByVal Na_C As Single, ByVal dNTPC As Single, _
                                                       Optional ByVal AllowSpacer As Boolean = True, _
                                                       Optional ByVal Optimize_Tm_InsteadOf_dG As Boolean = False, _
                                                       Optional ByRef ReportOligo_dG_Distr As List(Of Single) = Nothing, _
                                                       Optional ByRef ReportOligo_Tm_Distr As List(Of Single) = Nothing)


        Dim BestStickyRegion As Genome_Feature = Nothing
        Dim SeqShift As Integer = 0
        Dim CurrentSeq As String = ""
        Dim Primers As New List(Of Primer)



        For i = 0 To MaxL - MinL

            If AllowSpacer Then
                SeqShift = Sequence.Length - (MinL + i)
            Else
                SeqShift = 0
            End If



            For j = 0 To SeqShift

                If j + MinL + i > Sequence.Length Then
                    Exit For
                End If

                CurrentSeq = Sequence.Substring(j, MinL + i)
                Dim NewPrimer As New Primer
                NewPrimer.Location = j
                NewPrimer.Sequence = CurrentSeq
                NewPrimer.Tm = Bioinformatics.CalculateOligoTm(CurrentSeq, Oligo_C, Na_C, dNTPC, Mg_C, )
                NewPrimer.dG = Bioinformatics.CalculateOligoDG(CurrentSeq, Assembly_T, Oligo_C, Na_C, dNTPC, Mg_C, )
                Primers.Add(NewPrimer)
            Next j
        Next i


        If Primers.Count > 0 Then
            Dim OptimalP As Primer = Primers(0)

            If Optimize_Tm_InsteadOf_dG Then
                Dim BestTm_Dif As Single = Math.Abs(Assembly_T - OptimalP.Tm)
                Dim Tm_Dif As Single = 0

                For Each P As Primer In Primers
                    Tm_Dif = Math.Abs(Assembly_T - P.Tm)
                    If Tm_Dif < BestTm_Dif Then
                        OptimalP = P
                        BestTm_Dif = Tm_Dif
                    End If
                Next P
            Else
                Dim BestdG_Dif As Single = Math.Abs(Target_dG - OptimalP.dG)
                Dim dG_Dif As Single = 0

                For Each P As Primer In Primers
                    dG_Dif = Math.Abs(Target_dG - P.dG)
                    If dG_Dif < BestdG_Dif Then
                        OptimalP = P
                        BestdG_Dif = dG_Dif
                    End If
                Next P
            End If


            BestStickyRegion = New Genome_Feature
            BestStickyRegion.AbsoluteStart = OptimalP.Location
            BestStickyRegion.AbsoluteEnd = OptimalP.Location + OptimalP.Sequence.Length - 1
            BestStickyRegion.Description = "dG=" & OptimalP.dG & "; Tm=" & OptimalP.Tm
            BestStickyRegion.Type = 11

            If Not IsNothing(ReportOligo_dG_Distr) Then
                ReportOligo_dG_Distr.Add(OptimalP.dG)
            End If

            If Not IsNothing(ReportOligo_Tm_Distr) Then
                ReportOligo_Tm_Distr.Add(OptimalP.Tm)
            End If


        End If


        Return BestStickyRegion
    End Function

    Public Shared Function DesignPrimersForFragments(ByVal Sequence As String, ByVal FargmentName As String, _
                                                     Optional ByVal Target_Tm As Single = 60, _
                                                     Optional ByVal MinL As Integer = 15, _
                                                     Optional ByVal MaxL As Integer = 30, _
                                                     Optional ByVal TailName As String = "", _
                                                     Optional ByVal TailF As String = "", _
                                                     Optional ByVal TailR As String = "", Optional ByVal Add_No_Tail_Primers As Boolean = False)
        Dim CloningPrimers(1) As Genome_Feature

        If Add_No_Tail_Primers Then
            ReDim CloningPrimers(3)

            CloningPrimers(2) = New Genome_Feature
            CloningPrimers(2).TAG = FargmentName & "_T-F"
            CloningPrimers(2).Name = FargmentName & "_T-F"
            CloningPrimers(3) = New Genome_Feature
            CloningPrimers(3).TAG = FargmentName & "_T-R"
            CloningPrimers(3).Name = FargmentName & "_T-R"

        End If

        CloningPrimers(0) = New Genome_Feature
        CloningPrimers(0).TAG = FargmentName & "_P-F"
        CloningPrimers(0).Name = FargmentName & "_P-F"
        CloningPrimers(1) = New Genome_Feature
        CloningPrimers(1).TAG = FargmentName & "_P-R"
        CloningPrimers(1).Name = FargmentName & "_P-R"


        Dim Primers As New List(Of Primer)
        Dim CurrentSeq As String = ""

        For i = 0 To MaxL - MinL
            CurrentSeq = Sequence.Substring(0, MinL + i)
            Dim NewPrimer As New Primer
            NewPrimer.Location = 0
            NewPrimer.Sequence = CurrentSeq
            NewPrimer.Tm = Bioinformatics.CalculateOligoTm(CurrentSeq, )
            Primers.Add(NewPrimer)
        Next i

        Dim OptimalP As Primer = Primers(0)
        Dim BestTm_Dif As Single = Math.Abs(Target_Tm - OptimalP.Tm)
        Dim Tm_Dif As Single = 0

        For Each P As Primer In Primers
            Tm_Dif = Math.Abs(Target_Tm - P.Tm)
            If Tm_Dif < BestTm_Dif Then
                OptimalP = P
                BestTm_Dif = Tm_Dif
            End If
        Next P

        CloningPrimers(0).AbsoluteStart = OptimalP.Location + 1
        CloningPrimers(0).AbsoluteEnd = OptimalP.Location + OptimalP.Sequence.Length
        CloningPrimers(0).Description = "Forward; Tm=" & OptimalP.Tm
        'CloningPrimers(0).Sequence = OptimalP.Sequence
        CloningPrimers(0).Type = 8 '7
        CloningPrimers(0).Direction = 1

        If Add_No_Tail_Primers Then
            CloningPrimers(2).AbsoluteStart = OptimalP.Location + 1
            CloningPrimers(2).AbsoluteEnd = OptimalP.Location + OptimalP.Sequence.Length
            CloningPrimers(2).Description = "Forward; Tm=" & OptimalP.Tm
            CloningPrimers(2).Type = 8 '7
            CloningPrimers(2).Direction = 1
        End If


        If Not TailName = "" And Not TailF = "" Then
            CloningPrimers(0).TAG &= "_(" & TailName & ")"
            CloningPrimers(0).Name = CloningPrimers(0).TAG
            CloningPrimers(0).Sequence = TailF
        End If


        Primers.Clear()

        For i = Sequence.Length - MaxL To Sequence.Length - MinL
            CurrentSeq = Sequence.Substring(i)
            Dim NewPrimer As New Primer
            NewPrimer.Location = i
            NewPrimer.Sequence = CurrentSeq
            NewPrimer.Tm = Bioinformatics.CalculateOligoTm(CurrentSeq, )
            Primers.Add(NewPrimer)
        Next i

        OptimalP = Primers(0)
        BestTm_Dif = Math.Abs(Target_Tm - OptimalP.Tm)
        Tm_Dif = 0

        For Each P As Primer In Primers
            Tm_Dif = Math.Abs(Target_Tm - P.Tm)
            If Tm_Dif < BestTm_Dif Then
                OptimalP = P
                BestTm_Dif = Tm_Dif
            End If
        Next P

        CloningPrimers(1).AbsoluteStart = OptimalP.Location + 1
        CloningPrimers(1).AbsoluteEnd = OptimalP.Location + OptimalP.Sequence.Length
        CloningPrimers(1).Description = "Reverse; Tm=" & OptimalP.Tm
        'CloningPrimers(1).Sequence = Bioinformatics.GetReverseComplement(OptimalP.Sequence)
        CloningPrimers(1).Type = 8 '7
        CloningPrimers(1).Direction = 2

        If Add_No_Tail_Primers Then
            CloningPrimers(3).AbsoluteStart = OptimalP.Location + 1
            CloningPrimers(3).AbsoluteEnd = OptimalP.Location + OptimalP.Sequence.Length
            CloningPrimers(3).Description = "Reverse; Tm=" & OptimalP.Tm
            CloningPrimers(3).Type = 8 '7
            CloningPrimers(3).Direction = 2
        End If

        If Not TailName = "" And Not TailR = "" Then
            CloningPrimers(1).TAG &= "_(" & TailName & ")"
            CloningPrimers(1).Name = CloningPrimers(1).TAG
            CloningPrimers(1).Sequence = TailR
        End If

        Return CloningPrimers
    End Function

#End Region

End Class
