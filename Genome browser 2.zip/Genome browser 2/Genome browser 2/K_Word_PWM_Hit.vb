﻿Public Class K_Word_PWM_Hit
    Private SeqID As String = ""
    Private AlignedPos As Integer
    Private sglWeight As Single
    Private WordText As String = ""
    Private bBlocked As Boolean

    Public Property Aligned_Seq_ID() As String
        Get
            Aligned_Seq_ID = SeqID
        End Get
        Set(ByVal value As String)
            SeqID = value
        End Set
    End Property

    Public Property Aligned_Pos() As Integer
        Get
            Aligned_Pos = AlignedPos
        End Get
        Set(ByVal value As Integer)
            AlignedPos = value
        End Set
    End Property

    Public Property Aligned_Score() As Single
        Get
            Aligned_Score = sglWeight
        End Get
        Set(ByVal value As Single)
            sglWeight = value
        End Set
    End Property

    Public Property Word_Text() As String
        Get
            Word_Text = WordText
        End Get
        Set(ByVal value As String)
            WordText = value
        End Set
    End Property

    Public Property Is_Blocked() As Boolean
        Get
            Is_Blocked = bBlocked
        End Get
        Set(ByVal value As Boolean)
            bBlocked = value
        End Set
    End Property

End Class
