﻿Public Class TextInputBox
    Public Dir As Short = 0


    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        DialogResult = Windows.Forms.DialogResult.OK
        Dir = 0
        Me.Close()
    End Sub

    Private Sub EscButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EscButton.Click
        DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        SeqTextBox.Text = ""

    End Sub

    Private Sub SeqTextBox_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles SeqTextBox.KeyDown
        If e.KeyCode = Keys.A And e.Modifiers = Keys.Control Then
            SeqTextBox.SelectAll()
        End If

    End Sub

    Private Sub ForButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ForButton.Click
        DialogResult = Windows.Forms.DialogResult.OK
        Dir = 1
        Me.Close()
    End Sub

    Private Sub RevButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RevButton.Click
        DialogResult = Windows.Forms.DialogResult.OK
        Dir = 2
        Me.Close()
    End Sub
End Class