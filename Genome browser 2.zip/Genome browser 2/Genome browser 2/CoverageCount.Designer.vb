﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CoverageCount
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CoverageCount))
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.RefreshGroupsButton = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.RemoveItemButton = New System.Windows.Forms.Button
        Me.AddItemButton = New System.Windows.Forms.Button
        Me.AllRemoveButton = New System.Windows.Forms.Button
        Me.AllAddButton = New System.Windows.Forms.Button
        Me.AnalysisHolderListBox = New System.Windows.Forms.ListBox
        Me.AllHoldersListBox = New System.Windows.Forms.ListBox
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.CodingRadioButton = New System.Windows.Forms.RadioButton
        Me.AllLibRadioButton = New System.Windows.Forms.RadioButton
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.SourceComboBox = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.ASCheckBox = New System.Windows.Forms.CheckBox
        Me.GoButton = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.ScaleToMaxRadioButton = New System.Windows.Forms.RadioButton
        Me.ScaleIndipendentlyRadioButton = New System.Windows.Forms.RadioButton
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.RefreshGroupsButton)
        Me.GroupBox6.Controls.Add(Me.Label8)
        Me.GroupBox6.Controls.Add(Me.Label7)
        Me.GroupBox6.Controls.Add(Me.RemoveItemButton)
        Me.GroupBox6.Controls.Add(Me.AddItemButton)
        Me.GroupBox6.Controls.Add(Me.AllRemoveButton)
        Me.GroupBox6.Controls.Add(Me.AllAddButton)
        Me.GroupBox6.Controls.Add(Me.AnalysisHolderListBox)
        Me.GroupBox6.Controls.Add(Me.AllHoldersListBox)
        Me.GroupBox6.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(462, 150)
        Me.GroupBox6.TabIndex = 16
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Coverage profiles"
        '
        'RefreshGroupsButton
        '
        Me.RefreshGroupsButton.BackgroundImage = CType(resources.GetObject("RefreshGroupsButton.BackgroundImage"), System.Drawing.Image)
        Me.RefreshGroupsButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.RefreshGroupsButton.Location = New System.Drawing.Point(97, 18)
        Me.RefreshGroupsButton.Name = "RefreshGroupsButton"
        Me.RefreshGroupsButton.Size = New System.Drawing.Size(38, 23)
        Me.RefreshGroupsButton.TabIndex = 8
        Me.RefreshGroupsButton.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 28)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(88, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Available groups:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(253, 26)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(95, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Groups to analyze:"
        '
        'RemoveItemButton
        '
        Me.RemoveItemButton.BackgroundImage = CType(resources.GetObject("RemoveItemButton.BackgroundImage"), System.Drawing.Image)
        Me.RemoveItemButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.RemoveItemButton.Location = New System.Drawing.Point(212, 68)
        Me.RemoveItemButton.Name = "RemoveItemButton"
        Me.RemoveItemButton.Size = New System.Drawing.Size(38, 23)
        Me.RemoveItemButton.TabIndex = 5
        Me.RemoveItemButton.UseVisualStyleBackColor = True
        '
        'AddItemButton
        '
        Me.AddItemButton.BackgroundImage = CType(resources.GetObject("AddItemButton.BackgroundImage"), System.Drawing.Image)
        Me.AddItemButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.AddItemButton.Location = New System.Drawing.Point(212, 94)
        Me.AddItemButton.Name = "AddItemButton"
        Me.AddItemButton.Size = New System.Drawing.Size(38, 23)
        Me.AddItemButton.TabIndex = 4
        Me.AddItemButton.UseVisualStyleBackColor = True
        '
        'AllRemoveButton
        '
        Me.AllRemoveButton.BackgroundImage = CType(resources.GetObject("AllRemoveButton.BackgroundImage"), System.Drawing.Image)
        Me.AllRemoveButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.AllRemoveButton.Location = New System.Drawing.Point(212, 42)
        Me.AllRemoveButton.Name = "AllRemoveButton"
        Me.AllRemoveButton.Size = New System.Drawing.Size(38, 23)
        Me.AllRemoveButton.TabIndex = 3
        Me.AllRemoveButton.UseVisualStyleBackColor = True
        '
        'AllAddButton
        '
        Me.AllAddButton.BackgroundImage = CType(resources.GetObject("AllAddButton.BackgroundImage"), System.Drawing.Image)
        Me.AllAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.AllAddButton.Location = New System.Drawing.Point(212, 120)
        Me.AllAddButton.Name = "AllAddButton"
        Me.AllAddButton.Size = New System.Drawing.Size(38, 23)
        Me.AllAddButton.TabIndex = 2
        Me.AllAddButton.UseVisualStyleBackColor = True
        '
        'AnalysisHolderListBox
        '
        Me.AnalysisHolderListBox.FormattingEnabled = True
        Me.AnalysisHolderListBox.Location = New System.Drawing.Point(256, 44)
        Me.AnalysisHolderListBox.Name = "AnalysisHolderListBox"
        Me.AnalysisHolderListBox.Size = New System.Drawing.Size(200, 95)
        Me.AnalysisHolderListBox.TabIndex = 1
        '
        'AllHoldersListBox
        '
        Me.AllHoldersListBox.FormattingEnabled = True
        Me.AllHoldersListBox.Location = New System.Drawing.Point(6, 44)
        Me.AllHoldersListBox.Name = "AllHoldersListBox"
        Me.AllHoldersListBox.Size = New System.Drawing.Size(200, 95)
        Me.AllHoldersListBox.TabIndex = 0
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.CodingRadioButton)
        Me.GroupBox5.Controls.Add(Me.AllLibRadioButton)
        Me.GroupBox5.Location = New System.Drawing.Point(246, 168)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(228, 48)
        Me.GroupBox5.TabIndex = 18
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Library normalization method"
        '
        'CodingRadioButton
        '
        Me.CodingRadioButton.AutoSize = True
        Me.CodingRadioButton.Checked = True
        Me.CodingRadioButton.Location = New System.Drawing.Point(61, 19)
        Me.CodingRadioButton.Name = "CodingRadioButton"
        Me.CodingRadioButton.Size = New System.Drawing.Size(68, 17)
        Me.CodingRadioButton.TabIndex = 1
        Me.CodingRadioButton.TabStop = True
        Me.CodingRadioButton.Text = "All CDS's"
        Me.CodingRadioButton.UseVisualStyleBackColor = True
        '
        'AllLibRadioButton
        '
        Me.AllLibRadioButton.AutoSize = True
        Me.AllLibRadioButton.Location = New System.Drawing.Point(6, 19)
        Me.AllLibRadioButton.Name = "AllLibRadioButton"
        Me.AllLibRadioButton.Size = New System.Drawing.Size(49, 17)
        Me.AllLibRadioButton.TabIndex = 0
        Me.AllLibRadioButton.Text = "Total"
        Me.AllLibRadioButton.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.ASCheckBox)
        Me.GroupBox3.Controls.Add(Me.SourceComboBox)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 168)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(228, 123)
        Me.GroupBox3.TabIndex = 19
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Annotation"
        '
        'SourceComboBox
        '
        Me.SourceComboBox.FormattingEnabled = True
        Me.SourceComboBox.Items.AddRange(New Object() {"Main Features", "User Features"})
        Me.SourceComboBox.Location = New System.Drawing.Point(14, 37)
        Me.SourceComboBox.Name = "SourceComboBox"
        Me.SourceComboBox.Size = New System.Drawing.Size(121, 21)
        Me.SourceComboBox.TabIndex = 21
        Me.SourceComboBox.Text = "Main Features"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(11, 21)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 13)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Source of features:"
        '
        'ASCheckBox
        '
        Me.ASCheckBox.AutoSize = True
        Me.ASCheckBox.Location = New System.Drawing.Point(14, 64)
        Me.ASCheckBox.Name = "ASCheckBox"
        Me.ASCheckBox.Size = New System.Drawing.Size(150, 17)
        Me.ASCheckBox.TabIndex = 22
        Me.ASCheckBox.Text = "Count antisense coverage"
        Me.ASCheckBox.UseVisualStyleBackColor = True
        '
        'GoButton
        '
        Me.GoButton.Location = New System.Drawing.Point(399, 313)
        Me.GoButton.Name = "GoButton"
        Me.GoButton.Size = New System.Drawing.Size(75, 23)
        Me.GoButton.TabIndex = 20
        Me.GoButton.Text = "Go"
        Me.GoButton.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ScaleIndipendentlyRadioButton)
        Me.GroupBox1.Controls.Add(Me.ScaleToMaxRadioButton)
        Me.GroupBox1.Location = New System.Drawing.Point(246, 222)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(228, 69)
        Me.GroupBox1.TabIndex = 21
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Scaling factor"
        '
        'ScaleToMaxRadioButton
        '
        Me.ScaleToMaxRadioButton.AutoSize = True
        Me.ScaleToMaxRadioButton.Checked = True
        Me.ScaleToMaxRadioButton.Location = New System.Drawing.Point(6, 19)
        Me.ScaleToMaxRadioButton.Name = "ScaleToMaxRadioButton"
        Me.ScaleToMaxRadioButton.Size = New System.Drawing.Size(182, 17)
        Me.ScaleToMaxRadioButton.TabIndex = 0
        Me.ScaleToMaxRadioButton.TabStop = True
        Me.ScaleToMaxRadioButton.Text = "Normalize all datasets to max size"
        Me.ScaleToMaxRadioButton.UseVisualStyleBackColor = True
        '
        'ScaleIndipendentlyRadioButton
        '
        Me.ScaleIndipendentlyRadioButton.AutoSize = True
        Me.ScaleIndipendentlyRadioButton.Location = New System.Drawing.Point(6, 42)
        Me.ScaleIndipendentlyRadioButton.Name = "ScaleIndipendentlyRadioButton"
        Me.ScaleIndipendentlyRadioButton.Size = New System.Drawing.Size(182, 17)
        Me.ScaleIndipendentlyRadioButton.TabIndex = 1
        Me.ScaleIndipendentlyRadioButton.Text = "Normalize each dataset to its size"
        Me.ScaleIndipendentlyRadioButton.UseVisualStyleBackColor = True
        '
        'CoverageCount
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(484, 348)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GoButton)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox6)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "CoverageCount"
        Me.Text = "Count coverage"
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents RefreshGroupsButton As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents RemoveItemButton As System.Windows.Forms.Button
    Friend WithEvents AddItemButton As System.Windows.Forms.Button
    Friend WithEvents AllRemoveButton As System.Windows.Forms.Button
    Friend WithEvents AllAddButton As System.Windows.Forms.Button
    Friend WithEvents AnalysisHolderListBox As System.Windows.Forms.ListBox
    Friend WithEvents AllHoldersListBox As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents CodingRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents AllLibRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents SourceComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ASCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GoButton As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents ScaleIndipendentlyRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents ScaleToMaxRadioButton As System.Windows.Forms.RadioButton
End Class
