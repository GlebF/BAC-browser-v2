﻿Public Class SaveFileOptions

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitButton.Click
        DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class