﻿Public Class PositionalValuesChartControl

    Private Sub ColorButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorButton.Click
        If Master.ColorSelectDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            ColorPanel.BackColor = Master.ColorSelectDialog.Color
        End If
    End Sub

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        DialogResult = Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub CloseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseButton.Click
        DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub


End Class