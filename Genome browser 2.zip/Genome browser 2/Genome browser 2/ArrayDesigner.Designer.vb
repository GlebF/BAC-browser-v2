﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ArrayDesigner
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ArrayDesigner))
        Me.SourceComboBox = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.CDSOnlyCheckBox = New System.Windows.Forms.CheckBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.ProbeLengthTextBox = New System.Windows.Forms.TextBox
        Me.ProbeDGTextBox = New System.Windows.Forms.TextBox
        Me.ProbeDGRangeTextBox = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.ProbeSelfDGTextBox = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.XHybeTextBox = New System.Windows.Forms.TextBox
        Me.FinalProbesNumberTextBox = New System.Windows.Forms.TextBox
        Me.SearchProbesNumberTextBox = New System.Windows.Forms.TextBox
        Me.StructureTTextBox = New System.Windows.Forms.TextBox
        Me.MinFeatureLTextBox = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.XhybCheckBox = New System.Windows.Forms.CheckBox
        Me.GoButton = New System.Windows.Forms.Button
        Me.ReportLabel = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SourceComboBox
        '
        Me.SourceComboBox.FormattingEnabled = True
        Me.SourceComboBox.Items.AddRange(New Object() {"Main Features", "User Features"})
        Me.SourceComboBox.Location = New System.Drawing.Point(113, 19)
        Me.SourceComboBox.Name = "SourceComboBox"
        Me.SourceComboBox.Size = New System.Drawing.Size(121, 21)
        Me.SourceComboBox.TabIndex = 21
        Me.SourceComboBox.Text = "Main Features"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 13)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Source of features:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(107, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 13)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "Probe length:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(315, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 13)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Probe dG:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(285, 42)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(85, 13)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "Probe dG range:"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(422, 16)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(48, 13)
        Me.Label33.TabIndex = 25
        Me.Label33.Text = "kcal/mol"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(239, 68)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(131, 13)
        Me.Label5.TabIndex = 26
        Me.Label5.Text = "Probe self-anneal max dG:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(16, 94)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(161, 13)
        Me.Label6.TabIndex = 27
        Me.Label6.Text = "Probe max cross-hyb identity (%):"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(72, 42)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(105, 13)
        Me.Label7.TabIndex = 28
        Me.Label7.Text = "Final probes number:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(60, 68)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(117, 13)
        Me.Label8.TabIndex = 29
        Me.Label8.Text = "Search probes number:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(256, 23)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(113, 13)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "Minimal feature length:"
        '
        'CDSOnlyCheckBox
        '
        Me.CDSOnlyCheckBox.AutoSize = True
        Me.CDSOnlyCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CDSOnlyCheckBox.Checked = True
        Me.CDSOnlyCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CDSOnlyCheckBox.Location = New System.Drawing.Point(98, 46)
        Me.CDSOnlyCheckBox.Name = "CDSOnlyCheckBox"
        Me.CDSOnlyCheckBox.Size = New System.Drawing.Size(136, 17)
        Me.CDSOnlyCheckBox.TabIndex = 31
        Me.CDSOnlyCheckBox.Text = "Coding sequences only"
        Me.CDSOnlyCheckBox.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(255, 94)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(115, 13)
        Me.Label10.TabIndex = 32
        Me.Label10.Text = "Secondary structure T:"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(422, 94)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(14, 13)
        Me.Label25.TabIndex = 33
        Me.Label25.Text = "C"
        '
        'ProbeLengthTextBox
        '
        Me.ProbeLengthTextBox.Location = New System.Drawing.Point(183, 13)
        Me.ProbeLengthTextBox.Name = "ProbeLengthTextBox"
        Me.ProbeLengthTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ProbeLengthTextBox.TabIndex = 34
        Me.ProbeLengthTextBox.Text = "60"
        '
        'ProbeDGTextBox
        '
        Me.ProbeDGTextBox.Location = New System.Drawing.Point(376, 13)
        Me.ProbeDGTextBox.Name = "ProbeDGTextBox"
        Me.ProbeDGTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ProbeDGTextBox.TabIndex = 35
        Me.ProbeDGTextBox.Text = "-65"
        '
        'ProbeDGRangeTextBox
        '
        Me.ProbeDGRangeTextBox.Location = New System.Drawing.Point(376, 39)
        Me.ProbeDGRangeTextBox.Name = "ProbeDGRangeTextBox"
        Me.ProbeDGRangeTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ProbeDGRangeTextBox.TabIndex = 36
        Me.ProbeDGRangeTextBox.Text = "2"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(422, 42)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(48, 13)
        Me.Label11.TabIndex = 37
        Me.Label11.Text = "kcal/mol"
        '
        'ProbeSelfDGTextBox
        '
        Me.ProbeSelfDGTextBox.Location = New System.Drawing.Point(376, 65)
        Me.ProbeSelfDGTextBox.Name = "ProbeSelfDGTextBox"
        Me.ProbeSelfDGTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ProbeSelfDGTextBox.TabIndex = 38
        Me.ProbeSelfDGTextBox.Text = "-3"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(422, 68)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(48, 13)
        Me.Label12.TabIndex = 39
        Me.Label12.Text = "kcal/mol"
        '
        'XHybeTextBox
        '
        Me.XHybeTextBox.Location = New System.Drawing.Point(183, 91)
        Me.XHybeTextBox.Name = "XHybeTextBox"
        Me.XHybeTextBox.Size = New System.Drawing.Size(40, 20)
        Me.XHybeTextBox.TabIndex = 40
        Me.XHybeTextBox.Text = "0,8"
        '
        'FinalProbesNumberTextBox
        '
        Me.FinalProbesNumberTextBox.Location = New System.Drawing.Point(183, 39)
        Me.FinalProbesNumberTextBox.Name = "FinalProbesNumberTextBox"
        Me.FinalProbesNumberTextBox.Size = New System.Drawing.Size(40, 20)
        Me.FinalProbesNumberTextBox.TabIndex = 41
        Me.FinalProbesNumberTextBox.Text = "5"
        '
        'SearchProbesNumberTextBox
        '
        Me.SearchProbesNumberTextBox.Location = New System.Drawing.Point(183, 65)
        Me.SearchProbesNumberTextBox.Name = "SearchProbesNumberTextBox"
        Me.SearchProbesNumberTextBox.Size = New System.Drawing.Size(40, 20)
        Me.SearchProbesNumberTextBox.TabIndex = 42
        Me.SearchProbesNumberTextBox.Text = "10"
        '
        'StructureTTextBox
        '
        Me.StructureTTextBox.Location = New System.Drawing.Point(376, 91)
        Me.StructureTTextBox.Name = "StructureTTextBox"
        Me.StructureTTextBox.Size = New System.Drawing.Size(40, 20)
        Me.StructureTTextBox.TabIndex = 43
        Me.StructureTTextBox.Text = "37"
        '
        'MinFeatureLTextBox
        '
        Me.MinFeatureLTextBox.Location = New System.Drawing.Point(375, 20)
        Me.MinFeatureLTextBox.Name = "MinFeatureLTextBox"
        Me.MinFeatureLTextBox.Size = New System.Drawing.Size(40, 20)
        Me.MinFeatureLTextBox.TabIndex = 44
        Me.MinFeatureLTextBox.Text = "100"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.SourceComboBox)
        Me.GroupBox1.Controls.Add(Me.MinFeatureLTextBox)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.CDSOnlyCheckBox)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(482, 75)
        Me.GroupBox1.TabIndex = 45
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Features"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.XhybCheckBox)
        Me.GroupBox2.Controls.Add(Me.ProbeLengthTextBox)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.StructureTTextBox)
        Me.GroupBox2.Controls.Add(Me.Label25)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.XHybeTextBox)
        Me.GroupBox2.Controls.Add(Me.SearchProbesNumberTextBox)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.ProbeSelfDGTextBox)
        Me.GroupBox2.Controls.Add(Me.FinalProbesNumberTextBox)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.ProbeDGTextBox)
        Me.GroupBox2.Controls.Add(Me.ProbeDGRangeTextBox)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label33)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 93)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(482, 142)
        Me.GroupBox2.TabIndex = 46
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Probes"
        '
        'XhybCheckBox
        '
        Me.XhybCheckBox.AutoSize = True
        Me.XhybCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.XhybCheckBox.Checked = True
        Me.XhybCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.XhybCheckBox.Location = New System.Drawing.Point(77, 117)
        Me.XhybCheckBox.Name = "XhybCheckBox"
        Me.XhybCheckBox.Size = New System.Drawing.Size(146, 17)
        Me.XhybCheckBox.TabIndex = 44
        Me.XhybCheckBox.Text = "Check cross-hybridization"
        Me.XhybCheckBox.UseVisualStyleBackColor = True
        '
        'GoButton
        '
        Me.GoButton.Location = New System.Drawing.Point(421, 241)
        Me.GoButton.Name = "GoButton"
        Me.GoButton.Size = New System.Drawing.Size(75, 23)
        Me.GoButton.TabIndex = 47
        Me.GoButton.Text = "Go"
        Me.GoButton.UseVisualStyleBackColor = True
        '
        'ReportLabel
        '
        Me.ReportLabel.AutoSize = True
        Me.ReportLabel.Location = New System.Drawing.Point(9, 246)
        Me.ReportLabel.Name = "ReportLabel"
        Me.ReportLabel.Size = New System.Drawing.Size(38, 13)
        Me.ReportLabel.TabIndex = 48
        Me.ReportLabel.Text = "Ready"
        '
        'ArrayDesigner
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(508, 275)
        Me.Controls.Add(Me.ReportLabel)
        Me.Controls.Add(Me.GoButton)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "ArrayDesigner"
        Me.Text = "Array Designer"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SourceComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents CDSOnlyCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents ProbeLengthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProbeDGTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProbeDGRangeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents ProbeSelfDGTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents XHybeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FinalProbesNumberTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SearchProbesNumberTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StructureTTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MinFeatureLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GoButton As System.Windows.Forms.Button
    Friend WithEvents ReportLabel As System.Windows.Forms.Label
    Friend WithEvents XhybCheckBox As System.Windows.Forms.CheckBox
End Class
