﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AlignmentSearchTool
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AlignmentSearchTool))
        Me.QueryTextBox = New System.Windows.Forms.TextBox
        Me.FindButton = New System.Windows.Forms.Button
        Me.K_W_LengthTextBox = New System.Windows.Forms.TextBox
        Me.MinHitsTextBox = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.MinAlignedIdentityTextBox = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.TerDistTextBox = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.MinTotalIdentityTextBox = New System.Windows.Forms.TextBox
        Me.MainSplitContainer = New System.Windows.Forms.SplitContainer
        Me.DataSplitContainer = New System.Windows.Forms.SplitContainer
        Me.ClearButton = New System.Windows.Forms.Button
        Me.WNumLabel = New System.Windows.Forms.Label
        Me.MinHitsLabel = New System.Windows.Forms.Label
        Me.TCLabel = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.SizeTextBox = New System.Windows.Forms.TextBox
        Me.IndicatorLabel = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.MinAlignTextBox = New System.Windows.Forms.TextBox
        Me.MainSplitContainer.Panel1.SuspendLayout()
        Me.MainSplitContainer.Panel2.SuspendLayout()
        Me.MainSplitContainer.SuspendLayout()
        Me.DataSplitContainer.Panel1.SuspendLayout()
        Me.DataSplitContainer.SuspendLayout()
        Me.SuspendLayout()
        '
        'QueryTextBox
        '
        Me.QueryTextBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.QueryTextBox.Location = New System.Drawing.Point(0, 0)
        Me.QueryTextBox.Multiline = True
        Me.QueryTextBox.Name = "QueryTextBox"
        Me.QueryTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.QueryTextBox.Size = New System.Drawing.Size(852, 77)
        Me.QueryTextBox.TabIndex = 0
        '
        'FindButton
        '
        Me.FindButton.Location = New System.Drawing.Point(765, 115)
        Me.FindButton.Name = "FindButton"
        Me.FindButton.Size = New System.Drawing.Size(75, 23)
        Me.FindButton.TabIndex = 1
        Me.FindButton.Text = "Find"
        Me.FindButton.UseVisualStyleBackColor = True
        '
        'K_W_LengthTextBox
        '
        Me.K_W_LengthTextBox.Location = New System.Drawing.Point(223, 37)
        Me.K_W_LengthTextBox.Name = "K_W_LengthTextBox"
        Me.K_W_LengthTextBox.Size = New System.Drawing.Size(40, 20)
        Me.K_W_LengthTextBox.TabIndex = 2
        Me.K_W_LengthTextBox.Text = "11"
        '
        'MinHitsTextBox
        '
        Me.MinHitsTextBox.Location = New System.Drawing.Point(629, 89)
        Me.MinHitsTextBox.Name = "MinHitsTextBox"
        Me.MinHitsTextBox.Size = New System.Drawing.Size(40, 20)
        Me.MinHitsTextBox.TabIndex = 3
        Me.MinHitsTextBox.Text = "5"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(149, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Word length:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(553, 92)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Minimum hits:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(44, 66)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(173, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Minimum aligned region identity (%):"
        '
        'MinAlignedIdentityTextBox
        '
        Me.MinAlignedIdentityTextBox.Location = New System.Drawing.Point(223, 63)
        Me.MinAlignedIdentityTextBox.Name = "MinAlignedIdentityTextBox"
        Me.MinAlignedIdentityTextBox.Size = New System.Drawing.Size(40, 20)
        Me.MinAlignedIdentityTextBox.TabIndex = 8
        Me.MinAlignedIdentityTextBox.Text = "90"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(515, 66)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(108, 13)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "Termination distance:"
        '
        'TerDistTextBox
        '
        Me.TerDistTextBox.Location = New System.Drawing.Point(629, 63)
        Me.TerDistTextBox.Name = "TerDistTextBox"
        Me.TerDistTextBox.Size = New System.Drawing.Size(40, 20)
        Me.TerDistTextBox.TabIndex = 16
        Me.TerDistTextBox.Text = "50"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(13, 92)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(204, 13)
        Me.Label7.TabIndex = 19
        Me.Label7.Text = "Minimum total query identity coverage (%):"
        '
        'MinTotalIdentityTextBox
        '
        Me.MinTotalIdentityTextBox.Location = New System.Drawing.Point(223, 89)
        Me.MinTotalIdentityTextBox.Name = "MinTotalIdentityTextBox"
        Me.MinTotalIdentityTextBox.Size = New System.Drawing.Size(40, 20)
        Me.MinTotalIdentityTextBox.TabIndex = 18
        Me.MinTotalIdentityTextBox.Text = "90"
        '
        'MainSplitContainer
        '
        Me.MainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MainSplitContainer.Location = New System.Drawing.Point(0, 0)
        Me.MainSplitContainer.Name = "MainSplitContainer"
        Me.MainSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'MainSplitContainer.Panel1
        '
        Me.MainSplitContainer.Panel1.Controls.Add(Me.DataSplitContainer)
        '
        'MainSplitContainer.Panel2
        '
        Me.MainSplitContainer.Panel2.Controls.Add(Me.Label3)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.MinAlignTextBox)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.ClearButton)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.WNumLabel)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.MinHitsLabel)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.TCLabel)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.Label8)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.SizeTextBox)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.IndicatorLabel)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.Label7)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.FindButton)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.MinTotalIdentityTextBox)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.K_W_LengthTextBox)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.Label6)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.MinHitsTextBox)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.TerDistTextBox)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.Label1)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.Label2)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.MinAlignedIdentityTextBox)
        Me.MainSplitContainer.Panel2.Controls.Add(Me.Label4)
        Me.MainSplitContainer.Size = New System.Drawing.Size(852, 412)
        Me.MainSplitContainer.SplitterDistance = 258
        Me.MainSplitContainer.TabIndex = 20
        '
        'DataSplitContainer
        '
        Me.DataSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataSplitContainer.Location = New System.Drawing.Point(0, 0)
        Me.DataSplitContainer.Name = "DataSplitContainer"
        Me.DataSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'DataSplitContainer.Panel1
        '
        Me.DataSplitContainer.Panel1.Controls.Add(Me.QueryTextBox)
        '
        'DataSplitContainer.Panel2
        '
        Me.DataSplitContainer.Panel2.AutoScroll = True
        Me.DataSplitContainer.Size = New System.Drawing.Size(852, 258)
        Me.DataSplitContainer.SplitterDistance = 77
        Me.DataSplitContainer.TabIndex = 0
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(765, 9)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(75, 23)
        Me.ClearButton.TabIndex = 28
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'WNumLabel
        '
        Me.WNumLabel.AutoSize = True
        Me.WNumLabel.Location = New System.Drawing.Point(269, 40)
        Me.WNumLabel.Name = "WNumLabel"
        Me.WNumLabel.Size = New System.Drawing.Size(13, 13)
        Me.WNumLabel.TabIndex = 27
        Me.WNumLabel.Text = "0"
        '
        'MinHitsLabel
        '
        Me.MinHitsLabel.AutoSize = True
        Me.MinHitsLabel.Location = New System.Drawing.Point(675, 92)
        Me.MinHitsLabel.Name = "MinHitsLabel"
        Me.MinHitsLabel.Size = New System.Drawing.Size(13, 13)
        Me.MinHitsLabel.TabIndex = 26
        Me.MinHitsLabel.Text = "0"
        '
        'TCLabel
        '
        Me.TCLabel.AutoSize = True
        Me.TCLabel.Location = New System.Drawing.Point(269, 92)
        Me.TCLabel.Name = "TCLabel"
        Me.TCLabel.Size = New System.Drawing.Size(13, 13)
        Me.TCLabel.TabIndex = 23
        Me.TCLabel.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(158, 14)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 13)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "Query size:"
        '
        'SizeTextBox
        '
        Me.SizeTextBox.Location = New System.Drawing.Point(223, 11)
        Me.SizeTextBox.Name = "SizeTextBox"
        Me.SizeTextBox.ReadOnly = True
        Me.SizeTextBox.Size = New System.Drawing.Size(40, 20)
        Me.SizeTextBox.TabIndex = 21
        '
        'IndicatorLabel
        '
        Me.IndicatorLabel.AutoSize = True
        Me.IndicatorLabel.Location = New System.Drawing.Point(12, 125)
        Me.IndicatorLabel.Name = "IndicatorLabel"
        Me.IndicatorLabel.Size = New System.Drawing.Size(41, 13)
        Me.IndicatorLabel.TabIndex = 20
        Me.IndicatorLabel.Text = "Ready!"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(492, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(131, 13)
        Me.Label3.TabIndex = 30
        Me.Label3.Text = "Minimum alignment length:"
        '
        'MinAlignTextBox
        '
        Me.MinAlignTextBox.Location = New System.Drawing.Point(629, 37)
        Me.MinAlignTextBox.Name = "MinAlignTextBox"
        Me.MinAlignTextBox.Size = New System.Drawing.Size(40, 20)
        Me.MinAlignTextBox.TabIndex = 29
        Me.MinAlignTextBox.Text = "30"
        '
        'AlignmentSearchTool
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(852, 412)
        Me.Controls.Add(Me.MainSplitContainer)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "AlignmentSearchTool"
        Me.Text = "Nucleotide sequence search"
        Me.MainSplitContainer.Panel1.ResumeLayout(False)
        Me.MainSplitContainer.Panel2.ResumeLayout(False)
        Me.MainSplitContainer.Panel2.PerformLayout()
        Me.MainSplitContainer.ResumeLayout(False)
        Me.DataSplitContainer.Panel1.ResumeLayout(False)
        Me.DataSplitContainer.Panel1.PerformLayout()
        Me.DataSplitContainer.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents QueryTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FindButton As System.Windows.Forms.Button
    Friend WithEvents K_W_LengthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MinHitsTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents MinAlignedIdentityTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TerDistTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents MinTotalIdentityTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MainSplitContainer As System.Windows.Forms.SplitContainer
    Friend WithEvents DataSplitContainer As System.Windows.Forms.SplitContainer
    Friend WithEvents IndicatorLabel As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents SizeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TCLabel As System.Windows.Forms.Label
    Friend WithEvents MinHitsLabel As System.Windows.Forms.Label
    Friend WithEvents WNumLabel As System.Windows.Forms.Label
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents MinAlignTextBox As System.Windows.Forms.TextBox
End Class
