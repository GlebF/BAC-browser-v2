﻿Public Class AlignmentSearchTool
    Public MyGenomeViewer As Genome_Viewer = Nothing
    Public MyName As String = "Local Alignment Search Tool"
    Public Shared Counter As Integer = 0
    Dim TmpAlignmentList As New List(Of RBLAST_Graphics)

    Private Sub ExecuteIndexedSearch(ByVal GenomeIndex As List(Of K_Word_Hashed), ByVal QueryIndex As List(Of K_Word_Hashed), ByVal ReverseDirection As Boolean)


        Dim AssemblyList As New List(Of Subject_Based_Assembly)
        AssemblyList = Bioinformatics.Assemble_Indexed_Map(GenomeIndex, QueryIndex, TerDistTextBox.Text, MinHitsTextBox.Text, MinAlignTextBox.Text, IndicatorLabel)


        Dim Query As String = QueryTextBox.Text
        If ReverseDirection Then
            Query = Bioinformatics.GetReverseComplement(QueryTextBox.Text)
        End If


        Dim Report As String = ""

        IndicatorLabel.Text = "Preparing alignments: " & AssemblyList.Count
        IndicatorLabel.Refresh()

        For i = 0 To AssemblyList.Count - 1

            Dim NewRBLASTGraphics As New RBLAST_Graphics(Bioinformatics.AssembleAlignment(AssemblyList(i), MyGenomeViewer.Genome_Sequence, Query, K_W_LengthTextBox.Text), _
                                                         QueryTextBox.Text, ReverseDirection, Counter, MyGenomeViewer)

            If NewRBLASTGraphics.Total_Identity >= MinTotalIdentityTextBox.Text And NewRBLASTGraphics.Aligned_Identity >= MinAlignedIdentityTextBox.Text Then
                NewRBLASTGraphics.Dock = DockStyle.Top
                NewRBLASTGraphics.CreateText()
                TmpAlignmentList.Add(NewRBLASTGraphics)
                Counter += 1

                Report &= NewRBLASTGraphics.Name & " - " & NewRBLASTGraphics.Total_Identity & Environment.NewLine
            End If

        Next

    End Sub

    'Private Sub ExecuteSearch(ByVal Query As String, ByVal ReverseDirection As Boolean, ByVal MinQCover As Integer, ByVal MinSCover As Integer)


    'Dim AssemblyList As New List(Of Subject_Based_Assembly)
    'AssemblyList = Bioinformatics.Assemble_Hashed_Map(MyGenomeViewer.Genome_Sequence, Query, K_W_LengthTextBox.Text, TerDistTextBox.Text, MinHitsTextBox.Text, 30, , , IndicatorLabel) 'Bioinformatics.Assemble_Hit_Map_Subject_Based(MyGenomeViewer.Genome_Sequence, Query, K_W_LengthTextBox.Text, TerDistTextBox.Text, MinHitsTextBox.Text, MinQCover, MinSCover, , , IndicatorLabel)

    'Dim Report As String = ""

    'For i = 0 To AssemblyList.Count - 1

    'Dim NewRBLASTGraphics As New RBLAST_Graphics(Bioinformatics.AssembleAlignment(AssemblyList(i), MyGenomeViewer.Genome_Sequence, Query, K_W_LengthTextBox.Text), _
    'QueryTextBox.Text, ReverseDirection, Counter, MyGenomeViewer)

    'If NewRBLASTGraphics.Total_Identity >= MinTotalIdentityTextBox.Text And NewRBLASTGraphics.Aligned_Identity >= MinAlignedIdentityTextBox.Text Then
    'NewRBLASTGraphics.Dock = DockStyle.Top
    'NewRBLASTGraphics.CreateText()
    'TmpAlignmentList.Add(NewRBLASTGraphics)
    'Counter += 1

    'Report &= NewRBLASTGraphics.Name & " - " & NewRBLASTGraphics.Total_Identity & Environment.NewLine
    'End If

    'Next


    'End Sub

    Private Sub AlignmentSearchTool_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        QueryTextBox.Text = ""

    End Sub

    Private Sub FindButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindButton.Click
        TmpAlignmentList.Clear()
        DataSplitContainer.Panel2.Controls.Clear()

        IndicatorLabel.Text = "Indexing genome"
        IndicatorLabel.Refresh()
        Dim Word_Length As Integer = K_W_LengthTextBox.Text
        Dim GenomeIndex As List(Of K_Word_Hashed) = Bioinformatics.Make_K_Word_Hash(MyGenomeViewer.Genome_Sequence, Word_Length)

        IndicatorLabel.Text = "Indexing query"
        IndicatorLabel.Refresh()

        Dim ForQueryIndex As List(Of K_Word_Hashed) = Bioinformatics.Make_K_Word_Hash(QueryTextBox.Text, Word_Length)
        Dim RevQueryIndex As List(Of K_Word_Hashed) = Bioinformatics.Make_K_Word_Hash(Bioinformatics.GetReverseComplement(QueryTextBox.Text), Word_Length)

        IndicatorLabel.Text = "Launching aligner on plus strand"
        IndicatorLabel.Refresh()
        ExecuteIndexedSearch(GenomeIndex, ForQueryIndex, False)

        'Clear genome index before next use
        For i = 0 To GenomeIndex.Count - 1
            GenomeIndex(i).Aligned_Positions.Clear()
        Next

        IndicatorLabel.Text = "Launching aligner on minus strand"
        IndicatorLabel.Refresh()
        ExecuteIndexedSearch(GenomeIndex, RevQueryIndex, True)


        'IndicatorLabel.Text = "Launching aligner on plus strand!"
        'IndicatorLabel.Refresh()
        'ExecuteSearch(QueryTextBox.Text, False, MinQCover, MinSCover)
        'IndicatorLabel.Text = "Launching aligner on minus strand!"
        'IndicatorLabel.Refresh()
        'ExecuteSearch(Bioinformatics.GetReverseComplement(QueryTextBox.Text), True, MinQCover, MinSCover)

        Dim Tmp As RBLAST_Graphics = Nothing
        For i = 1 To TmpAlignmentList.Count - 1
            For j = 0 To TmpAlignmentList.Count - 1 - i
                If TmpAlignmentList(j).Total_Identity > TmpAlignmentList(j + 1).Total_Identity Then
                    Tmp = TmpAlignmentList(j)
                    TmpAlignmentList(j) = TmpAlignmentList(j + 1)
                    TmpAlignmentList(j + 1) = Tmp
                End If
            Next
        Next

        For i = 0 To TmpAlignmentList.Count - 1
            DataSplitContainer.Panel2.Controls.Add(TmpAlignmentList(i))
        Next

        IndicatorLabel.Text = "Ready!"

    End Sub

    Private Sub QueryTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QueryTextBox.TextChanged
        If Not QueryTextBox.Text = "" Then
            Try
                QueryTextBox.Text = QueryTextBox.Text.Replace(Chr(13), vbNullString)
                QueryTextBox.Text = QueryTextBox.Text.Replace(Chr(10), vbNullString)
                QueryTextBox.Text = QueryTextBox.Text.ToUpper()

                SizeTextBox.Text = QueryTextBox.Text.Length
                TCLabel.Text = Math.Round(QueryTextBox.Text.Length * MinTotalIdentityTextBox.Text / 100, 0) & " out of " & QueryTextBox.Text.Length
                MinHitsLabel.Text = "Out of " & QueryTextBox.Text.Length - K_W_LengthTextBox.Text
                WNumLabel.Text = "Total: " & QueryTextBox.Text.Length - K_W_LengthTextBox.Text
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub K_W_LengthTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles K_W_LengthTextBox.TextChanged
        If Not K_W_LengthTextBox.Text = "" Then
            Try
                MinHitsLabel.Text = "Out of " & QueryTextBox.Text.Length - K_W_LengthTextBox.Text
                WNumLabel.Text = "Total: " & QueryTextBox.Text.Length - K_W_LengthTextBox.Text
            Catch ex As Exception

            End Try
        End If
    End Sub

    Private Sub MinTotalIdentityTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MinTotalIdentityTextBox.TextChanged
        Try
            TCLabel.Text = Math.Round(QueryTextBox.Text.Length * MinTotalIdentityTextBox.Text / 100, 0) & " out of " & QueryTextBox.Text.Length
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        QueryTextBox.Text = ""

    End Sub
End Class