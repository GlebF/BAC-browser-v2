﻿Public Class Aligned_dG_block

    Private sgdG As Single = 0
    Private sgTm As Single = 0
    Private intStart As Integer = 0
    Private intEnd As Integer = 0
    Private sgdG_distance As Single = 0

    Public Property dG() As Single
        Get
            dG = sgdG
        End Get
        Set(ByVal value As Single)
            sgdG = value
        End Set
    End Property

    Public Property Tm() As Single
        Get
            Tm = sgTm
        End Get
        Set(ByVal value As Single)
            sgTm = value
        End Set
    End Property

    Public Property BlockStart() As Integer
        Get
            BlockStart = intStart
        End Get
        Set(ByVal value As Integer)
            intStart = value
        End Set
    End Property

    Public Property BlockEnd() As Integer
        Get
            BlockEnd = intEnd
        End Get
        Set(ByVal value As Integer)
            intEnd = value
        End Set
    End Property

    Public Property dG_Distance() As Single
        Get
            dG_Distance = sgdG_distance
        End Get
        Set(ByVal value As Single)
            sgdG_distance = value
        End Set
    End Property

End Class
