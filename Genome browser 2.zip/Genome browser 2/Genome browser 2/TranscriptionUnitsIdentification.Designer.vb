﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TranscriptionUnitsIdentification
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TranscriptionUnitsIdentification))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.TSSAsymmetryCheckBox = New System.Windows.Forms.CheckBox
        Me.TSSDropLengthTextBox = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.TSSDropTresholdTextBox = New System.Windows.Forms.TextBox
        Me.TSSFiltrationWindowTextBox = New System.Windows.Forms.TextBox
        Me.TSSIdentificationWindowTextBox = New System.Windows.Forms.TextBox
        Me.TSSBackgroundTextBox = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.GroupFiltrationTextBox = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.MinimalIntervalCoverageTextBox = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.NormTextBox = New System.Windows.Forms.TextBox
        Me.RemoveLowIntervalsCheckBox = New System.Windows.Forms.CheckBox
        Me.RemoveBackgroundCheckBox = New System.Windows.Forms.CheckBox
        Me.BackgroundWindowTextBox = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.BackgroundCoverageTextBox = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.SmoothingTextBox = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.TermCDSCorrectionTextBox = New System.Windows.Forms.TextBox
        Me.TermCDSCorrectionCheckBox = New System.Windows.Forms.CheckBox
        Me.TermFiltrationWindowTextBox = New System.Windows.Forms.TextBox
        Me.TermIdentificationWindowTextBox = New System.Windows.Forms.TextBox
        Me.TermBackgroundTextBox = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.NoIntervalFiltrationRadioButton = New System.Windows.Forms.RadioButton
        Me.SDFiltrationTextBox = New System.Windows.Forms.TextBox
        Me.SDIntervalFiltrationRadioButton = New System.Windows.Forms.RadioButton
        Me.GoButton = New System.Windows.Forms.Button
        Me.StatusLabelPlus = New System.Windows.Forms.Label
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.RefreshGroupsButton = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.RemoveItemButton = New System.Windows.Forms.Button
        Me.AddItemButton = New System.Windows.Forms.Button
        Me.AllRemoveButton = New System.Windows.Forms.Button
        Me.AllAddButton = New System.Windows.Forms.Button
        Me.AnalysisHolderListBox = New System.Windows.Forms.ListBox
        Me.AllHoldersListBox = New System.Windows.Forms.ListBox
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.BlocksCheckBox = New System.Windows.Forms.CheckBox
        Me.TSSandTTCheckBox = New System.Windows.Forms.CheckBox
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.NoNormRadioButton = New System.Windows.Forms.RadioButton
        Me.CodingRadioButton = New System.Windows.Forms.RadioButton
        Me.AllLibRadioButton = New System.Windows.Forms.RadioButton
        Me.StatusLabelMinus = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TSSAsymmetryCheckBox)
        Me.GroupBox1.Controls.Add(Me.TSSDropLengthTextBox)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.TSSDropTresholdTextBox)
        Me.GroupBox1.Controls.Add(Me.TSSFiltrationWindowTextBox)
        Me.GroupBox1.Controls.Add(Me.TSSIdentificationWindowTextBox)
        Me.GroupBox1.Controls.Add(Me.TSSBackgroundTextBox)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(480, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(228, 190)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Promoters (TSS's) identification"
        '
        'TSSAsymmetryCheckBox
        '
        Me.TSSAsymmetryCheckBox.AutoSize = True
        Me.TSSAsymmetryCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TSSAsymmetryCheckBox.Checked = True
        Me.TSSAsymmetryCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.TSSAsymmetryCheckBox.Location = New System.Drawing.Point(60, 149)
        Me.TSSAsymmetryCheckBox.Name = "TSSAsymmetryCheckBox"
        Me.TSSAsymmetryCheckBox.Size = New System.Drawing.Size(156, 17)
        Me.TSSAsymmetryCheckBox.TabIndex = 14
        Me.TSSAsymmetryCheckBox.Text = "Peak asymmetry correction:"
        Me.TSSAsymmetryCheckBox.UseVisualStyleBackColor = True
        '
        'TSSDropLengthTextBox
        '
        Me.TSSDropLengthTextBox.Location = New System.Drawing.Point(166, 97)
        Me.TSSDropLengthTextBox.Name = "TSSDropLengthTextBox"
        Me.TSSDropLengthTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TSSDropLengthTextBox.TabIndex = 8
        Me.TSSDropLengthTextBox.Text = "40"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(61, 100)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(99, 13)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Asymmetry window:"
        '
        'TSSDropTresholdTextBox
        '
        Me.TSSDropTresholdTextBox.Location = New System.Drawing.Point(166, 123)
        Me.TSSDropTresholdTextBox.Name = "TSSDropTresholdTextBox"
        Me.TSSDropTresholdTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TSSDropTresholdTextBox.TabIndex = 9
        Me.TSSDropTresholdTextBox.Text = "0,7"
        '
        'TSSFiltrationWindowTextBox
        '
        Me.TSSFiltrationWindowTextBox.Location = New System.Drawing.Point(166, 71)
        Me.TSSFiltrationWindowTextBox.Name = "TSSFiltrationWindowTextBox"
        Me.TSSFiltrationWindowTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TSSFiltrationWindowTextBox.TabIndex = 7
        Me.TSSFiltrationWindowTextBox.Text = "40"
        '
        'TSSIdentificationWindowTextBox
        '
        Me.TSSIdentificationWindowTextBox.Location = New System.Drawing.Point(166, 45)
        Me.TSSIdentificationWindowTextBox.Name = "TSSIdentificationWindowTextBox"
        Me.TSSIdentificationWindowTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TSSIdentificationWindowTextBox.TabIndex = 6
        Me.TSSIdentificationWindowTextBox.Text = "20"
        '
        'TSSBackgroundTextBox
        '
        Me.TSSBackgroundTextBox.Location = New System.Drawing.Point(166, 19)
        Me.TSSBackgroundTextBox.Name = "TSSBackgroundTextBox"
        Me.TSSBackgroundTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TSSBackgroundTextBox.TabIndex = 5
        Me.TSSBackgroundTextBox.Text = "10"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(30, 126)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(130, 13)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Asymmetry drop threshold:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(47, 74)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(113, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Peak filtration window:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(24, 48)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(136, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Peak identification window:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(92, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Background:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.GroupFiltrationTextBox)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.MinimalIntervalCoverageTextBox)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.NormTextBox)
        Me.GroupBox3.Controls.Add(Me.RemoveLowIntervalsCheckBox)
        Me.GroupBox3.Controls.Add(Me.RemoveBackgroundCheckBox)
        Me.GroupBox3.Controls.Add(Me.BackgroundWindowTextBox)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.BackgroundCoverageTextBox)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.SmoothingTextBox)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 168)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(228, 230)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Coverage analysis"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(13, 198)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(153, 13)
        Me.Label17.TabIndex = 21
        Me.Label17.Text = "Multiple peaks merge distance:"
        '
        'GroupFiltrationTextBox
        '
        Me.GroupFiltrationTextBox.Location = New System.Drawing.Point(172, 195)
        Me.GroupFiltrationTextBox.Name = "GroupFiltrationTextBox"
        Me.GroupFiltrationTextBox.Size = New System.Drawing.Size(50, 20)
        Me.GroupFiltrationTextBox.TabIndex = 20
        Me.GroupFiltrationTextBox.Text = "10"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(13, 123)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(153, 13)
        Me.Label16.TabIndex = 19
        Me.Label16.Text = "Interval background coverage:"
        '
        'MinimalIntervalCoverageTextBox
        '
        Me.MinimalIntervalCoverageTextBox.Location = New System.Drawing.Point(172, 120)
        Me.MinimalIntervalCoverageTextBox.Name = "MinimalIntervalCoverageTextBox"
        Me.MinimalIntervalCoverageTextBox.Size = New System.Drawing.Size(50, 20)
        Me.MinimalIntervalCoverageTextBox.TabIndex = 18
        Me.MinimalIntervalCoverageTextBox.Text = "2"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(75, 172)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(91, 13)
        Me.Label15.TabIndex = 17
        Me.Label15.Text = "TU scaling factor:"
        '
        'NormTextBox
        '
        Me.NormTextBox.Location = New System.Drawing.Point(172, 169)
        Me.NormTextBox.Name = "NormTextBox"
        Me.NormTextBox.Size = New System.Drawing.Size(50, 20)
        Me.NormTextBox.TabIndex = 16
        Me.NormTextBox.Text = "1"
        '
        'RemoveLowIntervalsCheckBox
        '
        Me.RemoveLowIntervalsCheckBox.AutoSize = True
        Me.RemoveLowIntervalsCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.RemoveLowIntervalsCheckBox.Checked = True
        Me.RemoveLowIntervalsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.RemoveLowIntervalsCheckBox.Location = New System.Drawing.Point(50, 146)
        Me.RemoveLowIntervalsCheckBox.Name = "RemoveLowIntervalsCheckBox"
        Me.RemoveLowIntervalsCheckBox.Size = New System.Drawing.Size(172, 17)
        Me.RemoveLowIntervalsCheckBox.TabIndex = 15
        Me.RemoveLowIntervalsCheckBox.Text = "Remove intervals below cutoff:"
        Me.RemoveLowIntervalsCheckBox.UseVisualStyleBackColor = True
        '
        'RemoveBackgroundCheckBox
        '
        Me.RemoveBackgroundCheckBox.AutoSize = True
        Me.RemoveBackgroundCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.RemoveBackgroundCheckBox.Checked = True
        Me.RemoveBackgroundCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.RemoveBackgroundCheckBox.Location = New System.Drawing.Point(79, 97)
        Me.RemoveBackgroundCheckBox.Name = "RemoveBackgroundCheckBox"
        Me.RemoveBackgroundCheckBox.Size = New System.Drawing.Size(143, 17)
        Me.RemoveBackgroundCheckBox.TabIndex = 14
        Me.RemoveBackgroundCheckBox.Text = "Filter background peaks:"
        Me.RemoveBackgroundCheckBox.UseVisualStyleBackColor = True
        '
        'BackgroundWindowTextBox
        '
        Me.BackgroundWindowTextBox.Location = New System.Drawing.Point(172, 71)
        Me.BackgroundWindowTextBox.Name = "BackgroundWindowTextBox"
        Me.BackgroundWindowTextBox.Size = New System.Drawing.Size(50, 20)
        Me.BackgroundWindowTextBox.TabIndex = 13
        Me.BackgroundWindowTextBox.Text = "200"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(59, 74)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(107, 13)
        Me.Label14.TabIndex = 12
        Me.Label14.Text = "Background window:"
        '
        'BackgroundCoverageTextBox
        '
        Me.BackgroundCoverageTextBox.Location = New System.Drawing.Point(172, 45)
        Me.BackgroundCoverageTextBox.Name = "BackgroundCoverageTextBox"
        Me.BackgroundCoverageTextBox.Size = New System.Drawing.Size(50, 20)
        Me.BackgroundCoverageTextBox.TabIndex = 11
        Me.BackgroundCoverageTextBox.Text = "2"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(23, 48)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(143, 13)
        Me.Label13.TabIndex = 10
        Me.Label13.Text = "Peak background coverage:"
        '
        'SmoothingTextBox
        '
        Me.SmoothingTextBox.Location = New System.Drawing.Point(172, 19)
        Me.SmoothingTextBox.Name = "SmoothingTextBox"
        Me.SmoothingTextBox.Size = New System.Drawing.Size(50, 20)
        Me.SmoothingTextBox.TabIndex = 8
        Me.SmoothingTextBox.Text = "100"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(106, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Smoothing:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.TermCDSCorrectionTextBox)
        Me.GroupBox2.Controls.Add(Me.TermCDSCorrectionCheckBox)
        Me.GroupBox2.Controls.Add(Me.TermFiltrationWindowTextBox)
        Me.GroupBox2.Controls.Add(Me.TermIdentificationWindowTextBox)
        Me.GroupBox2.Controls.Add(Me.TermBackgroundTextBox)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Location = New System.Drawing.Point(480, 208)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(228, 190)
        Me.GroupBox2.TabIndex = 10
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Terminators identification"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(35, 100)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(125, 13)
        Me.Label12.TabIndex = 15
        Me.Label12.Text = "CDS correction distance:"
        '
        'TermCDSCorrectionTextBox
        '
        Me.TermCDSCorrectionTextBox.Location = New System.Drawing.Point(166, 97)
        Me.TermCDSCorrectionTextBox.Name = "TermCDSCorrectionTextBox"
        Me.TermCDSCorrectionTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TermCDSCorrectionTextBox.TabIndex = 14
        Me.TermCDSCorrectionTextBox.Text = "100"
        '
        'TermCDSCorrectionCheckBox
        '
        Me.TermCDSCorrectionCheckBox.AutoSize = True
        Me.TermCDSCorrectionCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TermCDSCorrectionCheckBox.Checked = True
        Me.TermCDSCorrectionCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.TermCDSCorrectionCheckBox.Location = New System.Drawing.Point(75, 123)
        Me.TermCDSCorrectionCheckBox.Name = "TermCDSCorrectionCheckBox"
        Me.TermCDSCorrectionCheckBox.Size = New System.Drawing.Size(141, 17)
        Me.TermCDSCorrectionCheckBox.TabIndex = 13
        Me.TermCDSCorrectionCheckBox.Text = "Correct position by CDS:"
        Me.TermCDSCorrectionCheckBox.UseVisualStyleBackColor = True
        '
        'TermFiltrationWindowTextBox
        '
        Me.TermFiltrationWindowTextBox.Location = New System.Drawing.Point(166, 71)
        Me.TermFiltrationWindowTextBox.Name = "TermFiltrationWindowTextBox"
        Me.TermFiltrationWindowTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TermFiltrationWindowTextBox.TabIndex = 7
        Me.TermFiltrationWindowTextBox.Text = "20"
        '
        'TermIdentificationWindowTextBox
        '
        Me.TermIdentificationWindowTextBox.Location = New System.Drawing.Point(166, 45)
        Me.TermIdentificationWindowTextBox.Name = "TermIdentificationWindowTextBox"
        Me.TermIdentificationWindowTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TermIdentificationWindowTextBox.TabIndex = 6
        Me.TermIdentificationWindowTextBox.Text = "20"
        '
        'TermBackgroundTextBox
        '
        Me.TermBackgroundTextBox.Location = New System.Drawing.Point(166, 19)
        Me.TermBackgroundTextBox.Name = "TermBackgroundTextBox"
        Me.TermBackgroundTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TermBackgroundTextBox.TabIndex = 5
        Me.TermBackgroundTextBox.Text = "10"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(47, 74)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(113, 13)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Peak filtration window:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(24, 48)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(136, 13)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Peak identification window:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(92, 22)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(68, 13)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Background:"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.NoIntervalFiltrationRadioButton)
        Me.GroupBox4.Controls.Add(Me.SDFiltrationTextBox)
        Me.GroupBox4.Controls.Add(Me.SDIntervalFiltrationRadioButton)
        Me.GroupBox4.Location = New System.Drawing.Point(246, 222)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(228, 100)
        Me.GroupBox4.TabIndex = 11
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Step filtration method"
        '
        'NoIntervalFiltrationRadioButton
        '
        Me.NoIntervalFiltrationRadioButton.AutoSize = True
        Me.NoIntervalFiltrationRadioButton.Location = New System.Drawing.Point(6, 19)
        Me.NoIntervalFiltrationRadioButton.Name = "NoIntervalFiltrationRadioButton"
        Me.NoIntervalFiltrationRadioButton.Size = New System.Drawing.Size(51, 17)
        Me.NoIntervalFiltrationRadioButton.TabIndex = 17
        Me.NoIntervalFiltrationRadioButton.Text = "None"
        Me.NoIntervalFiltrationRadioButton.UseVisualStyleBackColor = True
        '
        'SDFiltrationTextBox
        '
        Me.SDFiltrationTextBox.Enabled = False
        Me.SDFiltrationTextBox.Location = New System.Drawing.Point(172, 41)
        Me.SDFiltrationTextBox.Name = "SDFiltrationTextBox"
        Me.SDFiltrationTextBox.Size = New System.Drawing.Size(50, 20)
        Me.SDFiltrationTextBox.TabIndex = 16
        Me.SDFiltrationTextBox.Text = "0,5"
        '
        'SDIntervalFiltrationRadioButton
        '
        Me.SDIntervalFiltrationRadioButton.AutoSize = True
        Me.SDIntervalFiltrationRadioButton.Checked = True
        Me.SDIntervalFiltrationRadioButton.Location = New System.Drawing.Point(6, 42)
        Me.SDIntervalFiltrationRadioButton.Name = "SDIntervalFiltrationRadioButton"
        Me.SDIntervalFiltrationRadioButton.Size = New System.Drawing.Size(111, 17)
        Me.SDIntervalFiltrationRadioButton.TabIndex = 1
        Me.SDIntervalFiltrationRadioButton.TabStop = True
        Me.SDIntervalFiltrationRadioButton.Text = "Standart deviation"
        Me.SDIntervalFiltrationRadioButton.UseVisualStyleBackColor = True
        '
        'GoButton
        '
        Me.GoButton.Location = New System.Drawing.Point(633, 404)
        Me.GoButton.Name = "GoButton"
        Me.GoButton.Size = New System.Drawing.Size(75, 23)
        Me.GoButton.TabIndex = 12
        Me.GoButton.Text = "Go"
        Me.GoButton.UseVisualStyleBackColor = True
        '
        'StatusLabelPlus
        '
        Me.StatusLabelPlus.AutoSize = True
        Me.StatusLabelPlus.Location = New System.Drawing.Point(12, 401)
        Me.StatusLabelPlus.Name = "StatusLabelPlus"
        Me.StatusLabelPlus.Size = New System.Drawing.Size(38, 13)
        Me.StatusLabelPlus.TabIndex = 13
        Me.StatusLabelPlus.Text = "Ready"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.RefreshGroupsButton)
        Me.GroupBox6.Controls.Add(Me.Label8)
        Me.GroupBox6.Controls.Add(Me.Label7)
        Me.GroupBox6.Controls.Add(Me.RemoveItemButton)
        Me.GroupBox6.Controls.Add(Me.AddItemButton)
        Me.GroupBox6.Controls.Add(Me.AllRemoveButton)
        Me.GroupBox6.Controls.Add(Me.AllAddButton)
        Me.GroupBox6.Controls.Add(Me.AnalysisHolderListBox)
        Me.GroupBox6.Controls.Add(Me.AllHoldersListBox)
        Me.GroupBox6.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(462, 150)
        Me.GroupBox6.TabIndex = 15
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Coverage profiles"
        '
        'RefreshGroupsButton
        '
        Me.RefreshGroupsButton.BackgroundImage = CType(resources.GetObject("RefreshGroupsButton.BackgroundImage"), System.Drawing.Image)
        Me.RefreshGroupsButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.RefreshGroupsButton.Location = New System.Drawing.Point(97, 18)
        Me.RefreshGroupsButton.Name = "RefreshGroupsButton"
        Me.RefreshGroupsButton.Size = New System.Drawing.Size(38, 23)
        Me.RefreshGroupsButton.TabIndex = 8
        Me.RefreshGroupsButton.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 28)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(88, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Available groups:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(253, 26)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(95, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Groups to analyze:"
        '
        'RemoveItemButton
        '
        Me.RemoveItemButton.BackgroundImage = CType(resources.GetObject("RemoveItemButton.BackgroundImage"), System.Drawing.Image)
        Me.RemoveItemButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.RemoveItemButton.Location = New System.Drawing.Point(212, 68)
        Me.RemoveItemButton.Name = "RemoveItemButton"
        Me.RemoveItemButton.Size = New System.Drawing.Size(38, 23)
        Me.RemoveItemButton.TabIndex = 5
        Me.RemoveItemButton.UseVisualStyleBackColor = True
        '
        'AddItemButton
        '
        Me.AddItemButton.BackgroundImage = CType(resources.GetObject("AddItemButton.BackgroundImage"), System.Drawing.Image)
        Me.AddItemButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.AddItemButton.Location = New System.Drawing.Point(212, 94)
        Me.AddItemButton.Name = "AddItemButton"
        Me.AddItemButton.Size = New System.Drawing.Size(38, 23)
        Me.AddItemButton.TabIndex = 4
        Me.AddItemButton.UseVisualStyleBackColor = True
        '
        'AllRemoveButton
        '
        Me.AllRemoveButton.BackgroundImage = CType(resources.GetObject("AllRemoveButton.BackgroundImage"), System.Drawing.Image)
        Me.AllRemoveButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.AllRemoveButton.Location = New System.Drawing.Point(212, 42)
        Me.AllRemoveButton.Name = "AllRemoveButton"
        Me.AllRemoveButton.Size = New System.Drawing.Size(38, 23)
        Me.AllRemoveButton.TabIndex = 3
        Me.AllRemoveButton.UseVisualStyleBackColor = True
        '
        'AllAddButton
        '
        Me.AllAddButton.BackgroundImage = CType(resources.GetObject("AllAddButton.BackgroundImage"), System.Drawing.Image)
        Me.AllAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.AllAddButton.Location = New System.Drawing.Point(212, 120)
        Me.AllAddButton.Name = "AllAddButton"
        Me.AllAddButton.Size = New System.Drawing.Size(38, 23)
        Me.AllAddButton.TabIndex = 2
        Me.AllAddButton.UseVisualStyleBackColor = True
        '
        'AnalysisHolderListBox
        '
        Me.AnalysisHolderListBox.FormattingEnabled = True
        Me.AnalysisHolderListBox.Location = New System.Drawing.Point(256, 44)
        Me.AnalysisHolderListBox.Name = "AnalysisHolderListBox"
        Me.AnalysisHolderListBox.Size = New System.Drawing.Size(200, 95)
        Me.AnalysisHolderListBox.TabIndex = 1
        '
        'AllHoldersListBox
        '
        Me.AllHoldersListBox.FormattingEnabled = True
        Me.AllHoldersListBox.Location = New System.Drawing.Point(6, 44)
        Me.AllHoldersListBox.Name = "AllHoldersListBox"
        Me.AllHoldersListBox.Size = New System.Drawing.Size(200, 95)
        Me.AllHoldersListBox.TabIndex = 0
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.BlocksCheckBox)
        Me.GroupBox7.Controls.Add(Me.TSSandTTCheckBox)
        Me.GroupBox7.Location = New System.Drawing.Point(246, 328)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(228, 70)
        Me.GroupBox7.TabIndex = 16
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Output"
        '
        'BlocksCheckBox
        '
        Me.BlocksCheckBox.AutoSize = True
        Me.BlocksCheckBox.Checked = True
        Me.BlocksCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.BlocksCheckBox.Location = New System.Drawing.Point(6, 42)
        Me.BlocksCheckBox.Name = "BlocksCheckBox"
        Me.BlocksCheckBox.Size = New System.Drawing.Size(112, 17)
        Me.BlocksCheckBox.TabIndex = 1
        Me.BlocksCheckBox.Text = "Transcription units"
        Me.BlocksCheckBox.UseVisualStyleBackColor = True
        '
        'TSSandTTCheckBox
        '
        Me.TSSandTTCheckBox.AutoSize = True
        Me.TSSandTTCheckBox.Checked = True
        Me.TSSandTTCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.TSSandTTCheckBox.Location = New System.Drawing.Point(6, 19)
        Me.TSSandTTCheckBox.Name = "TSSandTTCheckBox"
        Me.TSSandTTCheckBox.Size = New System.Drawing.Size(127, 17)
        Me.TSSandTTCheckBox.TabIndex = 0
        Me.TSSandTTCheckBox.Text = "TSS's and RNA ends"
        Me.TSSandTTCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.NoNormRadioButton)
        Me.GroupBox5.Controls.Add(Me.CodingRadioButton)
        Me.GroupBox5.Controls.Add(Me.AllLibRadioButton)
        Me.GroupBox5.Location = New System.Drawing.Point(246, 168)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(228, 48)
        Me.GroupBox5.TabIndex = 17
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Library normalization method"
        '
        'NoNormRadioButton
        '
        Me.NoNormRadioButton.AutoSize = True
        Me.NoNormRadioButton.Location = New System.Drawing.Point(135, 19)
        Me.NoNormRadioButton.Name = "NoNormRadioButton"
        Me.NoNormRadioButton.Size = New System.Drawing.Size(51, 17)
        Me.NoNormRadioButton.TabIndex = 2
        Me.NoNormRadioButton.Text = "None"
        Me.NoNormRadioButton.UseVisualStyleBackColor = True
        '
        'CodingRadioButton
        '
        Me.CodingRadioButton.AutoSize = True
        Me.CodingRadioButton.Checked = True
        Me.CodingRadioButton.Location = New System.Drawing.Point(61, 19)
        Me.CodingRadioButton.Name = "CodingRadioButton"
        Me.CodingRadioButton.Size = New System.Drawing.Size(68, 17)
        Me.CodingRadioButton.TabIndex = 1
        Me.CodingRadioButton.TabStop = True
        Me.CodingRadioButton.Text = "All CDS's"
        Me.CodingRadioButton.UseVisualStyleBackColor = True
        '
        'AllLibRadioButton
        '
        Me.AllLibRadioButton.AutoSize = True
        Me.AllLibRadioButton.Location = New System.Drawing.Point(6, 19)
        Me.AllLibRadioButton.Name = "AllLibRadioButton"
        Me.AllLibRadioButton.Size = New System.Drawing.Size(49, 17)
        Me.AllLibRadioButton.TabIndex = 0
        Me.AllLibRadioButton.Text = "Total"
        Me.AllLibRadioButton.UseVisualStyleBackColor = True
        '
        'StatusLabelMinus
        '
        Me.StatusLabelMinus.AutoSize = True
        Me.StatusLabelMinus.Location = New System.Drawing.Point(12, 417)
        Me.StatusLabelMinus.Name = "StatusLabelMinus"
        Me.StatusLabelMinus.Size = New System.Drawing.Size(38, 13)
        Me.StatusLabelMinus.TabIndex = 18
        Me.StatusLabelMinus.Text = "Ready"
        '
        'TranscriptionUnitsIdentification
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(721, 437)
        Me.Controls.Add(Me.StatusLabelMinus)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.StatusLabelPlus)
        Me.Controls.Add(Me.GoButton)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "TranscriptionUnitsIdentification"
        Me.Text = "Transcription units identification"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TSSDropTresholdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TSSDropLengthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TSSFiltrationWindowTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TSSIdentificationWindowTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TSSBackgroundTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SmoothingTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TermFiltrationWindowTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TermIdentificationWindowTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TermBackgroundTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GoButton As System.Windows.Forms.Button
    Friend WithEvents TermCDSCorrectionCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TermCDSCorrectionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SDIntervalFiltrationRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents StatusLabelPlus As System.Windows.Forms.Label
    Friend WithEvents SDFiltrationTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TSSAsymmetryCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents NoIntervalFiltrationRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents BackgroundCoverageTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents BackgroundWindowTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents RemoveBackgroundCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents BlocksCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents TSSandTTCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents AnalysisHolderListBox As System.Windows.Forms.ListBox
    Friend WithEvents AllHoldersListBox As System.Windows.Forms.ListBox
    Friend WithEvents AllRemoveButton As System.Windows.Forms.Button
    Friend WithEvents AllAddButton As System.Windows.Forms.Button
    Friend WithEvents RemoveLowIntervalsCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents AddItemButton As System.Windows.Forms.Button
    Friend WithEvents RemoveItemButton As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents NormTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents NoNormRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents CodingRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents AllLibRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents StatusLabelMinus As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents MinimalIntervalCoverageTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents GroupFiltrationTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RefreshGroupsButton As System.Windows.Forms.Button
End Class
