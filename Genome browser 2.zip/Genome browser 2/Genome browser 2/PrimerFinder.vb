﻿Public Class PrimerFinder
    Public SeqName As String = ""
    Public FeatureID As String = ""
    Public RangeStart As Integer = 0
    Public RangeEnd As Integer = 0
    Public InternalBrush As New SolidBrush(Color.FromArgb(30, 200, 0, 100))

    Public RegionList As New List(Of Genome_Feature)

    Private SuspendSeqLayout As Boolean = False


    'Design panel
    Private MarkerStarted As Boolean
    Private InitMarkerX As Integer
    Private InitCursorPositionX As Integer

    Public Sub CreatePairsList(ByVal Sequence As String, ByVal MinTm As Single, ByVal MaxTm As Single, ByVal TmDiff As Single, ByVal MinL As Integer, ByVal MaxL As Integer, ByVal MinAmpL As Integer, ByVal MaxAmpL As Integer, ByVal MinGC As Single, ByVal MaxGC As Single, ByVal UseClamp As Boolean, Optional ByVal ClampVal As Integer = 0, Optional ByVal UseLimits As Boolean = False, Optional ByVal ForUpperLimit As Integer = 0, Optional ByVal RevLowerLimit As Integer = 0)

        Dim Primers As New List(Of Primer)

        Dim CurrentSeq As String = ""
        Dim CurrentTm As Single = 0
        Dim CurrentGC As Single = 0

        Dim CurrentLength As Integer = 0
        For i = 0 To MaxL - MinL
            For j = 0 To Sequence.Length - (MinL + i)

                CurrentSeq = Sequence.Substring(j, MinL + i)
                CurrentTm = Bioinformatics.CalculateOligoTm(CurrentSeq)
                CurrentGC = Bioinformatics.CalculateCGContent(CurrentSeq)


                If CurrentTm >= MinTm And CurrentTm <= MaxTm And CurrentGC >= MinGC And CurrentGC <= MaxGC Then
                    Dim NewPrimer As New Primer
                    NewPrimer.Location = j
                    NewPrimer.Sequence = CurrentSeq
                    NewPrimer.Tm = CurrentTm
                    NewPrimer.GC = CurrentGC
                    Primers.Add(NewPrimer)
                End If

            Next
        Next

        Dim AmpSize As Integer = 0
        Dim counter As Integer = 1
        Dim CurrentRevSeq As String = ""
        Dim ClampCheck As Boolean = False
        Dim LimCheck As Boolean = False
        PrimersDataGridView.Rows.Clear()
        Dim dG(1) As Single

        For Each ForPrimer As Primer In Primers
            For Each RevPrimer As Primer In Primers

                AmpSize = RevPrimer.Location + RevPrimer.Sequence.Length - ForPrimer.Location
                CurrentRevSeq = Bioinformatics.GetReverseComplement(RevPrimer.Sequence)

                If UseClamp = False Then
                    ClampCheck = True
                ElseIf Bioinformatics.DetectClamp(ForPrimer.Sequence, ClampVal) And Bioinformatics.DetectClamp(CurrentRevSeq, ClampVal) Then
                    ClampCheck = True
                Else
                    ClampCheck = False
                End If

                If UseLimits = False Then
                    LimCheck = True
                ElseIf ForPrimer.Location + ForPrimer.Sequence.Length <= ForUpperLimit And RevPrimer.Location >= RevLowerLimit Then
                    LimCheck = True
                Else
                    LimCheck = False
                End If

                If ClampCheck = True And LimCheck = True And AmpSize >= MinAmpL And AmpSize <= MaxAmpL And Math.Abs(ForPrimer.Tm - RevPrimer.Tm) <= TmDiff Then
                    dG = Bioinformatics.GetDimersDG(ForPrimer.Sequence, CurrentRevSeq)
                    PrimersDataGridView.Rows.Add(counter, _
                                                 ForPrimer.Sequence, CurrentRevSeq, _
                                                 ForPrimer.Tm, RevPrimer.Tm, _
                                                 ForPrimer.Sequence.Length, RevPrimer.Sequence.Length, _
                                                 ForPrimer.GC, RevPrimer.GC, _
                                                 ForPrimer.Location, RevPrimer.Location, _
                                                 AmpSize, dG(1), dG(0))
                    counter += 1
                End If

            Next

        Next

        PrimersDataGridView.Sort(PrimersDataGridView.Columns(DataIO.GetColumnIndex("TotalDG", PrimersDataGridView)), System.ComponentModel.ListSortDirection.Descending)
        PrimersDataGridView.Sort(PrimersDataGridView.Columns(DataIO.GetColumnIndex("ExtDG", PrimersDataGridView)), System.ComponentModel.ListSortDirection.Descending)


        InfoTextBox.Text = String.Concat("Primers found: ", counter - 1, Environment.NewLine, "Sequence length: ", Sequence.Length, Environment.NewLine, "Sequence name: ", SeqName, Environment.NewLine, "Sequence locus: ", FeatureID)

    End Sub


    Public Sub DrawBorderButtons()

        Dim SeqBarStart As Integer = 50
        Dim SeqBarLength As Integer = Width - SeqBarStart * 2

        Try



            If SeqTextBox.Text.Length > 0 Then
                Dim ProjectionCoefficient As Single = SeqBarLength / SeqTextBox.Text.Length

                Dim LeftBorder As Integer = ForLimTextBox.Text * ProjectionCoefficient
                Dim RightBorder As Integer = RevLimTextBox.Text * ProjectionCoefficient

                LeftBorderButton.Location = New Point(LeftBorder + SeqBarStart - LeftBorderButton.Width / 2, 1)
                RightBorderButton.Location = New Point(RightBorder + SeqBarStart - RightBorderButton.Width / 2, DrawPanel.Height - RightBorderButton.Height - 1)

            Else

                LeftBorderButton.Location = New Point(SeqBarStart - RightBorderButton.Width / 2, 1)
                RightBorderButton.Location = New Point(SeqBarStart + SeqBarLength - RightBorderButton.Width / 2, DrawPanel.Height - RightBorderButton.Height - 1)

            End If

        Catch ex As Exception
            MsgBox("Draw Border Buttons Error!")
        End Try

    End Sub

    Private Sub UpdateLimitValues()
        If SeqTextBox.Text.Length > 0 Then
            Dim SeqBarStart As Integer = 50
            Dim SeqBarLength As Integer = Width - SeqBarStart * 2
            Dim ProjectionCoefficient As Single = SeqBarLength / SeqTextBox.Text.Length

            ForLimTextBox.Text = Math.Round((LeftBorderButton.Location.X - SeqBarStart + LeftBorderButton.Width / 2) / ProjectionCoefficient, 0)
            RevLimTextBox.Text = Math.Round((RightBorderButton.Location.X - SeqBarStart + RightBorderButton.Width / 2) / ProjectionCoefficient, 0)

        End If
    End Sub

    Private Sub GoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoButton.Click
        SuspendSeqLayout = True

        If ClearSeqCheckBox.Checked Then
            Dim InputSeq As String = SeqTextBox.Text
            InputSeq = InputSeq.Replace(Chr(13), vbNullString)
            InputSeq = InputSeq.Replace(Chr(10), vbNullString)
            InputSeq = InputSeq.ToUpper()
            SeqTextBox.Text = InputSeq
        End If

        Dim Seq As String = SeqTextBox.Text

        If BisulphiteSeq.Checked Then

            Dim MetylationSites As New List(Of String)

            If CpG_Button.Checked Then
                MetylationSites.Add("CG")
            End If

            Seq = Bioinformatics.BisulphiteTreatment(Seq, MetylationSites)
            SeqTextBox.Text = Seq
        End If

        CreatePairsList(Seq, TmMinTextBox.Text, TmMaxTextBox.Text, DeltaTMTextBox.Text, PrimerMinTextBox.Text, PrimerMaxTextBox.Text, AmpMinTextBox.Text, AmpMaxTextBox.Text, GCMinTextBox.Text, GCMaxTextBox.Text, GCClampCheckBox.Checked, ClampSizeTextBox.Text, LimCheckBox.Checked, ForLimTextBox.Text, RevLimTextBox.Text)

        SuspendSeqLayout = False
        DrawPanel.Refresh()

    End Sub

    Private Sub PrimersDataGridView_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles PrimersDataGridView.CellDoubleClick

        Oligocalculator.ForTextBox.Text = PrimersDataGridView.CurrentRow.Cells(1).Value
        Oligocalculator.RevTextBox.Text = PrimersDataGridView.CurrentRow.Cells(2).Value
        Oligocalculator.DoCalculations()
        Oligocalculator.Show()
        Oligocalculator.Focus()

    End Sub

    Private Sub PrimerFinder_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DrawBorderButtons()


    End Sub

    Private Sub DrawPanel_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles DrawPanel.Paint
        Dim SeqBarStart As Integer = 50
        Dim SeqBarLength As Integer = Width - SeqBarStart * 2
        Dim SeqbarOffset As Integer = DrawPanel.Height / 2

        If Not SuspendSeqLayout And PrimersDataGridView.RowCount > 1 And SeqTextBox.Text.Length > 0 Then

            Dim ForStart As Integer = (PrimersDataGridView.SelectedRows(0).Cells(9).Value / SeqTextBox.Text.Length) * SeqBarLength
            Dim ForLength As Integer = PrimersDataGridView.SelectedRows(0).Cells(5).Value
            Dim RevStart As Integer = (PrimersDataGridView.SelectedRows(0).Cells(10).Value / SeqTextBox.Text.Length) * SeqBarLength
            Dim RevLength As Integer = PrimersDataGridView.SelectedRows(0).Cells(6).Value



            '   MsgBox(String.Concat("ForStart=", ForStart, " ForLength=", ForLength, " RevStart=", RevStart, " RevLength=", RevLength))

            Dim PrimerPen As New Pen(Color.Red, 2)

            e.Graphics.DrawLine(PrimerPen, ForStart + SeqBarStart, SeqbarOffset - 5, ForStart + SeqBarStart + ForLength, SeqbarOffset - 5)
            e.Graphics.DrawLine(PrimerPen, ForStart + SeqBarStart + ForLength - 6, SeqbarOffset - 12, ForStart + SeqBarStart + ForLength, SeqbarOffset - 5)

            e.Graphics.DrawLine(PrimerPen, RevStart + SeqBarStart, SeqbarOffset + 5, RevStart + SeqBarStart + ForLength, SeqbarOffset + 5)
            e.Graphics.DrawLine(PrimerPen, RevStart + SeqBarStart, SeqbarOffset + 5, RevStart + SeqBarStart + 6, SeqbarOffset + 12)

            SeqTextBox.SelectAll()
            SeqTextBox.SelectionBackColor = Color.White
            SeqTextBox.DeselectAll()

            SeqTextBox.Select(PrimersDataGridView.SelectedRows(0).Cells(9).Value, PrimersDataGridView.SelectedRows(0).Cells(5).Value)
            SeqTextBox.SelectionBackColor = Color.Yellow

            SeqTextBox.Select(PrimersDataGridView.SelectedRows(0).Cells(10).Value, PrimersDataGridView.SelectedRows(0).Cells(6).Value)
            SeqTextBox.SelectionBackColor = Color.Yellow

            SeqTextBox.Select(PrimersDataGridView.SelectedRows(0).Cells(9).Value + PrimersDataGridView.SelectedRows(0).Cells(5).Value, PrimersDataGridView.SelectedRows(0).Cells(10).Value - PrimersDataGridView.SelectedRows(0).Cells(9).Value - PrimersDataGridView.SelectedRows(0).Cells(5).Value)
            SeqTextBox.SelectionBackColor = Color.LightGreen


        End If

        e.Graphics.DrawString(SeqTextBox.Text.Length, Me.Font, Brushes.Black, SeqBarStart + SeqBarLength, SeqbarOffset)
        e.Graphics.DrawString("0", Me.Font, Brushes.Black, SeqBarStart, SeqbarOffset)
        e.Graphics.DrawLine(Pens.Blue, SeqBarStart, SeqbarOffset, SeqBarStart + SeqBarLength, SeqbarOffset)

        If LimCheckBox.Checked Then
            e.Graphics.FillRectangle(InternalBrush, SeqBarStart, LeftBorderButton.Location.Y, LeftBorderButton.Location.X - SeqBarStart, LeftBorderButton.Height)
            e.Graphics.FillRectangle(InternalBrush, RightBorderButton.Location.X, RightBorderButton.Location.Y, SeqBarLength - RightBorderButton.Location.X + SeqBarStart, RightBorderButton.Height)
        End If

    End Sub

    Private Sub PrimersDataGridView_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles PrimersDataGridView.SelectionChanged
        DrawPanel.Refresh()

    End Sub

    Private Sub LimCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LimCheckBox.CheckedChanged
        LeftBorderButton.Visible = LimCheckBox.Checked
        RightBorderButton.Visible = LimCheckBox.Checked

    End Sub

    Private Sub LeftBorderButton_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles LeftBorderButton.MouseDown
        MarkerStarted = True
        InitMarkerX = LeftBorderButton.Location.X
        InitCursorPositionX = Windows.Forms.Cursor.Position.X
    End Sub

    Private Sub LeftBorderButton_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles LeftBorderButton.MouseMove
        If MarkerStarted Then

            Dim SeqBarStart As Integer = 50
            Dim SeqBarLength As Integer = Width - SeqBarStart * 2

            Dim deltaX As Integer = Windows.Forms.Cursor.Position.X - InitCursorPositionX
            If Not InitMarkerX + deltaX < SeqBarStart - LeftBorderButton.Width / 2 And Not InitMarkerX + deltaX > SeqBarStart + SeqBarLength - LeftBorderButton.Width / 2 Then
                LeftBorderButton.Location = New Point(InitMarkerX + deltaX, LeftBorderButton.Location.Y)
                UpdateLimitValues()
            End If

        End If
    End Sub

    Private Sub LeftBorderButton_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles LeftBorderButton.MouseUp
        MarkerStarted = False
    End Sub

    Private Sub RightBorderButton_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RightBorderButton.MouseDown
        MarkerStarted = True
        InitMarkerX = RightBorderButton.Location.X
        InitCursorPositionX = Windows.Forms.Cursor.Position.X
    End Sub

    Private Sub RightBorderButton_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RightBorderButton.MouseMove
        If MarkerStarted Then

            Dim SeqBarStart As Integer = 50
            Dim SeqBarLength As Integer = Width - SeqBarStart * 2

            Dim deltaX As Integer = Windows.Forms.Cursor.Position.X - InitCursorPositionX
            If Not InitMarkerX + deltaX > SeqBarStart + SeqBarLength - RightBorderButton.Width / 2 And Not InitMarkerX + deltaX < SeqBarStart - RightBorderButton.Width / 2 Then
                RightBorderButton.Location = New Point(InitMarkerX + deltaX, RightBorderButton.Location.Y)
                UpdateLimitValues()
            End If

        End If
    End Sub

    Private Sub RightBorderButton_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RightBorderButton.MouseUp
        MarkerStarted = False
    End Sub


    Private Sub CLSButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CLSButton.Click
        SeqTextBox.Clear()
        PrimersDataGridView.Rows.Clear()
        DrawBorderButtons()
        DrawPanel.Refresh()

    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteToolStripMenuItem.Click
        SeqTextBox.Text = Clipboard.GetText
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyToolStripMenuItem.Click
        Clipboard.SetText(SeqTextBox.Text)
    End Sub

    Private Sub LeftBorderButton_LocationChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LeftBorderButton.LocationChanged
        DrawPanel.Invalidate()
    End Sub

    Private Sub RightBorderButton_LocationChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RightBorderButton.LocationChanged
        DrawPanel.Invalidate()
    End Sub

    Private Sub SeqTextBox_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles SeqTextBox.KeyUp
        DrawPanel.Invalidate()
    End Sub

    Private Sub BisulphiteSeq_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BisulphiteSeq.CheckedChanged
        CpG_Button.Enabled = BisulphiteSeq.Checked

    End Sub
End Class