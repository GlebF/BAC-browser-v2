﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PositionalIntegrator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ForTextBox = New System.Windows.Forms.TextBox
        Me.RevTextBox = New System.Windows.Forms.TextBox
        Me.ForPileupButton = New System.Windows.Forms.Button
        Me.RevPileupButton = New System.Windows.Forms.Button
        Me.PileupOpenFileDialog = New System.Windows.Forms.OpenFileDialog
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.UserListCheckBox = New System.Windows.Forms.CheckBox
        Me.AnnotCheckBox = New System.Windows.Forms.CheckBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.AggregatedRadioButton = New System.Windows.Forms.RadioButton
        Me.CodingRadioButton = New System.Windows.Forms.RadioButton
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.DirRadioButton = New System.Windows.Forms.RadioButton
        Me.NonDirRadioButton = New System.Windows.Forms.RadioButton
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.ImportButton = New System.Windows.Forms.Button
        Me.GoButton = New System.Windows.Forms.Button
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.ASCheckBox = New System.Windows.Forms.CheckBox
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'ForTextBox
        '
        Me.ForTextBox.Location = New System.Drawing.Point(6, 19)
        Me.ForTextBox.Name = "ForTextBox"
        Me.ForTextBox.Size = New System.Drawing.Size(200, 20)
        Me.ForTextBox.TabIndex = 0
        '
        'RevTextBox
        '
        Me.RevTextBox.Location = New System.Drawing.Point(6, 45)
        Me.RevTextBox.Name = "RevTextBox"
        Me.RevTextBox.Size = New System.Drawing.Size(200, 20)
        Me.RevTextBox.TabIndex = 1
        '
        'ForPileupButton
        '
        Me.ForPileupButton.Location = New System.Drawing.Point(212, 17)
        Me.ForPileupButton.Name = "ForPileupButton"
        Me.ForPileupButton.Size = New System.Drawing.Size(75, 23)
        Me.ForPileupButton.TabIndex = 2
        Me.ForPileupButton.Text = "For pileup"
        Me.ForPileupButton.UseVisualStyleBackColor = True
        '
        'RevPileupButton
        '
        Me.RevPileupButton.Location = New System.Drawing.Point(212, 43)
        Me.RevPileupButton.Name = "RevPileupButton"
        Me.RevPileupButton.Size = New System.Drawing.Size(75, 23)
        Me.RevPileupButton.TabIndex = 3
        Me.RevPileupButton.Text = "Rev pileup"
        Me.RevPileupButton.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ForTextBox)
        Me.GroupBox1.Controls.Add(Me.RevPileupButton)
        Me.GroupBox1.Controls.Add(Me.RevTextBox)
        Me.GroupBox1.Controls.Add(Me.ForPileupButton)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(306, 79)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Pileup data source"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.UserListCheckBox)
        Me.GroupBox2.Controls.Add(Me.AnnotCheckBox)
        Me.GroupBox2.Location = New System.Drawing.Point(168, 97)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(150, 68)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Features layout source"
        '
        'UserListCheckBox
        '
        Me.UserListCheckBox.AutoSize = True
        Me.UserListCheckBox.Location = New System.Drawing.Point(6, 42)
        Me.UserListCheckBox.Name = "UserListCheckBox"
        Me.UserListCheckBox.Size = New System.Drawing.Size(104, 17)
        Me.UserListCheckBox.TabIndex = 1
        Me.UserListCheckBox.Text = "User features list"
        Me.UserListCheckBox.UseVisualStyleBackColor = True
        '
        'AnnotCheckBox
        '
        Me.AnnotCheckBox.AutoSize = True
        Me.AnnotCheckBox.Checked = True
        Me.AnnotCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.AnnotCheckBox.Location = New System.Drawing.Point(6, 19)
        Me.AnnotCheckBox.Name = "AnnotCheckBox"
        Me.AnnotCheckBox.Size = New System.Drawing.Size(77, 17)
        Me.AnnotCheckBox.TabIndex = 0
        Me.AnnotCheckBox.Text = "Annotation"
        Me.AnnotCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.AggregatedRadioButton)
        Me.GroupBox3.Controls.Add(Me.CodingRadioButton)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 171)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(150, 102)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Normalization method"
        '
        'AggregatedRadioButton
        '
        Me.AggregatedRadioButton.AutoSize = True
        Me.AggregatedRadioButton.Location = New System.Drawing.Point(6, 42)
        Me.AggregatedRadioButton.Name = "AggregatedRadioButton"
        Me.AggregatedRadioButton.Size = New System.Drawing.Size(110, 17)
        Me.AggregatedRadioButton.TabIndex = 1
        Me.AggregatedRadioButton.Text = "Aggregated signal"
        Me.AggregatedRadioButton.UseVisualStyleBackColor = True
        '
        'CodingRadioButton
        '
        Me.CodingRadioButton.AutoSize = True
        Me.CodingRadioButton.Checked = True
        Me.CodingRadioButton.Location = New System.Drawing.Point(6, 19)
        Me.CodingRadioButton.Name = "CodingRadioButton"
        Me.CodingRadioButton.Size = New System.Drawing.Size(108, 17)
        Me.CodingRadioButton.TabIndex = 0
        Me.CodingRadioButton.TabStop = True
        Me.CodingRadioButton.Text = "All coding regions"
        Me.CodingRadioButton.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.DirRadioButton)
        Me.GroupBox4.Controls.Add(Me.NonDirRadioButton)
        Me.GroupBox4.Location = New System.Drawing.Point(12, 97)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(150, 68)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Pileup data type"
        '
        'DirRadioButton
        '
        Me.DirRadioButton.AutoSize = True
        Me.DirRadioButton.Checked = True
        Me.DirRadioButton.Location = New System.Drawing.Point(6, 42)
        Me.DirRadioButton.Name = "DirRadioButton"
        Me.DirRadioButton.Size = New System.Drawing.Size(75, 17)
        Me.DirRadioButton.TabIndex = 1
        Me.DirRadioButton.TabStop = True
        Me.DirRadioButton.Text = "Directional"
        Me.DirRadioButton.UseVisualStyleBackColor = True
        '
        'NonDirRadioButton
        '
        Me.NonDirRadioButton.AutoSize = True
        Me.NonDirRadioButton.Location = New System.Drawing.Point(6, 19)
        Me.NonDirRadioButton.Name = "NonDirRadioButton"
        Me.NonDirRadioButton.Size = New System.Drawing.Size(142, 17)
        Me.NonDirRadioButton.TabIndex = 0
        Me.NonDirRadioButton.Text = "Non-directional (For only)"
        Me.NonDirRadioButton.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.ImportButton)
        Me.GroupBox5.Location = New System.Drawing.Point(168, 171)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(150, 48)
        Me.GroupBox5.TabIndex = 8
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Import features"
        '
        'ImportButton
        '
        Me.ImportButton.Location = New System.Drawing.Point(8, 19)
        Me.ImportButton.Name = "ImportButton"
        Me.ImportButton.Size = New System.Drawing.Size(75, 23)
        Me.ImportButton.TabIndex = 0
        Me.ImportButton.Text = "Import"
        Me.ImportButton.UseVisualStyleBackColor = True
        '
        'GoButton
        '
        Me.GoButton.Location = New System.Drawing.Point(240, 279)
        Me.GoButton.Name = "GoButton"
        Me.GoButton.Size = New System.Drawing.Size(75, 23)
        Me.GoButton.TabIndex = 9
        Me.GoButton.Text = "Go"
        Me.GoButton.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.ASCheckBox)
        Me.GroupBox6.Location = New System.Drawing.Point(168, 225)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(150, 48)
        Me.GroupBox6.TabIndex = 10
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Antisense options"
        '
        'ASCheckBox
        '
        Me.ASCheckBox.AutoSize = True
        Me.ASCheckBox.Location = New System.Drawing.Point(6, 19)
        Me.ASCheckBox.Name = "ASCheckBox"
        Me.ASCheckBox.Size = New System.Drawing.Size(132, 17)
        Me.ASCheckBox.TabIndex = 0
        Me.ASCheckBox.Text = "Count antisense signal"
        Me.ASCheckBox.UseVisualStyleBackColor = True
        '
        'PositionalIntegrator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(327, 314)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GoButton)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "PositionalIntegrator"
        Me.Text = "Positional Integrator"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ForTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RevTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ForPileupButton As System.Windows.Forms.Button
    Friend WithEvents RevPileupButton As System.Windows.Forms.Button
    Friend WithEvents PileupOpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents UserListCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents AnnotCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents AggregatedRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents CodingRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents DirRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents NonDirRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents GoButton As System.Windows.Forms.Button
    Friend WithEvents ImportButton As System.Windows.Forms.Button
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents ASCheckBox As System.Windows.Forms.CheckBox
End Class
