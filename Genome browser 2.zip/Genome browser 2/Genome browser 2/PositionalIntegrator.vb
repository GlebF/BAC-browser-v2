﻿Public Class PositionalIntegrator
    Public MyGenomeViewer As Genome_Viewer


    Private Sub ForPileupButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ForPileupButton.Click
        If PileupOpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            ForTextBox.Text = PileupOpenFileDialog.FileName
        End If

    End Sub

    Private Sub RevPileupButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RevPileupButton.Click
        If PileupOpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            RevTextBox.Text = PileupOpenFileDialog.FileName
        End If

    End Sub

    Private Sub GoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoButton.Click


        Dim ForPileup As New List(Of Integer)
        Dim RevPileup As New List(Of Integer)

        Dim NormalizerCount As Integer = 0

        Dim QueryFeatures As New List(Of Genome_Feature)

        If AnnotCheckBox.Checked Then
            QueryFeatures.AddRange(MyGenomeViewer.Features_Groups_List(0).FeaturesList)
        End If

        If UserListCheckBox.Checked Then
            QueryFeatures.AddRange(MyGenomeViewer.Features_Groups_List(1).FeaturesList)
        End If

        If NonDirRadioButton.Checked Then
            ForPileup = DataIO.RetrievePositionalValuesIntoListOfInteger(ForTextBox.Text)
            If CodingRadioButton.Checked Then
                NormalizerCount = Bioinformatics.GetTotalCountOfCoding(ForPileup, ForPileup, MyGenomeViewer.Features_Groups_List(0).FeaturesList, False)
            End If

            If AggregatedRadioButton.Checked Then
                NormalizerCount = Bioinformatics.GetAggregatedCoverage(ForPileup)
            End If

            If Master.SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
                Bioinformatics.GetNormalizedCoverage(NormalizerCount, QueryFeatures, ForPileup, ForPileup, Master.SaveFileDialog.FileName, False)
            End If

        End If

        If DirRadioButton.Checked Then
            ForPileup = DataIO.RetrievePositionalValuesIntoListOfInteger(ForTextBox.Text)
            RevPileup = DataIO.RetrievePositionalValuesIntoListOfInteger(RevTextBox.Text)

            If CodingRadioButton.Checked Then
                NormalizerCount = Bioinformatics.GetTotalCountOfCoding(ForPileup, RevPileup, MyGenomeViewer.Features_Groups_List(0).FeaturesList, True)
            End If

            If AggregatedRadioButton.Checked Then
                NormalizerCount += Bioinformatics.GetAggregatedCoverage(ForPileup)
                NormalizerCount += Bioinformatics.GetAggregatedCoverage(RevPileup)
            End If

            If Master.SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
                Bioinformatics.GetNormalizedCoverage(NormalizerCount, QueryFeatures, ForPileup, RevPileup, Master.SaveFileDialog.FileName & ".xls", True)

                If ASCheckBox.Checked Then
                    Bioinformatics.GetNormalizedCoverage(NormalizerCount, QueryFeatures, RevPileup, ForPileup, Master.SaveFileDialog.FileName & "-AntisenseCount.xls", True)
                End If

            End If

        End If


    End Sub

    Private Sub DirRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DirRadioButton.CheckedChanged
        If DirRadioButton.Checked Then
            RevTextBox.Enabled = True
            RevPileupButton.Enabled = True
        Else
            RevTextBox.Enabled = False
            RevPileupButton.Enabled = False
        End If
    End Sub

    Private Sub ImportButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportButton.Click
        ImportFeatures.MyGenomeViewer = MyGenomeViewer
        ImportFeatures.Show()

    End Sub

End Class