﻿Public Class K_Word_PWM
    Private WordText As String = ""
    Private WordPWM As New PWM
    Private OriginID As String = ""
    Private OriginPos As Integer
    Private HitPositions As New List(Of K_Word_PWM_Hit)
    Private bRestricted As Boolean = False
    Private bBlocked As Boolean = False

    Private MyRange As Single = 0

    Private SglCutoff As Single = 0

    Private MatchScore As Single = 0.6
    Private MismatchScore As Single = 0.2
   


    Public Property Word_Text() As String
        Get
            Word_Text = WordText
        End Get
        Set(ByVal value As String)
            WordText = value
        End Set
    End Property

    Public Property Word_PWM() As PWM
        Get
            Word_PWM = WordPWM
        End Get
        Set(ByVal value As PWM)
            WordPWM = value
        End Set
    End Property

    Public Property Seq_ID() As String
        Get
            Seq_ID = OriginID
        End Get
        Set(ByVal value As String)
            OriginID = value
        End Set
    End Property

    Public Property Word_Position() As Integer
        Get
            Word_Position = OriginPos
        End Get
        Set(ByVal value As Integer)
            OriginPos = value
        End Set
    End Property

    Public Property Hit_Positions() As List(Of K_Word_PWM_Hit)
        Get
            Hit_Positions = HitPositions
        End Get
        Set(ByVal value As List(Of K_Word_PWM_Hit))
            HitPositions = value
        End Set
    End Property

    Public Property Is_Restricted() As Boolean
        Get
            Is_Restricted = bRestricted
        End Get
        Set(ByVal value As Boolean)
            bRestricted = value
        End Set
    End Property

    Public Property Score_Cutoff() As Single
        Get
            Score_Cutoff = SglCutoff
        End Get
        Set(ByVal value As Single)
            SglCutoff = value
        End Set
    End Property

    Public Property PWM_Range() As Single
        Get
            PWM_Range = MyRange
        End Get
        Set(ByVal value As Single)
            MyRange = value
        End Set
    End Property

    Public Property Match_Score() As Single
        Get
            Match_Score = MatchScore
        End Get
        Set(ByVal value As Single)

        End Set
    End Property

    Public Property Mismatch_Score() As Single
        Get
            Mismatch_Score = MismatchScore
        End Get
        Set(ByVal value As Single)
            MismatchScore = value
        End Set
    End Property

    Public Property Is_Blocked() As Boolean
        Get
            Is_Blocked = bBlocked
        End Get
        Set(ByVal value As Boolean)
            bBlocked = value
        End Set
    End Property

    Public Sub PrimePWM(ByVal A_P As Single, ByVal T_P As Single, ByVal G_P As Single, ByVal C_P As Single)
        WordPWM.PWM_Table.Clear()

        For i = 0 To WordText.Length - 1
            Dim NewPWMcell As New PWM_cell

            Select Case WordText(i)
                Case "A"
                    NewPWMcell.A_Weight = Math.Log(MatchScore / A_P)
                    NewPWMcell.T_Weight = Math.Log(MismatchScore / T_P)
                    NewPWMcell.G_Weight = Math.Log(MismatchScore / G_P)
                    NewPWMcell.C_Weight = Math.Log(MismatchScore / C_P)
                Case "T"
                    NewPWMcell.A_Weight = Math.Log(MismatchScore / A_P)
                    NewPWMcell.T_Weight = Math.Log(MatchScore / T_P)
                    NewPWMcell.G_Weight = Math.Log(MismatchScore / G_P)
                    NewPWMcell.C_Weight = Math.Log(MismatchScore / C_P)
                Case "G"
                    NewPWMcell.A_Weight = Math.Log(MismatchScore / A_P)
                    NewPWMcell.T_Weight = Math.Log(MismatchScore / T_P)
                    NewPWMcell.G_Weight = Math.Log(MatchScore / G_P)
                    NewPWMcell.C_Weight = Math.Log(MismatchScore / C_P)
                Case "C"
                    NewPWMcell.A_Weight = Math.Log(MismatchScore / A_P)
                    NewPWMcell.T_Weight = Math.Log(MismatchScore / T_P)
                    NewPWMcell.G_Weight = Math.Log(MismatchScore / G_P)
                    NewPWMcell.C_Weight = Math.Log(MatchScore / C_P)
                Case Else
                    NewPWMcell.A_Weight = Math.Log(MismatchScore / A_P)
                    NewPWMcell.T_Weight = Math.Log(MismatchScore / T_P)
                    NewPWMcell.G_Weight = Math.Log(MismatchScore / G_P)
                    NewPWMcell.C_Weight = Math.Log(MismatchScore / C_P)
            End Select
            WordPWM.PWM_Table.Add(NewPWMcell)
        Next




    End Sub

    Public Sub CalculateCutoff(ByVal CutoffPercent As Single)
        Dim MaxWeight As Single = WordPWM.GetMaxWeight
        Dim MinWeight As Single = 0 'WordPWM.GetMinWeight
        Dim WeightRange As Single = MaxWeight - MinWeight
        SglCutoff = MaxWeight - WeightRange * CutoffPercent
    End Sub

    Public Sub ReCalcPWM(ByVal A_P As Single, ByVal T_P As Single, ByVal G_P As Single, ByVal C_P As Single)
        'Select top hits
        If HitPositions.Count > 0 Then
            Dim TopRatedHits As New List(Of Char())
            TopRatedHits.Add(WordText.ToCharArray)
            For Each WordHit As K_Word_PWM_Hit In HitPositions
                TopRatedHits.Add(WordHit.Word_Text.ToCharArray)
            Next

            'Rebuild PWM based on these sequences
            WordPWM = Bioinformatics.CalculatePWM(TopRatedHits, A_P, T_P, G_P, C_P, True)
        End If

    End Sub

End Class
