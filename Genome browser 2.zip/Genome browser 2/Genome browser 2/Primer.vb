﻿Public Class Primer
    Private strSequence As String
    Private sglTm As Single
    Private sglGC As Single
    Private sgldG As Single
    Private intLocation As Integer

    Public Property Location() As Integer
        Get
            Location = intLocation
        End Get
        Set(ByVal value As Integer)
            intLocation = value
        End Set
    End Property

    Public Property Sequence() As String
        Get
            Sequence = strSequence
        End Get
        Set(ByVal value As String)
            strSequence = value
        End Set
    End Property

    Public Property dG() As Single
        Get
            dG = sgldG
        End Get
        Set(ByVal value As Single)
            sgldG = value
        End Set
    End Property

    Public Property Tm() As Single
        Get
            Tm = sglTm
        End Get
        Set(ByVal value As Single)
            sglTm = value
        End Set
    End Property

    Public Property GC() As Single
        Get
            GC = sglGC
        End Get
        Set(ByVal value As Single)
            sglGC = value
        End Set
    End Property

End Class
