﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PWMbuilder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PWMbuilder))
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.MinTextBox = New System.Windows.Forms.TextBox
        Me.MaxTextBox = New System.Windows.Forms.TextBox
        Me.SaveButton = New System.Windows.Forms.Button
        Me.GCTextBox = New System.Windows.Forms.TextBox
        Me.GoButton = New System.Windows.Forms.Button
        Me.SeqTextBox = New System.Windows.Forms.TextBox
        Me.PWMDataGridView = New System.Windows.Forms.DataGridView
        Me.LOGOPanel = New System.Windows.Forms.Panel
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.SizeCorrectionCheckBox = New System.Windows.Forms.CheckBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.TextBox_CP = New System.Windows.Forms.TextBox
        Me.TextBox_GP = New System.Windows.Forms.TextBox
        Me.TextBox_TP = New System.Windows.Forms.TextBox
        Me.TextBox_AP = New System.Windows.Forms.TextBox
        Me.ManualPButton = New System.Windows.Forms.RadioButton
        Me.AutoPButton = New System.Windows.Forms.RadioButton
        Me.GCButton = New System.Windows.Forms.RadioButton
        Me.ClearButton = New System.Windows.Forms.Button
        Me.InvertXCheckBox = New System.Windows.Forms.CheckBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.SaveLogoButton = New System.Windows.Forms.Button
        Me.LogoPWMButton = New System.Windows.Forms.RadioButton
        Me.LogoEntropyButton = New System.Windows.Forms.RadioButton
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.PWMShannonButton = New System.Windows.Forms.RadioButton
        Me.PWMLogLikelyhoodButton = New System.Windows.Forms.RadioButton
        Me.SaveImageDialog = New System.Windows.Forms.SaveFileDialog
        CType(Me.PWMDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(337, 144)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 13)
        Me.Label5.TabIndex = 37
        Me.Label5.Text = "Min score:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(337, 105)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 13)
        Me.Label4.TabIndex = 36
        Me.Label4.Text = "Max score:"
        '
        'MinTextBox
        '
        Me.MinTextBox.Location = New System.Drawing.Point(340, 160)
        Me.MinTextBox.Name = "MinTextBox"
        Me.MinTextBox.ReadOnly = True
        Me.MinTextBox.Size = New System.Drawing.Size(70, 20)
        Me.MinTextBox.TabIndex = 35
        '
        'MaxTextBox
        '
        Me.MaxTextBox.Location = New System.Drawing.Point(340, 121)
        Me.MaxTextBox.Name = "MaxTextBox"
        Me.MaxTextBox.ReadOnly = True
        Me.MaxTextBox.Size = New System.Drawing.Size(70, 20)
        Me.MaxTextBox.TabIndex = 34
        '
        'SaveButton
        '
        Me.SaveButton.Location = New System.Drawing.Point(340, 41)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(75, 23)
        Me.SaveButton.TabIndex = 32
        Me.SaveButton.Text = "Save PWM"
        Me.SaveButton.UseVisualStyleBackColor = True
        '
        'GCTextBox
        '
        Me.GCTextBox.Location = New System.Drawing.Point(60, 18)
        Me.GCTextBox.Name = "GCTextBox"
        Me.GCTextBox.Size = New System.Drawing.Size(33, 20)
        Me.GCTextBox.TabIndex = 31
        Me.GCTextBox.Text = "0,5"
        '
        'GoButton
        '
        Me.GoButton.Location = New System.Drawing.Point(340, 12)
        Me.GoButton.Name = "GoButton"
        Me.GoButton.Size = New System.Drawing.Size(75, 23)
        Me.GoButton.TabIndex = 30
        Me.GoButton.Text = "Get PWM"
        Me.GoButton.UseVisualStyleBackColor = True
        '
        'SeqTextBox
        '
        Me.SeqTextBox.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.SeqTextBox.Location = New System.Drawing.Point(12, 12)
        Me.SeqTextBox.Multiline = True
        Me.SeqTextBox.Name = "SeqTextBox"
        Me.SeqTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.SeqTextBox.Size = New System.Drawing.Size(319, 168)
        Me.SeqTextBox.TabIndex = 29
        '
        'PWMDataGridView
        '
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PWMDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.PWMDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PWMDataGridView.DefaultCellStyle = DataGridViewCellStyle2
        Me.PWMDataGridView.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PWMDataGridView.Location = New System.Drawing.Point(0, 205)
        Me.PWMDataGridView.Name = "PWMDataGridView"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PWMDataGridView.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.PWMDataGridView.RowHeadersWidth = 51
        Me.PWMDataGridView.Size = New System.Drawing.Size(712, 150)
        Me.PWMDataGridView.TabIndex = 28
        '
        'LOGOPanel
        '
        Me.LOGOPanel.AutoScroll = True
        Me.LOGOPanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.LOGOPanel.Location = New System.Drawing.Point(0, 355)
        Me.LOGOPanel.Name = "LOGOPanel"
        Me.LOGOPanel.Size = New System.Drawing.Size(712, 124)
        Me.LOGOPanel.TabIndex = 38
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.SizeCorrectionCheckBox)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.TextBox_CP)
        Me.GroupBox1.Controls.Add(Me.TextBox_GP)
        Me.GroupBox1.Controls.Add(Me.TextBox_TP)
        Me.GroupBox1.Controls.Add(Me.TextBox_AP)
        Me.GroupBox1.Controls.Add(Me.ManualPButton)
        Me.GroupBox1.Controls.Add(Me.AutoPButton)
        Me.GroupBox1.Controls.Add(Me.GCButton)
        Me.GroupBox1.Controls.Add(Me.GCTextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(556, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(146, 168)
        Me.GroupBox1.TabIndex = 39
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Background"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(67, 114)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(17, 13)
        Me.Label6.TabIndex = 39
        Me.Label6.Text = "C:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 114)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(18, 13)
        Me.Label3.TabIndex = 38
        Me.Label3.Text = "G:"
        '
        'SizeCorrectionCheckBox
        '
        Me.SizeCorrectionCheckBox.AutoSize = True
        Me.SizeCorrectionCheckBox.Checked = True
        Me.SizeCorrectionCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.SizeCorrectionCheckBox.Location = New System.Drawing.Point(8, 137)
        Me.SizeCorrectionCheckBox.Name = "SizeCorrectionCheckBox"
        Me.SizeCorrectionCheckBox.Size = New System.Drawing.Size(135, 17)
        Me.SizeCorrectionCheckBox.TabIndex = 40
        Me.SizeCorrectionCheckBox.Text = "Sample size correction "
        Me.SizeCorrectionCheckBox.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(67, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(17, 13)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "T:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 88)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 13)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "A:"
        '
        'TextBox_CP
        '
        Me.TextBox_CP.Location = New System.Drawing.Point(90, 111)
        Me.TextBox_CP.Name = "TextBox_CP"
        Me.TextBox_CP.Size = New System.Drawing.Size(33, 20)
        Me.TextBox_CP.TabIndex = 35
        Me.TextBox_CP.Text = "0,25"
        '
        'TextBox_GP
        '
        Me.TextBox_GP.Location = New System.Drawing.Point(28, 111)
        Me.TextBox_GP.Name = "TextBox_GP"
        Me.TextBox_GP.Size = New System.Drawing.Size(33, 20)
        Me.TextBox_GP.TabIndex = 34
        Me.TextBox_GP.Text = "0,25"
        '
        'TextBox_TP
        '
        Me.TextBox_TP.Location = New System.Drawing.Point(90, 85)
        Me.TextBox_TP.Name = "TextBox_TP"
        Me.TextBox_TP.Size = New System.Drawing.Size(33, 20)
        Me.TextBox_TP.TabIndex = 33
        Me.TextBox_TP.Text = "0,25"
        '
        'TextBox_AP
        '
        Me.TextBox_AP.Location = New System.Drawing.Point(28, 85)
        Me.TextBox_AP.Name = "TextBox_AP"
        Me.TextBox_AP.Size = New System.Drawing.Size(33, 20)
        Me.TextBox_AP.TabIndex = 32
        Me.TextBox_AP.Text = "0,25"
        '
        'ManualPButton
        '
        Me.ManualPButton.AutoSize = True
        Me.ManualPButton.Location = New System.Drawing.Point(6, 65)
        Me.ManualPButton.Name = "ManualPButton"
        Me.ManualPButton.Size = New System.Drawing.Size(60, 17)
        Me.ManualPButton.TabIndex = 2
        Me.ManualPButton.Text = "Manual"
        Me.ManualPButton.UseVisualStyleBackColor = True
        '
        'AutoPButton
        '
        Me.AutoPButton.AutoSize = True
        Me.AutoPButton.Checked = True
        Me.AutoPButton.Location = New System.Drawing.Point(6, 42)
        Me.AutoPButton.Name = "AutoPButton"
        Me.AutoPButton.Size = New System.Drawing.Size(89, 17)
        Me.AutoPButton.TabIndex = 1
        Me.AutoPButton.TabStop = True
        Me.AutoPButton.Text = "Auto (sample)"
        Me.AutoPButton.UseVisualStyleBackColor = True
        '
        'GCButton
        '
        Me.GCButton.AutoSize = True
        Me.GCButton.Location = New System.Drawing.Point(6, 19)
        Me.GCButton.Name = "GCButton"
        Me.GCButton.Size = New System.Drawing.Size(48, 17)
        Me.GCButton.TabIndex = 0
        Me.GCButton.Text = "%GC"
        Me.GCButton.UseVisualStyleBackColor = True
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(340, 70)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(75, 23)
        Me.ClearButton.TabIndex = 41
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'InvertXCheckBox
        '
        Me.InvertXCheckBox.AutoSize = True
        Me.InvertXCheckBox.Location = New System.Drawing.Point(6, 19)
        Me.InvertXCheckBox.Name = "InvertXCheckBox"
        Me.InvertXCheckBox.Size = New System.Drawing.Size(117, 17)
        Me.InvertXCheckBox.TabIndex = 42
        Me.InvertXCheckBox.Text = "Invert LOGO X axis"
        Me.InvertXCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.SaveLogoButton)
        Me.GroupBox2.Controls.Add(Me.LogoPWMButton)
        Me.GroupBox2.Controls.Add(Me.LogoEntropyButton)
        Me.GroupBox2.Controls.Add(Me.InvertXCheckBox)
        Me.GroupBox2.Location = New System.Drawing.Point(425, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(125, 91)
        Me.GroupBox2.TabIndex = 43
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "LOGO"
        '
        'SaveLogoButton
        '
        Me.SaveLogoButton.Location = New System.Drawing.Point(79, 62)
        Me.SaveLogoButton.Name = "SaveLogoButton"
        Me.SaveLogoButton.Size = New System.Drawing.Size(40, 23)
        Me.SaveLogoButton.TabIndex = 45
        Me.SaveLogoButton.Text = "Save"
        Me.SaveLogoButton.UseVisualStyleBackColor = True
        '
        'LogoPWMButton
        '
        Me.LogoPWMButton.AutoSize = True
        Me.LogoPWMButton.Checked = True
        Me.LogoPWMButton.Location = New System.Drawing.Point(6, 65)
        Me.LogoPWMButton.Name = "LogoPWMButton"
        Me.LogoPWMButton.Size = New System.Drawing.Size(52, 17)
        Me.LogoPWMButton.TabIndex = 44
        Me.LogoPWMButton.TabStop = True
        Me.LogoPWMButton.Text = "PWM"
        Me.LogoPWMButton.UseVisualStyleBackColor = True
        '
        'LogoEntropyButton
        '
        Me.LogoEntropyButton.AutoSize = True
        Me.LogoEntropyButton.Location = New System.Drawing.Point(6, 42)
        Me.LogoEntropyButton.Name = "LogoEntropyButton"
        Me.LogoEntropyButton.Size = New System.Drawing.Size(106, 17)
        Me.LogoEntropyButton.TabIndex = 43
        Me.LogoEntropyButton.Text = "Shannon entropy"
        Me.LogoEntropyButton.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.PWMShannonButton)
        Me.GroupBox3.Controls.Add(Me.PWMLogLikelyhoodButton)
        Me.GroupBox3.Location = New System.Drawing.Point(425, 109)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(125, 71)
        Me.GroupBox3.TabIndex = 44
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "PWM"
        '
        'PWMShannonButton
        '
        Me.PWMShannonButton.AutoSize = True
        Me.PWMShannonButton.Checked = True
        Me.PWMShannonButton.Location = New System.Drawing.Point(7, 43)
        Me.PWMShannonButton.Name = "PWMShannonButton"
        Me.PWMShannonButton.Size = New System.Drawing.Size(106, 17)
        Me.PWMShannonButton.TabIndex = 1
        Me.PWMShannonButton.TabStop = True
        Me.PWMShannonButton.Text = "Shannon entropy"
        Me.PWMShannonButton.UseVisualStyleBackColor = True
        '
        'PWMLogLikelyhoodButton
        '
        Me.PWMLogLikelyhoodButton.AutoSize = True
        Me.PWMLogLikelyhoodButton.Location = New System.Drawing.Point(7, 20)
        Me.PWMLogLikelyhoodButton.Name = "PWMLogLikelyhoodButton"
        Me.PWMLogLikelyhoodButton.Size = New System.Drawing.Size(93, 17)
        Me.PWMLogLikelyhoodButton.TabIndex = 0
        Me.PWMLogLikelyhoodButton.Text = "Log-likelyhood"
        Me.PWMLogLikelyhoodButton.UseVisualStyleBackColor = True
        '
        'SaveImageDialog
        '
        Me.SaveImageDialog.Filter = "Bitmap|*bpm|JPEG|*jpg|PNG|*.png|TIFF|*.tif"
        '
        'PWMbuilder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(712, 479)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.MinTextBox)
        Me.Controls.Add(Me.MaxTextBox)
        Me.Controls.Add(Me.SaveButton)
        Me.Controls.Add(Me.GoButton)
        Me.Controls.Add(Me.SeqTextBox)
        Me.Controls.Add(Me.PWMDataGridView)
        Me.Controls.Add(Me.LOGOPanel)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "PWMbuilder"
        Me.Text = "PWM Builder"
        CType(Me.PWMDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents MinTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MaxTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SaveButton As System.Windows.Forms.Button
    Friend WithEvents GCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GoButton As System.Windows.Forms.Button
    Friend WithEvents SeqTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PWMDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents LOGOPanel As System.Windows.Forms.Panel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents AutoPButton As System.Windows.Forms.RadioButton
    Friend WithEvents GCButton As System.Windows.Forms.RadioButton
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox_CP As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_GP As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_TP As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_AP As System.Windows.Forms.TextBox
    Friend WithEvents ManualPButton As System.Windows.Forms.RadioButton
    Friend WithEvents SizeCorrectionCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents InvertXCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents LogoPWMButton As System.Windows.Forms.RadioButton
    Friend WithEvents LogoEntropyButton As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents PWMShannonButton As System.Windows.Forms.RadioButton
    Friend WithEvents PWMLogLikelyhoodButton As System.Windows.Forms.RadioButton
    Friend WithEvents SaveLogoButton As System.Windows.Forms.Button
    Friend WithEvents SaveImageDialog As System.Windows.Forms.SaveFileDialog
End Class
