﻿Public Class Repeat_finder

    Public MyGenomeViewer As Genome_Viewer


    Private Sub SearchButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchButton.Click
        Static Counter As Integer = 0

        Dim MinRepL As Integer = RepLMinTextBox.Text
        Dim MaxRepL As Integer = RepLMaxTextBox.Text
        Dim MinSpacerL As Integer = SpacerLMinTextBox.Text
        Dim MaxSpacerL As Integer = SpacerLMaxTextBox.Text
        Dim MismatchCount As Integer = MismatchesTextBox.Text
        Dim Inverted As Boolean = InvertedRepeatsRadioButton.Checked

        Dim CurrentRepL As Integer = MinRepL
        Dim CurrentSpacerL As Integer = MinSpacerL


        Dim RepeatsList As New List(Of Genome_Feature)


        SystemProgressBarBox.MasterProgressBar.Maximum = (MaxRepL - MinRepL) * (MaxSpacerL - MinSpacerL)
        SystemProgressBarBox.MasterProgressBar.Value = 0
        SystemProgressBarBox.Show()
        SystemProgressBarBox.Focus()
        SystemProgressBarBox.StatusLabel.Text = "Analyzing sequence"
        SystemProgressBarBox.StatusLabel.Refresh()


        For i = 0 To MaxRepL - MinRepL

            CurrentSpacerL = MinSpacerL

            For j = 0 To MaxSpacerL - MinSpacerL

                RepeatsList.AddRange(Bioinformatics.RepeatSearch(MyGenomeViewer.Genome_Sequence, CurrentRepL, CurrentSpacerL, MismatchCount, Inverted))

                CurrentSpacerL += 1

                SystemProgressBarBox.MasterProgressBar.PerformStep()

            Next j

            CurrentRepL += 1
        Next i

        Dim NewAssembly As New FeaturesAssembly
        NewAssembly.AssemblyName = "Repeat search-" & Counter
        NewAssembly.Visible = True

        Dim c As Integer = 0
        For Each Rep As Genome_Feature In RepeatsList
            Rep.TAG = "Rep_" & c
            Rep.Name = Rep.TAG
            Rep.Group = NewAssembly.AssemblyName
            c += 1
        Next Rep


        NewAssembly.FeaturesList = RepeatsList


        MyGenomeViewer.Features_Groups_List.Add(NewAssembly)
        MyGenomeViewer.FeaturesGroupsListBox.Items.Add(NewAssembly.AssemblyName)
        MyGenomeViewer.FeaturesGroupsListBox.Items(MyGenomeViewer.FeaturesGroupsListBox.Items.Count - 1).Checked = True

        SystemProgressBarBox.Close()

        Counter += 1
    End Sub


End Class