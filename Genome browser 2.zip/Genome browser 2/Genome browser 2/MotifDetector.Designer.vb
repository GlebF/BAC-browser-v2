﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MotifDetector
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MotifDetector))
        Me.AddButton = New System.Windows.Forms.Button
        Me.ClearButton = New System.Windows.Forms.Button
        Me.RemoveButton = New System.Windows.Forms.Button
        Me.UpButton = New System.Windows.Forms.Button
        Me.DownButton = New System.Windows.Forms.Button
        Me.SearchButton = New System.Windows.Forms.Button
        Me.ViewButton = New System.Windows.Forms.Button
        Me.StatusLabel = New System.Windows.Forms.Label
        Me.ReportTextBox = New System.Windows.Forms.TextBox
        Me.DrawButton = New System.Windows.Forms.Button
        Me.PWMDataGridView = New System.Windows.Forms.DataGridView
        Me.MaxTextBox = New System.Windows.Forms.TextBox
        Me.MinTextBox = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.FilesDataGridView = New System.Windows.Forms.DataGridView
        Me.File_Col = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Threshold_Col = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.LOGOPanel = New System.Windows.Forms.Panel
        Me.DistanceTextBox = New System.Windows.Forms.TextBox
        Me.TSSCheckBox = New System.Windows.Forms.CheckBox
        Me.SourceComboBox = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        CType(Me.PWMDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FilesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'AddButton
        '
        Me.AddButton.Location = New System.Drawing.Point(8, 458)
        Me.AddButton.Name = "AddButton"
        Me.AddButton.Size = New System.Drawing.Size(75, 23)
        Me.AddButton.TabIndex = 8
        Me.AddButton.Text = "Add"
        Me.AddButton.UseVisualStyleBackColor = True
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(89, 458)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(75, 23)
        Me.ClearButton.TabIndex = 9
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'RemoveButton
        '
        Me.RemoveButton.Location = New System.Drawing.Point(8, 487)
        Me.RemoveButton.Name = "RemoveButton"
        Me.RemoveButton.Size = New System.Drawing.Size(75, 23)
        Me.RemoveButton.TabIndex = 10
        Me.RemoveButton.Text = "Remove"
        Me.RemoveButton.UseVisualStyleBackColor = True
        '
        'UpButton
        '
        Me.UpButton.Location = New System.Drawing.Point(371, 317)
        Me.UpButton.Name = "UpButton"
        Me.UpButton.Size = New System.Drawing.Size(75, 23)
        Me.UpButton.TabIndex = 11
        Me.UpButton.Text = "Up"
        Me.UpButton.UseVisualStyleBackColor = True
        '
        'DownButton
        '
        Me.DownButton.Location = New System.Drawing.Point(371, 346)
        Me.DownButton.Name = "DownButton"
        Me.DownButton.Size = New System.Drawing.Size(75, 23)
        Me.DownButton.TabIndex = 12
        Me.DownButton.Text = "Down"
        Me.DownButton.UseVisualStyleBackColor = True
        '
        'SearchButton
        '
        Me.SearchButton.Location = New System.Drawing.Point(371, 404)
        Me.SearchButton.Name = "SearchButton"
        Me.SearchButton.Size = New System.Drawing.Size(75, 23)
        Me.SearchButton.TabIndex = 13
        Me.SearchButton.Text = "Search"
        Me.SearchButton.UseVisualStyleBackColor = True
        '
        'ViewButton
        '
        Me.ViewButton.Location = New System.Drawing.Point(371, 375)
        Me.ViewButton.Name = "ViewButton"
        Me.ViewButton.Size = New System.Drawing.Size(75, 23)
        Me.ViewButton.TabIndex = 15
        Me.ViewButton.Text = "View PWM"
        Me.ViewButton.UseVisualStyleBackColor = True
        '
        'StatusLabel
        '
        Me.StatusLabel.AutoSize = True
        Me.StatusLabel.Location = New System.Drawing.Point(5, 519)
        Me.StatusLabel.Name = "StatusLabel"
        Me.StatusLabel.Size = New System.Drawing.Size(41, 13)
        Me.StatusLabel.TabIndex = 16
        Me.StatusLabel.Text = "Ready!"
        '
        'ReportTextBox
        '
        Me.ReportTextBox.Location = New System.Drawing.Point(452, 291)
        Me.ReportTextBox.Multiline = True
        Me.ReportTextBox.Name = "ReportTextBox"
        Me.ReportTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.ReportTextBox.Size = New System.Drawing.Size(315, 190)
        Me.ReportTextBox.TabIndex = 22
        '
        'DrawButton
        '
        Me.DrawButton.Location = New System.Drawing.Point(371, 433)
        Me.DrawButton.Name = "DrawButton"
        Me.DrawButton.Size = New System.Drawing.Size(75, 23)
        Me.DrawButton.TabIndex = 23
        Me.DrawButton.Text = "Draw sites"
        Me.DrawButton.UseVisualStyleBackColor = True
        '
        'PWMDataGridView
        '
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PWMDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.PWMDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PWMDataGridView.DefaultCellStyle = DataGridViewCellStyle2
        Me.PWMDataGridView.Location = New System.Drawing.Point(12, 12)
        Me.PWMDataGridView.Name = "PWMDataGridView"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PWMDataGridView.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.PWMDataGridView.RowHeadersWidth = 51
        Me.PWMDataGridView.Size = New System.Drawing.Size(755, 150)
        Me.PWMDataGridView.TabIndex = 0
        '
        'MaxTextBox
        '
        Me.MaxTextBox.Location = New System.Drawing.Point(48, 291)
        Me.MaxTextBox.Name = "MaxTextBox"
        Me.MaxTextBox.Size = New System.Drawing.Size(50, 20)
        Me.MaxTextBox.TabIndex = 24
        '
        'MinTextBox
        '
        Me.MinTextBox.Location = New System.Drawing.Point(137, 291)
        Me.MinTextBox.Name = "MinTextBox"
        Me.MinTextBox.Size = New System.Drawing.Size(50, 20)
        Me.MinTextBox.TabIndex = 25
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 294)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 13)
        Me.Label4.TabIndex = 26
        Me.Label4.Text = "Max:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(104, 294)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(27, 13)
        Me.Label5.TabIndex = 27
        Me.Label5.Text = "Min:"
        '
        'FilesDataGridView
        '
        Me.FilesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.FilesDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.File_Col, Me.Threshold_Col})
        Me.FilesDataGridView.Location = New System.Drawing.Point(11, 317)
        Me.FilesDataGridView.Name = "FilesDataGridView"
        Me.FilesDataGridView.Size = New System.Drawing.Size(354, 135)
        Me.FilesDataGridView.TabIndex = 28
        '
        'File_Col
        '
        Me.File_Col.HeaderText = "PWM file"
        Me.File_Col.Name = "File_Col"
        Me.File_Col.Width = 200
        '
        'Threshold_Col
        '
        Me.Threshold_Col.HeaderText = "Threshold"
        Me.Threshold_Col.Name = "Threshold_Col"
        Me.Threshold_Col.Width = 70
        '
        'LOGOPanel
        '
        Me.LOGOPanel.Location = New System.Drawing.Point(12, 169)
        Me.LOGOPanel.Name = "LOGOPanel"
        Me.LOGOPanel.Size = New System.Drawing.Size(755, 116)
        Me.LOGOPanel.TabIndex = 29
        '
        'DistanceTextBox
        '
        Me.DistanceTextBox.Location = New System.Drawing.Point(335, 461)
        Me.DistanceTextBox.Name = "DistanceTextBox"
        Me.DistanceTextBox.Size = New System.Drawing.Size(30, 20)
        Me.DistanceTextBox.TabIndex = 30
        Me.DistanceTextBox.Text = "50"
        '
        'TSSCheckBox
        '
        Me.TSSCheckBox.AutoSize = True
        Me.TSSCheckBox.Location = New System.Drawing.Point(244, 463)
        Me.TSSCheckBox.Name = "TSSCheckBox"
        Me.TSSCheckBox.Size = New System.Drawing.Size(73, 17)
        Me.TSSCheckBox.TabIndex = 31
        Me.TSSCheckBox.Text = "Near TSS"
        Me.TSSCheckBox.UseVisualStyleBackColor = True
        '
        'SourceComboBox
        '
        Me.SourceComboBox.FormattingEnabled = True
        Me.SourceComboBox.Items.AddRange(New Object() {"Main Features", "User Features"})
        Me.SourceComboBox.Location = New System.Drawing.Point(244, 487)
        Me.SourceComboBox.Name = "SourceComboBox"
        Me.SourceComboBox.Size = New System.Drawing.Size(121, 21)
        Me.SourceComboBox.TabIndex = 33
        Me.SourceComboBox.Text = "Main Features"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(141, 490)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 13)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "Source of features:"
        '
        'MotifDetector
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(779, 541)
        Me.Controls.Add(Me.SourceComboBox)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TSSCheckBox)
        Me.Controls.Add(Me.DistanceTextBox)
        Me.Controls.Add(Me.LOGOPanel)
        Me.Controls.Add(Me.FilesDataGridView)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.MinTextBox)
        Me.Controls.Add(Me.MaxTextBox)
        Me.Controls.Add(Me.DrawButton)
        Me.Controls.Add(Me.ReportTextBox)
        Me.Controls.Add(Me.StatusLabel)
        Me.Controls.Add(Me.ViewButton)
        Me.Controls.Add(Me.SearchButton)
        Me.Controls.Add(Me.DownButton)
        Me.Controls.Add(Me.UpButton)
        Me.Controls.Add(Me.RemoveButton)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.AddButton)
        Me.Controls.Add(Me.PWMDataGridView)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "MotifDetector"
        Me.Text = "Search PWM"
        CType(Me.PWMDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FilesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents AddButton As System.Windows.Forms.Button
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents RemoveButton As System.Windows.Forms.Button
    Friend WithEvents UpButton As System.Windows.Forms.Button
    Friend WithEvents DownButton As System.Windows.Forms.Button
    Friend WithEvents SearchButton As System.Windows.Forms.Button
    Friend WithEvents ViewButton As System.Windows.Forms.Button
    Friend WithEvents StatusLabel As System.Windows.Forms.Label
    Friend WithEvents ReportTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DrawButton As System.Windows.Forms.Button
    Friend WithEvents PWMDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents MaxTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MinTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents FilesDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents File_Col As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Threshold_Col As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LOGOPanel As System.Windows.Forms.Panel
    Friend WithEvents DistanceTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TSSCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents SourceComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
End Class
