﻿Public Class PromoterAssembly

    Private strSequence As String

    Private m10 As K_Word_Weighted
    Private m35 As K_Word_Weighted
    Private ext As K_Word_Weighted

    Private m10_35_SpacerScore As Single = 0
    Private m10_TSS_SpacerScore As Single = 0


    Private bValidated As Boolean = False


    Private listPeakData As New List(Of Single) 'Peaks for all experimental samples
    Private listBackgroundData As New List(Of Single) 'Background for all experimental samples
    Private listBestHitPos As New List(Of Integer) 'List of peak coordinates to control TSS position
    Private strInitiator As New List(Of String)

    Public Property PromoterSequence() As String
        Get
            PromoterSequence = strSequence
        End Get
        Set(ByVal value As String)
            strSequence = value
        End Set
    End Property

    Public Property Initiator() As List(Of String)
        Get
            Initiator = strInitiator
        End Get
        Set(ByVal value As List(Of String))
            strInitiator = value
        End Set
    End Property

    Public Property BestPos() As List(Of Integer)
        Get
            BestPos = listBestHitPos
        End Get
        Set(ByVal value As List(Of Integer))
            listBestHitPos = value
        End Set
    End Property

    Public Property PeakData() As List(Of Single)
        Get
            PeakData = listPeakData
        End Get
        Set(ByVal value As List(Of Single))
            listPeakData = value
        End Set
    End Property

    Public Property BackgroundData() As List(Of Single)
        Get
            BackgroundData = listBackgroundData
        End Get
        Set(ByVal value As List(Of Single))
            listBackgroundData = value
        End Set
    End Property


    Public Property Validated() As Boolean
        Get
            Validated = bValidated
        End Get
        Set(ByVal value As Boolean)
            bValidated = value
        End Set
    End Property

    Public Property minus10_To_minus35_SpacerWeight() As Single
        Get
            minus10_To_minus35_SpacerWeight = m10_35_SpacerScore
        End Get
        Set(ByVal value As Single)
            m10_35_SpacerScore = value
        End Set
    End Property

    Public Property minus10_To_TSS_SpacerWeight() As Single
        Get
            minus10_To_TSS_SpacerWeight = m10_TSS_SpacerScore
        End Get
        Set(ByVal value As Single)
            m10_TSS_SpacerScore = value
        End Set
    End Property

    Public Property minus10() As K_Word_Weighted
        Get
            minus10 = m10
        End Get
        Set(ByVal value As K_Word_Weighted)
            m10 = value
        End Set
    End Property

    Public Property minus35() As K_Word_Weighted
        Get
            minus35 = m35
        End Get
        Set(ByVal value As K_Word_Weighted)
            m35 = value
        End Set
    End Property

    Public Property Extension() As K_Word_Weighted
        Get
            Extension = ext
        End Get
        Set(ByVal value As K_Word_Weighted)
            ext = value
        End Set
    End Property



End Class
