﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Promoter_power_distribution
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SearchButton = New System.Windows.Forms.Button
        Me.PWM10TextBox = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.PWM35TextBox = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.SpacerTextBox = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.PWMExtTextBox = New System.Windows.Forms.TextBox
        Me.Threshold10TextBox = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Minus10_35spacerLTextBox = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Minus10_35spacerDivTextBox = New System.Windows.Forms.TextBox
        Me.Minus10_TSSspacerDivTextBox = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Minus10_TSSspacerLTextBox = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'SearchButton
        '
        Me.SearchButton.Location = New System.Drawing.Point(574, 194)
        Me.SearchButton.Name = "SearchButton"
        Me.SearchButton.Size = New System.Drawing.Size(75, 23)
        Me.SearchButton.TabIndex = 0
        Me.SearchButton.Text = "Search"
        Me.SearchButton.UseVisualStyleBackColor = True
        '
        'PWM10TextBox
        '
        Me.PWM10TextBox.Location = New System.Drawing.Point(12, 29)
        Me.PWM10TextBox.Name = "PWM10TextBox"
        Me.PWM10TextBox.Size = New System.Drawing.Size(250, 20)
        Me.PWM10TextBox.TabIndex = 1
        Me.PWM10TextBox.Text = "C:\Users\User\Documents\Геномика\Mycoplasma gallisepticum S6\Promoter modeling\mi" & _
            "nus10.pwm.txt"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "-10 box PWM"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "-35 box PWM"
        '
        'PWM35TextBox
        '
        Me.PWM35TextBox.Location = New System.Drawing.Point(12, 80)
        Me.PWM35TextBox.Name = "PWM35TextBox"
        Me.PWM35TextBox.Size = New System.Drawing.Size(250, 20)
        Me.PWM35TextBox.TabIndex = 3
        Me.PWM35TextBox.Text = "C:\Users\User\Documents\Геномика\Mycoplasma gallisepticum S6\Promoter modeling\mi" & _
            "nus35.pwm.txt"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 168)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Spacer PWM"
        '
        'SpacerTextBox
        '
        Me.SpacerTextBox.Location = New System.Drawing.Point(12, 184)
        Me.SpacerTextBox.Name = "SpacerTextBox"
        Me.SpacerTextBox.Size = New System.Drawing.Size(250, 20)
        Me.SpacerTextBox.TabIndex = 7
        Me.SpacerTextBox.Text = "C:\Users\User\Documents\Геномика\Mycoplasma gallisepticum S6\Promoter modeling\Sp" & _
            "acer_preference.pwm.txt"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(9, 115)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Ext PWM"
        '
        'PWMExtTextBox
        '
        Me.PWMExtTextBox.Location = New System.Drawing.Point(12, 131)
        Me.PWMExtTextBox.Name = "PWMExtTextBox"
        Me.PWMExtTextBox.Size = New System.Drawing.Size(250, 20)
        Me.PWMExtTextBox.TabIndex = 5
        Me.PWMExtTextBox.Text = "C:\Users\User\Documents\Геномика\Mycoplasma gallisepticum S6\Promoter modeling\ex" & _
            "t.pwm.txt"
        '
        'Threshold10TextBox
        '
        Me.Threshold10TextBox.Location = New System.Drawing.Point(283, 29)
        Me.Threshold10TextBox.Name = "Threshold10TextBox"
        Me.Threshold10TextBox.Size = New System.Drawing.Size(100, 20)
        Me.Threshold10TextBox.TabIndex = 9
        Me.Threshold10TextBox.Text = "10"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(280, 13)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Threshold:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(402, 13)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(122, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "-10 to -35 spacer length:"
        '
        'Minus10_35spacerLTextBox
        '
        Me.Minus10_35spacerLTextBox.Location = New System.Drawing.Point(405, 29)
        Me.Minus10_35spacerLTextBox.Name = "Minus10_35spacerLTextBox"
        Me.Minus10_35spacerLTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Minus10_35spacerLTextBox.TabIndex = 12
        Me.Minus10_35spacerLTextBox.Text = "17"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(402, 64)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(146, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "-10 to -35 spacer divergence:"
        '
        'Minus10_35spacerDivTextBox
        '
        Me.Minus10_35spacerDivTextBox.Location = New System.Drawing.Point(405, 80)
        Me.Minus10_35spacerDivTextBox.Name = "Minus10_35spacerDivTextBox"
        Me.Minus10_35spacerDivTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Minus10_35spacerDivTextBox.TabIndex = 14
        Me.Minus10_35spacerDivTextBox.Text = "2"
        '
        'Minus10_TSSspacerDivTextBox
        '
        Me.Minus10_TSSspacerDivTextBox.Location = New System.Drawing.Point(405, 184)
        Me.Minus10_TSSspacerDivTextBox.Name = "Minus10_TSSspacerDivTextBox"
        Me.Minus10_TSSspacerDivTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Minus10_TSSspacerDivTextBox.TabIndex = 18
        Me.Minus10_TSSspacerDivTextBox.Text = "1"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(402, 168)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(152, 13)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "-10 to TSS spacer divergence:"
        '
        'Minus10_TSSspacerLTextBox
        '
        Me.Minus10_TSSspacerLTextBox.Location = New System.Drawing.Point(405, 131)
        Me.Minus10_TSSspacerLTextBox.Name = "Minus10_TSSspacerLTextBox"
        Me.Minus10_TSSspacerLTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Minus10_TSSspacerLTextBox.TabIndex = 16
        Me.Minus10_TSSspacerLTextBox.Text = "6"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(402, 115)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(128, 13)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "-10 to TSS spacer length:"
        '
        'Promoter_power_distribution
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(661, 229)
        Me.Controls.Add(Me.Minus10_TSSspacerDivTextBox)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Minus10_TSSspacerLTextBox)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Minus10_35spacerDivTextBox)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Minus10_35spacerLTextBox)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Threshold10TextBox)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.SpacerTextBox)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PWMExtTextBox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PWM35TextBox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PWM10TextBox)
        Me.Controls.Add(Me.SearchButton)
        Me.Name = "Promoter_power_distribution"
        Me.Text = "Promoter power distribution"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SearchButton As System.Windows.Forms.Button
    Friend WithEvents PWM10TextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PWM35TextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents SpacerTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PWMExtTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Threshold10TextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Minus10_35spacerLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Minus10_35spacerDivTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Minus10_TSSspacerDivTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Minus10_TSSspacerLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
End Class
