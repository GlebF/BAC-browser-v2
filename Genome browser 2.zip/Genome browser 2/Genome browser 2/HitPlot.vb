﻿Public Class HitPlot
    Private ForAlignedHitMap As List(Of K_Word_Hashed) = Nothing
    Private RevAlignedHitMap As List(Of K_Word_Hashed) = Nothing

    Private Sub HitMap_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles SplitContainer1.Panel1.Paint

        If Not IsNothing(ForAlignedHitMap) Then


            Dim X_Proj_K As Single = SplitContainer1.Panel1.Width / ForAlignedHitMap.Count
            Dim Y_Proj_K As Single = SplitContainer1.Panel1.Height / ForAlignedHitMap.Count


            For x = 0 To ForAlignedHitMap.Count - 1

                If ForAlignedHitMap(x).Aligned_Positions.Count > 0 Then
                    For y = 0 To ForAlignedHitMap(x).Aligned_Positions.Count - 1
                        e.Graphics.DrawRectangle(Pens.Red, ForAlignedHitMap(x).Relative_Position * X_Proj_K, ForAlignedHitMap(x).Aligned_Positions(y) * Y_Proj_K, 1, 1)

                    Next y
                End If


                If RevAlignedHitMap(x).Aligned_Positions.Count > 0 Then
                    For y = 0 To RevAlignedHitMap(x).Aligned_Positions.Count - 1
                        e.Graphics.DrawRectangle(Pens.Blue, RevAlignedHitMap(x).Relative_Position * X_Proj_K, (RevAlignedHitMap.Count - RevAlignedHitMap(x).Aligned_Positions(y)) * Y_Proj_K, 1, 1)

                    Next y
                End If

            Next x

        End If
    End Sub

    Public Sub RefreshPlot()

        If SeqTextBox.Text.Length > 0 Then


            Dim WordL As Integer = CType(WLTextBox.Text, Integer)


            ForAlignedHitMap = Bioinformatics.Make_Hashed_Hit_List(SeqTextBox.Text, SeqTextBox.Text, WordL)

            RevAlignedHitMap = Bioinformatics.Make_Hashed_Hit_List(SeqTextBox.Text, Bioinformatics.GetReverseComplement(SeqTextBox.Text), WordL)

            SplitContainer1.Panel1.Invalidate()

        End If

    End Sub


    Private Sub RefreshPlotButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshPlotButton.Click
        RefreshPlot()
    End Sub

End Class