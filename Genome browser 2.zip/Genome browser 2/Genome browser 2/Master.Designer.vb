﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Master
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Master))
        Me.MasterMenuStrip = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaveAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator
        Me.MergeGBToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.UndoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator16 = New System.Windows.Forms.ToolStripSeparator
        Me.FindDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FindTabToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ReloadDataTablesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MultilineTabsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator22 = New System.Windows.Forms.ToolStripSeparator
        Me.CircularViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MapByFeatureIDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator19 = New System.Windows.Forms.ToolStripSeparator
        Me.InSilico2DEF_ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator
        Me.TranslationF6ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewInBrowserToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.Export6FToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CDSTranslationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator
        Me.FunctionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GCContentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GCSkew_ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ATSkew_ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DGDistributionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PolyTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FeaturesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RBLASTToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator21 = New System.Windows.Forms.ToolStripSeparator
        Me.FindORFsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FindRepeatsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FindHairpinsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FindSequencesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator
        Me.AddFeaturesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ImportFeaturesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AnnotationFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TABSeparatedFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.ExportSequencesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExportProteinsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.ExtractDataFromGbFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExtractProteinIDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.QuantitationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ImportSAMFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OpenPositionalValuesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ImportMultiplePositionalValuesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ImportPositionalValuesTableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OverlayIntegratedValuesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator24 = New System.Windows.Forms.ToolStripSeparator
        Me.CountCoverageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.IdentifyTranscriptionUnitsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AnalyzeERSLibraryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PositionalQuantitationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SmoothCoverageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.MakeCoverageFromFeaturesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PWMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BuildPWMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FindPWMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator17 = New System.Windows.Forms.ToolStripSeparator
        Me.FindMotifToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator23 = New System.Windows.Forms.ToolStripSeparator
        Me.FindBestPWMHit_ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PWMDistributionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OligocalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BatchOligocalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ThermodynamicsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ODToPmolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FindPrimersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HitPlotToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator18 = New System.Windows.Forms.ToolStripSeparator
        Me.ProteinMWAndPIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator20 = New System.Windows.Forms.ToolStripSeparator
        Me.RandomSequenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator
        Me.ExpectWordCount_ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CodonUsageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.KmerStatisticsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.IdentifyPromotersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ArrayDesign_ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.SyntheticBiologyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DesignAssemblyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReloadDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ServiceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReloadSourceDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LogWindowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewHistoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CallTestFormToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TestToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MasterStatusStrip = New System.Windows.Forms.StatusStrip
        Me.MasterStatusLabel = New System.Windows.Forms.ToolStripStatusLabel
        Me.MasterTabControl = New System.Windows.Forms.TabControl
        Me.OpenFileDialog = New System.Windows.Forms.OpenFileDialog
        Me.SaveFileDialog = New System.Windows.Forms.SaveFileDialog
        Me.SaveImageDialog = New System.Windows.Forms.SaveFileDialog
        Me.ColorSelectDialog = New System.Windows.Forms.ColorDialog
        Me.MasterMenuStrip.SuspendLayout()
        Me.MasterStatusStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'MasterMenuStrip
        '
        Me.MasterMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.ViewToolStripMenuItem, Me.FeaturesToolStripMenuItem, Me.QuantitationToolStripMenuItem, Me.PWMToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.ServiceToolStripMenuItem})
        Me.MasterMenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MasterMenuStrip.Name = "MasterMenuStrip"
        Me.MasterMenuStrip.Size = New System.Drawing.Size(891, 24)
        Me.MasterMenuStrip.TabIndex = 0
        Me.MasterMenuStrip.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.ToolStripSeparator1, Me.OpenToolStripMenuItem, Me.ToolStripSeparator2, Me.SaveToolStripMenuItem, Me.SaveAsToolStripMenuItem, Me.ToolStripSeparator10, Me.MergeGBToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Image = CType(resources.GetObject("NewToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(155, 6)
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Image = CType(resources.GetObject("OpenToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.OpenToolStripMenuItem.Text = "Open"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(155, 6)
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Image = CType(resources.GetObject("SaveToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'SaveAsToolStripMenuItem
        '
        Me.SaveAsToolStripMenuItem.Image = CType(resources.GetObject("SaveAsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SaveAsToolStripMenuItem.Name = "SaveAsToolStripMenuItem"
        Me.SaveAsToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.SaveAsToolStripMenuItem.Text = "Save as"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(155, 6)
        '
        'MergeGBToolStripMenuItem
        '
        Me.MergeGBToolStripMenuItem.Name = "MergeGBToolStripMenuItem"
        Me.MergeGBToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.MergeGBToolStripMenuItem.Text = "Merge GenBank"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UndoToolStripMenuItem, Me.ToolStripSeparator16, Me.FindDataToolStripMenuItem, Me.FindTabToolStripMenuItem, Me.ToolStripSeparator3, Me.ReloadDataTablesToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'UndoToolStripMenuItem
        '
        Me.UndoToolStripMenuItem.Image = CType(resources.GetObject("UndoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UndoToolStripMenuItem.Name = "UndoToolStripMenuItem"
        Me.UndoToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.UndoToolStripMenuItem.Text = "Undo"
        '
        'ToolStripSeparator16
        '
        Me.ToolStripSeparator16.Name = "ToolStripSeparator16"
        Me.ToolStripSeparator16.Size = New System.Drawing.Size(167, 6)
        '
        'FindDataToolStripMenuItem
        '
        Me.FindDataToolStripMenuItem.Image = CType(resources.GetObject("FindDataToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FindDataToolStripMenuItem.Name = "FindDataToolStripMenuItem"
        Me.FindDataToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.FindDataToolStripMenuItem.Text = "Metasearch"
        '
        'FindTabToolStripMenuItem
        '
        Me.FindTabToolStripMenuItem.Image = CType(resources.GetObject("FindTabToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FindTabToolStripMenuItem.Name = "FindTabToolStripMenuItem"
        Me.FindTabToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.FindTabToolStripMenuItem.Text = "Find tab"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(167, 6)
        '
        'ReloadDataTablesToolStripMenuItem
        '
        Me.ReloadDataTablesToolStripMenuItem.Name = "ReloadDataTablesToolStripMenuItem"
        Me.ReloadDataTablesToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.ReloadDataTablesToolStripMenuItem.Text = "Reload data tables"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MultilineTabsToolStripMenuItem, Me.ToolStripSeparator22, Me.CircularViewToolStripMenuItem, Me.MapByFeatureIDToolStripMenuItem, Me.ToolStripSeparator19, Me.InSilico2DEF_ToolStripMenuItem, Me.ToolStripSeparator13, Me.TranslationF6ToolStripMenuItem, Me.CDSTranslationToolStripMenuItem, Me.ToolStripSeparator12, Me.FunctionsToolStripMenuItem})
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'MultilineTabsToolStripMenuItem
        '
        Me.MultilineTabsToolStripMenuItem.CheckOnClick = True
        Me.MultilineTabsToolStripMenuItem.Name = "MultilineTabsToolStripMenuItem"
        Me.MultilineTabsToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.MultilineTabsToolStripMenuItem.Text = "Multiline tabs"
        '
        'ToolStripSeparator22
        '
        Me.ToolStripSeparator22.Name = "ToolStripSeparator22"
        Me.ToolStripSeparator22.Size = New System.Drawing.Size(190, 6)
        '
        'CircularViewToolStripMenuItem
        '
        Me.CircularViewToolStripMenuItem.Image = CType(resources.GetObject("CircularViewToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CircularViewToolStripMenuItem.Name = "CircularViewToolStripMenuItem"
        Me.CircularViewToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.CircularViewToolStripMenuItem.Text = "Circular map view"
        Me.CircularViewToolStripMenuItem.ToolTipText = "Maps features from the annotation to circle"
        '
        'MapByFeatureIDToolStripMenuItem
        '
        Me.MapByFeatureIDToolStripMenuItem.Name = "MapByFeatureIDToolStripMenuItem"
        Me.MapByFeatureIDToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.MapByFeatureIDToolStripMenuItem.Text = "Map by feature ID"
        Me.MapByFeatureIDToolStripMenuItem.ToolTipText = "Maps feature to circle by ID"
        '
        'ToolStripSeparator19
        '
        Me.ToolStripSeparator19.Name = "ToolStripSeparator19"
        Me.ToolStripSeparator19.Size = New System.Drawing.Size(190, 6)
        '
        'InSilico2DEF_ToolStripMenuItem
        '
        Me.InSilico2DEF_ToolStripMenuItem.Image = CType(resources.GetObject("InSilico2DEF_ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.InSilico2DEF_ToolStripMenuItem.Name = "InSilico2DEF_ToolStripMenuItem"
        Me.InSilico2DEF_ToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.InSilico2DEF_ToolStripMenuItem.Text = "In silico 2D EF"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(190, 6)
        '
        'TranslationF6ToolStripMenuItem
        '
        Me.TranslationF6ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewInBrowserToolStripMenuItem1, Me.Export6FToolStripMenuItem})
        Me.TranslationF6ToolStripMenuItem.Image = CType(resources.GetObject("TranslationF6ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TranslationF6ToolStripMenuItem.Name = "TranslationF6ToolStripMenuItem"
        Me.TranslationF6ToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.TranslationF6ToolStripMenuItem.Text = "6-Frame translation"
        '
        'ViewInBrowserToolStripMenuItem1
        '
        Me.ViewInBrowserToolStripMenuItem1.Name = "ViewInBrowserToolStripMenuItem1"
        Me.ViewInBrowserToolStripMenuItem1.Size = New System.Drawing.Size(157, 22)
        Me.ViewInBrowserToolStripMenuItem1.Text = "View in browser"
        '
        'Export6FToolStripMenuItem
        '
        Me.Export6FToolStripMenuItem.Name = "Export6FToolStripMenuItem"
        Me.Export6FToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.Export6FToolStripMenuItem.Text = "Export"
        '
        'CDSTranslationToolStripMenuItem
        '
        Me.CDSTranslationToolStripMenuItem.CheckOnClick = True
        Me.CDSTranslationToolStripMenuItem.Image = CType(resources.GetObject("CDSTranslationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CDSTranslationToolStripMenuItem.Name = "CDSTranslationToolStripMenuItem"
        Me.CDSTranslationToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.CDSTranslationToolStripMenuItem.Text = "Toggle CDS translation"
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(190, 6)
        '
        'FunctionsToolStripMenuItem
        '
        Me.FunctionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GCContentToolStripMenuItem, Me.GCSkew_ToolStripMenuItem, Me.ATSkew_ToolStripMenuItem, Me.DGDistributionToolStripMenuItem, Me.PolyTToolStripMenuItem})
        Me.FunctionsToolStripMenuItem.Image = CType(resources.GetObject("FunctionsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FunctionsToolStripMenuItem.Name = "FunctionsToolStripMenuItem"
        Me.FunctionsToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.FunctionsToolStripMenuItem.Text = "Functions"
        '
        'GCContentToolStripMenuItem
        '
        Me.GCContentToolStripMenuItem.Name = "GCContentToolStripMenuItem"
        Me.GCContentToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.GCContentToolStripMenuItem.Text = "GC content"
        '
        'GCSkew_ToolStripMenuItem
        '
        Me.GCSkew_ToolStripMenuItem.Name = "GCSkew_ToolStripMenuItem"
        Me.GCSkew_ToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.GCSkew_ToolStripMenuItem.Text = "GC skew"
        '
        'ATSkew_ToolStripMenuItem
        '
        Me.ATSkew_ToolStripMenuItem.Name = "ATSkew_ToolStripMenuItem"
        Me.ATSkew_ToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.ATSkew_ToolStripMenuItem.Text = "AT skew"
        '
        'DGDistributionToolStripMenuItem
        '
        Me.DGDistributionToolStripMenuItem.Name = "DGDistributionToolStripMenuItem"
        Me.DGDistributionToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.DGDistributionToolStripMenuItem.Text = "Secondary structure"
        Me.DGDistributionToolStripMenuItem.ToolTipText = "Calculates secondary structure stability in a window"
        '
        'PolyTToolStripMenuItem
        '
        Me.PolyTToolStripMenuItem.Name = "PolyTToolStripMenuItem"
        Me.PolyTToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.PolyTToolStripMenuItem.Text = "Poly-T"
        '
        'FeaturesToolStripMenuItem
        '
        Me.FeaturesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RBLASTToolStripMenuItem1, Me.ToolStripSeparator21, Me.FindORFsToolStripMenuItem, Me.FindRepeatsToolStripMenuItem, Me.FindHairpinsToolStripMenuItem, Me.FindSequencesToolStripMenuItem, Me.ToolStripSeparator14, Me.AddFeaturesToolStripMenuItem, Me.ImportFeaturesToolStripMenuItem, Me.ToolStripSeparator4, Me.ExportSequencesToolStripMenuItem, Me.ExportProteinsToolStripMenuItem, Me.ToolStripSeparator6, Me.ExtractDataFromGbFileToolStripMenuItem})
        Me.FeaturesToolStripMenuItem.Name = "FeaturesToolStripMenuItem"
        Me.FeaturesToolStripMenuItem.Size = New System.Drawing.Size(79, 20)
        Me.FeaturesToolStripMenuItem.Text = "Annotation"
        '
        'RBLASTToolStripMenuItem1
        '
        Me.RBLASTToolStripMenuItem1.Image = CType(resources.GetObject("RBLASTToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.RBLASTToolStripMenuItem1.Name = "RBLASTToolStripMenuItem1"
        Me.RBLASTToolStripMenuItem1.Size = New System.Drawing.Size(225, 22)
        Me.RBLASTToolStripMenuItem1.Text = "Search nucleotide sequence"
        '
        'ToolStripSeparator21
        '
        Me.ToolStripSeparator21.Name = "ToolStripSeparator21"
        Me.ToolStripSeparator21.Size = New System.Drawing.Size(222, 6)
        '
        'FindORFsToolStripMenuItem
        '
        Me.FindORFsToolStripMenuItem.Image = CType(resources.GetObject("FindORFsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FindORFsToolStripMenuItem.Name = "FindORFsToolStripMenuItem"
        Me.FindORFsToolStripMenuItem.Size = New System.Drawing.Size(225, 22)
        Me.FindORFsToolStripMenuItem.Text = "Find ORFs"
        '
        'FindRepeatsToolStripMenuItem
        '
        Me.FindRepeatsToolStripMenuItem.Image = CType(resources.GetObject("FindRepeatsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FindRepeatsToolStripMenuItem.Name = "FindRepeatsToolStripMenuItem"
        Me.FindRepeatsToolStripMenuItem.Size = New System.Drawing.Size(225, 22)
        Me.FindRepeatsToolStripMenuItem.Text = "Find repeats"
        '
        'FindHairpinsToolStripMenuItem
        '
        Me.FindHairpinsToolStripMenuItem.Name = "FindHairpinsToolStripMenuItem"
        Me.FindHairpinsToolStripMenuItem.Size = New System.Drawing.Size(225, 22)
        Me.FindHairpinsToolStripMenuItem.Text = "Find hairpins"
        '
        'FindSequencesToolStripMenuItem
        '
        Me.FindSequencesToolStripMenuItem.Image = CType(resources.GetObject("FindSequencesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FindSequencesToolStripMenuItem.Name = "FindSequencesToolStripMenuItem"
        Me.FindSequencesToolStripMenuItem.Size = New System.Drawing.Size(225, 22)
        Me.FindSequencesToolStripMenuItem.Text = "Map sequences"
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(222, 6)
        '
        'AddFeaturesToolStripMenuItem
        '
        Me.AddFeaturesToolStripMenuItem.Image = CType(resources.GetObject("AddFeaturesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AddFeaturesToolStripMenuItem.Name = "AddFeaturesToolStripMenuItem"
        Me.AddFeaturesToolStripMenuItem.Size = New System.Drawing.Size(225, 22)
        Me.AddFeaturesToolStripMenuItem.Text = "Add features"
        '
        'ImportFeaturesToolStripMenuItem
        '
        Me.ImportFeaturesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AnnotationFileToolStripMenuItem, Me.TABSeparatedFileToolStripMenuItem})
        Me.ImportFeaturesToolStripMenuItem.Image = CType(resources.GetObject("ImportFeaturesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ImportFeaturesToolStripMenuItem.Name = "ImportFeaturesToolStripMenuItem"
        Me.ImportFeaturesToolStripMenuItem.Size = New System.Drawing.Size(225, 22)
        Me.ImportFeaturesToolStripMenuItem.Text = "Import features"
        '
        'AnnotationFileToolStripMenuItem
        '
        Me.AnnotationFileToolStripMenuItem.Name = "AnnotationFileToolStripMenuItem"
        Me.AnnotationFileToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.AnnotationFileToolStripMenuItem.Text = "Annotation file"
        '
        'TABSeparatedFileToolStripMenuItem
        '
        Me.TABSeparatedFileToolStripMenuItem.Name = "TABSeparatedFileToolStripMenuItem"
        Me.TABSeparatedFileToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.TABSeparatedFileToolStripMenuItem.Text = "TAB separated file"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(222, 6)
        '
        'ExportSequencesToolStripMenuItem
        '
        Me.ExportSequencesToolStripMenuItem.Image = CType(resources.GetObject("ExportSequencesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ExportSequencesToolStripMenuItem.Name = "ExportSequencesToolStripMenuItem"
        Me.ExportSequencesToolStripMenuItem.Size = New System.Drawing.Size(225, 22)
        Me.ExportSequencesToolStripMenuItem.Text = "Export nucleotide sequences"
        '
        'ExportProteinsToolStripMenuItem
        '
        Me.ExportProteinsToolStripMenuItem.Image = CType(resources.GetObject("ExportProteinsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ExportProteinsToolStripMenuItem.Name = "ExportProteinsToolStripMenuItem"
        Me.ExportProteinsToolStripMenuItem.Size = New System.Drawing.Size(225, 22)
        Me.ExportProteinsToolStripMenuItem.Text = "Export protein sequences"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(222, 6)
        '
        'ExtractDataFromGbFileToolStripMenuItem
        '
        Me.ExtractDataFromGbFileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExtractProteinIDToolStripMenuItem})
        Me.ExtractDataFromGbFileToolStripMenuItem.Name = "ExtractDataFromGbFileToolStripMenuItem"
        Me.ExtractDataFromGbFileToolStripMenuItem.Size = New System.Drawing.Size(225, 22)
        Me.ExtractDataFromGbFileToolStripMenuItem.Text = "Extract data from gb file"
        '
        'ExtractProteinIDToolStripMenuItem
        '
        Me.ExtractProteinIDToolStripMenuItem.Name = "ExtractProteinIDToolStripMenuItem"
        Me.ExtractProteinIDToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.ExtractProteinIDToolStripMenuItem.Text = "Extract protein ID"
        '
        'QuantitationToolStripMenuItem
        '
        Me.QuantitationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ImportSAMFileToolStripMenuItem, Me.OpenPositionalValuesToolStripMenuItem, Me.ImportMultiplePositionalValuesToolStripMenuItem, Me.ImportPositionalValuesTableToolStripMenuItem, Me.OverlayIntegratedValuesToolStripMenuItem, Me.ToolStripSeparator24, Me.CountCoverageToolStripMenuItem, Me.IdentifyTranscriptionUnitsToolStripMenuItem, Me.AnalyzeERSLibraryToolStripMenuItem, Me.PositionalQuantitationToolStripMenuItem, Me.SmoothCoverageToolStripMenuItem, Me.ToolStripSeparator7, Me.MakeCoverageFromFeaturesToolStripMenuItem})
        Me.QuantitationToolStripMenuItem.Name = "QuantitationToolStripMenuItem"
        Me.QuantitationToolStripMenuItem.Size = New System.Drawing.Size(69, 20)
        Me.QuantitationToolStripMenuItem.Text = "Coverage"
        '
        'ImportSAMFileToolStripMenuItem
        '
        Me.ImportSAMFileToolStripMenuItem.Name = "ImportSAMFileToolStripMenuItem"
        Me.ImportSAMFileToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.ImportSAMFileToolStripMenuItem.Text = "Import SAM file"
        '
        'OpenPositionalValuesToolStripMenuItem
        '
        Me.OpenPositionalValuesToolStripMenuItem.Image = CType(resources.GetObject("OpenPositionalValuesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenPositionalValuesToolStripMenuItem.Name = "OpenPositionalValuesToolStripMenuItem"
        Me.OpenPositionalValuesToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.OpenPositionalValuesToolStripMenuItem.Text = "Import coverage file"
        '
        'ImportMultiplePositionalValuesToolStripMenuItem
        '
        Me.ImportMultiplePositionalValuesToolStripMenuItem.Name = "ImportMultiplePositionalValuesToolStripMenuItem"
        Me.ImportMultiplePositionalValuesToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.ImportMultiplePositionalValuesToolStripMenuItem.Text = "Import multiple coverage files"
        '
        'ImportPositionalValuesTableToolStripMenuItem
        '
        Me.ImportPositionalValuesTableToolStripMenuItem.Image = CType(resources.GetObject("ImportPositionalValuesTableToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ImportPositionalValuesTableToolStripMenuItem.Name = "ImportPositionalValuesTableToolStripMenuItem"
        Me.ImportPositionalValuesTableToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.ImportPositionalValuesTableToolStripMenuItem.Text = "Import coverage table"
        '
        'OverlayIntegratedValuesToolStripMenuItem
        '
        Me.OverlayIntegratedValuesToolStripMenuItem.Image = CType(resources.GetObject("OverlayIntegratedValuesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OverlayIntegratedValuesToolStripMenuItem.Name = "OverlayIntegratedValuesToolStripMenuItem"
        Me.OverlayIntegratedValuesToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.OverlayIntegratedValuesToolStripMenuItem.Text = "Import coverage blocks"
        '
        'ToolStripSeparator24
        '
        Me.ToolStripSeparator24.Name = "ToolStripSeparator24"
        Me.ToolStripSeparator24.Size = New System.Drawing.Size(229, 6)
        '
        'CountCoverageToolStripMenuItem
        '
        Me.CountCoverageToolStripMenuItem.Image = CType(resources.GetObject("CountCoverageToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CountCoverageToolStripMenuItem.Name = "CountCoverageToolStripMenuItem"
        Me.CountCoverageToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.CountCoverageToolStripMenuItem.Text = "Count relative coverage"
        '
        'IdentifyTranscriptionUnitsToolStripMenuItem
        '
        Me.IdentifyTranscriptionUnitsToolStripMenuItem.Image = CType(resources.GetObject("IdentifyTranscriptionUnitsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.IdentifyTranscriptionUnitsToolStripMenuItem.Name = "IdentifyTranscriptionUnitsToolStripMenuItem"
        Me.IdentifyTranscriptionUnitsToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.IdentifyTranscriptionUnitsToolStripMenuItem.Text = "Identify transcription units"
        '
        'AnalyzeERSLibraryToolStripMenuItem
        '
        Me.AnalyzeERSLibraryToolStripMenuItem.Image = CType(resources.GetObject("AnalyzeERSLibraryToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AnalyzeERSLibraryToolStripMenuItem.Name = "AnalyzeERSLibraryToolStripMenuItem"
        Me.AnalyzeERSLibraryToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.AnalyzeERSLibraryToolStripMenuItem.Text = "Analyze 5'-enriched libraries"
        '
        'PositionalQuantitationToolStripMenuItem
        '
        Me.PositionalQuantitationToolStripMenuItem.Name = "PositionalQuantitationToolStripMenuItem"
        Me.PositionalQuantitationToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.PositionalQuantitationToolStripMenuItem.Text = "Positional quantitation"
        Me.PositionalQuantitationToolStripMenuItem.Visible = False
        '
        'SmoothCoverageToolStripMenuItem
        '
        Me.SmoothCoverageToolStripMenuItem.Name = "SmoothCoverageToolStripMenuItem"
        Me.SmoothCoverageToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.SmoothCoverageToolStripMenuItem.Text = "Smooth coverage"
        Me.SmoothCoverageToolStripMenuItem.ToolTipText = "Smoothes coverage for a list of files"
        Me.SmoothCoverageToolStripMenuItem.Visible = False
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(229, 6)
        '
        'MakeCoverageFromFeaturesToolStripMenuItem
        '
        Me.MakeCoverageFromFeaturesToolStripMenuItem.Name = "MakeCoverageFromFeaturesToolStripMenuItem"
        Me.MakeCoverageFromFeaturesToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.MakeCoverageFromFeaturesToolStripMenuItem.Text = "Make coverage from features"
        '
        'PWMToolStripMenuItem
        '
        Me.PWMToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BuildPWMToolStripMenuItem, Me.FindPWMToolStripMenuItem, Me.ToolStripSeparator17, Me.FindMotifToolStripMenuItem, Me.ToolStripSeparator23, Me.FindBestPWMHit_ToolStripMenuItem, Me.PWMDistributionToolStripMenuItem})
        Me.PWMToolStripMenuItem.Name = "PWMToolStripMenuItem"
        Me.PWMToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.PWMToolStripMenuItem.Text = "PWM"
        '
        'BuildPWMToolStripMenuItem
        '
        Me.BuildPWMToolStripMenuItem.Image = CType(resources.GetObject("BuildPWMToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BuildPWMToolStripMenuItem.Name = "BuildPWMToolStripMenuItem"
        Me.BuildPWMToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.BuildPWMToolStripMenuItem.Text = "Build PWM"
        '
        'FindPWMToolStripMenuItem
        '
        Me.FindPWMToolStripMenuItem.Image = CType(resources.GetObject("FindPWMToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FindPWMToolStripMenuItem.Name = "FindPWMToolStripMenuItem"
        Me.FindPWMToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.FindPWMToolStripMenuItem.Text = "Search PWM"
        '
        'ToolStripSeparator17
        '
        Me.ToolStripSeparator17.Name = "ToolStripSeparator17"
        Me.ToolStripSeparator17.Size = New System.Drawing.Size(184, 6)
        '
        'FindMotifToolStripMenuItem
        '
        Me.FindMotifToolStripMenuItem.Name = "FindMotifToolStripMenuItem"
        Me.FindMotifToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.FindMotifToolStripMenuItem.Text = "De novo motif search"
        '
        'ToolStripSeparator23
        '
        Me.ToolStripSeparator23.Name = "ToolStripSeparator23"
        Me.ToolStripSeparator23.Size = New System.Drawing.Size(184, 6)
        '
        'FindBestPWMHit_ToolStripMenuItem
        '
        Me.FindBestPWMHit_ToolStripMenuItem.Name = "FindBestPWMHit_ToolStripMenuItem"
        Me.FindBestPWMHit_ToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.FindBestPWMHit_ToolStripMenuItem.Text = "Find best PWM hit"
        Me.FindBestPWMHit_ToolStripMenuItem.ToolTipText = "Finds the best PWM entry for each of sequences in a list (Multi-FASTA)"
        '
        'PWMDistributionToolStripMenuItem
        '
        Me.PWMDistributionToolStripMenuItem.Name = "PWMDistributionToolStripMenuItem"
        Me.PWMDistributionToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.PWMDistributionToolStripMenuItem.Text = "PWM distribution"
        Me.PWMDistributionToolStripMenuItem.ToolTipText = "Finds the distribution of PWM weights for each of sequences in a list (Multi-FAST" & _
            "A)"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SequenceToolStripMenuItem, Me.OligocalculatorToolStripMenuItem, Me.BatchOligocalculatorToolStripMenuItem, Me.FindPrimersToolStripMenuItem, Me.HitPlotToolStripMenuItem, Me.ToolStripSeparator18, Me.ProteinMWAndPIToolStripMenuItem, Me.ToolStripSeparator20, Me.RandomSequenceToolStripMenuItem, Me.ToolStripSeparator11, Me.ExpectWordCount_ToolStripMenuItem, Me.CodonUsageToolStripMenuItem, Me.KmerStatisticsToolStripMenuItem, Me.IdentifyPromotersToolStripMenuItem, Me.ArrayDesign_ToolStripMenuItem, Me.ReloadDataToolStripMenuItem, Me.ToolStripSeparator5, Me.SyntheticBiologyToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'SequenceToolStripMenuItem
        '
        Me.SequenceToolStripMenuItem.Image = CType(resources.GetObject("SequenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SequenceToolStripMenuItem.Name = "SequenceToolStripMenuItem"
        Me.SequenceToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.SequenceToolStripMenuItem.Text = "Sequence"
        '
        'OligocalculatorToolStripMenuItem
        '
        Me.OligocalculatorToolStripMenuItem.Image = CType(resources.GetObject("OligocalculatorToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OligocalculatorToolStripMenuItem.Name = "OligocalculatorToolStripMenuItem"
        Me.OligocalculatorToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.OligocalculatorToolStripMenuItem.Text = "Oligocalculator"
        '
        'BatchOligocalculatorToolStripMenuItem
        '
        Me.BatchOligocalculatorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ThermodynamicsToolStripMenuItem, Me.ODToPmolToolStripMenuItem})
        Me.BatchOligocalculatorToolStripMenuItem.Name = "BatchOligocalculatorToolStripMenuItem"
        Me.BatchOligocalculatorToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.BatchOligocalculatorToolStripMenuItem.Text = "Calculate for multiple oligos"
        '
        'ThermodynamicsToolStripMenuItem
        '
        Me.ThermodynamicsToolStripMenuItem.Name = "ThermodynamicsToolStripMenuItem"
        Me.ThermodynamicsToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.ThermodynamicsToolStripMenuItem.Text = "dG, Tm, self-anneal"
        Me.ThermodynamicsToolStripMenuItem.ToolTipText = "Format (TAB-separated): Name Seq"
        '
        'ODToPmolToolStripMenuItem
        '
        Me.ODToPmolToolStripMenuItem.Name = "ODToPmolToolStripMenuItem"
        Me.ODToPmolToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.ODToPmolToolStripMenuItem.Text = "OD to pmol"
        Me.ODToPmolToolStripMenuItem.ToolTipText = "Format (TAB-separated): Name Seq OD"
        '
        'FindPrimersToolStripMenuItem
        '
        Me.FindPrimersToolStripMenuItem.Image = CType(resources.GetObject("FindPrimersToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FindPrimersToolStripMenuItem.Name = "FindPrimersToolStripMenuItem"
        Me.FindPrimersToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.FindPrimersToolStripMenuItem.Text = "Find primers"
        '
        'HitPlotToolStripMenuItem
        '
        Me.HitPlotToolStripMenuItem.Name = "HitPlotToolStripMenuItem"
        Me.HitPlotToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.HitPlotToolStripMenuItem.Text = "Hit plot"
        '
        'ToolStripSeparator18
        '
        Me.ToolStripSeparator18.Name = "ToolStripSeparator18"
        Me.ToolStripSeparator18.Size = New System.Drawing.Size(220, 6)
        '
        'ProteinMWAndPIToolStripMenuItem
        '
        Me.ProteinMWAndPIToolStripMenuItem.Name = "ProteinMWAndPIToolStripMenuItem"
        Me.ProteinMWAndPIToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.ProteinMWAndPIToolStripMenuItem.Text = "Protein MW, pI and HI"
        Me.ProteinMWAndPIToolStripMenuItem.ToolTipText = "Format (TAB-separated): Name AA-Seq"
        '
        'ToolStripSeparator20
        '
        Me.ToolStripSeparator20.Name = "ToolStripSeparator20"
        Me.ToolStripSeparator20.Size = New System.Drawing.Size(220, 6)
        '
        'RandomSequenceToolStripMenuItem
        '
        Me.RandomSequenceToolStripMenuItem.Image = CType(resources.GetObject("RandomSequenceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RandomSequenceToolStripMenuItem.Name = "RandomSequenceToolStripMenuItem"
        Me.RandomSequenceToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.RandomSequenceToolStripMenuItem.Text = "Random sequence"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(220, 6)
        '
        'ExpectWordCount_ToolStripMenuItem
        '
        Me.ExpectWordCount_ToolStripMenuItem.Name = "ExpectWordCount_ToolStripMenuItem"
        Me.ExpectWordCount_ToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.ExpectWordCount_ToolStripMenuItem.Text = "Expect word count"
        '
        'CodonUsageToolStripMenuItem
        '
        Me.CodonUsageToolStripMenuItem.Name = "CodonUsageToolStripMenuItem"
        Me.CodonUsageToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.CodonUsageToolStripMenuItem.Text = "Codon usage"
        '
        'KmerStatisticsToolStripMenuItem
        '
        Me.KmerStatisticsToolStripMenuItem.Name = "KmerStatisticsToolStripMenuItem"
        Me.KmerStatisticsToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.KmerStatisticsToolStripMenuItem.Text = "K-mer statistics"
        '
        'IdentifyPromotersToolStripMenuItem
        '
        Me.IdentifyPromotersToolStripMenuItem.Name = "IdentifyPromotersToolStripMenuItem"
        Me.IdentifyPromotersToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.IdentifyPromotersToolStripMenuItem.Text = "Export promoters"
        Me.IdentifyPromotersToolStripMenuItem.Visible = False
        '
        'ArrayDesign_ToolStripMenuItem
        '
        Me.ArrayDesign_ToolStripMenuItem.Name = "ArrayDesign_ToolStripMenuItem"
        Me.ArrayDesign_ToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.ArrayDesign_ToolStripMenuItem.Text = "Expression array design"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(220, 6)
        '
        'SyntheticBiologyToolStripMenuItem
        '
        Me.SyntheticBiologyToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DesignAssemblyToolStripMenuItem})
        Me.SyntheticBiologyToolStripMenuItem.Name = "SyntheticBiologyToolStripMenuItem"
        Me.SyntheticBiologyToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.SyntheticBiologyToolStripMenuItem.Text = "Synthetic biology"
        '
        'DesignAssemblyToolStripMenuItem
        '
        Me.DesignAssemblyToolStripMenuItem.Name = "DesignAssemblyToolStripMenuItem"
        Me.DesignAssemblyToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.DesignAssemblyToolStripMenuItem.Text = "Design assembly"
        '
        'ReloadDataToolStripMenuItem
        '
        Me.ReloadDataToolStripMenuItem.Name = "ReloadDataToolStripMenuItem"
        Me.ReloadDataToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.ReloadDataToolStripMenuItem.Text = "Reload data tables"
        '
        'ServiceToolStripMenuItem
        '
        Me.ServiceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReloadSourceDataToolStripMenuItem, Me.LogWindowToolStripMenuItem, Me.ViewHistoryToolStripMenuItem, Me.CallTestFormToolStripMenuItem, Me.TestToolStripMenuItem})
        Me.ServiceToolStripMenuItem.Name = "ServiceToolStripMenuItem"
        Me.ServiceToolStripMenuItem.Size = New System.Drawing.Size(56, 20)
        Me.ServiceToolStripMenuItem.Text = "Service"
        Me.ServiceToolStripMenuItem.Visible = False
        '
        'ReloadSourceDataToolStripMenuItem
        '
        Me.ReloadSourceDataToolStripMenuItem.Name = "ReloadSourceDataToolStripMenuItem"
        Me.ReloadSourceDataToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.ReloadSourceDataToolStripMenuItem.Text = "Reload data tables"
        '
        'LogWindowToolStripMenuItem
        '
        Me.LogWindowToolStripMenuItem.Name = "LogWindowToolStripMenuItem"
        Me.LogWindowToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.LogWindowToolStripMenuItem.Text = "Log window"
        '
        'ViewHistoryToolStripMenuItem
        '
        Me.ViewHistoryToolStripMenuItem.Name = "ViewHistoryToolStripMenuItem"
        Me.ViewHistoryToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.ViewHistoryToolStripMenuItem.Text = "View History"
        '
        'CallTestFormToolStripMenuItem
        '
        Me.CallTestFormToolStripMenuItem.Name = "CallTestFormToolStripMenuItem"
        Me.CallTestFormToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.CallTestFormToolStripMenuItem.Text = "Call test form"
        '
        'TestToolStripMenuItem
        '
        Me.TestToolStripMenuItem.Name = "TestToolStripMenuItem"
        Me.TestToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.TestToolStripMenuItem.Text = "Test"
        '
        'MasterStatusStrip
        '
        Me.MasterStatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MasterStatusLabel})
        Me.MasterStatusStrip.Location = New System.Drawing.Point(0, 340)
        Me.MasterStatusStrip.Name = "MasterStatusStrip"
        Me.MasterStatusStrip.Size = New System.Drawing.Size(891, 22)
        Me.MasterStatusStrip.TabIndex = 1
        Me.MasterStatusStrip.Text = "StatusStrip1"
        '
        'MasterStatusLabel
        '
        Me.MasterStatusLabel.Name = "MasterStatusLabel"
        Me.MasterStatusLabel.Size = New System.Drawing.Size(39, 17)
        Me.MasterStatusLabel.Text = "Ready"
        '
        'MasterTabControl
        '
        Me.MasterTabControl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MasterTabControl.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed
        Me.MasterTabControl.ItemSize = New System.Drawing.Size(250, 20)
        Me.MasterTabControl.Location = New System.Drawing.Point(0, 24)
        Me.MasterTabControl.Name = "MasterTabControl"
        Me.MasterTabControl.SelectedIndex = 0
        Me.MasterTabControl.Size = New System.Drawing.Size(891, 316)
        Me.MasterTabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.MasterTabControl.TabIndex = 2
        '
        'OpenFileDialog
        '
        Me.OpenFileDialog.Multiselect = True
        '
        'SaveImageDialog
        '
        Me.SaveImageDialog.Filter = "Bitmap|*bpm|JPEG|*jpg|PNG|*.png|TIFF|*.tif"
        '
        'Master
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(891, 362)
        Me.Controls.Add(Me.MasterTabControl)
        Me.Controls.Add(Me.MasterStatusStrip)
        Me.Controls.Add(Me.MasterMenuStrip)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MainMenuStrip = Me.MasterMenuStrip
        Me.Name = "Master"
        Me.Text = "BAC-browser 2.2"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MasterMenuStrip.ResumeLayout(False)
        Me.MasterMenuStrip.PerformLayout()
        Me.MasterStatusStrip.ResumeLayout(False)
        Me.MasterStatusStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MasterMenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents MasterStatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MasterTabControl As System.Windows.Forms.TabControl
    Friend WithEvents NewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveAsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OligocalculatorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindPrimersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents OpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog As System.Windows.Forms.SaveFileDialog
    Friend WithEvents ServiceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReloadSourceDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogWindowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TestToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RandomSequenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveImageDialog As System.Windows.Forms.SaveFileDialog
    Friend WithEvents ColorSelectDialog As System.Windows.Forms.ColorDialog
    Friend WithEvents FeaturesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportFeaturesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddFeaturesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportSequencesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportProteinsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UndoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewHistoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents QuantitationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PositionalQuantitationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenPositionalValuesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OverlayIntegratedValuesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AnnotationFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TABSeparatedFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IdentifyTranscriptionUnitsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportMultiplePositionalValuesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AnalyzeERSLibraryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CallTestFormToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportPositionalValuesTableToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MasterStatusLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CircularViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InSilico2DEF_ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TranslationF6ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewInBrowserToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Export6FToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CDSTranslationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FunctionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GCContentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GCSkew_ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ATSkew_ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator14 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExpectWordCount_ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DGDistributionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindORFsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindHairpinsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindRepeatsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IdentifyPromotersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SmoothCoverageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MergeGBToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindSequencesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KmerStatisticsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ArrayDesign_ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BatchOligocalculatorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ThermodynamicsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ODToPmolToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator18 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ProteinMWAndPIToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MapByFeatureIDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator19 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator20 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents RBLASTToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator21 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator16 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FindTabToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MultilineTabsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator22 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PWMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BuildPWMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindPWMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindMotifToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindBestPWMHit_ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PWMDistributionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator17 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator23 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator24 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CountCoverageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportSAMFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CodonUsageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ReloadDataTablesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SyntheticBiologyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DesignAssemblyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PolyTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExtractDataFromGbFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExtractProteinIDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HitPlotToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MakeCoverageFromFeaturesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReloadDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
