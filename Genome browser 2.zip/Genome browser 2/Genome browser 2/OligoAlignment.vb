﻿Public Class OligoAlignment
    Private strForSeq As String
    Private strRevSeq As String
    Private strMatchSeq As String
    Private sglSumDG As Single
    Private boolExtensible As Boolean = False
    Private shType As Short
    Private strOddChar As String = ""
    Private strName As String = ""
    Private intMaxComplement As Integer = 0
    Private intFadd3 As Integer = 0
    Private intFadd5 As Integer = 0

    Public Property ForSeq() As String
        Get
            ForSeq = strForSeq
        End Get
        Set(ByVal value As String)
            strForSeq = value
        End Set
    End Property

    Public Property RevSeq()
        Get
            RevSeq = strRevSeq
        End Get
        Set(ByVal value)
            strRevSeq = value
        End Set
    End Property

    Public Property MatchSeq() As String
        Get
            MatchSeq = strMatchSeq
        End Get
        Set(ByVal value As String)
            strMatchSeq = value
        End Set
    End Property

    Public Property SumDG() As Single
        Get
            SumDG = sglSumDG
        End Get
        Set(ByVal value As Single)
            sglSumDG = value
        End Set
    End Property

    Public Property IsExtensible() As Boolean
        Get
            IsExtensible = boolExtensible
        End Get
        Set(ByVal value As Boolean)
            boolExtensible = value
        End Set
    End Property

    Public Property Type() As Short
        Get
            Type = shType
        End Get
        Set(ByVal value As Short)
            shType = value
        End Set
    End Property

    Public Property OddChar() As String
        Get
            OddChar = strOddChar
        End Get
        Set(ByVal value As String)
            strOddChar = value
        End Set
    End Property

    Public Property AlignmentName() As String
        Get
            AlignmentName = strName
        End Get
        Set(ByVal value As String)
            strName = value
        End Set
    End Property

    Public Property MaxComplement() As Integer
        Get
            MaxComplement = intMaxComplement
        End Get
        Set(ByVal value As Integer)
            intMaxComplement = value
        End Set
    End Property

    Public Property Fadd3() As Integer
        Get
            Fadd3 = intFadd3
        End Get
        Set(ByVal value As Integer)
            intFadd3 = value
        End Set
    End Property

    Public Property Fadd5() As Integer
        Get
            Fadd5 = intFadd5
        End Get
        Set(ByVal value As Integer)
            intFadd5 = value
        End Set
    End Property

    Public Sub CalculateSumDG(ByVal T As Single)
        sglSumDG = 0
        Dim FSeq As Char() = strForSeq.ToCharArray
        Dim RSeq As Char() = strRevSeq.ToCharArray
        Dim CurrentReadSeq As String = ""
        Dim CurrentDG As Single = 0
        Dim Max As Integer = FSeq.GetUpperBound(0)
        For i = 0 To Max
            If Bioinformatics.IsComplement(FSeq(i), RSeq(i)) Then

                strMatchSeq &= "|"

                CurrentReadSeq &= FSeq(i)

                If i = Max And Not CurrentReadSeq = "" Then
                    CurrentDG = Bioinformatics.CalculateOligoDG(CurrentReadSeq, T)
                    sglSumDG += CurrentDG
                    CurrentReadSeq = ""
                End If

            Else
                strMatchSeq &= " "

                If Not CurrentReadSeq = "" Then
                    CurrentDG = Bioinformatics.CalculateOligoDG(CurrentReadSeq, T)
                    sglSumDG += CurrentDG
                End If
                CurrentReadSeq = ""
            End If

        Next

    End Sub

    Public Sub CalculateSumDG_RNA(ByVal T As Single)
        sglSumDG = 0
        Dim FSeq As Char() = strForSeq.ToCharArray
        Dim RSeq As Char() = strRevSeq.ToCharArray
        Dim CurrentReadSeq As String = ""
        Dim CurrentDG As Single = 0
        Dim Max As Integer = FSeq.GetUpperBound(0)

        Dim MinLength As Integer = 3
        Dim ComplementLengthList As New List(Of Integer)

        For i = 0 To Max
            If Bioinformatics.IsComplementRNA(FSeq(i), RSeq(i), False) Then

                strMatchSeq &= "|"

                CurrentReadSeq &= FSeq(i)

                If i = Max And CurrentReadSeq.Length > MinLength Then
                    CurrentDG = Bioinformatics.CalculateOligoDG_RNA(CurrentReadSeq, T)
                    sglSumDG += CurrentDG
                    ComplementLengthList.Add(CurrentReadSeq.Length)
                    CurrentReadSeq = ""
                ElseIf i = Max And CurrentReadSeq.Length > 0 Then
                    ComplementLengthList.Add(CurrentReadSeq.Length)
                    CurrentReadSeq = ""
                End If

            Else
                strMatchSeq &= " "

                If Not CurrentReadSeq = "" And CurrentReadSeq.Length > MinLength Then
                    CurrentDG = Bioinformatics.CalculateOligoDG_RNA(CurrentReadSeq, T)
                    sglSumDG += CurrentDG
                    ComplementLengthList.Add(CurrentReadSeq.Length)
                ElseIf CurrentReadSeq.Length > 0 Then
                    ComplementLengthList.Add(CurrentReadSeq.Length)
                    CurrentReadSeq = ""
                End If
                CurrentReadSeq = ""
            End If

        Next

        If ComplementLengthList.Count > 0 Then
            intMaxComplement = Bioinformatics.Maximum(ComplementLengthList)
        Else
            intMaxComplement = 0
        End If




    End Sub


    Public Sub CalculateExtensibility(Optional ByVal N3complement As Short = 3)

        If strForSeq.EndsWith(Bioinformatics.GetSpaceChar) Then

            Dim SpacePos As Short = Bioinformatics.GetLastLetter(strForSeq) + 1 'strForSeq.IndexOf(Bioinformatics.GetSpaceChar)
            Dim FString As String = ""
            Dim RString As String = ""

            If SpacePos - N3complement >= 0 Then
                FString = strForSeq.Substring(SpacePos - N3complement, N3complement)
                RString = strRevSeq.Substring(SpacePos - N3complement, N3complement)
            Else
                Exit Sub
            End If

            Dim FSeq As Char() = FString.ToCharArray
            Dim RSeq As Char() = RString.ToCharArray
            Dim Max As Integer = FSeq.GetUpperBound(0)
            Dim check As Boolean = False


            For i = 0 To Max
                check = False
                If Bioinformatics.IsComplement(FSeq(i), RSeq(i)) Then
                    check = True
                End If
                If check = False Then
                    Exit For
                End If
            Next

            If check = True Then
                boolExtensible = True
            End If


        End If


        Dim report As String = ""
        Try

            If strRevSeq.StartsWith(Bioinformatics.GetSpaceChar) Then
                report &= strForSeq
                report &= Environment.NewLine
                report &= strRevSeq
                report &= Environment.NewLine

                Dim SpacePos As Short = Bioinformatics.GetFirstLetter(strRevSeq)  'strRevSeq.LastIndexOf(Bioinformatics.GetSpaceChar)

                report &= ("Length= " & strForSeq.Length & "; Index= " & SpacePos + 1 & "; SubLength= " & N3complement)

                Dim FString As String = strForSeq.Substring(SpacePos, N3complement)
                Dim RString As String = strRevSeq.Substring(SpacePos, N3complement)
                Dim FSeq As Char() = FString.ToCharArray
                Dim RSeq As Char() = RString.ToCharArray
                Dim Max As Integer = FSeq.GetUpperBound(0)
                Dim check As Boolean = False

                For i = 0 To Max
                    check = False
                    If Bioinformatics.IsComplement(FSeq(i), RSeq(i)) Then
                        check = True
                    End If
                    If check = False Then
                        Exit For
                    End If
                Next

                If check = True Then
                    boolExtensible = True
                End If
            End If

        Catch ex As Exception
            MsgBox(report)
        End Try
    End Sub

End Class
