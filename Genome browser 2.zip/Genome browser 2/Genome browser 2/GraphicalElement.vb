﻿Public Class GraphicalElement
    'Used for translation viewer

    Private intAbsX As Integer = 0
    Private intAbsY As Integer = 0
    Private intAbsW As Integer = 0
    Private intAbsH As Integer = 0

    Private strText As String
    Private brFillBrush As SolidBrush
    Private bUseFill As Boolean = False
    Private bIsSelected As Boolean = False

    Public Property Abs_X() As Integer
        Get
            Abs_X = intAbsX
        End Get
        Set(ByVal value As Integer)
            intAbsX = value
        End Set
    End Property

    Public Property Abs_Y() As Integer
        Get
            Abs_Y = intAbsY
        End Get
        Set(ByVal value As Integer)
            intAbsY = value
        End Set
    End Property

    Public Property Abs_W() As Integer
        Get
            Abs_W = intAbsW
        End Get
        Set(ByVal value As Integer)
            intAbsW = value
        End Set
    End Property

    Public Property Abs_H() As Integer
        Get
            Abs_H = intAbsH
        End Get
        Set(ByVal value As Integer)
            intAbsH = value
        End Set
    End Property

    Public Property Text() As String
        Get
            Text = strText
        End Get
        Set(ByVal value As String)
            strText = value
        End Set
    End Property

    Public Property FillBrush() As SolidBrush
        Get
            FillBrush = brFillBrush
        End Get
        Set(ByVal value As SolidBrush)
            brFillBrush = value
        End Set
    End Property

    Public Property FillRect() As Boolean
        Get
            FillRect = bUseFill
        End Get
        Set(ByVal value As Boolean)
            bUseFill = value
        End Set
    End Property

    Public Property IsSelected() As Boolean
        Get
            IsSelected = bIsSelected
        End Get
        Set(ByVal value As Boolean)
            bIsSelected = value
        End Set
    End Property

    Public Sub New(ByVal X As Integer, ByVal Y As Integer, ByVal W As Integer, ByVal H As Integer, ByVal Label As String)
        intAbsX = X
        intAbsY = Y
        intAbsW = W
        intAbsH = H
        strText = Label

    End Sub

End Class
