﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TextInputBox
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SeqTextBox = New System.Windows.Forms.TextBox
        Me.OKButton = New System.Windows.Forms.Button
        Me.EscButton = New System.Windows.Forms.Button
        Me.ClearButton = New System.Windows.Forms.Button
        Me.RevButton = New System.Windows.Forms.Button
        Me.ForButton = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'SeqTextBox
        '
        Me.SeqTextBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.SeqTextBox.Location = New System.Drawing.Point(0, 0)
        Me.SeqTextBox.Multiline = True
        Me.SeqTextBox.Name = "SeqTextBox"
        Me.SeqTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.SeqTextBox.Size = New System.Drawing.Size(381, 217)
        Me.SeqTextBox.TabIndex = 0
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(132, 223)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.Size = New System.Drawing.Size(75, 51)
        Me.OKButton.TabIndex = 1
        Me.OKButton.Text = "Sequence only"
        Me.OKButton.UseVisualStyleBackColor = True
        '
        'EscButton
        '
        Me.EscButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.EscButton.Location = New System.Drawing.Point(12, 251)
        Me.EscButton.Name = "EscButton"
        Me.EscButton.Size = New System.Drawing.Size(75, 23)
        Me.EscButton.TabIndex = 2
        Me.EscButton.Text = "Cancel"
        Me.EscButton.UseVisualStyleBackColor = True
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(12, 223)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(75, 23)
        Me.ClearButton.TabIndex = 3
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'RevButton
        '
        Me.RevButton.Location = New System.Drawing.Point(213, 223)
        Me.RevButton.Name = "RevButton"
        Me.RevButton.Size = New System.Drawing.Size(75, 51)
        Me.RevButton.TabIndex = 5
        Me.RevButton.Text = "Reverse + annotation"
        Me.RevButton.UseVisualStyleBackColor = True
        '
        'ForButton
        '
        Me.ForButton.Location = New System.Drawing.Point(294, 223)
        Me.ForButton.Name = "ForButton"
        Me.ForButton.Size = New System.Drawing.Size(75, 51)
        Me.ForButton.TabIndex = 6
        Me.ForButton.Text = "Forward + annotation"
        Me.ForButton.UseVisualStyleBackColor = True
        '
        'TextInputBox
        '
        Me.AcceptButton = Me.OKButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.EscButton
        Me.ClientSize = New System.Drawing.Size(381, 283)
        Me.Controls.Add(Me.ForButton)
        Me.Controls.Add(Me.RevButton)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.EscButton)
        Me.Controls.Add(Me.OKButton)
        Me.Controls.Add(Me.SeqTextBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "TextInputBox"
        Me.Text = "Sequence"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SeqTextBox As System.Windows.Forms.TextBox
    Friend WithEvents OKButton As System.Windows.Forms.Button
    Friend WithEvents EscButton As System.Windows.Forms.Button
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents RevButton As System.Windows.Forms.Button
    Friend WithEvents ForButton As System.Windows.Forms.Button
End Class
