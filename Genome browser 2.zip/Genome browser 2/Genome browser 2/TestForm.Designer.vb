﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TestForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.InputTextBox = New System.Windows.Forms.TextBox
        Me.OKButton = New System.Windows.Forms.Button
        Me.ResultBox = New System.Windows.Forms.TextBox
        Me.HitMap = New System.Windows.Forms.Panel
        Me.TestChartButton = New System.Windows.Forms.Button
        Me.WLTextBox = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'InputTextBox
        '
        Me.InputTextBox.Location = New System.Drawing.Point(12, 12)
        Me.InputTextBox.Multiline = True
        Me.InputTextBox.Name = "InputTextBox"
        Me.InputTextBox.Size = New System.Drawing.Size(586, 116)
        Me.InputTextBox.TabIndex = 0
        Me.InputTextBox.Text = "Mycoplasma gallisepticum S6; Bacteria; Tenericutes; Mollicutes; Mycoplasmataceae;" & _
            " Mycoplasma."
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(523, 134)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.Size = New System.Drawing.Size(75, 23)
        Me.OKButton.TabIndex = 1
        Me.OKButton.Text = "OK"
        Me.OKButton.UseVisualStyleBackColor = True
        '
        'ResultBox
        '
        Me.ResultBox.Location = New System.Drawing.Point(12, 193)
        Me.ResultBox.Multiline = True
        Me.ResultBox.Name = "ResultBox"
        Me.ResultBox.Size = New System.Drawing.Size(586, 119)
        Me.ResultBox.TabIndex = 5
        '
        'HitMap
        '
        Me.HitMap.Location = New System.Drawing.Point(604, 12)
        Me.HitMap.Name = "HitMap"
        Me.HitMap.Size = New System.Drawing.Size(300, 300)
        Me.HitMap.TabIndex = 6
        '
        'TestChartButton
        '
        Me.TestChartButton.Location = New System.Drawing.Point(442, 134)
        Me.TestChartButton.Name = "TestChartButton"
        Me.TestChartButton.Size = New System.Drawing.Size(75, 23)
        Me.TestChartButton.TabIndex = 7
        Me.TestChartButton.Text = "Chart"
        Me.TestChartButton.UseVisualStyleBackColor = True
        '
        'WLTextBox
        '
        Me.WLTextBox.Location = New System.Drawing.Point(386, 136)
        Me.WLTextBox.Name = "WLTextBox"
        Me.WLTextBox.Size = New System.Drawing.Size(50, 20)
        Me.WLTextBox.TabIndex = 9
        Me.WLTextBox.Text = "10"
        '
        'TestForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(928, 345)
        Me.Controls.Add(Me.WLTextBox)
        Me.Controls.Add(Me.TestChartButton)
        Me.Controls.Add(Me.HitMap)
        Me.Controls.Add(Me.ResultBox)
        Me.Controls.Add(Me.OKButton)
        Me.Controls.Add(Me.InputTextBox)
        Me.Name = "TestForm"
        Me.Text = "TestForm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents InputTextBox As System.Windows.Forms.TextBox
    Friend WithEvents OKButton As System.Windows.Forms.Button
    Friend WithEvents ResultBox As System.Windows.Forms.TextBox
    Friend WithEvents HitMap As System.Windows.Forms.Panel
    Friend WithEvents TestChartButton As System.Windows.Forms.Button
    Friend WithEvents WLTextBox As System.Windows.Forms.TextBox
End Class
