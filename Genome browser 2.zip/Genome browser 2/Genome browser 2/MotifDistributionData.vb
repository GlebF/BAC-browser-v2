﻿Public Class MotifDistributionData
    Private strSeqID As String
    Private strSeq As String
    Private lsMotifStart As New List(Of Single)
    Private lsMotifEnd As New List(Of Single)
    Private lsMotifWeight As New List(Of Single)

    Public Property SeqID() As String
        Get
            SeqID = strSeqID
        End Get
        Set(ByVal value As String)
            strSeqID = value
        End Set
    End Property

    Public Property Seq() As String
        Get
            Seq = strSeq
        End Get
        Set(ByVal value As String)
            strSeq = value
        End Set
    End Property

    Public Property MotifStart() As List(Of Single)
        Get
            MotifStart = lsMotifStart
        End Get
        Set(ByVal value As List(Of Single))
            lsMotifStart = value
        End Set
    End Property

    Public Property MotifEnd() As List(Of Single)
        Get
            MotifEnd = lsMotifEnd
        End Get
        Set(ByVal value As List(Of Single))
            lsMotifEnd = value
        End Set
    End Property

    Public Property MotifWeight() As List(Of Single)
        Get
            MotifWeight = lsMotifWeight
        End Get
        Set(ByVal value As List(Of Single))
            lsMotifWeight = value
        End Set
    End Property

End Class
