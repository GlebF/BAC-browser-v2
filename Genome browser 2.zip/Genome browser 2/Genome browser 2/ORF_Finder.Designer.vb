﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ORF_Finder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ORF_Finder))
        Me.UnivarsalInitCheckBox = New System.Windows.Forms.CheckBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.ManualStartTextBox = New System.Windows.Forms.TextBox
        Me.ManualStartCheckBox = New System.Windows.Forms.CheckBox
        Me.ATAATTCheckBox = New System.Windows.Forms.CheckBox
        Me.TTGGTGCheckBox = New System.Windows.Forms.CheckBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.TGACheckBox = New System.Windows.Forms.CheckBox
        Me.ManualStopTextBox = New System.Windows.Forms.TextBox
        Me.ManualStopCheckBox = New System.Windows.Forms.CheckBox
        Me.TAGCheckBox = New System.Windows.Forms.CheckBox
        Me.TAACheckBox = New System.Windows.Forms.CheckBox
        Me.LengthTextBox = New System.Windows.Forms.TextBox
        Me.OKButton = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'UnivarsalInitCheckBox
        '
        Me.UnivarsalInitCheckBox.AutoSize = True
        Me.UnivarsalInitCheckBox.Checked = True
        Me.UnivarsalInitCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.UnivarsalInitCheckBox.Location = New System.Drawing.Point(6, 19)
        Me.UnivarsalInitCheckBox.Name = "UnivarsalInitCheckBox"
        Me.UnivarsalInitCheckBox.Size = New System.Drawing.Size(101, 17)
        Me.UnivarsalInitCheckBox.TabIndex = 1
        Me.UnivarsalInitCheckBox.Text = "ATG (Universal)"
        Me.UnivarsalInitCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ManualStartTextBox)
        Me.GroupBox1.Controls.Add(Me.ManualStartCheckBox)
        Me.GroupBox1.Controls.Add(Me.ATAATTCheckBox)
        Me.GroupBox1.Controls.Add(Me.TTGGTGCheckBox)
        Me.GroupBox1.Controls.Add(Me.UnivarsalInitCheckBox)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(170, 145)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Start codons"
        '
        'ManualStartTextBox
        '
        Me.ManualStartTextBox.Location = New System.Drawing.Point(6, 111)
        Me.ManualStartTextBox.Name = "ManualStartTextBox"
        Me.ManualStartTextBox.Size = New System.Drawing.Size(154, 20)
        Me.ManualStartTextBox.TabIndex = 5
        '
        'ManualStartCheckBox
        '
        Me.ManualStartCheckBox.AutoSize = True
        Me.ManualStartCheckBox.Location = New System.Drawing.Point(6, 88)
        Me.ManualStartCheckBox.Name = "ManualStartCheckBox"
        Me.ManualStartCheckBox.Size = New System.Drawing.Size(154, 17)
        Me.ManualStartCheckBox.TabIndex = 4
        Me.ManualStartCheckBox.Text = "Manual (comma separated)"
        Me.ManualStartCheckBox.UseVisualStyleBackColor = True
        '
        'ATAATTCheckBox
        '
        Me.ATAATTCheckBox.AutoSize = True
        Me.ATAATTCheckBox.Location = New System.Drawing.Point(6, 65)
        Me.ATAATTCheckBox.Name = "ATAATTCheckBox"
        Me.ATAATTCheckBox.Size = New System.Drawing.Size(74, 17)
        Me.ATAATTCheckBox.TabIndex = 3
        Me.ATAATTCheckBox.Text = "ATA, ATT"
        Me.ATAATTCheckBox.UseVisualStyleBackColor = True
        '
        'TTGGTGCheckBox
        '
        Me.TTGGTGCheckBox.AutoSize = True
        Me.TTGGTGCheckBox.Checked = True
        Me.TTGGTGCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.TTGGTGCheckBox.Location = New System.Drawing.Point(6, 42)
        Me.TTGGTGCheckBox.Name = "TTGGTGCheckBox"
        Me.TTGGTGCheckBox.Size = New System.Drawing.Size(77, 17)
        Me.TTGGTGCheckBox.TabIndex = 2
        Me.TTGGTGCheckBox.Text = "TTG, GTG"
        Me.TTGGTGCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.TGACheckBox)
        Me.GroupBox2.Controls.Add(Me.ManualStopTextBox)
        Me.GroupBox2.Controls.Add(Me.ManualStopCheckBox)
        Me.GroupBox2.Controls.Add(Me.TAGCheckBox)
        Me.GroupBox2.Controls.Add(Me.TAACheckBox)
        Me.GroupBox2.Location = New System.Drawing.Point(188, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(170, 145)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Stop codons"
        '
        'TGACheckBox
        '
        Me.TGACheckBox.AutoSize = True
        Me.TGACheckBox.Location = New System.Drawing.Point(6, 65)
        Me.TGACheckBox.Name = "TGACheckBox"
        Me.TGACheckBox.Size = New System.Drawing.Size(48, 17)
        Me.TGACheckBox.TabIndex = 6
        Me.TGACheckBox.Text = "TGA"
        Me.TGACheckBox.UseVisualStyleBackColor = True
        '
        'ManualStopTextBox
        '
        Me.ManualStopTextBox.Location = New System.Drawing.Point(6, 111)
        Me.ManualStopTextBox.Name = "ManualStopTextBox"
        Me.ManualStopTextBox.Size = New System.Drawing.Size(154, 20)
        Me.ManualStopTextBox.TabIndex = 5
        '
        'ManualStopCheckBox
        '
        Me.ManualStopCheckBox.AutoSize = True
        Me.ManualStopCheckBox.Location = New System.Drawing.Point(6, 88)
        Me.ManualStopCheckBox.Name = "ManualStopCheckBox"
        Me.ManualStopCheckBox.Size = New System.Drawing.Size(154, 17)
        Me.ManualStopCheckBox.TabIndex = 4
        Me.ManualStopCheckBox.Text = "Manual (comma separated)"
        Me.ManualStopCheckBox.UseVisualStyleBackColor = True
        '
        'TAGCheckBox
        '
        Me.TAGCheckBox.AutoSize = True
        Me.TAGCheckBox.Checked = True
        Me.TAGCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.TAGCheckBox.Location = New System.Drawing.Point(6, 42)
        Me.TAGCheckBox.Name = "TAGCheckBox"
        Me.TAGCheckBox.Size = New System.Drawing.Size(48, 17)
        Me.TAGCheckBox.TabIndex = 3
        Me.TAGCheckBox.Text = "TAG"
        Me.TAGCheckBox.UseVisualStyleBackColor = True
        '
        'TAACheckBox
        '
        Me.TAACheckBox.AutoSize = True
        Me.TAACheckBox.Checked = True
        Me.TAACheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.TAACheckBox.Location = New System.Drawing.Point(6, 19)
        Me.TAACheckBox.Name = "TAACheckBox"
        Me.TAACheckBox.Size = New System.Drawing.Size(47, 17)
        Me.TAACheckBox.TabIndex = 1
        Me.TAACheckBox.Text = "TAA"
        Me.TAACheckBox.UseVisualStyleBackColor = True
        '
        'LengthTextBox
        '
        Me.LengthTextBox.Location = New System.Drawing.Point(120, 13)
        Me.LengthTextBox.Name = "LengthTextBox"
        Me.LengthTextBox.Size = New System.Drawing.Size(50, 20)
        Me.LengthTextBox.TabIndex = 7
        Me.LengthTextBox.Text = "100"
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(284, 217)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.Size = New System.Drawing.Size(75, 23)
        Me.OKButton.TabIndex = 8
        Me.OKButton.Text = "OK"
        Me.OKButton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(108, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Minimum ORF length:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.LengthTextBox)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 163)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(346, 48)
        Me.GroupBox3.TabIndex = 10
        Me.GroupBox3.TabStop = False
        '
        'ORF_Finder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(371, 251)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.OKButton)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "ORF_Finder"
        Me.Text = "ORF Finder"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents UnivarsalInitCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents ATAATTCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents TTGGTGCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ManualStartTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ManualStartCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TGACheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ManualStopTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ManualStopCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents TAGCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents TAACheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents LengthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents OKButton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
End Class
