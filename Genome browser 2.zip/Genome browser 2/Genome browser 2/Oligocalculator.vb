﻿Public Class Oligocalculator

    Private Sub InputCheck()
        ForMolTextBox.ReadOnly = Not ForMRadioButton.Checked
        ForGramTextBox.ReadOnly = Not ForGRadioButton.Checked
        RevMolTextBox.ReadOnly = Not RevMRadioButton.Checked
        RevGramTextBox.ReadOnly = Not RevGRadioButton.Checked
    End Sub

    Public Sub DoCalculations()

        Dim ForOligoThermodynamics As Single() = Bioinformatics.CalculateOligoThermodynamics(ForTextBox.Text.ToCharArray, TTextBox.Text)
        Dim RevOligoThermodynamics As Single() = Bioinformatics.CalculateOligoThermodynamics(RevTextBox.Text.ToCharArray, TTextBox.Text)

        FordHTextBox.Text = ForOligoThermodynamics(0)
        FordSTextBox.Text = ForOligoThermodynamics(1)
        FordGTextBox.Text = ForOligoThermodynamics(2)

        RevdHTextBox.Text = RevOligoThermodynamics(0)
        RevdSTextBox.Text = RevOligoThermodynamics(1)
        RevdGTextBox.Text = RevOligoThermodynamics(2)

        If ForTextBox.Text.Length > 14 Then
            ForTmTextBox.Text = ForOligoThermodynamics(3)
        Else
            ForTmTextBox.Text = Bioinformatics.CalculateShortOligoTm(ForTextBox.Text.ToCharArray)
        End If

        If RevTextBox.Text.Length > 14 Then
            RevTmTextBox.Text = RevOligoThermodynamics(3)
        Else
            RevTmTextBox.Text = Bioinformatics.CalculateShortOligoTm(RevTextBox.Text.ToCharArray)
        End If

       

        Dim SearchSeqList As New DataTable

        SearchSeqList.Columns.Add("Name")
        SearchSeqList.Columns.Add("Seq")

        If SiteBox.CheckedItems.Count > 0 Then
            For Each Row As DataRow In Master.SiteSeqList.Rows
                For i = 0 To SiteBox.CheckedItems.Count - 1
                    If Row.Item(0) = SiteBox.CheckedItems(i) Then
                        SearchSeqList.Rows.Add(Row.Item(0), Row.Item(1))
                    End If
                Next
            Next
        End If


        Dim ModListFor As New List(Of Single)
        Dim ModListRev As New List(Of Single)

        Dim DecimalFormat As System.Globalization.NumberFormatInfo = System.Globalization.CultureInfo.InstalledUICulture.NumberFormat.Clone
        DecimalFormat.NumberDecimalSeparator = "."

        For Each Row As DataRow In Master.OligoModifications.Rows
            For i = 0 To For5ModBox.CheckedItems.Count - 1
                If Row.Item(0) = For5ModBox.CheckedItems(i) Then
                    ModListFor.Add(Single.Parse(Row.Item(1), DecimalFormat))
                End If
            Next

            For i = 0 To For3ModBox.CheckedItems.Count - 1
                If Row.Item(0) = For3ModBox.CheckedItems(i) Then
                    ModListFor.Add(Single.Parse(Row.Item(1), DecimalFormat))
                End If
            Next

            For i = 0 To Rev5ModBox.CheckedItems.Count - 1
                If Row.Item(0) = Rev5ModBox.CheckedItems(i) Then
                    ModListRev.Add(Single.Parse(Row.Item(1), DecimalFormat))
                End If
            Next

            For i = 0 To Rev3ModBox.CheckedItems.Count - 1
                If Row.Item(0) = Rev3ModBox.CheckedItems(i) Then
                    ModListRev.Add(Single.Parse(Row.Item(1), DecimalFormat))
                End If
            Next

        Next


        ForLengthTextBox.Text = ForTextBox.Text.Length
        ForGCTextBox.Text = Bioinformatics.CalculateCGContent(ForTextBox.Text.ToCharArray)
        ForMWTextBox.Text = Bioinformatics.CalculateOligoMW(ForTextBox.Text.ToCharArray, ModListFor)

        RevLengthTextBox.Text = RevTextBox.Text.Length
        RevGCTextBox.Text = Bioinformatics.CalculateCGContent(RevTextBox.Text.ToCharArray)
        RevMWTextBox.Text = Bioinformatics.CalculateOligoMW(RevTextBox.Text.ToCharArray, ModListRev)

        Dim ForMod_Absorbance As Integer = 0
        Dim RevMod_Absorbance As Integer = 0

        For Each Row As DataRow In Master.OligoModifications.Rows
            For i = 0 To For5ModBox.CheckedItems.Count - 1
                If Row.Item(0) = For5ModBox.CheckedItems(i) Then
                    ForMod_Absorbance += Row.Item(2)
                End If
            Next

            For i = 0 To For3ModBox.CheckedItems.Count - 1
                If Row.Item(0) = For3ModBox.CheckedItems(i) Then
                    ForMod_Absorbance += Row.Item(2)
                End If
            Next

            For i = 0 To Rev5ModBox.CheckedItems.Count - 1
                If Row.Item(0) = Rev5ModBox.CheckedItems(i) Then
                    RevMod_Absorbance += Row.Item(2)
                End If
            Next

            For i = 0 To Rev3ModBox.CheckedItems.Count - 1
                If Row.Item(0) = Rev3ModBox.CheckedItems(i) Then
                    RevMod_Absorbance += Row.Item(2)
                End If
            Next

        Next

        If ForRadioButton.Checked Then
            ForMolTextBox.Text = Bioinformatics.CalculateOligoC(ForTextBox.Text.ToCharArray, ODForTextBox.Text, ForMod_Absorbance)
            ForGramTextBox.Text = Bioinformatics.CalculateOligoMass(ForMolTextBox.Text, ForMWTextBox.Text)
        End If

        If ForMRadioButton.Checked Then
            ForGramTextBox.Text = Bioinformatics.CalculateOligoMass(ForMolTextBox.Text, ForMWTextBox.Text)
        End If

        If ForGRadioButton.Checked Then
            ForMolTextBox.Text = Bioinformatics.mkgTOpMol(ForGramTextBox.Text, ForTextBox.Text)
        End If

        If RevRadioButton.Checked Then
            RevMolTextBox.Text = Bioinformatics.CalculateOligoC(RevTextBox.Text.ToCharArray, ODRevTextBox.Text, RevMod_Absorbance)
            RevGramTextBox.Text = Bioinformatics.CalculateOligoMass(RevMolTextBox.Text, RevMWTextBox.Text)
        End If

        If RevMRadioButton.Checked Then
            RevGramTextBox.Text = Bioinformatics.CalculateOligoMass(RevMolTextBox.Text, RevMWTextBox.Text)
        End If

        If RevGRadioButton.Checked Then
            RevMolTextBox.Text = Bioinformatics.mkgTOpMol(RevGramTextBox.Text, RevTextBox.Text)
        End If



        Dim ForFinalVol As Single = Math.Round((ForVTextBox.Text * ForTargetCTextBox.Text / ForMolTextBox.Text), 1)
        If Not ForFinalVol > ForVTextBox.Text Then
            ForVtoTakeTextBox.Text = ForFinalVol
        Else
            ForVtoTakeTextBox.Text = "Error"
            MsgBox("Too low oligo concentration to make a specified dilution!")
        End If

        Dim RevFinalVol As Single = Math.Round((RevVTextBox.Text * RevTargetCTextBox.Text / RevMolTextBox.Text), 1)
        If Not RevFinalVol > RevVTextBox.Text Then
            RevVtoTakeTextBox.Text = RevFinalVol
        Else
            RevVtoTakeTextBox.Text = "Error"
            MsgBox("Too low oligo concentration to make a specified dilution!")
        End If

        If PDCheckBox.Checked Then
            Dim SumVol As Single = ForVTextBox.Text
            mQTextBox.Text = SumVol - (ForFinalVol + RevFinalVol)
        End If


        If ForTextBox.Text.Length < 100 And RevTextBox.Text.Length < 100 Then
            Dim ForForAlignment As List(Of OligoAlignment) = Nothing
            Dim ForRevAlignment As List(Of OligoAlignment) = Nothing
            Dim RevRevAlignment As List(Of OligoAlignment) = Nothing

            Dim ForHairpins As List(Of OligoAlignment) = Nothing
            Dim RevHairpins As List(Of OligoAlignment) = Nothing

            If Not ForTextBox.Text = "" Then
                If DimersCheckBox.Checked Then
                    ForForAlignment = Bioinformatics.CreateAlignedList(ForTextBox.Text, Bioinformatics.ReverseStrand(ForTextBox.Text), TTextBox.Text, CutoffTextBox.Text)
                End If
                If HairpinsCheckBox.Checked Then
                    ForHairpins = Bioinformatics.CreateHairpinList(ForTextBox.Text, TTextBox.Text, CutoffTextBox.Text)
                End If
            End If

            If Not RevTextBox.Text = "" Then
                If DimersCheckBox.Checked Then
                    RevRevAlignment = Bioinformatics.CreateAlignedList(RevTextBox.Text, Bioinformatics.ReverseStrand(RevTextBox.Text), TTextBox.Text, CutoffTextBox.Text)
                End If
                If HairpinsCheckBox.Checked Then
                    RevHairpins = Bioinformatics.CreateHairpinList(RevTextBox.Text, TTextBox.Text, CutoffTextBox.Text)
                End If
            End If

            If Not ForTextBox.Text = "" And Not RevTextBox.Text = "" Then
                If DimersCheckBox.Checked Then
                    ForRevAlignment = Bioinformatics.CreateAlignedList(ForTextBox.Text, Bioinformatics.ReverseStrand(RevTextBox.Text), TTextBox.Text, CutoffTextBox.Text)
                End If
            End If



            Dim SuperList As New List(Of OligoAlignment)
            Dim ExtState As Boolean = ExtCheckBox.Checked
            Dim dGLim As Integer = dGLimTextBox.Text


            'Create single dG filtered list
            If Not IsNothing(ForForAlignment) Then
                For Each Item As OligoAlignment In ForForAlignment
                    If Item.SumDG < dGLim And (Item.IsExtensible = True Or Item.IsExtensible = ExtState) Then
                        Item.AlignmentName = "For vs For"
                        SuperList.Add(Item)
                    End If
                Next
            End If

            If Not IsNothing(ForHairpins) Then
                For Each Item As OligoAlignment In ForHairpins
                    If Item.SumDG < dGLim And (Item.IsExtensible = True Or Item.IsExtensible = ExtState) Then
                        Item.AlignmentName = "For hairpin"
                        Item.Type = 1
                        SuperList.Add(Item)
                    End If
                Next
            End If

            If Not IsNothing(ForRevAlignment) Then
                For Each Item As OligoAlignment In ForRevAlignment
                    If Item.SumDG < dGLim And (Item.IsExtensible = True Or Item.IsExtensible = ExtState) Then
                        Item.AlignmentName = "For vs Rev"
                        SuperList.Add(Item)
                    End If
                Next
            End If

            If Not IsNothing(RevRevAlignment) Then
                For Each Item As OligoAlignment In RevRevAlignment
                    If Item.SumDG < dGLim And (Item.IsExtensible = True Or Item.IsExtensible = ExtState) Then
                        Item.AlignmentName = "Rev vs Rev"
                        SuperList.Add(Item)
                    End If
                Next
            End If

            If Not IsNothing(RevHairpins) Then
                For Each Item As OligoAlignment In RevHairpins
                    If Item.SumDG < dGLim And (Item.IsExtensible = True Or Item.IsExtensible = ExtState) Then
                        Item.AlignmentName = "Rev hairpin"
                        Item.Type = 1
                        SuperList.Add(Item)
                    End If
                Next
            End If

            'Sort by dG
            Dim Tmp As OligoAlignment = Nothing
            For i = 1 To SuperList.Count - 1
                For j = 0 To SuperList.Count - 1 - i
                    If SuperList(j).SumDG > SuperList(j + 1).SumDG Then '> --> < as the lower dG the stronger the bonds
                        Tmp = SuperList(j)
                        SuperList(j) = SuperList(j + 1)
                        SuperList(j + 1) = Tmp
                    End If
                Next
            Next


            If TextViewButton.Checked Then
                MakeTextView(SuperList, SearchSeqList)
            ElseIf GraphicalButton.Checked Then
                MakeGraphicalView(SuperList, SearchSeqList)
            End If


        End If

    End Sub

    Private Sub MakeTextView(ByVal SuperList As List(Of OligoAlignment), ByVal SearchSeqList As DataTable)

        StructuresTextBox.Text = ""
        For Each Item As OligoAlignment In SuperList

            StructuresTextBox.Text &= Item.AlignmentName
            StructuresTextBox.Text &= Environment.NewLine

            Select Case Item.Type
                Case 0
                    StructuresTextBox.Text &= ("5'->" & Item.ForSeq & "->3'")
                    StructuresTextBox.Text &= Environment.NewLine
                    StructuresTextBox.Text &= ("    " & Item.MatchSeq & "     " & Item.SumDG & " kcal/Mol")
                    StructuresTextBox.Text &= Environment.NewLine
                    StructuresTextBox.Text &= ("3'<-" & Item.RevSeq & "<-5'")

                Case 1
                    StructuresTextBox.Text &= (" /" & Item.ForSeq & "->3'")
                    StructuresTextBox.Text &= Environment.NewLine
                    If Item.OddChar = "" Then
                        StructuresTextBox.Text &= ("| " & Item.MatchSeq & "    " & Item.SumDG & " kcal/Mol")
                    Else
                        StructuresTextBox.Text &= (Item.OddChar & " " & Item.MatchSeq & "    " & Item.SumDG & " kcal/Mol")
                    End If
                    StructuresTextBox.Text &= Environment.NewLine
                    StructuresTextBox.Text &= (" \" & Item.RevSeq & "<-5'")
            End Select

            StructuresTextBox.Text &= Environment.NewLine
            StructuresTextBox.Text &= Environment.NewLine

        Next

        'Search for sites
        If SiteBox.CheckedItems.Count > 0 Then
            StructuresTextBox.Text &= Environment.NewLine
            StructuresTextBox.Text &= "Sites"
            StructuresTextBox.Text &= Environment.NewLine

            Dim FrameReader As Integer = 0
            Dim QuerySeq As String = ""
            Dim TargetSeq As String = ""


            For Each Row As DataRow In SearchSeqList.Rows
                QuerySeq = Row.Item(1).ToString
                QuerySeq = QuerySeq.Replace(Chr(94), vbNullString) 'Remove cut sign
                QuerySeq = QuerySeq.Replace(Chr(42), vbNullString)

                StructuresTextBox.Text &= Environment.NewLine
                StructuresTextBox.Text &= Row.Item(0)
                StructuresTextBox.Text &= Environment.NewLine

                FrameReader = 0
                For i = 0 To ForTextBox.Text.Length - QuerySeq.Length
                    TargetSeq = ForTextBox.Text.Substring(FrameReader, QuerySeq.Length)
                    If Bioinformatics.IsEquivalent(TargetSeq, QuerySeq) Then
                        StructuresTextBox.Text &= "For oligo: " & ForTextBox.Text.Substring(0, FrameReader) & "[" & Row.Item(1) & "]" & ForTextBox.Text.Substring(FrameReader + QuerySeq.Length)
                        StructuresTextBox.Text &= Environment.NewLine
                    End If
                    FrameReader += 1
                Next

                FrameReader = 0
                For i = 0 To RevTextBox.Text.Length - QuerySeq.Length
                    TargetSeq = RevTextBox.Text.Substring(FrameReader, QuerySeq.Length)
                    If TargetSeq = QuerySeq Then
                        StructuresTextBox.Text &= "Rev oligo: " & RevTextBox.Text.Substring(0, FrameReader) & "[" & Row.Item(1) & "]" & RevTextBox.Text.Substring(FrameReader + QuerySeq.Length)
                        StructuresTextBox.Text &= Environment.NewLine
                    End If
                    FrameReader += 1
                Next
            Next



        End If
    End Sub

    Private Sub MakeGraphicalView(ByVal SuperList As List(Of OligoAlignment), ByVal SearchSeqList As DataTable)

        Dim H_Per_Structure As Integer = 85
        Dim W_Per_Char As Integer = 8
        Dim W_Per_Small_Char As Integer = 6
        Dim Half_W_Per_Char As Integer = W_Per_Char / 2
        Dim W_Reserved As Integer = 100
        Dim Seq_H_Offset As Integer = 25
        Dim H_Spacer As Integer = 5

        Dim Image_H_Offset As Integer = 20
        Dim Image_W_Offset As Integer = 10 + W_Per_Char * 2


        Dim ImageH As Integer = SuperList.Count * H_Per_Structure + Image_H_Offset
        Dim ImageW As Integer = Math.Max(ForTextBox.Text.Length * 2, RevTextBox.Text.Length * 2) * W_Per_Char + W_Reserved + Image_W_Offset

        Dim NameFont As New Font("Courier New", W_Per_Char, FontStyle.Italic)
        Dim StructFont As New Font("Courier New", W_Per_Char, FontStyle.Bold)
        Dim SiteFont As New Font("Tahoma", W_Per_Small_Char, FontStyle.Regular)

        Dim StructImage As New Bitmap(ImageW, ImageH)

        Dim CurrentX As Integer = Image_W_Offset
        Dim CurrentY As Integer = Image_H_Offset

        Dim StructBrush As Brush = Brushes.Black
        Dim BondBrush As Brush = Brushes.Black

        Dim SpaceChar As Char = Bioinformatics.GetSpaceChar
        Dim CurrentForSeq As Char()
        Dim CurrentRevSeq As Char()
        Dim CurrentMatchSeq As Char()

        Dim ForSiteList As List(Of Integer) = Nothing
        Dim RevSiteList As List(Of Integer) = Nothing
        Dim ClearedSiteSeq As String = ""
        Dim CutPos As Integer = 0
        Dim IsCut As Boolean = False

        Using g As Graphics = Graphics.FromImage(StructImage)
            g.Clear(Color.White)

            For Each Item As OligoAlignment In SuperList
                CurrentForSeq = Item.ForSeq.ToCharArray
                CurrentRevSeq = Item.RevSeq.ToCharArray
                CurrentMatchSeq = Item.MatchSeq.ToCharArray

                CurrentX = Image_W_Offset

                g.DrawString(Item.AlignmentName & "   " & Item.SumDG & " kcal/Mol", NameFont, Brushes.Black, CurrentX, CurrentY)

                Select Case Item.Type

                    Case 0

                        g.DrawString("5'", NameFont, Brushes.Black, CurrentX - W_Per_Char * 2 + (Item.ForSeq.Length - Item.ForSeq.TrimStart(SpaceChar).Length) * W_Per_Char, CurrentY + Seq_H_Offset - H_Spacer)
                        g.DrawString("3'", NameFont, Brushes.Black, CurrentX + (Item.ForSeq.TrimEnd(SpaceChar).Length) * W_Per_Char, CurrentY + Seq_H_Offset - H_Spacer)

                        g.DrawString("3'", NameFont, Brushes.Black, CurrentX - W_Per_Char * 2 + (Item.RevSeq.Length - Item.RevSeq.TrimStart(SpaceChar).Length) * W_Per_Char, CurrentY + (W_Per_Char + H_Spacer) * 2 + Seq_H_Offset + H_Spacer)
                        g.DrawString("5'", NameFont, Brushes.Black, CurrentX + (Item.RevSeq.TrimEnd(SpaceChar).Length) * W_Per_Char, CurrentY + (W_Per_Char + H_Spacer) * 2 + Seq_H_Offset + H_Spacer)


                    Case 1

                        g.DrawString("3'", NameFont, Brushes.Black, CurrentX + (Item.ForSeq.TrimEnd(SpaceChar).Length) * W_Per_Char, CurrentY + Seq_H_Offset - H_Spacer)
                        g.DrawString("5'", NameFont, Brushes.Black, CurrentX + (Item.RevSeq.TrimEnd(SpaceChar).Length) * W_Per_Char, CurrentY + (W_Per_Char + H_Spacer) * 2 + Seq_H_Offset + H_Spacer)

                        If Item.OddChar = "" Then
                            g.DrawLine(Pens.Black, CurrentX - W_Per_Char, CurrentY + Seq_H_Offset + W_Per_Char, CurrentX - W_Per_Char, CurrentY + (W_Per_Char + H_Spacer) * 2 + Seq_H_Offset + W_Per_Char)
                            g.DrawLine(Pens.Black, CurrentX - W_Per_Char, CurrentY + Seq_H_Offset + W_Per_Char, CurrentX, CurrentY + Seq_H_Offset + W_Per_Char)
                            g.DrawLine(Pens.Black, CurrentX - W_Per_Char, CurrentY + (W_Per_Char + H_Spacer) * 2 + Seq_H_Offset + W_Per_Char, CurrentX, CurrentY + (W_Per_Char + H_Spacer) * 2 + Seq_H_Offset + W_Per_Char)
                        Else
                            g.DrawString(Item.OddChar, StructFont, Brushes.Black, CurrentX - W_Per_Char - Half_W_Per_Char, CurrentY + W_Per_Char + H_Spacer + Seq_H_Offset)
                            g.DrawLine(Pens.Black, CurrentX - W_Per_Char, CurrentY + Seq_H_Offset + W_Per_Char, CurrentX - W_Per_Char, CurrentY + Seq_H_Offset + W_Per_Char + H_Spacer)
                            g.DrawLine(Pens.Black, CurrentX - W_Per_Char, CurrentY + Seq_H_Offset + (W_Per_Char + H_Spacer) * 2, CurrentX - W_Per_Char, CurrentY + (W_Per_Char + H_Spacer) * 2 + Seq_H_Offset + W_Per_Char)
                            g.DrawLine(Pens.Black, CurrentX - W_Per_Char, CurrentY + Seq_H_Offset + W_Per_Char, CurrentX, CurrentY + Seq_H_Offset + W_Per_Char)
                            g.DrawLine(Pens.Black, CurrentX - W_Per_Char, CurrentY + (W_Per_Char + H_Spacer) * 2 + Seq_H_Offset + W_Per_Char, CurrentX, CurrentY + (W_Per_Char + H_Spacer) * 2 + Seq_H_Offset + W_Per_Char)
                        End If
                End Select


                For i = 0 To CurrentMatchSeq.GetUpperBound(0)

                    If CurrentMatchSeq(i) = Chr(124) Then

                        If CurrentForSeq(i) = Chr(67) Or CurrentForSeq(i) = Chr(71) Then
                            StructBrush = Brushes.Red
                        Else
                            StructBrush = Brushes.DeepSkyBlue
                        End If
                    Else
                        StructBrush = Brushes.Black
                    End If

                    g.DrawString(CurrentMatchSeq(i), StructFont, BondBrush, CurrentX, CurrentY + W_Per_Char + H_Spacer + Seq_H_Offset)

                    If Not CurrentForSeq(i) = SpaceChar Then
                        g.DrawString(CurrentForSeq(i), StructFont, StructBrush, CurrentX, CurrentY + Seq_H_Offset)
                    End If

                    If Not CurrentRevSeq(i) = SpaceChar Then
                        g.DrawString(CurrentRevSeq(i), StructFont, StructBrush, CurrentX, CurrentY + (W_Per_Char + H_Spacer) * 2 + Seq_H_Offset)
                    End If

                    CurrentX += W_Per_Char
                Next


                If SiteBox.CheckedItems.Count > 0 Then
                    IsCut = False

                    For Each Site As DataRow In SearchSeqList.Rows
                        If Site.Item(1).ToString.Contains(Chr(94)) Then
                            IsCut = True
                            CutPos = Site.Item(1).ToString.IndexOf(Chr(94))
                        End If

                        ClearedSiteSeq = Site.Item(1).ToString.Replace(Chr(94), vbNullString) 'Remove cut sign
                        ClearedSiteSeq = ClearedSiteSeq.Replace(Chr(42), vbNullString)

                        ForSiteList = Bioinformatics.ContainsEquivalent(Item.ForSeq, ClearedSiteSeq)
                        RevSiteList = Bioinformatics.ContainsEquivalent(Item.RevSeq, Bioinformatics.ReverseStrand(ClearedSiteSeq))

                        For Each Pos As Integer In ForSiteList
                            g.DrawString(Site.Item(0), SiteFont, Brushes.Green, Image_W_Offset + W_Per_Char * Pos, CurrentY + Seq_H_Offset - W_Per_Small_Char - H_Spacer)
                            g.DrawLine(Pens.Green, Image_W_Offset + W_Per_Char * Pos, CurrentY + Seq_H_Offset, Image_W_Offset + W_Per_Char * (Pos + ClearedSiteSeq.Length), CurrentY + Seq_H_Offset)
                            If IsCut Then
                                g.DrawLine(Pens.Green, Image_W_Offset + W_Per_Char * (Pos + CutPos) + 1, CurrentY + Seq_H_Offset, Image_W_Offset + W_Per_Char * (Pos + CutPos) + 1, CurrentY + Seq_H_Offset + W_Per_Char * 2)
                            End If
                        Next

                        For Each Pos As Integer In RevSiteList
                            g.DrawString(Site.Item(0), SiteFont, Brushes.Green, Image_W_Offset + W_Per_Char * Pos, CurrentY + (W_Per_Char + H_Spacer) * 3 + Seq_H_Offset)
                            g.DrawLine(Pens.Green, Image_W_Offset + W_Per_Char * Pos, CurrentY + (W_Per_Char + H_Spacer) * 3 + Seq_H_Offset, Image_W_Offset + W_Per_Char * (Pos + ClearedSiteSeq.Length), CurrentY + (W_Per_Char + H_Spacer) * 3 + Seq_H_Offset)
                            If IsCut Then
                                g.DrawLine(Pens.Green, Image_W_Offset + W_Per_Char * (Pos + ClearedSiteSeq.Length - CutPos) + 1, CurrentY + (W_Per_Char + H_Spacer) * 3 + Seq_H_Offset, Image_W_Offset + W_Per_Char * (Pos + ClearedSiteSeq.Length - CutPos) + 1, CurrentY + (W_Per_Char + H_Spacer) * 2 + Seq_H_Offset)
                            End If
                        Next

                    Next
                End If

                CurrentY += H_Per_Structure

            Next




        End Using

        StructuresPictureBox.Size = New Size(ImageW, ImageH)
        StructuresPictureBox.Image = StructImage


    End Sub


    Public Sub RefreshModList()
        For5ModBox.Items.Clear()
        Rev5ModBox.Items.Clear()
        For3ModBox.Items.Clear()
        Rev3ModBox.Items.Clear()

        For Each Row As DataRow In Master.OligoModifications.Rows
            For5ModBox.Items.Add(Row.Item(0))
            Rev5ModBox.Items.Add(Row.Item(0))
            For3ModBox.Items.Add(Row.Item(0))
            Rev3ModBox.Items.Add(Row.Item(0))
        Next

    End Sub

    Private Sub RefreshSiteList()
        SiteBox.Items.Clear()
        For Each Row As DataRow In Master.SiteSeqList.Rows
            SiteBox.Items.Add(Row.Item(0))
        Next

    End Sub

    Private Sub UpdateViewMode()
        If TextViewButton.Checked Then
            StructuresTextBox.Visible = True
            ImagePanel.Visible = False
            My.Settings.OligoStructViewMode = False
        ElseIf GraphicalButton.Checked Then
            StructuresTextBox.Visible = False
            ImagePanel.Visible = True
            My.Settings.OligoStructViewMode = True
        End If
    End Sub

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        Try
            DoCalculations()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub Oligocalc_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If My.Settings.OligoStructViewMode = False Then
            TextViewButton.Checked = True
        Else
            GraphicalButton.Checked = True
        End If

        StructuresTextBox.Dock = DockStyle.Fill
        ImagePanel.Dock = DockStyle.Fill

        RefreshSiteList()
        RefreshModList()

        NaCTextBox.Text = My.Settings.NaC
        MgCTextBox.Text = My.Settings.MgC
        dNTPCTextBox.Text = My.Settings.dNTPC
        OligoCTextBox.Text = My.Settings.OligoC

        'Select Case DatabaseComboBox.Text
        'Case "UCSC"
        'SpeciesComboBox.Text = "Homo sapience hg19"
        'SearchTabControl.SelectedIndex = 1

        'Case "Current sequence"
        'SpeciesComboBox.Text = ""
        'SearchTabControl.SelectedIndex = 0

        'End Select

        UpdateViewMode()

    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click

        RefreshModList()

        ForTextBox.Text = ""
        RevTextBox.Text = ""
        ODForTextBox.Text = ""
        ODRevTextBox.Text = ""

    End Sub

    Private Sub ForRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ForRadioButton.CheckedChanged
        InputCheck()
    End Sub

    Private Sub ForMRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ForMRadioButton.CheckedChanged
        InputCheck()
    End Sub

    Private Sub ForGRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ForGRadioButton.CheckedChanged
        InputCheck()
    End Sub

    Private Sub RevRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RevRadioButton.CheckedChanged
        InputCheck()
    End Sub

    Private Sub RevMRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RevMRadioButton.CheckedChanged
        InputCheck()
    End Sub

    Private Sub RevGRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RevGRadioButton.CheckedChanged
        InputCheck()
    End Sub

    Private Sub DatabaseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DatabaseButton.Click



        Select Case DatabaseComboBox.Text

            'Case "UCSC"

            'Dim strURL As String = ""

            'Select Case SpeciesComboBox.Text
            'Case "Homo sapience hg19"

            'strURL = String.Concat("http://genome.ucsc.edu/cgi-bin/hgPcr?hgsid=183142071&org=Human&db=hg19&wp_target=hg19Kg&wp_f=", ForTextBox.Text, "&wp_r=", RevTextBox.Text, "&Submit=submit&wp_size=", AmpMaxTextBox.Text, "&wp_perfect=", PerfMatchTextBox.Text, "&wp_good=", GoodMatchTextBox.Text, "&boolshad.wp_flipReverse=0")

            'Case "S. cerevisiae SGD/sacCer2"

            'strURL = String.Concat("http://genome.ucsc.edu/cgi-bin/hgPcr?hgsid=183142071&org=S.+cerevisiae&db=sacCer2&wp_target=genome&wp_f=", ForTextBox.Text, "&wp_r=", RevTextBox.Text, "&Submit=submit&wp_size=", AmpMaxTextBox.Text, "&wp_perfect=", PerfMatchTextBox.Text, "&wp_good=", GoodMatchTextBox.Text, "&boolshad.wp_flipReverse=0")

            'Case "A. melifera Baylor 2.0/apiMel2"

            'strURL = String.Concat("http://genome.ucsc.edu/cgi-bin/hgPcr?hgsid=183142071&org=A.+mellifera&db=apiMel2&wp_target=genome&wp_f=", ForTextBox.Text, "&wp_r=", RevTextBox.Text, "&Submit=submit&wp_size=", AmpMaxTextBox.Text, "&wp_perfect=", PerfMatchTextBox.Text, "&wp_good=", GoodMatchTextBox.Text, "&boolshad.wp_flipReverse=0")

            'End Select

            'DataIO.LaunchBrowser(strURL)

            Case "Current sequence"

                Try

                    Dim CurrentGenomeViewer As Genome_Viewer = Master.MasterTabControl.SelectedTab.Controls(0)

                    If AccClearCheckBox.Checked Then
                        CurrentGenomeViewer.ClearUserFeatures()
                        CurrentGenomeViewer.DisplayFeatures()
                    End If

                    CurrentGenomeViewer.MapFeature(ForTextBox.Text, ForIdTextBox.Text, "ForPrimer", , False)
                    CurrentGenomeViewer.MapFeature(RevTextBox.Text, RevIdTextBox.Text, "RevPrimer", , False)

                Catch ex As Exception
                    MsgBox("Error in primer find")
                End Try


        End Select



    End Sub

    Private Sub DatabaseComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DatabaseComboBox.SelectedIndexChanged
        'Select Case DatabaseComboBox.Text
        'Case "UCSC"
        'SpeciesComboBox.Text = "Homo sapience hg19"
        'SearchTabControl.SelectedIndex = 1

        'Case "Current sequence"
        'SpeciesComboBox.Text = ""
        'SearchTabControl.SelectedIndex = 0

        'End Select

    End Sub

    Private Sub SaveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        My.Settings.NaC = NaCTextBox.Text
        My.Settings.MgC = MgCTextBox.Text
        My.Settings.dNTPC = dNTPCTextBox.Text
        My.Settings.OligoC = OligoCTextBox.Text
    End Sub

    Private Sub RestoreButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RestoreButton.Click
        NaCTextBox.Text = 50
        MgCTextBox.Text = 1.5
        dNTPCTextBox.Text = 0.2
        OligoCTextBox.Text = 200
    End Sub

    Private Sub TextViewButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextViewButton.CheckedChanged
        UpdateViewMode()
    End Sub

    Private Sub GraphicalButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GraphicalButton.CheckedChanged
        UpdateViewMode()
    End Sub

    Private Sub RefreshSitesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshSitesButton.Click
        RefreshSiteList()
    End Sub
End Class