﻿Public Class FeatureReportBox
    Private cMyParent As Genome_Viewer

    Public Property MyParent() As Genome_Viewer
        Get
            MyParent = cMyParent
        End Get
        Set(ByVal value As Genome_Viewer)
            cMyParent = value
        End Set
    End Property

    Private Sub OrthologyLabel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles OrthologyLabel.Click
        If OrthologyTextBox.Text.StartsWith("COG") Then
            DataIO.LaunchBrowser("http://www.ncbi.nlm.nih.gov/COG/grace/wiew.cgi?" & OrthologyTextBox.Text)
        End If

        If OrthologyTextBox.Text.StartsWith("K") Then
            DataIO.LaunchBrowser("http://www.genome.jp/dbget-bin/www_bfind_sub?mode=bfind&max_hit=1000&dbkey=orthology&keywords=" & OrthologyTextBox.Text)
        End If

    End Sub

    Private Sub OrthologyLabel_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrthologyLabel.MouseEnter
        If Not OrthologyTextBox.Text = "" Then
            OrthologyLabel.ForeColor = Color.Blue
            OrthologyLabel.Cursor = Cursors.Hand
        End If

    End Sub

    Private Sub OrthologyLabel_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrthologyLabel.MouseLeave
        OrthologyLabel.ForeColor = Color.Black
        OrthologyLabel.Cursor = Cursors.Default
    End Sub

    Private Sub FindButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindButton.Click
        If Not IsNothing(cMyParent.Selected_Feature) Then
            MyParent.FeaturesGroupDataGridView.Rows.Clear()
            For Each FeaturesList As FeaturesAssembly In MyParent.Features_Groups_List
                For Each Feature As Genome_Feature In FeaturesList.FeaturesList
                    If Feature.TAG = FeatureTextBox.Text And Feature.Group = GroupTextBox.Text And Feature.Type = cMyParent.Selected_Feature.Type Then
                        MyParent.WriteFeatureRow(Feature, MyParent.FeaturesGroupDataGridView)
                        Exit For
                    End If
                Next
            Next

        End If
    End Sub

    Private Sub FeatureSeqButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FeatureSeqButton.Click
        If Not IsNothing(cMyParent.Selected_Feature) Then


            If cMyParent.Selected_Feature.ReadList.Count > 0 Then
                SequenceDisplay.ReadList = cMyParent.Selected_Feature.ReadList
                SequenceDisplay.ReadListCheckBox.Checked = True
            Else
                SequenceDisplay.ReadList.Clear()
                SequenceDisplay.ReadListCheckBox.Checked = False
            End If

            SequenceDisplay.MRNATextBox.Text = ""
            SequenceDisplay.TranslationTextBox.Text = ""
            SequenceDisplay.Show()
            SequenceDisplay.Locus_ID = cMyParent.Selected_Feature.TAG
            SequenceDisplay.Locus_Name = cMyParent.Selected_Feature.Name
            SequenceDisplay.SeqTextBox.Text = cMyParent.GetFeatureSequence(cMyParent.Selected_Feature)
            SequenceDisplay.TranslateComboBox.Text = cMyParent.Control_Box.TransComboBox.Text

            SequenceDisplay.Focus()

        End If
    End Sub

    Private Sub ToggleTranslationButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToggleTranslationButton.Click
        If Not IsNothing(cMyParent.Selected_Feature) Then

            If cMyParent.Selected_Feature.DisplayTranslation Then
                cMyParent.Selected_Feature.SetTranslation(False)
            Else
                cMyParent.Selected_Feature.SetTranslation(True, _
                                                                     cMyParent.GetFeatureSequence(cMyParent.Selected_Feature), _
                                                                     cMyParent.Control_Box.TransComboBox.Text.Split("-")(0))
            End If


            cMyParent.DisplayFeatures()


        End If
    End Sub

    Private Sub TGATGGToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TGATGGToolStripMenuItem.Click
        If Not IsNothing(cMyParent.Selected_Feature) Then

            If cMyParent.Selected_Feature.Type = 1 Then
                Dim CurrentSeq As String = cMyParent.GetFeatureSequence(cMyParent.Selected_Feature)
                Dim CurrentTripplete As String = ""
                Dim FrameReader As Integer = 0
                Dim Max As Integer = Math.Truncate(CurrentSeq.Length / 3) - 1

                Dim BaseCoord As Integer = 0
                Dim PrimerStart As Integer = 0
                Dim PrimerEnd As Integer = 0
                Dim counter As Integer = 1
                Dim PrimerWindow As Integer = 20

                For i = 0 To Max
                    CurrentTripplete = CurrentSeq.Substring(FrameReader, 3)


                    If CurrentTripplete = "TGA" Then

                        'Design correction primer

                        If cMyParent.Selected_Feature.Direction = 1 Then
                            BaseCoord = cMyParent.Selected_Feature.AbsoluteStart + FrameReader + 2

                        ElseIf cMyParent.Selected_Feature.Direction = 2 Then
                            BaseCoord = cMyParent.Selected_Feature.AbsoluteEnd - FrameReader - 2

                        Else
                            BaseCoord = cMyParent.Selected_Feature.AbsoluteStart + FrameReader + 2

                        End If



                        PrimerStart = BaseCoord - PrimerWindow
                        PrimerEnd = BaseCoord + PrimerWindow

                        Dim NewRevPrimer As New Genome_Feature
                        NewRevPrimer.Direction = Bioinformatics.GetOppositeDirection(cMyParent.Selected_Feature.Direction)
                        NewRevPrimer.AbsoluteStart = PrimerStart
                        NewRevPrimer.AbsoluteEnd = PrimerEnd
                        NewRevPrimer.TAG = cMyParent.Selected_Feature.Name & "-M" & counter
                        NewRevPrimer.Name = NewRevPrimer.TAG
                        NewRevPrimer.Type = 7
                        counter += 1

                        Dim NewForPrimer As New Genome_Feature
                        NewForPrimer.Direction = cMyParent.Selected_Feature.Direction
                        NewForPrimer.AbsoluteStart = PrimerStart
                        NewForPrimer.AbsoluteEnd = PrimerEnd
                        NewForPrimer.TAG = cMyParent.Selected_Feature.Name & "-M" & counter
                        NewForPrimer.Name = NewForPrimer.TAG
                        NewForPrimer.Type = 7
                        counter += 1




                        If cMyParent.Selected_Feature.Direction = 1 Then 'For
                            NewForPrimer.Sequence = DataIO.RetrieveSeqFromCache(cMyParent.Genome_Sequence, cMyParent.Selected_Feature.AbsoluteStart + FrameReader - PrimerWindow + 2, cMyParent.Selected_Feature.AbsoluteStart + FrameReader + 1) & "G" & DataIO.RetrieveSeqFromCache(cMyParent.Genome_Sequence, cMyParent.Selected_Feature.AbsoluteStart + FrameReader + 3, cMyParent.Selected_Feature.AbsoluteStart + FrameReader + 2 + PrimerWindow)
                            NewRevPrimer.Sequence = Bioinformatics.GetReverseComplement(NewForPrimer.Sequence)
                        ElseIf cMyParent.Selected_Feature.Direction = 2 Then 'Rev

                            NewRevPrimer.Sequence = DataIO.RetrieveSeqFromCache(cMyParent.Genome_Sequence, cMyParent.Selected_Feature.AbsoluteEnd - FrameReader - PrimerWindow - 2, cMyParent.Selected_Feature.AbsoluteEnd - FrameReader - 3) & "C" & DataIO.RetrieveSeqFromCache(cMyParent.Genome_Sequence, cMyParent.Selected_Feature.AbsoluteEnd - FrameReader - 1, cMyParent.Selected_Feature.AbsoluteEnd - FrameReader + PrimerWindow - 2)
                            NewForPrimer.Sequence = Bioinformatics.GetReverseComplement(NewRevPrimer.Sequence)

                        End If






                        cMyParent.Features_Groups_List(1).FeaturesList.Add(NewForPrimer)
                        cMyParent.Features_Groups_List(1).FeaturesList.Add(NewRevPrimer)


                    End If


                    FrameReader += 3
                Next i

                cMyParent.DisplayFeatures()
            End If

        End If
    End Sub

    Private Sub FeatureTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FeatureTextBox.TextChanged
        If FeatureTextBox.Text = "" Then
            FindButton.Enabled = False
            FeatureSeqButton.Enabled = False
            ToggleTranslationButton.Enabled = False
            TuneButton.Enabled = False
        Else
            FindButton.Enabled = True
            FeatureSeqButton.Enabled = True
            ToggleTranslationButton.Enabled = True
            TuneButton.Enabled = True
        End If
    End Sub

End Class
