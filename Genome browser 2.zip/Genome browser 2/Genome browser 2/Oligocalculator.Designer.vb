﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Oligocalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Oligocalculator))
        Me.SearchTabControl = New System.Windows.Forms.TabControl
        Me.SeqTabPage = New System.Windows.Forms.TabPage
        Me.AccClearCheckBox = New System.Windows.Forms.CheckBox
        Me.AmpliconsRadioButton = New System.Windows.Forms.RadioButton
        Me.PrimersRadioButton = New System.Windows.Forms.RadioButton
        Me.Label51 = New System.Windows.Forms.Label
        Me.Label50 = New System.Windows.Forms.Label
        Me.Label48 = New System.Windows.Forms.Label
        Me.Label49 = New System.Windows.Forms.Label
        Me.ForIdTextBox = New System.Windows.Forms.TextBox
        Me.RevIdTextBox = New System.Windows.Forms.TextBox
        Me.DatabaseComboBox = New System.Windows.Forms.ComboBox
        Me.AmpMaxTextBox = New System.Windows.Forms.TextBox
        Me.DatabaseButton = New System.Windows.Forms.Button
        Me.Label45 = New System.Windows.Forms.Label
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.mQTextBox = New System.Windows.Forms.TextBox
        Me.Label44 = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.PDCheckBox = New System.Windows.Forms.CheckBox
        Me.GroupBox8 = New System.Windows.Forms.GroupBox
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label40 = New System.Windows.Forms.Label
        Me.RevVTextBox = New System.Windows.Forms.TextBox
        Me.RevVtoTakeTextBox = New System.Windows.Forms.TextBox
        Me.Label41 = New System.Windows.Forms.Label
        Me.RevTargetCTextBox = New System.Windows.Forms.TextBox
        Me.Label42 = New System.Windows.Forms.Label
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label34 = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.RevdSTextBox = New System.Windows.Forms.TextBox
        Me.RevdHTextBox = New System.Windows.Forms.TextBox
        Me.RevdGTextBox = New System.Windows.Forms.TextBox
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.DimersCheckBox = New System.Windows.Forms.CheckBox
        Me.HairpinsCheckBox = New System.Windows.Forms.CheckBox
        Me.Label60 = New System.Windows.Forms.Label
        Me.dGLimTextBox = New System.Windows.Forms.TextBox
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.ExtCheckBox = New System.Windows.Forms.CheckBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.TTextBox = New System.Windows.Forms.TextBox
        Me.CutoffTextBox = New System.Windows.Forms.TextBox
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.RevRadioButton = New System.Windows.Forms.RadioButton
        Me.RevLengthTextBox = New System.Windows.Forms.TextBox
        Me.RevMRadioButton = New System.Windows.Forms.RadioButton
        Me.RevGRadioButton = New System.Windows.Forms.RadioButton
        Me.RevMWTextBox = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.RevGCTextBox = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.RevTmTextBox = New System.Windows.Forms.TextBox
        Me.RevGramTextBox = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.RevMolTextBox = New System.Windows.Forms.TextBox
        Me.DimerGroupBox = New System.Windows.Forms.GroupBox
        Me.ImagePanel = New System.Windows.Forms.Panel
        Me.StructuresPictureBox = New System.Windows.Forms.PictureBox
        Me.StructuresTextBox = New System.Windows.Forms.RichTextBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.Rev3ModBox = New System.Windows.Forms.CheckedListBox
        Me.For3ModBox = New System.Windows.Forms.CheckedListBox
        Me.Rev5ModBox = New System.Windows.Forms.CheckedListBox
        Me.For5ModBox = New System.Windows.Forms.CheckedListBox
        Me.ODRevTextBox = New System.Windows.Forms.TextBox
        Me.ForTextBox = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.ClearButton = New System.Windows.Forms.Button
        Me.RevTextBox = New System.Windows.Forms.TextBox
        Me.ODForTextBox = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.FordSTextBox = New System.Windows.Forms.TextBox
        Me.FordHTextBox = New System.Windows.Forms.TextBox
        Me.FordGTextBox = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.ForRadioButton = New System.Windows.Forms.RadioButton
        Me.ForMRadioButton = New System.Windows.Forms.RadioButton
        Me.ForGRadioButton = New System.Windows.Forms.RadioButton
        Me.ForLengthTextBox = New System.Windows.Forms.TextBox
        Me.ForMWTextBox = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.ForGCTextBox = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.ForTmTextBox = New System.Windows.Forms.TextBox
        Me.ForGramTextBox = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.ForMolTextBox = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.ForVTextBox = New System.Windows.Forms.TextBox
        Me.ForVtoTakeTextBox = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.ForTargetCTextBox = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.OKButton = New System.Windows.Forms.Button
        Me.GroupBox10 = New System.Windows.Forms.GroupBox
        Me.RestoreButton = New System.Windows.Forms.Button
        Me.SaveButton = New System.Windows.Forms.Button
        Me.Label52 = New System.Windows.Forms.Label
        Me.Label53 = New System.Windows.Forms.Label
        Me.Label54 = New System.Windows.Forms.Label
        Me.Label55 = New System.Windows.Forms.Label
        Me.Label56 = New System.Windows.Forms.Label
        Me.OligoCTextBox = New System.Windows.Forms.TextBox
        Me.Label57 = New System.Windows.Forms.Label
        Me.Label58 = New System.Windows.Forms.Label
        Me.Label59 = New System.Windows.Forms.Label
        Me.dNTPCTextBox = New System.Windows.Forms.TextBox
        Me.MgCTextBox = New System.Windows.Forms.TextBox
        Me.NaCTextBox = New System.Windows.Forms.TextBox
        Me.GroupBox11 = New System.Windows.Forms.GroupBox
        Me.GroupBox12 = New System.Windows.Forms.GroupBox
        Me.RefreshSitesButton = New System.Windows.Forms.Button
        Me.SiteBox = New System.Windows.Forms.CheckedListBox
        Me.GraphicalButton = New System.Windows.Forms.RadioButton
        Me.TextViewButton = New System.Windows.Forms.RadioButton
        Me.ViewSettingsGroupBox = New System.Windows.Forms.GroupBox
        Me.GroupBox13 = New System.Windows.Forms.GroupBox
        Me.SearchTabControl.SuspendLayout()
        Me.SeqTabPage.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.DimerGroupBox.SuspendLayout()
        Me.ImagePanel.SuspendLayout()
        CType(Me.StructuresPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.ViewSettingsGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'SearchTabControl
        '
        Me.SearchTabControl.Controls.Add(Me.SeqTabPage)
        Me.SearchTabControl.Location = New System.Drawing.Point(126, 9)
        Me.SearchTabControl.Name = "SearchTabControl"
        Me.SearchTabControl.SelectedIndex = 0
        Me.SearchTabControl.Size = New System.Drawing.Size(329, 111)
        Me.SearchTabControl.TabIndex = 85
        '
        'SeqTabPage
        '
        Me.SeqTabPage.Controls.Add(Me.AccClearCheckBox)
        Me.SeqTabPage.Controls.Add(Me.AmpliconsRadioButton)
        Me.SeqTabPage.Controls.Add(Me.PrimersRadioButton)
        Me.SeqTabPage.Controls.Add(Me.Label51)
        Me.SeqTabPage.Controls.Add(Me.Label50)
        Me.SeqTabPage.Controls.Add(Me.Label48)
        Me.SeqTabPage.Controls.Add(Me.Label49)
        Me.SeqTabPage.Controls.Add(Me.ForIdTextBox)
        Me.SeqTabPage.Controls.Add(Me.RevIdTextBox)
        Me.SeqTabPage.Location = New System.Drawing.Point(4, 22)
        Me.SeqTabPage.Name = "SeqTabPage"
        Me.SeqTabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.SeqTabPage.Size = New System.Drawing.Size(321, 85)
        Me.SeqTabPage.TabIndex = 0
        Me.SeqTabPage.Text = "Seq..."
        Me.SeqTabPage.UseVisualStyleBackColor = True
        '
        'AccClearCheckBox
        '
        Me.AccClearCheckBox.AutoSize = True
        Me.AccClearCheckBox.Checked = True
        Me.AccClearCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.AccClearCheckBox.Location = New System.Drawing.Point(85, 59)
        Me.AccClearCheckBox.Name = "AccClearCheckBox"
        Me.AccClearCheckBox.Size = New System.Drawing.Size(120, 17)
        Me.AccClearCheckBox.TabIndex = 73
        Me.AccClearCheckBox.Text = "Clear previous items"
        Me.AccClearCheckBox.UseVisualStyleBackColor = True
        '
        'AmpliconsRadioButton
        '
        Me.AmpliconsRadioButton.AutoSize = True
        Me.AmpliconsRadioButton.Enabled = False
        Me.AmpliconsRadioButton.Location = New System.Drawing.Point(154, 32)
        Me.AmpliconsRadioButton.Name = "AmpliconsRadioButton"
        Me.AmpliconsRadioButton.Size = New System.Drawing.Size(109, 17)
        Me.AmpliconsRadioButton.TabIndex = 72
        Me.AmpliconsRadioButton.Text = "Display amplicons"
        Me.AmpliconsRadioButton.UseVisualStyleBackColor = True
        '
        'PrimersRadioButton
        '
        Me.PrimersRadioButton.AutoSize = True
        Me.PrimersRadioButton.Checked = True
        Me.PrimersRadioButton.Location = New System.Drawing.Point(154, 7)
        Me.PrimersRadioButton.Name = "PrimersRadioButton"
        Me.PrimersRadioButton.Size = New System.Drawing.Size(95, 17)
        Me.PrimersRadioButton.TabIndex = 71
        Me.PrimersRadioButton.TabStop = True
        Me.PrimersRadioButton.Text = "Display primers"
        Me.PrimersRadioButton.UseVisualStyleBackColor = True
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(125, 36)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(15, 13)
        Me.Label51.TabIndex = 70
        Me.Label51.Text = "%"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(125, 9)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(15, 13)
        Me.Label50.TabIndex = 69
        Me.Label50.Text = "%"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(13, 36)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(66, 13)
        Me.Label48.TabIndex = 68
        Me.Label48.Text = "Rev identity:"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(18, 9)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(61, 13)
        Me.Label49.TabIndex = 67
        Me.Label49.Text = "For identity:"
        '
        'ForIdTextBox
        '
        Me.ForIdTextBox.Location = New System.Drawing.Point(85, 6)
        Me.ForIdTextBox.Name = "ForIdTextBox"
        Me.ForIdTextBox.Size = New System.Drawing.Size(34, 20)
        Me.ForIdTextBox.TabIndex = 66
        Me.ForIdTextBox.Text = "100"
        '
        'RevIdTextBox
        '
        Me.RevIdTextBox.Location = New System.Drawing.Point(85, 33)
        Me.RevIdTextBox.Name = "RevIdTextBox"
        Me.RevIdTextBox.Size = New System.Drawing.Size(34, 20)
        Me.RevIdTextBox.TabIndex = 65
        Me.RevIdTextBox.Text = "100"
        '
        'DatabaseComboBox
        '
        Me.DatabaseComboBox.FormattingEnabled = True
        Me.DatabaseComboBox.Items.AddRange(New Object() {"Current sequence"})
        Me.DatabaseComboBox.Location = New System.Drawing.Point(6, 48)
        Me.DatabaseComboBox.Name = "DatabaseComboBox"
        Me.DatabaseComboBox.Size = New System.Drawing.Size(113, 21)
        Me.DatabaseComboBox.TabIndex = 82
        Me.DatabaseComboBox.Text = "Current sequence"
        '
        'AmpMaxTextBox
        '
        Me.AmpMaxTextBox.Location = New System.Drawing.Point(85, 75)
        Me.AmpMaxTextBox.Name = "AmpMaxTextBox"
        Me.AmpMaxTextBox.Size = New System.Drawing.Size(34, 20)
        Me.AmpMaxTextBox.TabIndex = 83
        Me.AmpMaxTextBox.Text = "2000"
        '
        'DatabaseButton
        '
        Me.DatabaseButton.Location = New System.Drawing.Point(6, 19)
        Me.DatabaseButton.Name = "DatabaseButton"
        Me.DatabaseButton.Size = New System.Drawing.Size(113, 23)
        Me.DatabaseButton.TabIndex = 81
        Me.DatabaseButton.Text = "Check primers"
        Me.DatabaseButton.UseVisualStyleBackColor = True
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(4, 78)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(75, 13)
        Me.Label45.TabIndex = 84
        Me.Label45.Text = "Max amplicon:"
        '
        'GroupBox9
        '
        Me.GroupBox9.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox9.Controls.Add(Me.mQTextBox)
        Me.GroupBox9.Controls.Add(Me.Label44)
        Me.GroupBox9.Controls.Add(Me.Label43)
        Me.GroupBox9.Controls.Add(Me.PDCheckBox)
        Me.GroupBox9.Location = New System.Drawing.Point(750, 510)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(236, 63)
        Me.GroupBox9.TabIndex = 80
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Dilution options"
        '
        'mQTextBox
        '
        Me.mQTextBox.Location = New System.Drawing.Point(131, 24)
        Me.mQTextBox.Name = "mQTextBox"
        Me.mQTextBox.Size = New System.Drawing.Size(40, 20)
        Me.mQTextBox.TabIndex = 23
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(177, 27)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(23, 13)
        Me.Label44.TabIndex = 2
        Me.Label44.Text = "mcl"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(99, 27)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(26, 13)
        Me.Label43.TabIndex = 1
        Me.Label43.Text = "mQ:"
        '
        'PDCheckBox
        '
        Me.PDCheckBox.AutoSize = True
        Me.PDCheckBox.Location = New System.Drawing.Point(12, 27)
        Me.PDCheckBox.Name = "PDCheckBox"
        Me.PDCheckBox.Size = New System.Drawing.Size(80, 17)
        Me.PDCheckBox.TabIndex = 0
        Me.PDCheckBox.Text = "Pair dilution"
        Me.PDCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox8.Controls.Add(Me.Label37)
        Me.GroupBox8.Controls.Add(Me.Label38)
        Me.GroupBox8.Controls.Add(Me.Label39)
        Me.GroupBox8.Controls.Add(Me.Label40)
        Me.GroupBox8.Controls.Add(Me.RevVTextBox)
        Me.GroupBox8.Controls.Add(Me.RevVtoTakeTextBox)
        Me.GroupBox8.Controls.Add(Me.Label41)
        Me.GroupBox8.Controls.Add(Me.RevTargetCTextBox)
        Me.GroupBox8.Controls.Add(Me.Label42)
        Me.GroupBox8.Location = New System.Drawing.Point(750, 399)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(236, 105)
        Me.GroupBox8.TabIndex = 79
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Dilution Rev"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(177, 48)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(50, 13)
        Me.Label37.TabIndex = 29
        Me.Label37.Text = "pmol/mcl"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(177, 74)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(23, 13)
        Me.Label38.TabIndex = 28
        Me.Label38.Text = "mcl"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(177, 22)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(23, 13)
        Me.Label39.TabIndex = 27
        Me.Label39.Text = "mcl"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(9, 74)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(116, 13)
        Me.Label40.TabIndex = 26
        Me.Label40.Text = "Vol. to take from stock:"
        '
        'RevVTextBox
        '
        Me.RevVTextBox.Location = New System.Drawing.Point(131, 19)
        Me.RevVTextBox.Name = "RevVTextBox"
        Me.RevVTextBox.Size = New System.Drawing.Size(40, 20)
        Me.RevVTextBox.TabIndex = 20
        Me.RevVTextBox.Text = "100"
        '
        'RevVtoTakeTextBox
        '
        Me.RevVtoTakeTextBox.Location = New System.Drawing.Point(131, 71)
        Me.RevVtoTakeTextBox.Name = "RevVtoTakeTextBox"
        Me.RevVtoTakeTextBox.ReadOnly = True
        Me.RevVtoTakeTextBox.Size = New System.Drawing.Size(40, 20)
        Me.RevVtoTakeTextBox.TabIndex = 21
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(25, 48)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(100, 13)
        Me.Label41.TabIndex = 24
        Me.Label41.Text = "Final concentration:"
        '
        'RevTargetCTextBox
        '
        Me.RevTargetCTextBox.Location = New System.Drawing.Point(131, 45)
        Me.RevTargetCTextBox.Name = "RevTargetCTextBox"
        Me.RevTargetCTextBox.Size = New System.Drawing.Size(40, 20)
        Me.RevTargetCTextBox.TabIndex = 22
        Me.RevTargetCTextBox.Text = "10"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(56, 22)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(69, 13)
        Me.Label42.TabIndex = 23
        Me.Label42.Text = "Final volume:"
        '
        'GroupBox7
        '
        Me.GroupBox7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox7.Controls.Add(Me.Label31)
        Me.GroupBox7.Controls.Add(Me.Label32)
        Me.GroupBox7.Controls.Add(Me.Label33)
        Me.GroupBox7.Controls.Add(Me.Label34)
        Me.GroupBox7.Controls.Add(Me.Label35)
        Me.GroupBox7.Controls.Add(Me.Label36)
        Me.GroupBox7.Controls.Add(Me.RevdSTextBox)
        Me.GroupBox7.Controls.Add(Me.RevdHTextBox)
        Me.GroupBox7.Controls.Add(Me.RevdGTextBox)
        Me.GroupBox7.Location = New System.Drawing.Point(810, 12)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(176, 102)
        Me.GroupBox7.TabIndex = 72
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Thermodynamic constants Rev"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(81, 75)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(53, 13)
        Me.Label31.TabIndex = 20
        Me.Label31.Text = "cal/K*mol"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(81, 49)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(48, 13)
        Me.Label32.TabIndex = 19
        Me.Label32.Text = "kcal/mol"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(81, 23)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(48, 13)
        Me.Label33.TabIndex = 18
        Me.Label33.Text = "kcal/mol"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(6, 75)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(23, 13)
        Me.Label34.TabIndex = 17
        Me.Label34.Text = "dS:"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(5, 49)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(24, 13)
        Me.Label35.TabIndex = 16
        Me.Label35.Text = "dH:"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(5, 23)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(24, 13)
        Me.Label36.TabIndex = 15
        Me.Label36.Text = "dG:"
        '
        'RevdSTextBox
        '
        Me.RevdSTextBox.Location = New System.Drawing.Point(35, 72)
        Me.RevdSTextBox.Name = "RevdSTextBox"
        Me.RevdSTextBox.ReadOnly = True
        Me.RevdSTextBox.Size = New System.Drawing.Size(40, 20)
        Me.RevdSTextBox.TabIndex = 14
        '
        'RevdHTextBox
        '
        Me.RevdHTextBox.Location = New System.Drawing.Point(35, 46)
        Me.RevdHTextBox.Name = "RevdHTextBox"
        Me.RevdHTextBox.ReadOnly = True
        Me.RevdHTextBox.Size = New System.Drawing.Size(40, 20)
        Me.RevdHTextBox.TabIndex = 13
        '
        'RevdGTextBox
        '
        Me.RevdGTextBox.Location = New System.Drawing.Point(35, 20)
        Me.RevdGTextBox.Name = "RevdGTextBox"
        Me.RevdGTextBox.ReadOnly = True
        Me.RevdGTextBox.Size = New System.Drawing.Size(40, 20)
        Me.RevdGTextBox.TabIndex = 12
        '
        'GroupBox6
        '
        Me.GroupBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox6.Controls.Add(Me.DimersCheckBox)
        Me.GroupBox6.Controls.Add(Me.HairpinsCheckBox)
        Me.GroupBox6.Controls.Add(Me.Label60)
        Me.GroupBox6.Controls.Add(Me.dGLimTextBox)
        Me.GroupBox6.Controls.Add(Me.Label25)
        Me.GroupBox6.Controls.Add(Me.Label19)
        Me.GroupBox6.Controls.Add(Me.ExtCheckBox)
        Me.GroupBox6.Controls.Add(Me.Label24)
        Me.GroupBox6.Controls.Add(Me.TTextBox)
        Me.GroupBox6.Controls.Add(Me.CutoffTextBox)
        Me.GroupBox6.Location = New System.Drawing.Point(12, 123)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(187, 144)
        Me.GroupBox6.TabIndex = 78
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Options"
        '
        'DimersCheckBox
        '
        Me.DimersCheckBox.AutoSize = True
        Me.DimersCheckBox.Checked = True
        Me.DimersCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.DimersCheckBox.Location = New System.Drawing.Point(7, 98)
        Me.DimersCheckBox.Name = "DimersCheckBox"
        Me.DimersCheckBox.Size = New System.Drawing.Size(58, 17)
        Me.DimersCheckBox.TabIndex = 36
        Me.DimersCheckBox.Text = "Dimers"
        Me.DimersCheckBox.UseVisualStyleBackColor = True
        '
        'HairpinsCheckBox
        '
        Me.HairpinsCheckBox.AutoSize = True
        Me.HairpinsCheckBox.Checked = True
        Me.HairpinsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.HairpinsCheckBox.Location = New System.Drawing.Point(71, 98)
        Me.HairpinsCheckBox.Name = "HairpinsCheckBox"
        Me.HairpinsCheckBox.Size = New System.Drawing.Size(64, 17)
        Me.HairpinsCheckBox.TabIndex = 23
        Me.HairpinsCheckBox.Text = "Hairpins"
        Me.HairpinsCheckBox.UseVisualStyleBackColor = True
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(2, 74)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(113, 13)
        Me.Label60.TabIndex = 38
        Me.Label60.Text = "dG filtration (kcal/mol):"
        '
        'dGLimTextBox
        '
        Me.dGLimTextBox.Location = New System.Drawing.Point(121, 71)
        Me.dGLimTextBox.Name = "dGLimTextBox"
        Me.dGLimTextBox.Size = New System.Drawing.Size(40, 20)
        Me.dGLimTextBox.TabIndex = 37
        Me.dGLimTextBox.Text = "0"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(167, 23)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(14, 13)
        Me.Label25.TabIndex = 32
        Me.Label25.Text = "C"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(7, 48)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(108, 13)
        Me.Label19.TabIndex = 35
        Me.Label19.Text = "3' complement cutoff:"
        '
        'ExtCheckBox
        '
        Me.ExtCheckBox.AutoSize = True
        Me.ExtCheckBox.Location = New System.Drawing.Point(7, 119)
        Me.ExtCheckBox.Name = "ExtCheckBox"
        Me.ExtCheckBox.Size = New System.Drawing.Size(146, 17)
        Me.ExtCheckBox.TabIndex = 33
        Me.ExtCheckBox.Text = "Only extensible structures"
        Me.ExtCheckBox.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(14, 23)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(101, 13)
        Me.Label24.TabIndex = 31
        Me.Label24.Text = "Dimers temperature:"
        '
        'TTextBox
        '
        Me.TTextBox.Location = New System.Drawing.Point(121, 19)
        Me.TTextBox.Name = "TTextBox"
        Me.TTextBox.Size = New System.Drawing.Size(40, 20)
        Me.TTextBox.TabIndex = 30
        Me.TTextBox.Text = "37"
        '
        'CutoffTextBox
        '
        Me.CutoffTextBox.Location = New System.Drawing.Point(121, 45)
        Me.CutoffTextBox.Name = "CutoffTextBox"
        Me.CutoffTextBox.Size = New System.Drawing.Size(40, 20)
        Me.CutoffTextBox.TabIndex = 34
        Me.CutoffTextBox.Text = "3"
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox5.Controls.Add(Me.RevRadioButton)
        Me.GroupBox5.Controls.Add(Me.RevLengthTextBox)
        Me.GroupBox5.Controls.Add(Me.RevMRadioButton)
        Me.GroupBox5.Controls.Add(Me.RevGRadioButton)
        Me.GroupBox5.Controls.Add(Me.RevMWTextBox)
        Me.GroupBox5.Controls.Add(Me.Label20)
        Me.GroupBox5.Controls.Add(Me.Label26)
        Me.GroupBox5.Controls.Add(Me.RevGCTextBox)
        Me.GroupBox5.Controls.Add(Me.Label27)
        Me.GroupBox5.Controls.Add(Me.RevTmTextBox)
        Me.GroupBox5.Controls.Add(Me.RevGramTextBox)
        Me.GroupBox5.Controls.Add(Me.Label28)
        Me.GroupBox5.Controls.Add(Me.Label29)
        Me.GroupBox5.Controls.Add(Me.Label30)
        Me.GroupBox5.Controls.Add(Me.RevMolTextBox)
        Me.GroupBox5.Location = New System.Drawing.Point(476, 123)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(265, 98)
        Me.GroupBox5.TabIndex = 71
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Rev primer properties"
        '
        'RevRadioButton
        '
        Me.RevRadioButton.AutoSize = True
        Me.RevRadioButton.Checked = True
        Me.RevRadioButton.Location = New System.Drawing.Point(246, 23)
        Me.RevRadioButton.Name = "RevRadioButton"
        Me.RevRadioButton.Size = New System.Drawing.Size(14, 13)
        Me.RevRadioButton.TabIndex = 25
        Me.RevRadioButton.TabStop = True
        Me.RevRadioButton.UseVisualStyleBackColor = True
        '
        'RevLengthTextBox
        '
        Me.RevLengthTextBox.Location = New System.Drawing.Point(58, 19)
        Me.RevLengthTextBox.Name = "RevLengthTextBox"
        Me.RevLengthTextBox.ReadOnly = True
        Me.RevLengthTextBox.Size = New System.Drawing.Size(40, 20)
        Me.RevLengthTextBox.TabIndex = 9
        '
        'RevMRadioButton
        '
        Me.RevMRadioButton.AutoSize = True
        Me.RevMRadioButton.Location = New System.Drawing.Point(246, 48)
        Me.RevMRadioButton.Name = "RevMRadioButton"
        Me.RevMRadioButton.Size = New System.Drawing.Size(14, 13)
        Me.RevMRadioButton.TabIndex = 24
        Me.RevMRadioButton.UseVisualStyleBackColor = True
        '
        'RevGRadioButton
        '
        Me.RevGRadioButton.AutoSize = True
        Me.RevGRadioButton.Location = New System.Drawing.Point(246, 74)
        Me.RevGRadioButton.Name = "RevGRadioButton"
        Me.RevGRadioButton.Size = New System.Drawing.Size(14, 13)
        Me.RevGRadioButton.TabIndex = 23
        Me.RevGRadioButton.UseVisualStyleBackColor = True
        '
        'RevMWTextBox
        '
        Me.RevMWTextBox.Location = New System.Drawing.Point(200, 19)
        Me.RevMWTextBox.Name = "RevMWTextBox"
        Me.RevMWTextBox.ReadOnly = True
        Me.RevMWTextBox.Size = New System.Drawing.Size(40, 20)
        Me.RevMWTextBox.TabIndex = 11
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(9, 22)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(43, 13)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "Length:"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(164, 22)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(30, 13)
        Me.Label26.TabIndex = 12
        Me.Label26.Text = "MW:"
        '
        'RevGCTextBox
        '
        Me.RevGCTextBox.Location = New System.Drawing.Point(58, 45)
        Me.RevGCTextBox.Name = "RevGCTextBox"
        Me.RevGCTextBox.ReadOnly = True
        Me.RevGCTextBox.Size = New System.Drawing.Size(40, 20)
        Me.RevGCTextBox.TabIndex = 7
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(109, 48)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(85, 13)
        Me.Label27.TabIndex = 19
        Me.Label27.Text = "mcM (pmol/mcl):"
        '
        'RevTmTextBox
        '
        Me.RevTmTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.RevTmTextBox.Location = New System.Drawing.Point(58, 71)
        Me.RevTmTextBox.Name = "RevTmTextBox"
        Me.RevTmTextBox.ReadOnly = True
        Me.RevTmTextBox.Size = New System.Drawing.Size(40, 20)
        Me.RevTmTextBox.TabIndex = 5
        '
        'RevGramTextBox
        '
        Me.RevGramTextBox.Location = New System.Drawing.Point(200, 71)
        Me.RevGramTextBox.Name = "RevGramTextBox"
        Me.RevGramTextBox.ReadOnly = True
        Me.RevGramTextBox.Size = New System.Drawing.Size(40, 20)
        Me.RevGramTextBox.TabIndex = 18
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(16, 48)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(36, 13)
        Me.Label28.TabIndex = 8
        Me.Label28.Text = "% GC:"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(113, 74)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(81, 13)
        Me.Label29.TabIndex = 17
        Me.Label29.Text = "g/L (mcg/mcL):"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label30.Location = New System.Drawing.Point(24, 74)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(28, 13)
        Me.Label30.TabIndex = 6
        Me.Label30.Text = "Tm:"
        '
        'RevMolTextBox
        '
        Me.RevMolTextBox.Location = New System.Drawing.Point(200, 45)
        Me.RevMolTextBox.Name = "RevMolTextBox"
        Me.RevMolTextBox.ReadOnly = True
        Me.RevMolTextBox.Size = New System.Drawing.Size(40, 20)
        Me.RevMolTextBox.TabIndex = 16
        '
        'DimerGroupBox
        '
        Me.DimerGroupBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DimerGroupBox.Controls.Add(Me.ImagePanel)
        Me.DimerGroupBox.Controls.Add(Me.StructuresTextBox)
        Me.DimerGroupBox.Location = New System.Drawing.Point(12, 273)
        Me.DimerGroupBox.Name = "DimerGroupBox"
        Me.DimerGroupBox.Size = New System.Drawing.Size(729, 168)
        Me.DimerGroupBox.TabIndex = 74
        Me.DimerGroupBox.TabStop = False
        Me.DimerGroupBox.Text = "Primer-dimers"
        '
        'ImagePanel
        '
        Me.ImagePanel.AutoScroll = True
        Me.ImagePanel.Controls.Add(Me.StructuresPictureBox)
        Me.ImagePanel.Location = New System.Drawing.Point(373, 18)
        Me.ImagePanel.Name = "ImagePanel"
        Me.ImagePanel.Size = New System.Drawing.Size(200, 100)
        Me.ImagePanel.TabIndex = 2
        '
        'StructuresPictureBox
        '
        Me.StructuresPictureBox.Location = New System.Drawing.Point(3, 3)
        Me.StructuresPictureBox.Name = "StructuresPictureBox"
        Me.StructuresPictureBox.Size = New System.Drawing.Size(100, 50)
        Me.StructuresPictureBox.TabIndex = 1
        Me.StructuresPictureBox.TabStop = False
        '
        'StructuresTextBox
        '
        Me.StructuresTextBox.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.StructuresTextBox.Location = New System.Drawing.Point(3, 16)
        Me.StructuresTextBox.Name = "StructuresTextBox"
        Me.StructuresTextBox.Size = New System.Drawing.Size(133, 72)
        Me.StructuresTextBox.TabIndex = 0
        Me.StructuresTextBox.Text = ""
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox4.Controls.Add(Me.Rev3ModBox)
        Me.GroupBox4.Controls.Add(Me.For3ModBox)
        Me.GroupBox4.Controls.Add(Me.Rev5ModBox)
        Me.GroupBox4.Controls.Add(Me.For5ModBox)
        Me.GroupBox4.Controls.Add(Me.ODRevTextBox)
        Me.GroupBox4.Controls.Add(Me.ForTextBox)
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Controls.Add(Me.ClearButton)
        Me.GroupBox4.Controls.Add(Me.RevTextBox)
        Me.GroupBox4.Controls.Add(Me.ODForTextBox)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(610, 102)
        Me.GroupBox4.TabIndex = 73
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Oligo"
        '
        'Rev3ModBox
        '
        Me.Rev3ModBox.CheckOnClick = True
        Me.Rev3ModBox.FormattingEnabled = True
        Me.Rev3ModBox.Location = New System.Drawing.Point(455, 58)
        Me.Rev3ModBox.Name = "Rev3ModBox"
        Me.Rev3ModBox.Size = New System.Drawing.Size(100, 34)
        Me.Rev3ModBox.TabIndex = 41
        '
        'For3ModBox
        '
        Me.For3ModBox.CheckOnClick = True
        Me.For3ModBox.FormattingEnabled = True
        Me.For3ModBox.Location = New System.Drawing.Point(455, 19)
        Me.For3ModBox.Name = "For3ModBox"
        Me.For3ModBox.Size = New System.Drawing.Size(100, 34)
        Me.For3ModBox.TabIndex = 40
        '
        'Rev5ModBox
        '
        Me.Rev5ModBox.CheckOnClick = True
        Me.Rev5ModBox.FormattingEnabled = True
        Me.Rev5ModBox.Location = New System.Drawing.Point(10, 58)
        Me.Rev5ModBox.Name = "Rev5ModBox"
        Me.Rev5ModBox.Size = New System.Drawing.Size(100, 34)
        Me.Rev5ModBox.TabIndex = 39
        '
        'For5ModBox
        '
        Me.For5ModBox.CheckOnClick = True
        Me.For5ModBox.FormattingEnabled = True
        Me.For5ModBox.Location = New System.Drawing.Point(10, 19)
        Me.For5ModBox.Name = "For5ModBox"
        Me.For5ModBox.Size = New System.Drawing.Size(100, 34)
        Me.For5ModBox.TabIndex = 38
        '
        'ODRevTextBox
        '
        Me.ODRevTextBox.Location = New System.Drawing.Point(564, 72)
        Me.ODRevTextBox.Name = "ODRevTextBox"
        Me.ODRevTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ODRevTextBox.TabIndex = 33
        Me.ODRevTextBox.Text = "10"
        '
        'ForTextBox
        '
        Me.ForTextBox.Location = New System.Drawing.Point(116, 33)
        Me.ForTextBox.Name = "ForTextBox"
        Me.ForTextBox.Size = New System.Drawing.Size(333, 20)
        Me.ForTextBox.TabIndex = 0
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(114, 56)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(115, 13)
        Me.Label15.TabIndex = 30
        Me.Label15.Text = "Reverse primer (if any):"
        '
        'ClearButton
        '
        Me.ClearButton.Image = CType(resources.GetObject("ClearButton.Image"), System.Drawing.Image)
        Me.ClearButton.Location = New System.Drawing.Point(564, 52)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(40, 20)
        Me.ClearButton.TabIndex = 35
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'RevTextBox
        '
        Me.RevTextBox.Location = New System.Drawing.Point(116, 72)
        Me.RevTextBox.Name = "RevTextBox"
        Me.RevTextBox.Size = New System.Drawing.Size(333, 20)
        Me.RevTextBox.TabIndex = 29
        '
        'ODForTextBox
        '
        Me.ODForTextBox.Location = New System.Drawing.Point(564, 32)
        Me.ODForTextBox.Name = "ODForTextBox"
        Me.ODForTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ODForTextBox.TabIndex = 14
        Me.ODForTextBox.Text = "10"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(114, 17)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(142, 13)
        Me.Label14.TabIndex = 28
        Me.Label14.Text = "Forward primer (or any oligo):"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(561, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(26, 13)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "OD:"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox3.Controls.Add(Me.Label23)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.Label21)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.FordSTextBox)
        Me.GroupBox3.Controls.Add(Me.FordHTextBox)
        Me.GroupBox3.Controls.Add(Me.FordGTextBox)
        Me.GroupBox3.Location = New System.Drawing.Point(628, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(176, 102)
        Me.GroupBox3.TabIndex = 70
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Thermodynamic constants For"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(81, 75)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(53, 13)
        Me.Label23.TabIndex = 20
        Me.Label23.Text = "cal/K*mol"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(81, 49)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(48, 13)
        Me.Label22.TabIndex = 19
        Me.Label22.Text = "kcal/mol"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(81, 23)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(48, 13)
        Me.Label21.TabIndex = 18
        Me.Label21.Text = "kcal/mol"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(6, 75)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(23, 13)
        Me.Label18.TabIndex = 17
        Me.Label18.Text = "dS:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(5, 49)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(24, 13)
        Me.Label17.TabIndex = 16
        Me.Label17.Text = "dH:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(5, 23)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(24, 13)
        Me.Label16.TabIndex = 15
        Me.Label16.Text = "dG:"
        '
        'FordSTextBox
        '
        Me.FordSTextBox.Location = New System.Drawing.Point(35, 72)
        Me.FordSTextBox.Name = "FordSTextBox"
        Me.FordSTextBox.ReadOnly = True
        Me.FordSTextBox.Size = New System.Drawing.Size(40, 20)
        Me.FordSTextBox.TabIndex = 14
        '
        'FordHTextBox
        '
        Me.FordHTextBox.Location = New System.Drawing.Point(35, 46)
        Me.FordHTextBox.Name = "FordHTextBox"
        Me.FordHTextBox.ReadOnly = True
        Me.FordHTextBox.Size = New System.Drawing.Size(40, 20)
        Me.FordHTextBox.TabIndex = 13
        '
        'FordGTextBox
        '
        Me.FordGTextBox.Location = New System.Drawing.Point(35, 20)
        Me.FordGTextBox.Name = "FordGTextBox"
        Me.FordGTextBox.ReadOnly = True
        Me.FordGTextBox.Size = New System.Drawing.Size(40, 20)
        Me.FordGTextBox.TabIndex = 12
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.ForRadioButton)
        Me.GroupBox2.Controls.Add(Me.ForMRadioButton)
        Me.GroupBox2.Controls.Add(Me.ForGRadioButton)
        Me.GroupBox2.Controls.Add(Me.ForLengthTextBox)
        Me.GroupBox2.Controls.Add(Me.ForMWTextBox)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.ForGCTextBox)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.ForTmTextBox)
        Me.GroupBox2.Controls.Add(Me.ForGramTextBox)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.ForMolTextBox)
        Me.GroupBox2.Location = New System.Drawing.Point(205, 123)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(265, 98)
        Me.GroupBox2.TabIndex = 69
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "For primer properties"
        '
        'ForRadioButton
        '
        Me.ForRadioButton.AutoSize = True
        Me.ForRadioButton.Checked = True
        Me.ForRadioButton.Location = New System.Drawing.Point(246, 23)
        Me.ForRadioButton.Name = "ForRadioButton"
        Me.ForRadioButton.Size = New System.Drawing.Size(14, 13)
        Me.ForRadioButton.TabIndex = 22
        Me.ForRadioButton.TabStop = True
        Me.ForRadioButton.UseVisualStyleBackColor = True
        '
        'ForMRadioButton
        '
        Me.ForMRadioButton.AutoSize = True
        Me.ForMRadioButton.Location = New System.Drawing.Point(246, 48)
        Me.ForMRadioButton.Name = "ForMRadioButton"
        Me.ForMRadioButton.Size = New System.Drawing.Size(14, 13)
        Me.ForMRadioButton.TabIndex = 21
        Me.ForMRadioButton.TabStop = True
        Me.ForMRadioButton.UseVisualStyleBackColor = True
        '
        'ForGRadioButton
        '
        Me.ForGRadioButton.AutoSize = True
        Me.ForGRadioButton.Location = New System.Drawing.Point(246, 74)
        Me.ForGRadioButton.Name = "ForGRadioButton"
        Me.ForGRadioButton.Size = New System.Drawing.Size(14, 13)
        Me.ForGRadioButton.TabIndex = 20
        Me.ForGRadioButton.TabStop = True
        Me.ForGRadioButton.UseVisualStyleBackColor = True
        '
        'ForLengthTextBox
        '
        Me.ForLengthTextBox.Location = New System.Drawing.Point(58, 19)
        Me.ForLengthTextBox.Name = "ForLengthTextBox"
        Me.ForLengthTextBox.ReadOnly = True
        Me.ForLengthTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ForLengthTextBox.TabIndex = 9
        '
        'ForMWTextBox
        '
        Me.ForMWTextBox.Location = New System.Drawing.Point(200, 19)
        Me.ForMWTextBox.Name = "ForMWTextBox"
        Me.ForMWTextBox.ReadOnly = True
        Me.ForMWTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ForMWTextBox.TabIndex = 11
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 13)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Length:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(164, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 13)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "MW:"
        '
        'ForGCTextBox
        '
        Me.ForGCTextBox.Location = New System.Drawing.Point(58, 45)
        Me.ForGCTextBox.Name = "ForGCTextBox"
        Me.ForGCTextBox.ReadOnly = True
        Me.ForGCTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ForGCTextBox.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(109, 48)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(85, 13)
        Me.Label7.TabIndex = 19
        Me.Label7.Text = "mcM (pmol/mcl):"
        '
        'ForTmTextBox
        '
        Me.ForTmTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ForTmTextBox.Location = New System.Drawing.Point(58, 71)
        Me.ForTmTextBox.Name = "ForTmTextBox"
        Me.ForTmTextBox.ReadOnly = True
        Me.ForTmTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ForTmTextBox.TabIndex = 5
        '
        'ForGramTextBox
        '
        Me.ForGramTextBox.Location = New System.Drawing.Point(200, 71)
        Me.ForGramTextBox.Name = "ForGramTextBox"
        Me.ForGramTextBox.ReadOnly = True
        Me.ForGramTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ForGramTextBox.TabIndex = 18
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(36, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "% GC:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(113, 74)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(81, 13)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "g/L (mcg/mcL):"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label1.Location = New System.Drawing.Point(24, 74)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Tm:"
        '
        'ForMolTextBox
        '
        Me.ForMolTextBox.Location = New System.Drawing.Point(200, 45)
        Me.ForMolTextBox.Name = "ForMolTextBox"
        Me.ForMolTextBox.ReadOnly = True
        Me.ForMolTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ForMolTextBox.TabIndex = 16
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.ForVTextBox)
        Me.GroupBox1.Controls.Add(Me.ForVtoTakeTextBox)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.ForTargetCTextBox)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Location = New System.Drawing.Point(750, 288)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(236, 105)
        Me.GroupBox1.TabIndex = 68
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Dilution For"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(177, 48)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(50, 13)
        Me.Label13.TabIndex = 29
        Me.Label13.Text = "pmol/mcl"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(177, 74)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(23, 13)
        Me.Label12.TabIndex = 28
        Me.Label12.Text = "mcl"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(177, 22)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(23, 13)
        Me.Label11.TabIndex = 27
        Me.Label11.Text = "mcl"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(9, 74)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(116, 13)
        Me.Label10.TabIndex = 26
        Me.Label10.Text = "Vol. to take from stock:"
        '
        'ForVTextBox
        '
        Me.ForVTextBox.Location = New System.Drawing.Point(131, 19)
        Me.ForVTextBox.Name = "ForVTextBox"
        Me.ForVTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ForVTextBox.TabIndex = 20
        Me.ForVTextBox.Text = "100"
        '
        'ForVtoTakeTextBox
        '
        Me.ForVtoTakeTextBox.Location = New System.Drawing.Point(131, 71)
        Me.ForVtoTakeTextBox.Name = "ForVtoTakeTextBox"
        Me.ForVtoTakeTextBox.ReadOnly = True
        Me.ForVtoTakeTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ForVtoTakeTextBox.TabIndex = 21
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(25, 48)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(100, 13)
        Me.Label9.TabIndex = 24
        Me.Label9.Text = "Final concentration:"
        '
        'ForTargetCTextBox
        '
        Me.ForTargetCTextBox.Location = New System.Drawing.Point(131, 45)
        Me.ForTargetCTextBox.Name = "ForTargetCTextBox"
        Me.ForTargetCTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ForTargetCTextBox.TabIndex = 22
        Me.ForTargetCTextBox.Text = "10"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(56, 22)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(69, 13)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "Final volume:"
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(911, 579)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.Size = New System.Drawing.Size(75, 23)
        Me.OKButton.TabIndex = 67
        Me.OKButton.Text = "Calculate"
        Me.OKButton.UseVisualStyleBackColor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox10.Controls.Add(Me.RestoreButton)
        Me.GroupBox10.Controls.Add(Me.SaveButton)
        Me.GroupBox10.Controls.Add(Me.Label52)
        Me.GroupBox10.Controls.Add(Me.Label53)
        Me.GroupBox10.Controls.Add(Me.Label54)
        Me.GroupBox10.Controls.Add(Me.Label55)
        Me.GroupBox10.Controls.Add(Me.Label56)
        Me.GroupBox10.Controls.Add(Me.OligoCTextBox)
        Me.GroupBox10.Controls.Add(Me.Label57)
        Me.GroupBox10.Controls.Add(Me.Label58)
        Me.GroupBox10.Controls.Add(Me.Label59)
        Me.GroupBox10.Controls.Add(Me.dNTPCTextBox)
        Me.GroupBox10.Controls.Add(Me.MgCTextBox)
        Me.GroupBox10.Controls.Add(Me.NaCTextBox)
        Me.GroupBox10.Location = New System.Drawing.Point(750, 123)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(236, 159)
        Me.GroupBox10.TabIndex = 86
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "PCR mixture composition"
        '
        'RestoreButton
        '
        Me.RestoreButton.Image = CType(resources.GetObject("RestoreButton.Image"), System.Drawing.Image)
        Me.RestoreButton.Location = New System.Drawing.Point(105, 121)
        Me.RestoreButton.Name = "RestoreButton"
        Me.RestoreButton.Size = New System.Drawing.Size(40, 23)
        Me.RestoreButton.TabIndex = 89
        Me.RestoreButton.UseVisualStyleBackColor = True
        '
        'SaveButton
        '
        Me.SaveButton.Image = CType(resources.GetObject("SaveButton.Image"), System.Drawing.Image)
        Me.SaveButton.Location = New System.Drawing.Point(59, 121)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(40, 23)
        Me.SaveButton.TabIndex = 88
        Me.SaveButton.UseVisualStyleBackColor = True
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(105, 98)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(71, 13)
        Me.Label52.TabIndex = 11
        Me.Label52.Text = "nM (fmol/mcl)"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(105, 72)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(24, 13)
        Me.Label53.TabIndex = 10
        Me.Label53.Text = "mM"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(105, 46)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(24, 13)
        Me.Label54.TabIndex = 9
        Me.Label54.Text = "mM"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(105, 22)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(24, 13)
        Me.Label55.TabIndex = 8
        Me.Label55.Text = "mM"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(14, 98)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(39, 13)
        Me.Label56.TabIndex = 7
        Me.Label56.Text = "Oligos:"
        '
        'OligoCTextBox
        '
        Me.OligoCTextBox.Location = New System.Drawing.Point(59, 95)
        Me.OligoCTextBox.Name = "OligoCTextBox"
        Me.OligoCTextBox.Size = New System.Drawing.Size(40, 20)
        Me.OligoCTextBox.TabIndex = 6
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(15, 72)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(38, 13)
        Me.Label57.TabIndex = 5
        Me.Label57.Text = "dNTP:"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(16, 46)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(37, 13)
        Me.Label58.TabIndex = 4
        Me.Label58.Text = "Mg2+:"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(23, 20)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(30, 13)
        Me.Label59.TabIndex = 3
        Me.Label59.Text = "Na+:"
        '
        'dNTPCTextBox
        '
        Me.dNTPCTextBox.Location = New System.Drawing.Point(59, 69)
        Me.dNTPCTextBox.Name = "dNTPCTextBox"
        Me.dNTPCTextBox.Size = New System.Drawing.Size(40, 20)
        Me.dNTPCTextBox.TabIndex = 2
        '
        'MgCTextBox
        '
        Me.MgCTextBox.Location = New System.Drawing.Point(59, 43)
        Me.MgCTextBox.Name = "MgCTextBox"
        Me.MgCTextBox.Size = New System.Drawing.Size(40, 20)
        Me.MgCTextBox.TabIndex = 1
        '
        'NaCTextBox
        '
        Me.NaCTextBox.Location = New System.Drawing.Point(59, 17)
        Me.NaCTextBox.Name = "NaCTextBox"
        Me.NaCTextBox.Size = New System.Drawing.Size(40, 20)
        Me.NaCTextBox.TabIndex = 0
        '
        'GroupBox11
        '
        Me.GroupBox11.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox11.Controls.Add(Me.SearchTabControl)
        Me.GroupBox11.Controls.Add(Me.DatabaseButton)
        Me.GroupBox11.Controls.Add(Me.Label45)
        Me.GroupBox11.Controls.Add(Me.AmpMaxTextBox)
        Me.GroupBox11.Controls.Add(Me.DatabaseComboBox)
        Me.GroupBox11.Location = New System.Drawing.Point(12, 447)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(466, 126)
        Me.GroupBox11.TabIndex = 87
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Check primers"
        '
        'GroupBox12
        '
        Me.GroupBox12.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox12.Controls.Add(Me.RefreshSitesButton)
        Me.GroupBox12.Controls.Add(Me.SiteBox)
        Me.GroupBox12.Location = New System.Drawing.Point(484, 447)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(257, 126)
        Me.GroupBox12.TabIndex = 88
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Site detector"
        '
        'RefreshSitesButton
        '
        Me.RefreshSitesButton.Image = CType(resources.GetObject("RefreshSitesButton.Image"), System.Drawing.Image)
        Me.RefreshSitesButton.Location = New System.Drawing.Point(209, 19)
        Me.RefreshSitesButton.Name = "RefreshSitesButton"
        Me.RefreshSitesButton.Size = New System.Drawing.Size(40, 20)
        Me.RefreshSitesButton.TabIndex = 36
        Me.RefreshSitesButton.UseVisualStyleBackColor = True
        '
        'SiteBox
        '
        Me.SiteBox.CheckOnClick = True
        Me.SiteBox.FormattingEnabled = True
        Me.SiteBox.Location = New System.Drawing.Point(6, 19)
        Me.SiteBox.Name = "SiteBox"
        Me.SiteBox.Size = New System.Drawing.Size(197, 94)
        Me.SiteBox.TabIndex = 0
        '
        'GraphicalButton
        '
        Me.GraphicalButton.AutoSize = True
        Me.GraphicalButton.Location = New System.Drawing.Point(58, 15)
        Me.GraphicalButton.Name = "GraphicalButton"
        Me.GraphicalButton.Size = New System.Drawing.Size(70, 17)
        Me.GraphicalButton.TabIndex = 1
        Me.GraphicalButton.Text = "Graphical"
        Me.GraphicalButton.UseVisualStyleBackColor = True
        '
        'TextViewButton
        '
        Me.TextViewButton.AutoSize = True
        Me.TextViewButton.Location = New System.Drawing.Point(6, 15)
        Me.TextViewButton.Name = "TextViewButton"
        Me.TextViewButton.Size = New System.Drawing.Size(46, 17)
        Me.TextViewButton.TabIndex = 0
        Me.TextViewButton.Text = "Text"
        Me.TextViewButton.UseVisualStyleBackColor = True
        '
        'ViewSettingsGroupBox
        '
        Me.ViewSettingsGroupBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ViewSettingsGroupBox.Controls.Add(Me.GraphicalButton)
        Me.ViewSettingsGroupBox.Controls.Add(Me.TextViewButton)
        Me.ViewSettingsGroupBox.Location = New System.Drawing.Point(205, 227)
        Me.ViewSettingsGroupBox.Name = "ViewSettingsGroupBox"
        Me.ViewSettingsGroupBox.Size = New System.Drawing.Size(265, 40)
        Me.ViewSettingsGroupBox.TabIndex = 89
        Me.ViewSettingsGroupBox.TabStop = False
        Me.ViewSettingsGroupBox.Text = "View settings"
        '
        'GroupBox13
        '
        Me.GroupBox13.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox13.Location = New System.Drawing.Point(476, 227)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(265, 40)
        Me.GroupBox13.TabIndex = 90
        Me.GroupBox13.TabStop = False
        '
        'Oligocalculator
        '
        Me.AcceptButton = Me.OKButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(994, 612)
        Me.Controls.Add(Me.GroupBox13)
        Me.Controls.Add(Me.ViewSettingsGroupBox)
        Me.Controls.Add(Me.GroupBox12)
        Me.Controls.Add(Me.GroupBox11)
        Me.Controls.Add(Me.GroupBox10)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.DimerGroupBox)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.OKButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Oligocalculator"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Oligocalculator"
        Me.SearchTabControl.ResumeLayout(False)
        Me.SeqTabPage.ResumeLayout(False)
        Me.SeqTabPage.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.DimerGroupBox.ResumeLayout(False)
        Me.ImagePanel.ResumeLayout(False)
        CType(Me.StructuresPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox12.ResumeLayout(False)
        Me.ViewSettingsGroupBox.ResumeLayout(False)
        Me.ViewSettingsGroupBox.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SearchTabControl As System.Windows.Forms.TabControl
    Friend WithEvents SeqTabPage As System.Windows.Forms.TabPage
    Friend WithEvents AccClearCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents AmpliconsRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents PrimersRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents ForIdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RevIdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DatabaseComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents AmpMaxTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DatabaseButton As System.Windows.Forms.Button
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents mQTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents PDCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents RevVTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RevVtoTakeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents RevTargetCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents RevdSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RevdHTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RevdGTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents ExtCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CutoffTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents RevRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents RevLengthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RevMRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents RevGRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents RevMWTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents RevGCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents RevTmTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RevGramTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents RevMolTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DimerGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents ODRevTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ForTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents RevTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ODForTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents FordSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FordHTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FordGTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents ForRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents ForMRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents ForGRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents ForLengthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ForMWTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ForGCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents ForTmTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ForGramTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ForMolTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents ForVTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ForVtoTakeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ForTargetCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents OKButton As System.Windows.Forms.Button
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents OligoCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents dNTPCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MgCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NaCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents RestoreButton As System.Windows.Forms.Button
    Friend WithEvents SaveButton As System.Windows.Forms.Button
    Friend WithEvents For5ModBox As System.Windows.Forms.CheckedListBox
    Friend WithEvents Rev5ModBox As System.Windows.Forms.CheckedListBox
    Friend WithEvents Rev3ModBox As System.Windows.Forms.CheckedListBox
    Friend WithEvents For3ModBox As System.Windows.Forms.CheckedListBox
    Friend WithEvents DimersCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents HairpinsCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents SiteBox As System.Windows.Forms.CheckedListBox
    Friend WithEvents StructuresTextBox As System.Windows.Forms.RichTextBox
    Friend WithEvents GraphicalButton As System.Windows.Forms.RadioButton
    Friend WithEvents TextViewButton As System.Windows.Forms.RadioButton
    Friend WithEvents StructuresPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents ImagePanel As System.Windows.Forms.Panel
    Friend WithEvents RefreshSitesButton As System.Windows.Forms.Button
    Friend WithEvents ViewSettingsGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents dGLimTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox13 As System.Windows.Forms.GroupBox
End Class
