﻿Public Class Master

    Public OligoThermodynamics As DataTable
    Public RNAThermodynamics As DataTable
    Public OligoModifications As DataTable
    Public AminoacidMWList As DataTable
    Public AminoacidPIList As DataTable
    Public AminoacidHIList As DataTable
    Public AminoacidNamesList As DataTable
    Public CodeNamesList As DataTable
    Public SiteSeqList As DataTable

    Public InitMousePoint As Point
    Public InitMouseRect As Rectangle
    Public InitTabIndex As Integer = 0
    Public CurrentTabIndex As Integer = 0

    Public ClipboardStarted As Boolean = False
    Public SeqClipboard As String = ""
    Public AnnotClipboard As New List(Of Genome_Feature)

    Public Ctrl_Pressed As Boolean = False 'Control is pressed

#Region "Initialization"

    Public Sub LoadData()
        OligoThermodynamics = Bioinformatics.GetOligoThermodynamicsList()
        RNAThermodynamics = Bioinformatics.GetOligoThermodynamicsList_RNA()
        OligoModifications = Bioinformatics.GetOligoModificationsList()
        AminoacidNamesList = Bioinformatics.GetAminoacidNamesList()
        AminoacidMWList = Bioinformatics.GetAminoacidMWList()
        AminoacidPIList = Bioinformatics.GetAminoacidPIList()
        AminoacidHIList = Bioinformatics.GetAminoacidHIList()
        CodeNamesList = Bioinformatics.GetCodeNamesTable()
        SiteSeqList = Bioinformatics.GetSites()
    End Sub

    Private Sub Master_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.ControlKey Then
            Ctrl_Pressed = False
        End If
    End Sub

    Private Sub Master_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.ControlKey Then
            Ctrl_Pressed = True
        End If
    End Sub

    Private Sub Master_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LoadData()

        CheckMenu()

    End Sub



#End Region

#Region "File operations"

    Public Function GetDataValueFromInfoData(ByVal InfoData As FeatureData, ByVal Header As String)
        Dim Val As String = ""

        If Not IsNothing(InfoData) Then

            For i = 0 To InfoData.DataHeaders.Count - 1
                If InfoData.DataHeaders(i) = Header Then
                    Val = InfoData.DataValues(i)
                    Exit For
                End If
            Next i

        End If

        Return Val
    End Function

    Private Sub ParseFasta(ByVal FASTA_Seq As String, ByRef HeaderList As List(Of String), ByRef SeqList As List(Of String))

        HeaderList.Clear()
        SeqList.Clear()


        Dim InitHeader As Boolean = False
        Dim InitSeq As Boolean = False
        Dim MaxText As Integer = FASTA_Seq.Length - 1
        Dim NewLineChar As Char = vbNewLine

        Dim CurrentHeaderStart As Integer = 0
        Dim CurrentSeqStart As Integer = 0

        Dim Counter As Integer = 0

        Dim ReportString As String = ""



        For i = 0 To MaxText

            If FASTA_Seq(i) = ">" Then
                InitHeader = True
                CurrentHeaderStart = i + 1
            End If

            If InitHeader Then

                Counter = 0
                For j = i To MaxText

                    If FASTA_Seq(j) = Chr(10) Or FASTA_Seq(j) = Chr(13) Then

                        InitHeader = False
                        InitSeq = True
                        CurrentSeqStart = j + 1
                        i = CurrentSeqStart
                        HeaderList.Add(FASTA_Seq.Substring(CurrentHeaderStart, Counter - 1)) 'Counter-1 to get rid of new line character

                        Exit For
                    End If
                    Counter += 1
                Next j

            End If 'InitHeader

            If InitSeq Then


                Counter = 0
                For j = i To MaxText

                    If FASTA_Seq(j) = ">" Then 'Next block is reached
                        InitSeq = False
                        i = j - 1

                        SeqList.Add(FASTA_Seq.Substring(CurrentSeqStart, Counter))

                        Exit For
                    End If

                    If j = MaxText Then 'End of the file is reached
                        InitSeq = False
                        i = MaxText
                        SeqList.Add(FASTA_Seq.Substring(CurrentSeqStart))
                    End If

                    Counter += 1
                Next j

            End If 'InitSeq

        Next i


    End Sub

    Private Sub OpenFastaAndGFF(ByVal SeqFile As String, ByVal AnnotFile As String)



        Dim FS As New IO.FileStream(SeqFile, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(FS)

        Dim FASTA As String = Reader.ReadToEnd
        Dim HeaderList As New List(Of String)
        Dim SeqList As New List(Of String)



        ParseFasta(FASTA, HeaderList, SeqList)



        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()



        Dim SeqIDList As New List(Of String)
        Dim AnnotList As New List(Of FeaturesAssembly)

        For Each Header As String In HeaderList
            SeqIDList.Add(Header.Split(" ")(0))
        Next Header

        AnnotList = DataIO.ReadGFFData(AnnotFile, "Main Features")

        Dim CurrentAnnot As FeaturesAssembly = Nothing
        Dim CurrentSeq As String = ""
        Dim bShowLoading As Boolean = False
        Dim ErrorCounter As Integer = 0

        If SeqIDList.Count <= 10 Then
            bShowLoading = True
        End If


        'Read GFF header
        Dim GFF_Header As FeatureData = Nothing

        Try
            GFF_Header = DataIO.ReadGFFHeader(AnnotFile)
        Catch ex As Exception
            ErrorCounter += 1
            MsgBox("Error parsing GFF header!")
        End Try


        For i = 0 To SeqIDList.Count - 1

            'Initiate browser for each sequence in the list by ID and assign annotation from respective feature list

            Try
                CurrentAnnot = Nothing
                For Each Annot As FeaturesAssembly In AnnotList
                    If Annot.AssemblyName = SeqIDList(i) Then

                        CurrentAnnot = Annot
                        Exit For

                    End If
                Next Annot

                CurrentSeq = SeqList(i)
                CurrentSeq = CurrentSeq.Replace(Chr(13), vbNullString)
                CurrentSeq = CurrentSeq.Replace(Chr(10), vbNullString)
                CurrentSeq = CurrentSeq.ToUpper()

                'Try to identify topology
                Dim Circular As Boolean = False
                For Each Feature As Genome_Feature In CurrentAnnot.FeaturesList
                    If Feature.Type = 99 Then
                        If Feature.GetAdditionalValue("Is_circular") = "true" Then
                            Circular = True
                        End If
                        Exit For
                    End If
                Next Feature


                Dim CodonTable As Short = 1
                Dim TableFound As Boolean = False

                'Assign correct codon table for the sequence
                For Each Feature As Genome_Feature In CurrentAnnot.FeaturesList
                    If Not IsNothing(Feature.AdditionalProperties) Then
                        For k = 0 To Feature.AdditionalProperties.DataHeaders.Count - 1
                            If Feature.AdditionalProperties.DataHeaders(k) = "transl_table" Then
                                CodonTable = CType(Feature.AdditionalProperties.DataValues(k), Short)
                                TableFound = True
                                Exit For
                            End If
                        Next k
                    End If
                    If TableFound Then
                        Exit For
                    End If
                Next Feature



                Dim NewViewer As New Genome_Viewer(CurrentSeq, HeaderList(i), CurrentAnnot.FeaturesList, GFF_Header, , Circular)
                Dim NewTab As New TabPage(HeaderList(i))
                NewViewer.Dock = DockStyle.Fill
                NewTab.Controls.Add(NewViewer)
                MasterTabControl.TabPages.Add(NewTab)

                If bShowLoading Then 'Switch off graphical loading if there are too much sequences
                    MasterTabControl.SelectedTab = NewTab
                End If


            Catch ex As Exception
                ErrorCounter += 1
                MsgBox("Error opening multisequence file..." & vbNewLine & ex.Message)
            End Try

        Next i




        MasterStatusLabel.Text = "Loaded " & SeqIDList.Count & " sequence(s). Errors: " & ErrorCounter


    End Sub

    Private Sub OpenFastaOnly(ByVal SeqFile As String)
        Dim FS As New IO.FileStream(SeqFile, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(FS)

        Dim FASTA As String = Reader.ReadToEnd
        Dim HeaderList As New List(Of String)
        Dim SeqList As New List(Of String)

        ParseFasta(FASTA, HeaderList, SeqList)

        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()

        Dim CurrentSeq As String = ""
        Dim bShowLoading As Boolean = False
        Dim ErrorCounter As Integer = 0

        If SeqList.Count <= 10 Then
            bShowLoading = True
        End If

        For i = 0 To SeqList.Count - 1
            Try

                CurrentSeq = SeqList(i)
                CurrentSeq = CurrentSeq.Replace(Chr(13), vbNullString)
                CurrentSeq = CurrentSeq.Replace(Chr(10), vbNullString)
                CurrentSeq = CurrentSeq.ToUpper()

                Dim NewViewer As New Genome_Viewer(CurrentSeq, HeaderList(i))
                Dim NewTab As New TabPage(HeaderList(i))
                NewViewer.Dock = DockStyle.Fill
                NewTab.Controls.Add(NewViewer)
                MasterTabControl.TabPages.Add(NewTab)

                If bShowLoading Then 'Switch off graphical loading if there are too much sequences
                    MasterTabControl.SelectedTab = NewTab
                End If

            Catch ex As Exception
                ErrorCounter += 1
                MsgBox("Error opening multisequence file..." & vbNewLine & ex.Message)
            End Try
        Next i

        MasterStatusLabel.Text = "Loaded " & SeqList.Count & " sequence(s). Errors: " & ErrorCounter

    End Sub

    Private Sub OpenFastaAndAnnot(ByVal FileName As String, ByVal FilePathAndNameWithoutExtension As String, ByVal SeqFileType As String, ByVal AnnotFileType As String)
        Dim NewViewer As New Genome_Viewer(FilePathAndNameWithoutExtension, SeqFileType, AnnotFileType)
        Dim NewTab As New TabPage(FileName)
        NewViewer.Dock = DockStyle.Fill
        NewTab.Controls.Add(NewViewer)
        MasterTabControl.TabPages.Add(NewTab)
        MasterTabControl.SelectedTab = NewTab
    End Sub

    Private Sub OpenGenBank(ByVal File As String)
        Dim ErrorCounter As Integer = 0

        Dim InfoData As FeatureData = Nothing
        Dim SeqName As String = ""
        Dim Circular As Boolean = False

       
        Try
            InfoData = DataIO.ReadGBFileToInfo(File)

            SeqName = GetDataValueFromInfoData(InfoData, "DEFINITION")
            If SeqName = "" Then
                MsgBox("GenBank file lacks DEFINITION field!")
                SeqName = "New_Seq"
            End If

            If Not IsNothing(InfoData) Then
                'For i = 0 To InfoData.DataHeaders.Count - 1
                If GetDataValueFromInfoData(InfoData, "LOCUS").Contains("circular") Then
                    Circular = True
                End If
                'Next i
            End If

        Catch ex As Exception
            ErrorCounter += 1
            SeqName = "New_Seq"
            MsgBox("Error reading header from GenBank!" & vbNewLine & ex.Message)
        End Try

        Dim Seq As String = DataIO.ReadGBFileToSequence(File)


        If Seq = "" Then
            Select Case MsgBox("No sequence in GB file! Import sequence from external FASTA?", MsgBoxStyle.YesNoCancel)
                Case MsgBoxResult.Yes
                    If OpenFileDialog.ShowDialog = DialogResult.OK Then
                        Dim FS As New IO.FileStream(OpenFileDialog.FileName, IO.FileMode.Open, IO.FileAccess.Read)
                        Dim Reader As New IO.StreamReader(FS)

                        Reader.ReadLine() 'Ignore header

                        Seq = Reader.ReadToEnd
                        Seq = Seq.Replace(Chr(10), vbNullString)
                        Seq = Seq.Replace(Chr(13), vbNullString)
                        Seq = Seq.ToUpper

                        Reader.Close()
                        FS.Close()
                        Reader.Dispose()
                        FS.Dispose()
                    End If
                Case Else
                    Exit Sub

            End Select

        End If



        Dim Features As List(Of Genome_Feature) = DataIO.ReadGBFileToAnnotation(File)
        Dim CodonTable As Short = 1
        Dim TableFound As Boolean = False

        'Assign correct codon table for the sequence
        For Each Feature As Genome_Feature In Features
            If Not IsNothing(Feature.AdditionalProperties) Then
                For i = 0 To Feature.AdditionalProperties.DataHeaders.Count - 1
                    If Feature.AdditionalProperties.DataHeaders(i) = "transl_table" Then
                        CodonTable = CType(Feature.AdditionalProperties.DataValues(i), Short)
                        TableFound = True
                        Exit For
                    End If
                Next i
            End If
            If TableFound Then
                Exit For
            End If
        Next Feature



        Dim NewViewer As New Genome_Viewer(Seq, SeqName, Features, InfoData, CodonTable, Circular)

        Dim NewTab As New TabPage(SeqName)
        NewViewer.Dock = DockStyle.Fill
        NewTab.Controls.Add(NewViewer)
        MasterTabControl.TabPages.Add(NewTab)
        MasterTabControl.SelectedTab = NewTab

        MasterStatusLabel.Text = "Loaded GenBank file. Errors: " & ErrorCounter '"Loaded " & SeqIDList.Count & " sequence(s). Errors: " & ErrorCounter
    End Sub

    Private Sub OpenMultyGenBank(ByVal File As String)
        Dim ErrorCounter As Integer = 0
        Dim DataList As List(Of String) = DataIO.ReadGBFile(File)

        Dim CurrentDataList As New List(Of String)
       
        Dim Counter As Integer = 0


        For i = 0 To DataList.Count - 1
            If DataList(i) = "//" Then

                Try

                    'Get information
                    Dim InfoData As FeatureData = DataIO.ReadStringListToInfo(CurrentDataList)

                    Dim SeqName As String = GetDataValueFromInfoData(InfoData, "DEFINITION")

                    If SeqName = "" Then
                        MsgBox("GenBank file lacks DEFINITION field!")
                        SeqName = "New_Seq" & Counter
                    End If

                    Dim Circular As Boolean = False
                    If GetDataValueFromInfoData(InfoData, "LOCUS").Contains("circular") Then
                        Circular = True
                    End If


                    'Get sequence
                    Dim CurrentSeq As String = DataIO.ReadStringListToSequence(CurrentDataList)

                    If Not CurrentSeq = "" Then


                        'Get features
                        Dim TableFound As Boolean = False

                        Dim StartReading As Boolean = False
                        Dim AnnotationStrings As New List(Of String)

                        For j = 0 To CurrentDataList.Count - 1

                            If CurrentDataList(j).StartsWith("ORIGIN") Then
                                StartReading = False
                            End If

                            If StartReading Then
                                AnnotationStrings.Add(CurrentDataList(j))
                            End If

                            If CurrentDataList(j).StartsWith("FEATURES") Then
                                StartReading = True
                            End If
                        Next j




                        Dim Features As List(Of Genome_Feature) = DataIO.ReadStringListToAnnotation(CurrentDataList)
                        Dim CodonTable As Short = 1

                        'Assign correct codon table for the sequence
                        For Each Feature As Genome_Feature In Features
                            If Not IsNothing(Feature.AdditionalProperties) Then
                                For j = 0 To Feature.AdditionalProperties.DataHeaders.Count - 1
                                    If Feature.AdditionalProperties.DataHeaders(j) = "transl_table" Then
                                        CodonTable = CType(Feature.AdditionalProperties.DataValues(j), Short)
                                        TableFound = True
                                        Exit For
                                    End If
                                Next j
                            End If
                            If TableFound Then
                                Exit For
                            End If
                        Next Feature


                        'Initialize browser
                        Dim NewViewer As New Genome_Viewer(CurrentSeq, SeqName, Features, InfoData, CodonTable, Circular)
                        Dim NewTab As New TabPage(SeqName)
                        NewViewer.Dock = DockStyle.Fill
                        NewTab.Controls.Add(NewViewer)
                        MasterTabControl.TabPages.Add(NewTab)
                        MasterTabControl.SelectedTab = NewTab
                        Counter += 1

                    Else

                        MsgBox("No sequence for: " & SeqName)

                        ErrorCounter += 1
                    End If 'Not CurrentSeq = ""


                Catch ex As Exception

                    MsgBox("Error parsing multysequence GenBank")

                    ErrorCounter += 1
                End Try


                CurrentDataList.Clear()

            Else

                CurrentDataList.Add(DataList(i))

            End If

        Next i




        MasterStatusLabel.Text = "Loaded GenBank file. Errors: " & ErrorCounter
    End Sub

    Public Sub OpenFile(ByVal File As String)

        Dim FilePathFolders As String() = File.Split("\")

        Dim FileNameWithExtension As String = FilePathFolders(FilePathFolders.GetUpperBound(0))
        Dim ExtensionPos As String = FileNameWithExtension.LastIndexOf(".")
        Dim FileName As String = FileNameWithExtension.Substring(0, ExtensionPos)
        Dim FileExtension As String = FileNameWithExtension.Substring(ExtensionPos)
        Dim FilePathAndNameWithoutExtension As String = File.Substring(0, File.LastIndexOf("."))

        Dim SearchSequenceExtensions As New List(Of String)
        SearchSequenceExtensions.Add(".fna")
        SearchSequenceExtensions.Add(".fasta")
        SearchSequenceExtensions.Add(".fa")
        SearchSequenceExtensions.Add(".fas")

        Dim SearchAnnotationExtensions As New List(Of String)
        SearchAnnotationExtensions.Add(".gff")
        SearchAnnotationExtensions.Add(".gff3")
        SearchAnnotationExtensions.Add(".annot")

        Dim SeqFile As String = ""
        Dim AnnotFile As String = ""
        Dim SeqFileType As String = ""
        Dim AnnotFileType As String = ""


        If FileExtension = ".fna" Or FileExtension = ".fasta" Or FileExtension = ".fa" Or FileExtension = ".fas" Then

            'All sequences are in more or less same FASTA format (formatting characters may be present and have to be removed then)

            SeqFile = File
            SeqFileType = FileExtension

            For Each FileType As String In SearchAnnotationExtensions
                If IO.File.Exists(FilePathAndNameWithoutExtension & FileType) Then

                    AnnotFile = FilePathAndNameWithoutExtension & FileType
                    AnnotFileType = FileType

                    Exit For
                End If
            Next FileType

            'FASTA may contain multiple sequences! Parse FASTA here

            If AnnotFileType = ".annot" Then 'Single fasta and own annotation

                OpenFastaAndAnnot(FileName, FilePathAndNameWithoutExtension, SeqFileType, AnnotFileType)

            ElseIf AnnotFileType = ".gff" Or AnnotFileType = ".gff3" Then 'Annotation file in GFF

                OpenFastaAndGFF(File, FilePathAndNameWithoutExtension & AnnotFileType)

            ElseIf AnnotFileType = "" Then 'No annotation file

                OpenFastaOnly(File)

            End If


        ElseIf FileExtension = ".annot" Then

            AnnotFile = File
            AnnotFileType = FileExtension

            For Each FileType As String In SearchSequenceExtensions
                If IO.File.Exists(FilePathAndNameWithoutExtension & FileType) Then

                    SeqFile = FilePathAndNameWithoutExtension & FileType
                    SeqFileType = FileType

                    Exit For
                End If
            Next FileType

            If Not SeqFileType = "" Then

                OpenFastaAndAnnot(FileName, FilePathAndNameWithoutExtension, SeqFileType, AnnotFileType)

            Else
                MsgBox("Sequence is missing!")
            End If

        ElseIf FileExtension = ".gff" Or FileExtension = ".gff3" Then

            AnnotFile = File
            AnnotFileType = FileExtension

            For Each FileType As String In SearchSequenceExtensions
                If IO.File.Exists(FilePathAndNameWithoutExtension & FileType) Then

                    SeqFile = FilePathAndNameWithoutExtension & FileType
                    SeqFileType = FileType

                    Exit For
                End If
            Next FileType

            If Not SeqFileType = "" Then

                OpenFastaAndGFF(FilePathAndNameWithoutExtension & SeqFileType, File)

            Else
                MsgBox("Sequence is missing!")
            End If


        ElseIf FileExtension = ".gb" Then

            'Scan GenBank if there is single or multiple sequences
            Dim FS As New IO.FileStream(File, IO.FileMode.Open, IO.FileAccess.Read)
            Dim Reader As New IO.StreamReader(FS)
            Dim CurrentLine As String = ""
            Dim Counter As Integer = 0

            While Reader.Peek > -1

                CurrentLine = Reader.ReadLine()
                If CurrentLine.Contains("ORIGIN") Then
                    Counter += 1
                End If

                If Counter > 1 Then
                    Exit While
                End If

            End While


            Reader.Close()
            FS.Close()
            Reader.Dispose()
            FS.Dispose()


            If Counter > 1 Then
                OpenMultyGenBank(File)
            Else
                OpenGenBank(File)
            End If



        ElseIf FileExtension = ".txt" Then

            Dim FS As New IO.FileStream(File, IO.FileMode.Open, IO.FileAccess.Read)
            Dim Reader As New IO.StreamReader(FS)
            Dim FirstLine As String = Reader.ReadLine()
            Reader.Close()
            FS.Close()
            Reader.Dispose()
            FS.Dispose()

            If FirstLine.StartsWith(">") Then
                Try
                    OpenFastaOnly(File)
                Catch ex As Exception
                    MsgBox("Attempted to read TXT file as FASTA!" & vbNewLine & ex.Message)
                End Try
            ElseIf FirstLine.StartsWith("LOCUS") Then
                'Try
                OpenGenBank(File)
                'Catch ex As Exception
                'MsgBox("Attempted to read TXT file as GenBank!" & vbNewLine & ex.Message)
                'End Try
            End If

        Else

            MsgBox("Unknown file format!")

        End If 'FileExtension


    End Sub

    Public Sub OpenAnnotation(ByVal FileName As String, ByVal Viewer As Genome_Viewer)
        Dim FileArray_AssemblyName As String() = FileName.Split("\")
        Dim AssemblyName As String = FileArray_AssemblyName(FileArray_AssemblyName.GetUpperBound(0))

        Dim NewList As New FeaturesAssembly
        NewList.AssemblyName = AssemblyName
        NewList.Visible = True
        NewList.FeaturesList = DataIO.ReadAnnotationData(FileName, AssemblyName)
        Viewer.Features_Groups_List.Add(NewList)

        Viewer.FeaturesGroupsListBox.Items.Add(AssemblyName)
        Viewer.FeaturesGroupsListBox.Items(Viewer.FeaturesGroupsListBox.Items.Count - 1).Checked = True

    End Sub

    Private Sub SaveNewFile(ByVal CurrentGenomeViewer As Genome_Viewer)

        If SaveFileOptions.ShowDialog = Windows.Forms.DialogResult.OK Then

            If SaveFileOptions.AnnotRadioButton.Checked Then

                Dim AdditionalData As FeatureData = Nothing

                For Each Row As DataGridViewRow In CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows

                    If Not Row.Cells(0).Value = "" Then

                        If IsNothing(AdditionalData) Then
                            AdditionalData = New FeatureData
                            AdditionalData.DataHeaders.Add(Row.Cells(0).Value)
                            AdditionalData.DataValues.Add(Row.Cells(1).Value)
                        Else
                            AdditionalData.DataHeaders.Add(Row.Cells(0).Value)
                            AdditionalData.DataValues.Add(Row.Cells(1).Value)
                        End If

                    End If

                Next Row


                DataIO.WriteAnnotationFull(CurrentGenomeViewer.Features_Groups_List(0).FeaturesList, SaveFileDialog.FileName, CurrentGenomeViewer.GenomeTopology, CurrentGenomeViewer.Genetic_Code, CurrentGenomeViewer.Comment, , , True, AdditionalData)
                DataIO.WriteSequence(CurrentGenomeViewer.Genome_Sequence & vbNewLine, SaveFileDialog.FileName, CurrentGenomeViewer.Fasta_Header)

                CurrentGenomeViewer.File_Name = SaveFileDialog.FileName
                Dim FileArray As String() = SaveFileDialog.FileName.Split("\")
                MasterTabControl.SelectedTab.Text = FileArray(FileArray.GetUpperBound(0))
                CurrentGenomeViewer.Save_Required = False

            ElseIf SaveFileOptions.ShortAnnotRadioButton.Checked Then

                DataIO.WriteAnnotation(CurrentGenomeViewer.Features_Groups_List(0).FeaturesList, SaveFileDialog.FileName, CurrentGenomeViewer.GenomeTopology, CurrentGenomeViewer.Genetic_Code, CurrentGenomeViewer.Comment)
                DataIO.WriteSequence(CurrentGenomeViewer.Genome_Sequence & vbNewLine, SaveFileDialog.FileName, CurrentGenomeViewer.Fasta_Header)

                CurrentGenomeViewer.File_Name = SaveFileDialog.FileName
                Dim FileArray As String() = SaveFileDialog.FileName.Split("\")
                MasterTabControl.SelectedTab.Text = FileArray(FileArray.GetUpperBound(0))
                CurrentGenomeViewer.Save_Required = False

            ElseIf SaveFileOptions.GFFRadioButton.Checked Then
                MsgBox("Disabled!")
            ElseIf SaveFileOptions.GBRadioButton.Checked Then 'GB file

                Dim SeqName As String = CurrentGenomeViewer.Control_Box.SeqNameTextBox.Text
                Dim Locus As String = "Undefined"
                Dim Source As String = ""
                Dim Organism As String = ""
                Dim Accession As String = ""
                Dim Version As String = ""
                Dim DBlink As String = ""
                Dim Keywords As String = ""
                Dim Comment As String = CurrentGenomeViewer.Control_Box.CommentTextBox.Text

                For i = 0 To CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows.Count - 2
                    If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "DEFINITION" Or _
                    CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "definition" Or _
                    CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "Definition" Then
                        SeqName = CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(1).Value.ToString
                    End If

                    If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "LOCUS" Or _
                    CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "locus" Or _
                    CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "Locus" Then
                        Locus = CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(1).Value.ToString
                    End If

                    If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "SOURCE" Or _
                   CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "source" Or _
                   CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "Source" Then
                        Source = CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(1).Value.ToString
                    End If

                    If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "ORGANISM" Or _
                  CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "organism" Or _
                  CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "Organism" Then
                        Organism = CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(1).Value.ToString
                    End If

                    If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "ACCESSION" Or _
                    CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "accession" Or _
                    CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "Accession" Then
                        Accession = CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(1).Value.ToString
                    End If

                    If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "VERSION" Or _
                    CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "version" Or _
                    CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "Version" Then
                        Version = CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(1).Value.ToString
                    End If

                    If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "DBLINK" Or _
                    CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "dblink" Then
                        DBlink = CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(1).Value.ToString
                    End If

                    If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "KEYWORDS" Or _
                    CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "keywords" Or _
                    CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "Keywords" Then
                        Keywords = CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(1).Value.ToString
                    End If

                    If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "COMMENT" Or _
                    CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "comment" Or _
                    CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "Comment" Then
                        Comment = CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(1).Value.ToString
                    End If

                Next i

                Dim RefData As String = ""
                Dim LocalRefData As String = "Unknown"
                Dim LocalJournal As String = "Unknown"
                Dim LocalAuthor As String = "Unknown"
                Dim LocalTitle As String = "Unknown"
                Dim LocalID As String = ""
                Dim LocalRem As String = ""


                For i = 0 To CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows.Count - 2
                    If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(0).Value.ToString = "REFERENCE" Then

                        LocalRefData = "REFERENCE   " & CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(i).Cells(1).Value.ToString


                        For j = i + 1 To CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows.Count - 2

                            If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(j).Cells(0).Value.ToString = "REFERENCE" Then
                                Exit For
                            End If

                            If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(j).Cells(0).Value.ToString = "AUTHORS" Then
                                LocalAuthor = "  AUTHORS   " & DataIO.FormatStringForGB(CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(j).Cells(1).Value.ToString, , 1)
                            End If

                            If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(j).Cells(0).Value.ToString = "TITLE" Then
                                LocalTitle = "  TITLE     " & DataIO.FormatStringForGB(CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(j).Cells(1).Value.ToString, , 1)
                            End If

                            If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(j).Cells(0).Value.ToString = "JOURNAL" Then
                                LocalJournal = "  JOURNAL   " & DataIO.FormatStringForGB(CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(j).Cells(1).Value.ToString, , 1)
                            End If

                            If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(j).Cells(0).Value.ToString = "PUBMED" Then
                                LocalID = "   PUBMED   " & DataIO.FormatStringForGB(CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(j).Cells(1).Value.ToString, , 1)
                            End If

                            If CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(j).Cells(0).Value.ToString = "REMARK" Then
                                LocalRem = "  REMARK    " & DataIO.FormatStringForGB(CurrentGenomeViewer.Control_Box.InfoDataGridView.Rows(j).Cells(1).Value.ToString, , 1)
                            End If

                        Next j


                        RefData &= LocalRefData & vbNewLine & LocalAuthor & vbNewLine & LocalTitle & vbNewLine

                        If Not LocalID = "" Then
                            RefData &= LocalID & vbNewLine
                            LocalID = ""
                        End If

                        If Not LocalRem = "" Then
                            RefData &= LocalRem & vbNewLine
                            LocalRem = ""
                        End If

                    End If


                Next i


                DataIO.WriteGBFormat(SaveFileDialog.FileName, CurrentGenomeViewer.Features_Groups_List(0).FeaturesList, CurrentGenomeViewer.Genome_Sequence, CurrentGenomeViewer.GenomeTopology, CurrentGenomeViewer.Genetic_Code, SeqName, Locus, Source, Organism, Accession, Version, DBlink, Keywords, Comment, RefData)

            ElseIf SaveFileOptions.FastaOnlyRadioButton.Checked Then

                DataIO.WriteSequence(CurrentGenomeViewer.Genome_Sequence & vbNewLine, SaveFileDialog.FileName, CurrentGenomeViewer.Fasta_Header)

            End If


        End If




    End Sub

    Private Sub SaveExistingFile(ByVal CurrentGenomeViewer As Genome_Viewer)
        DataIO.WriteAnnotation(CurrentGenomeViewer.Features_Groups_List(0).FeaturesList, CurrentGenomeViewer.File_Name, CurrentGenomeViewer.GenomeTopology, CurrentGenomeViewer.Genetic_Code, CurrentGenomeViewer.Comment)
        DataIO.WriteSequence(CurrentGenomeViewer.Genome_Sequence & vbNewLine, CurrentGenomeViewer.File_Name, CurrentGenomeViewer.Fasta_Header)
        CurrentGenomeViewer.Save_Required = False
    End Sub

#End Region

#Region "Tab control"

    Private Function CheckSave(ByVal CurrentTab As TabPage)
        Dim AllowClosing As Boolean = True

        For Each Component As Control In CurrentTab.Controls  'MasterTabControl.SelectedTab
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component
                If CurrentGenomeViewer.Save_Required Then

                    Dim SaveDialogResult As Microsoft.VisualBasic.MsgBoxResult = MsgBox("Annotation was changed, save it?", MsgBoxStyle.YesNoCancel, "Save")


                    If SaveDialogResult = MsgBoxResult.Yes Then
                        If Not CurrentGenomeViewer.File_Name = "" Then
                            DataIO.WriteAnnotation(CurrentGenomeViewer.Features_Groups_List(0).FeaturesList, CurrentGenomeViewer.File_Name, CurrentGenomeViewer.GenomeTopology, CurrentGenomeViewer.Genetic_Code, CurrentGenomeViewer.Comment)
                            DataIO.WriteSequence(CurrentGenomeViewer.Genome_Sequence, CurrentGenomeViewer.File_Name, CurrentGenomeViewer.Fasta_Header)
                        Else
                            If SaveFileDialog.ShowDialog() = Windows.Forms.DialogResult.OK Then
                                DataIO.WriteAnnotation(CurrentGenomeViewer.Features_Groups_List(0).FeaturesList, SaveFileDialog.FileName, CurrentGenomeViewer.GenomeTopology, CurrentGenomeViewer.Genetic_Code, CurrentGenomeViewer.Comment)
                                DataIO.WriteSequence(CurrentGenomeViewer.Genome_Sequence, SaveFileDialog.FileName, CurrentGenomeViewer.Fasta_Header)
                            End If
                        End If


                    ElseIf SaveDialogResult = MsgBoxResult.Cancel Then
                        AllowClosing = False
                    End If

                    Exit For
                End If
            End If
        Next

        Return AllowClosing
    End Function

    Private Sub CheckMenu()

        If MasterTabControl.TabPages.Count = 0 Then
            ViewToolStripMenuItem.Enabled = False
            EditToolStripMenuItem.Enabled = False
            FeaturesToolStripMenuItem.Enabled = False
            QuantitationToolStripMenuItem.Enabled = False

            ExpectWordCount_ToolStripMenuItem.Enabled = False
            KmerStatisticsToolStripMenuItem.Enabled = False
            ArrayDesign_ToolStripMenuItem.Enabled = False
            IdentifyPromotersToolStripMenuItem.Enabled = False
            FindPWMToolStripMenuItem.Enabled = False

            CodonUsageToolStripMenuItem.Enabled = False
            SyntheticBiologyToolStripMenuItem.Enabled = False

        Else
            ViewToolStripMenuItem.Enabled = True
            EditToolStripMenuItem.Enabled = True
            FeaturesToolStripMenuItem.Enabled = True
            QuantitationToolStripMenuItem.Enabled = True

            ExpectWordCount_ToolStripMenuItem.Enabled = True
            KmerStatisticsToolStripMenuItem.Enabled = True
            ArrayDesign_ToolStripMenuItem.Enabled = True
            IdentifyPromotersToolStripMenuItem.Enabled = True
            FindPWMToolStripMenuItem.Enabled = True

            CodonUsageToolStripMenuItem.Enabled = True
            SyntheticBiologyToolStripMenuItem.Enabled = True

        End If


    End Sub

    Private Sub MasterTabControl_ControlAdded(ByVal sender As Object, ByVal e As System.Windows.Forms.ControlEventArgs) Handles MasterTabControl.ControlAdded
        CheckMenu()
    End Sub

    Private Sub MasterTabControl_DrawItem(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DrawItemEventArgs) Handles MasterTabControl.DrawItem
        Try

            Dim CurrentTab As TabPage = MasterTabControl.TabPages(e.Index)
            Dim CurrentRect As Rectangle = MasterTabControl.GetTabRect(e.Index)

            Dim IconRect As New Rectangle
            IconRect.Size = New Size(16, 16)
            IconRect.Location = New Point(CurrentRect.Right - 16, CurrentRect.Top + 3)

            If MasterTabControl.SelectedIndex = e.Index Then
                e.Graphics.FillRectangle(Brushes.LightGreen, CurrentRect)
            End If


            Dim StringSize As SizeF = e.Graphics.MeasureString(CurrentTab.Text, CurrentTab.Font)
            Dim DrawString As String = ""

            If StringSize.Width > MasterTabControl.ItemSize.Width Then
                Dim AverageCharL As Single = StringSize.Width / CurrentTab.Text.Length
                Dim ExtraL As Single = StringSize.Width - MasterTabControl.ItemSize.Width
                Dim ExtraCharNum As Short = Math.Ceiling(ExtraL / AverageCharL)

                If CurrentTab.Text.Contains("[View*]") Then
                    DrawString = CurrentTab.Text.Substring(0, CurrentTab.Text.Length - ExtraCharNum - 13) & "... [View*]"
                ElseIf CurrentTab.Text.Contains("[2D*]") Then
                    DrawString = CurrentTab.Text.Substring(0, CurrentTab.Text.Length - ExtraCharNum - 11) & "... [2D*]"
                ElseIf CurrentTab.Text.Contains("[View]") Then
                    DrawString = CurrentTab.Text.Substring(0, CurrentTab.Text.Length - ExtraCharNum - 12) & "... [View]"
                ElseIf CurrentTab.Text.Contains("[2D]") Then
                    DrawString = CurrentTab.Text.Substring(0, CurrentTab.Text.Length - ExtraCharNum - 10) & "... [2D]"
                Else
                    DrawString = CurrentTab.Text.Substring(0, CurrentTab.Text.Length - ExtraCharNum - 5) & "..."
                End If

            Else
                DrawString = CurrentTab.Text
            End If

            e.Graphics.DrawString(DrawString, CurrentTab.Font, Brushes.Black, CurrentRect.Left + 3, CurrentRect.Top + 3)

            e.Graphics.DrawIcon(My.Resources.Symbol_Delete, IconRect)

        Catch ex As Exception
            ' MsgBox(InitTabIndex & vbNewLine & CurrentTabIndex & vbNewLine & ex.Message)
        End Try

    End Sub

    Private Sub MasterTabControl_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MasterTabControl.MouseDown
        InitMouseRect = Nothing
        InitMousePoint = Nothing

        For i = 0 To MasterTabControl.TabPages.Count - 1
            Dim CurrentRect As Rectangle = MasterTabControl.GetTabRect(i)


            'Check if close button is pressed
            Dim IconRect As New Rectangle

            IconRect.Size = New Size(16, 16)
            IconRect.Location = New Point(CurrentRect.Right - 16, CurrentRect.Top + 3)


            If IconRect.Contains(e.X, e.Y) Then
                If CheckSave(MasterTabControl.SelectedTab) = False Then
                    Exit Sub
                End If

                MasterTabControl.TabPages.RemoveAt(i)
                CheckMenu()
                Exit Sub
            End If

            'Else check if Drag-Drop is initiated
            'InitMousePoint

            If CurrentRect.Contains(e.X, e.Y) Then
                InitMouseRect = CurrentRect
                InitMousePoint = e.Location
                InitTabIndex = i
                Exit Sub
            End If

        Next

    End Sub

    Private Sub MasterTabControl_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MasterTabControl.MouseUp

        If Not IsNothing(InitMousePoint) Then
            Try

           
                If Not InitMouseRect.Contains(e.Location) Then

                    For i = 0 To MasterTabControl.TabPages.Count - 1
                        Dim CurrentRect As Rectangle = MasterTabControl.GetTabRect(i)
                        If CurrentRect.Contains(e.X, e.Y) Then

                            

                            Dim TmpPage As TabPage = MasterTabControl.TabPages(InitTabIndex)
                            MasterTabControl.TabPages.RemoveAt(InitTabIndex)
                            MasterTabControl.TabPages.Insert(i, TmpPage)
                            MasterTabControl.SelectTab(i)


                            CurrentTabIndex = i


                            Exit Sub
                        End If
                    Next
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub Master_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        For Each MyTabPage As TabPage In MasterTabControl.TabPages
            If CheckSave(MyTabPage) = False Then
                e.Cancel = True
            End If
        Next


    End Sub

#End Region

#Region "File menu"

    Private Sub NewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripMenuItem.Click

        TextInputBox.Text = "Enter new sequence(s) (FASTA format)"
        If TextInputBox.ShowDialog = Windows.Forms.DialogResult.OK Then

            If Not TextInputBox.SeqTextBox.Text = "" Then

                If TextInputBox.SeqTextBox.Text.IndexOf(">") = -1 Then 'Single sequence not in fasta

                    Dim Seq As String = TextInputBox.SeqTextBox.Text
                    Dim Header As String = "Unnamed sequence"

                    Seq = Seq.Replace(Chr(10), "")
                    Seq = Seq.Replace(Chr(13), "")
                    Seq = Seq.Replace(" ", "")
                    Seq = Seq.ToUpper

                    Dim NewTab As New TabPage(Header)
                    Dim NewViewer As New Genome_Viewer(Seq, Header)
                    NewViewer.Dock = DockStyle.Fill
                    NewTab.Controls.Add(NewViewer)
                    MasterTabControl.TabPages.Add(NewTab)
                    MasterTabControl.SelectedTab = NewTab

                Else 'Fasta or multifasta

                    Dim HeaderList As New List(Of String)
                    Dim SeqList As New List(Of String)

                    Static Counter As Integer = 1

                    ParseFasta(TextInputBox.SeqTextBox.Text, HeaderList, SeqList)

                    Dim Header As String = ""
                    Dim Seq As String = ""

                    For i = 0 To HeaderList.Count - 1

                        Header = HeaderList(i)
                        Header = Header.Replace(Chr(10), "")
                        Header = Header.Replace(Chr(13), "")

                        If Header = "" Or Header = " " Then
                            Header = "New sequence " & Counter
                            Counter += 1
                        End If

                        Seq = SeqList(i)
                        Seq = Seq.Replace(Chr(10), "")
                        Seq = Seq.Replace(Chr(13), "")
                        Seq = Seq.Replace(" ", "")
                        Seq = Seq.ToUpper

                        Dim NewTab As New TabPage(Header)
                        Dim NewViewer As New Genome_Viewer(Seq, Header)
                        NewViewer.Dock = DockStyle.Fill
                        NewTab.Controls.Add(NewViewer)
                        MasterTabControl.TabPages.Add(NewTab)
                        MasterTabControl.SelectedTab = NewTab

                    Next i

                End If 'TextInputBox.SeqTextBox.Text.IndexOf(">") = -1

            Else
                MsgBox("Enter some sequence!")
            End If 'Not TextInputBox.SeqTextBox.Text = ""

        End If 'TextInputBox.Result = True

    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click
        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            For Each File As String In OpenFileDialog.FileNames
                Try
                    OpenFile(File)
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try

            Next
        End If
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveAsToolStripMenuItem.Click
        Try

            For Each Component As Control In MasterTabControl.SelectedTab.Controls

                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component

                    Do
                        If SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
                            If Not IO.File.Exists(SaveFileDialog.FileName & ".fasta") Then

                                SaveNewFile(CurrentGenomeViewer)

                                Exit Do
                                Exit For

                            Else

                                If MsgBox(SaveFileDialog.FileName & ".fasta already exists! " & "Replace file?", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then

                                    SaveNewFile(CurrentGenomeViewer)

                                    Exit Do
                                    Exit For

                                End If

                            End If
                        Else
                            Exit Do
                            Exit For
                        End If
                    Loop

                End If
            Next Component

        Catch ex As Exception
            MsgBox("Save as Error!" & ex.Message)
        End Try
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component

                    If CurrentGenomeViewer.File_Name = "" Then

                        Do
                            If SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

                                If Not IO.File.Exists(SaveFileDialog.FileName & ".fasta") Then

                                    SaveNewFile(CurrentGenomeViewer)

                                    Exit Do
                                    Exit For
                                Else
                                    If MsgBox(SaveFileDialog.FileName & ".fasta already exists! " & "Replace file?", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then

                                        SaveNewFile(CurrentGenomeViewer)

                                        Exit Do
                                        Exit For
                                    End If
                                End If

                            Else
                                Exit Do
                                Exit For
                            End If
                        Loop

                    Else

                        SaveExistingFile(CurrentGenomeViewer)

                        Exit For
                    End If

                    Exit For
                End If
            Next
        Catch ex As Exception
            MsgBox("Save error! " & ex.Message)
        End Try



    End Sub

    Private Sub MergeGBToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MergeGBToolStripMenuItem.Click
        MergeGB_Master.Show()
    End Sub

#End Region

#Region "Edit menu"
    Private Sub UndoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UndoToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component
                CurrentGenomeViewer.Undo()

                Exit For
            End If
        Next
    End Sub


    Private Sub FindDataToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindDataToolStripMenuItem.Click
        MetaSearch.Show()

    End Sub

    Private Sub FindTabToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindTabToolStripMenuItem.Click
        If SystemTextBox.DialogReturn = 1 Then

            For i = 0 To MasterTabControl.TabPages.Count - 1
                If MasterTabControl.TabPages(i).Text.Contains(SystemTextBox.InputTextBox.Text) Then
                    MasterTabControl.SelectTab(i)
                    Exit For
                End If
            Next i

        End If
    End Sub

    Private Sub ReloadDataTablesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReloadDataTablesToolStripMenuItem.Click
        LoadData()
    End Sub

#End Region

#Region "View menu"

    Private Sub MultilineTabsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MultilineTabsToolStripMenuItem.Click

        MasterTabControl.Multiline = MultilineTabsToolStripMenuItem.Checked
       
    End Sub

    Private Sub CircularViewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CircularViewToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component
                    CurrentGenomeViewer.CreateGenomicView()
                End If
            Next
        Catch ex As Exception
            MsgBox("Genome viewer call error! " & ex.Message)
        End Try
    End Sub

    Private Sub MapByFeatureIDToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MapByFeatureIDToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component
                    Dim MapIDList As New List(Of String)

                    If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
                        Dim ReadStream As New IO.FileStream(OpenFileDialog.FileName, IO.FileMode.Open)
                        Dim Reader As New IO.StreamReader(ReadStream)

                        While Reader.Peek > -1
                            MapIDList.Add(Reader.ReadLine)
                        End While

                        Reader.Close()
                        ReadStream.Close()
                        Reader.Dispose()
                        ReadStream.Dispose()

                    End If

                    Dim DisplayFeatures As New List(Of Genome_Feature)
                    For Each ID As String In MapIDList
                        For Each Feature As Genome_Feature In CurrentGenomeViewer.Features_Groups_List(0).FeaturesList
                            If Feature.TAG = ID Then
                                CurrentGenomeViewer.ShowTopology(Feature)
                                Exit For
                            End If
                        Next
                    Next


                    Exit For
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
    End Sub

    Private Sub InSilico2DEF_ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InSilico2DEF_ToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component
                    CurrentGenomeViewer.CreateProteomicsView()
                End If
            Next
        Catch ex As Exception
            MsgBox("Genome viewer call error! " & ex.Message)
        End Try
    End Sub

    Private Sub GCContentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GCContentToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component

                Static N As Integer = 0

                SystemProgressBarBox.Show()
                SystemProgressBarBox.Focus()

                Dim WindowL As Integer = 100
                SystemTextBox.InputTextBox.Text = WindowL
                If SystemTextBox.DialogReturn = 1 Then
                    WindowL = CType(SystemTextBox.InputTextBox.Text, Integer)
                Else
                    Exit Sub
                End If

                Dim Data As Integer() = Bioinformatics.CalculateGCDistribution(CurrentGenomeViewer.Genome_Sequence, WindowL, CurrentGenomeViewer.GenomeTopology, False, SystemProgressBarBox)

                Dim Values As New List(Of Integer)
                For Each V As Integer In Data
                    Values.Add(V)
                Next

                Dim NewPosHolderName As String = "GC-content " & N

                Dim NewPositionalHolder As New PositionalValuesHolder(NewPosHolderName, 1, Values, Color.Black, 0)
                NewPositionalHolder.Visible = True

                CurrentGenomeViewer.Positional_Values_Collection.Add(NewPositionalHolder)

                CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Add(NewPositionalHolder.Visible, NewPosHolderName, "Plus", "", "Linear", NewPositionalHolder.Group)
                CurrentGenomeViewer.PositionalValuesDataGridView.Rows(CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = Color.Black

                SystemProgressBarBox.Close()


            End If
        Next Component
    End Sub

    Private Sub GCSkew_ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GCSkew_ToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component

                Static N As Integer = 0

                SystemProgressBarBox.Show()
                SystemProgressBarBox.Focus()


                Dim Data As Integer() = Bioinformatics.CalculateGCSkew(CurrentGenomeViewer.Genome_Sequence, , CurrentGenomeViewer.GenomeTopology, SystemProgressBarBox, )

                Dim Values As New List(Of Integer)
                For Each V As Integer In Data
                    Values.Add(V)
                Next

                Dim NewPosHolderName As String = "GC-skew " & N

                Dim NewPositionalHolder As New PositionalValuesHolder(NewPosHolderName, 1, Values, Color.Black, 0)
                NewPositionalHolder.Visible = True

                CurrentGenomeViewer.Positional_Values_Collection.Add(NewPositionalHolder)

                CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Add(NewPositionalHolder.Visible, NewPosHolderName, "Plus", "", "Linear", NewPositionalHolder.Group)
                CurrentGenomeViewer.PositionalValuesDataGridView.Rows(CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = Color.Black

                SystemProgressBarBox.Close()


            End If
        Next Component
    End Sub

    Private Sub ATSkew_ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ATSkew_ToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component

                Static N As Integer = 0

                SystemProgressBarBox.Show()
                SystemProgressBarBox.Focus()

                Dim Smooting As Integer = 100

                SystemTextBox.Text = "Sliding window"
                SystemTextBox.InputTextBox.Text = Smooting

                If SystemTextBox.DialogReturn = 1 Then
                    Smooting = SystemTextBox.InputTextBox.Text
                End If


                Dim Data As Integer() = Bioinformatics.CalculateGCSkew(CurrentGenomeViewer.Genome_Sequence, Smooting, CurrentGenomeViewer.GenomeTopology, SystemProgressBarBox, False)

                Dim Values As New List(Of Integer)
                For Each V As Integer In Data
                    Values.Add(V)
                Next

                Dim NewPosHolderName As String = "AT-skew " & N

                Dim NewPositionalHolder As New PositionalValuesHolder(NewPosHolderName, 1, Values, Color.Black, 0)
                NewPositionalHolder.Visible = True

                CurrentGenomeViewer.Positional_Values_Collection.Add(NewPositionalHolder)

                CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Add(NewPositionalHolder.Visible, NewPosHolderName, "Plus", "", "Linear", NewPositionalHolder.Group)
                CurrentGenomeViewer.PositionalValuesDataGridView.Rows(CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = Color.Black

                SystemProgressBarBox.Close()


            End If
        Next Component
    End Sub

    Private Sub DGDistributionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DGDistributionToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component

                Dim Values As List(Of Integer) = Bioinformatics.GetStructureDistribution(CurrentGenomeViewer.Genome_Sequence, 15, CurrentGenomeViewer.GenomeTopology, 37, 100, SystemProgressBarBox)

                PositionalValuesChartControl.NameTextBox.Text = "dG_distr_func"
                PositionalValuesChartControl.ColorPanel.BackColor = Color.Black
                PositionalValuesChartControl.StrandComboBox.Text = "Plus"
                PositionalValuesChartControl.ScaleComboBox.Text = "Linear"

                Dim Strand As Short = 0
                Dim Scale As Short = 0

                If PositionalValuesChartControl.ShowDialog = DialogResult.OK Then


                    Select Case PositionalValuesChartControl.StrandComboBox.Text
                        Case "Plus"
                            Strand = 1
                        Case "Minus"
                            Strand = 2
                        Case "Undetermined"
                            Strand = 0
                    End Select


                    Select Case PositionalValuesChartControl.ScaleComboBox.Text
                        Case "Logarithm"
                            Scale = 1
                        Case "Linear"
                            Scale = 0
                    End Select

                Else
                    Exit Sub
                End If



                Dim NewPositionalHolder As New PositionalValuesHolder(PositionalValuesChartControl.NameTextBox.Text, Strand, Values, PositionalValuesChartControl.ColorPanel.BackColor, Scale)
                NewPositionalHolder.Visible = PositionalValuesChartControl.VisibleCheckBox.Checked

                CurrentGenomeViewer.Control_Box.SkewOnRadioButton.Checked = True

                CurrentGenomeViewer.Positional_Values_Collection.Add(NewPositionalHolder)

                CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Add(NewPositionalHolder.Visible, PositionalValuesChartControl.NameTextBox.Text, PositionalValuesChartControl.StrandComboBox.Text, "", PositionalValuesChartControl.ScaleComboBox.Text, NewPositionalHolder.Group)
                CurrentGenomeViewer.PositionalValuesDataGridView.Rows(CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = PositionalValuesChartControl.ColorPanel.BackColor


                Exit For
            End If
        Next Component
    End Sub

    Private Sub PolyTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PolyTToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component

                Dim ValuesT As List(Of Integer) = Bioinformatics.GetPolyNDistribution(CurrentGenomeViewer.Genome_Sequence, 5, CurrentGenomeViewer.GenomeTopology, "T", 500, SystemProgressBarBox)

                PositionalValuesChartControl.NameTextBox.Text = "PolyT_score_plus"
                PositionalValuesChartControl.ColorPanel.BackColor = Color.Black
                PositionalValuesChartControl.StrandComboBox.Text = "Plus"
                PositionalValuesChartControl.ScaleComboBox.Text = "Linear"

                Dim Strand As Short = 1
                Dim Scale As Short = 0

                Dim NewPositionalHolderT As New PositionalValuesHolder(PositionalValuesChartControl.NameTextBox.Text, Strand, ValuesT, PositionalValuesChartControl.ColorPanel.BackColor, Scale)
                NewPositionalHolderT.Visible = PositionalValuesChartControl.VisibleCheckBox.Checked

                CurrentGenomeViewer.Control_Box.SkewOnRadioButton.Checked = True

                CurrentGenomeViewer.Positional_Values_Collection.Add(NewPositionalHolderT)

                CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Add(NewPositionalHolderT.Visible, PositionalValuesChartControl.NameTextBox.Text, PositionalValuesChartControl.StrandComboBox.Text, "", PositionalValuesChartControl.ScaleComboBox.Text, NewPositionalHolderT.Group)
                CurrentGenomeViewer.PositionalValuesDataGridView.Rows(CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = PositionalValuesChartControl.ColorPanel.BackColor



                Dim ValuesA As List(Of Integer) = Bioinformatics.GetPolyNDistribution(CurrentGenomeViewer.Genome_Sequence, 5, CurrentGenomeViewer.GenomeTopology, "A", 500, SystemProgressBarBox)

                PositionalValuesChartControl.NameTextBox.Text = "PolyT_score_minus"
                PositionalValuesChartControl.ColorPanel.BackColor = Color.Black
                PositionalValuesChartControl.StrandComboBox.Text = "Plus"
                PositionalValuesChartControl.ScaleComboBox.Text = "Linear"

                Strand = 2
               
                Dim NewPositionalHolderA As New PositionalValuesHolder(PositionalValuesChartControl.NameTextBox.Text, Strand, ValuesA, PositionalValuesChartControl.ColorPanel.BackColor, Scale)
                NewPositionalHolderA.Visible = PositionalValuesChartControl.VisibleCheckBox.Checked

                CurrentGenomeViewer.Control_Box.SkewOnRadioButton.Checked = True

                CurrentGenomeViewer.Positional_Values_Collection.Add(NewPositionalHolderA)

                CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Add(NewPositionalHolderA.Visible, PositionalValuesChartControl.NameTextBox.Text, PositionalValuesChartControl.StrandComboBox.Text, "", PositionalValuesChartControl.ScaleComboBox.Text, NewPositionalHolderA.Group)
                CurrentGenomeViewer.PositionalValuesDataGridView.Rows(CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = PositionalValuesChartControl.ColorPanel.BackColor


                Exit For
            End If
        Next Component
    End Sub

    Private Sub ViewInBrowser6FToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewInBrowserToolStripMenuItem1.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component
                    Dim CodeTable As DataTable = Bioinformatics.GetTranslationTable(CurrentGenomeViewer.Control_Box.TransComboBox.Text.Split("-")(0))
                    CurrentGenomeViewer.TranslationList6Frame = Bioinformatics.Make6FrameTranslation(CurrentGenomeViewer.Genome_Sequence, CodeTable, CurrentGenomeViewer.GenomeTopology, True, True, SystemProgressBarBox)
                    CurrentGenomeViewer.Control_Box.TranslationOnButton.Checked = True
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Export6FToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Export6FToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component

                    If SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

                        Dim FS As New IO.FileStream(SaveFileDialog.FileName, IO.FileMode.Create)
                        Dim Writer As New IO.StreamWriter(FS)
                        Dim CurrentTranslationTable As DataTable = Bioinformatics.GetTranslationTable(CurrentGenomeViewer.Control_Box.TransComboBox.Text.Split("-")(0))


                        Dim Frame1_AAF As String = Bioinformatics.Translate(CurrentGenomeViewer.Genome_Sequence, CurrentTranslationTable)
                        Dim Prot_1F As String() = Frame1_AAF.Split("*")
                        For Each Prot As String In Prot_1F
                            Writer.WriteLine(Prot & Chr(9) & "Frame_1F")
                        Next Prot

                        Dim Frame2_NNF As String = CurrentGenomeViewer.Genome_Sequence.Substring(1)
                        Dim Frame2_AAF As String = Bioinformatics.Translate(Frame2_NNF, CurrentTranslationTable)
                        Dim Prot_2F As String() = Frame2_AAF.Split("*")
                        For Each Prot As String In Prot_2F
                            Writer.WriteLine(Prot & Chr(9) & "Frame_2F")
                        Next Prot

                        Dim Frame3_NNF As String = CurrentGenomeViewer.Genome_Sequence.Substring(2)
                        Dim Frame3_AAF As String = Bioinformatics.Translate(Frame3_NNF, CurrentTranslationTable)
                        Dim Prot_3F As String() = Frame3_AAF.Split("*")
                        For Each Prot As String In Prot_3F
                            Writer.WriteLine(Prot & Chr(9) & "Frame_3F")
                        Next Prot


                        Dim Frame1_NNR As String = Bioinformatics.GetReverseComplement(CurrentGenomeViewer.Genome_Sequence)
                        Dim Frame1_AAR As String = Bioinformatics.Translate(Frame1_NNR, CurrentTranslationTable)
                        Dim Prot_1R As String() = Frame1_AAR.Split("*")
                        For Each Prot As String In Prot_1R
                            Writer.WriteLine(Prot & Chr(9) & "Frame_1R")
                        Next Prot

                        Dim Frame2_NNR As String = Frame1_NNR.Substring(1)
                        Dim Frame2_AAR As String = Bioinformatics.Translate(Frame2_NNR, CurrentTranslationTable)
                        Dim Prot_2R As String() = Frame2_AAR.Split("*")
                        For Each Prot As String In Prot_2R
                            Writer.WriteLine(Prot & Chr(9) & "Frame_2R")
                        Next Prot

                        Dim Frame3_NNR As String = Frame1_NNR.Substring(2)
                        Dim Frame3_AAR As String = Bioinformatics.Translate(Frame3_NNR, CurrentTranslationTable)
                        Dim Prot_3R As String() = Frame3_AAR.Split("*")
                        For Each Prot As String In Prot_3R
                            Writer.WriteLine(Prot & Chr(9) & "Frame_3R")
                        Next Prot

                        Writer.Close()
                        FS.Close()
                        Writer.Dispose()
                        FS.Dispose()

                    End If



                End If
            Next Component

        Catch ex As Exception
            MsgBox("Genome viewer call error! " & ex.Message)
        End Try
    End Sub

    Private Sub CDSTranslationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CDSTranslationToolStripMenuItem.Click

        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component

                If CDSTranslationToolStripMenuItem.Checked Then

                    For Each Feature As Genome_Feature In CurrentGenomeViewer.Features_Groups_List(0).FeaturesList
                        If Feature.Type = 1 Then
                            Feature.SetTranslation(True, CurrentGenomeViewer.GetFeatureSequence(Feature), CurrentGenomeViewer.Control_Box.TransComboBox.Text.Split("-")(0))
                        End If

                    Next Feature

                Else

                    For Each Feature As Genome_Feature In CurrentGenomeViewer.Features_Groups_List(0).FeaturesList
                        If Feature.Type = 1 Then
                            Feature.SetTranslation(False)
                        End If

                    Next Feature

                End If

                CurrentGenomeViewer.DisplayFeatures()
                Exit For
            End If

        Next Component



        'For Each Component As Control In MasterTabControl.SelectedTab.Controls
        'If Component.GetType.Name = "Genome_Viewer" Then
        'Dim CurrentGenomeViewer As Genome_Viewer = Component

        'For Each Feature As Genome_Feature In CurrentGenomeViewer.Features_Groups_List(0).FeaturesList
        'If Feature.Type = 1 Then
        'Feature.SetTranslation(False)
        'End If

        'Next Feature

        'CurrentGenomeViewer.DisplayFeatures()
        'Exit For
        'End If
        'Next Component



    End Sub



#End Region

#Region "Annotation menu"

    Private Sub RBLASTToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RBLASTToolStripMenuItem1.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component
                    AlignmentSearchTool.MyGenomeViewer = CurrentGenomeViewer
                    AlignmentSearchTool.Text = AlignmentSearchTool.MyName & " - " & CurrentGenomeViewer.Parent.Text
                    AlignmentSearchTool.Show()
                    AlignmentSearchTool.Focus()
                End If
            Next
        Catch ex As Exception
            MsgBox("Genome viewer call error! " & ex.Message)
        End Try
    End Sub

    Private Sub FindORFsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindORFsToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component
                    ORF_Finder.MyGenomeViewer = CurrentGenomeViewer
                    ORF_Finder.Show()
                    ORF_Finder.Focus()
                End If
            Next
        Catch ex As Exception
            MsgBox("Genome viewer call error! " & ex.Message)
        End Try
    End Sub

    Private Sub FindHairpinsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindHairpinsToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component
                    HairpinFinder.MyViewer = CurrentGenomeViewer
                    HairpinFinder.Show()
                    HairpinFinder.Focus()

                End If
            Next
        Catch ex As Exception
            MsgBox("Genome viewer call error! " & ex.Message)
        End Try
    End Sub

    Private Sub FindRepeatsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindRepeatsToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component



                Repeat_finder.MyGenomeViewer = CurrentGenomeViewer
                Repeat_finder.Show()


                Exit For
            End If
        Next Component
    End Sub

    Private Sub FindSequencesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindSequencesToolStripMenuItem.Click
        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component
                    Dim Identity As Integer = 0
                    Select Case MsgBox("Map with 100% match? [No] = 90%", MsgBoxStyle.YesNoCancel)

                        Case MsgBoxResult.Yes
                            Identity = 100
                        Case MsgBoxResult.No
                            Identity = 90
                        Case MsgBoxResult.Cancel
                            Exit Sub
                    End Select


                    If OpenFileDialog.FileName.EndsWith(".fasta") Or OpenFileDialog.FileName.EndsWith(".fna") Or OpenFileDialog.FileName.EndsWith(".fas") Or OpenFileDialog.FileName.EndsWith(".fa") Then

                        Dim FS As New IO.FileStream(OpenFileDialog.FileName, IO.FileMode.Open)
                        Dim Reader As New IO.StreamReader(FS)
                        Dim CurrentSeq As String = ""

                        Dim Data As String = Reader.ReadToEnd


                        Dim Headers As New List(Of String)
                        Dim Sequences As New List(Of String)

                        ParseFasta(Data, Headers, Sequences)

                        For i = 0 To Headers.Count - 1

                            CurrentSeq = Sequences(i)
                            CurrentSeq = CurrentSeq.Replace(Chr(10), "")
                            CurrentSeq = CurrentSeq.Replace(Chr(13), "")

                            CurrentGenomeViewer.MapFeature(CurrentSeq, Identity, Headers(i), False)



                        Next i


                        Reader.Close()
                        FS.Close()
                        Reader.Dispose()
                        FS.Dispose()

                    Else
                        Dim FS As New IO.FileStream(OpenFileDialog.FileName, IO.FileMode.Open)
                        Dim Reader As New IO.StreamReader(FS)
                        Dim CurrentLine As String()

                        While Reader.Peek > -1
                            CurrentLine = Reader.ReadLine.Split(Chr(9))
                            CurrentGenomeViewer.MapFeature(CurrentLine(1), Identity, CurrentLine(0), False)
                        End While


                        Reader.Close()
                        FS.Close()
                        Reader.Dispose()
                        FS.Dispose()

                    End If



                End If

            Next Component
        End If
    End Sub

    Private Sub AddFeaturesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddFeaturesToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component

                    Dim ParentTabNameArray As String() = CurrentGenomeViewer.File_Name.Split("\")
                    Dim ParentTabName As String = ParentTabNameArray(ParentTabNameArray.GetUpperBound(0))
                    AddFeature.Text = ParentTabName & " - New feature"
                    AddFeature.MyParent = CurrentGenomeViewer
                    AddFeature.Show()
                    AddFeature.Focus()

                End If
            Next
        Catch ex As Exception
            MsgBox("Genome viewer call error! " & ex.Message)
        End Try
    End Sub

    Private Sub TABSeparatedFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TABSeparatedFileToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component
                    ImportFeatures.MyGenomeViewer = CurrentGenomeViewer
                    ImportFeatures.Show()
                    ImportFeatures.Focus()
                End If
            Next
        Catch ex As Exception
            MsgBox("Genome viewer call error! " & ex.Message)
        End Try
    End Sub

    Private Sub AnnotationFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AnnotationFileToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component
                If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
                    For Each File As String In OpenFileDialog.FileNames
                        OpenAnnotation(File, CurrentGenomeViewer)
                    Next

                End If

                Exit For
            End If
        Next
    End Sub

    Private Sub ExportSequencesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportSequencesToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component

                    SeqExporter.MyGenomeViewer = CurrentGenomeViewer
                    SeqExporter.Show()
                    SeqExporter.Focus()
                End If
            Next
        Catch ex As Exception
            MsgBox("Genome viewer call error! " & ex.Message)
        End Try

    End Sub

    Private Sub ExportProteinsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportProteinsToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component

                    If SaveFileDialog.ShowDialog = DialogResult.OK Then

                        Dim Proteins As List(Of ProtPeptide)

                        Proteins = Bioinformatics.MakeProteinList(CurrentGenomeViewer.Features_Groups_List(0).FeaturesList, CurrentGenomeViewer.Genome_Sequence, Bioinformatics.GetTranslationTable(CurrentGenomeViewer.Control_Box.TransComboBox.Text.Split("-")(0)), AminoacidMWList, SystemProgressBarBox)


                        Dim WS As New IO.FileStream(SaveFileDialog.FileName, IO.FileMode.Create)
                        Dim Writer As New IO.StreamWriter(WS)

                        Writer.WriteLine("Tag" & Chr(9) & "Name" & Chr(9) & "Descr" & Chr(9) & "Seq")

                        For Each Prot As ProtPeptide In Proteins
                            Writer.WriteLine(Prot.My_Feature.TAG & Chr(9) & Prot.My_Feature.Name & Chr(9) & Prot.My_Feature.Description & Chr(9) & Prot.AA_Seq)
                        Next

                        Writer.Close()
                        WS.Close()

                        Writer.Dispose()
                        WS.Dispose()

                        MsgBox("Export completed!")

                    End If

                End If
            Next
        Catch ex As Exception
            MsgBox("Genome viewer call error! " & ex.Message)
        End Try
    End Sub

    Private Sub ExtractProteinIDToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExtractProteinIDToolStripMenuItem.Click

        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component

                Dim Report As String = ""
                Dim CurrentFeature As Genome_Feature = Nothing


                For i = 0 To CurrentGenomeViewer.Features_Groups_List(0).FeaturesList.Count - 1


                    If CurrentGenomeViewer.Features_Groups_List(0).FeaturesList(i).Type = 1 Then



                        CurrentFeature = CurrentGenomeViewer.Features_Groups_List(0).FeaturesList(i)
                        For j = 0 To CurrentFeature.AdditionalProperties.DataHeaders.Count - 1
                            If CurrentFeature.AdditionalProperties.DataHeaders(j) = "protein_id" Then
                                Report &= CurrentFeature.TAG & Chr(9) & CurrentFeature.Name & Chr(9) & CurrentFeature.Description & Chr(9) & CurrentFeature.AdditionalProperties.DataValues(j) & vbNewLine

                            End If
                        Next j

                    End If
                Next i

                If Report.Length > 0 Then

                    If SaveFileDialog.ShowDialog = DialogResult.OK Then
                        Dim WS As New IO.FileStream(SaveFileDialog.FileName, IO.FileMode.Create)
                        Dim Writer As New IO.StreamWriter(WS)

                        Writer.Write(Report)

                        Writer.Close()
                        WS.Close()

                        Writer.Dispose()
                        WS.Dispose()

                        MsgBox("Export completed!")

                    End If
                Else
                    MsgBox("No data extracted!")
                End If


            End If
        Next
       
    End Sub

#End Region

#Region "PWM"

    Private Sub SearchPWMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindPWMToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component

                    MotifDetector.CurrentGenome = CurrentGenomeViewer
                    MotifDetector.Show()
                    MotifDetector.Focus()

                End If
            Next
        Catch ex As Exception
            MsgBox("Genome viewer call error! " & ex.Message)
        End Try
    End Sub

    Private Sub MotifDetectorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BuildPWMToolStripMenuItem.Click
        PWMbuilder.Show()

    End Sub

    Private Sub DiscoverMotifsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindMotifToolStripMenuItem.Click
        MBMD_Search.Show()
        MBMD_Search.Focus()

    End Sub

    Private Sub FindBestPWMHitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindBestPWMHit_ToolStripMenuItem.Click
        Dim InputFile As String = ""
        Dim PWMFile As String = ""

        OpenFileDialog.Title = "Sequences (multiFASTA)"
        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            InputFile = OpenFileDialog.FileName
        End If
        OpenFileDialog.Title = "PWM"
        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            PWMFile = OpenFileDialog.FileName

            If Not InputFile.Length = 0 Then
                Bioinformatics.FindBestPWMEntryInMultifasta(InputFile, PWMFile)
            End If

        End If
        OpenFileDialog.Title = ""
    End Sub

    Private Sub PWMDistributionPlotToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PWMDistributionToolStripMenuItem.Click
        Dim InputFile As String = ""
        Dim PWMFile As String = ""

        OpenFileDialog.Title = "Sequences (multiFASTA)"
        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            InputFile = OpenFileDialog.FileName
        End If
        OpenFileDialog.Title = "PWM"
        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            PWMFile = OpenFileDialog.FileName

            If Not InputFile.Length = 0 Then
                Bioinformatics.GetPWMSpaceFromMultifasta(InputFile, PWMFile, 5) '20 by default
            End If

        End If
        OpenFileDialog.Title = ""
    End Sub

#End Region

#Region "Coverage"

    Private Sub ImportSAMFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportSAMFileToolStripMenuItem.Click

        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

            If MasterTabControl.TabPages.Count > 0 Then
                For Each Component As Control In MasterTabControl.SelectedTab.Controls
                    If Component.GetType.Name = "Genome_Viewer" Then
                        Dim CurrentGenomeViewer As Genome_Viewer = Component

                        If SAM_convert_dialog.ShowDialog = DialogResult.OK Then

                            For Each File As String In OpenFileDialog.FileNames

                                'Try

                                Bioinformatics.ConvertSAMtoCoverage(CurrentGenomeViewer, File, _
                                                                    SAM_convert_dialog.PlusShiftTextBox.Text, _
                                                                    SAM_convert_dialog.MinusShiftTextBox.Text, _
                                                                    SAM_convert_dialog.FirstNTCovCheckBox.Checked, _
                                                                    )
                                'Catch ex As Exception
                                'MsgBox(ex.Message)
                                'End Try

                            Next File

                        End If



                        Exit For
                    End If
                Next Component
            End If




        End If
    End Sub

    Private Sub OpenPositionalValuesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenPositionalValuesToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component
                DataIO.RetrievePositionalValues(CurrentGenomeViewer)
                'CurrentGenomeViewer.GraphPanel.Visible = True
                CurrentGenomeViewer.Control_Box.SkewOnRadioButton.Checked = True

                Exit For
            End If
        Next Component

    End Sub

    Private Sub ImportMultiplePositionalValuesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportMultiplePositionalValuesToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component
                DataIO.ImportMultiplePositionalValues(CurrentGenomeViewer, SystemProgressBarBox)


                Exit For
            End If
        Next
    End Sub

    Private Sub ImportPositionalValuesTableToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportPositionalValuesTableToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component
                DataIO.RetrievePositionalDataset(CurrentGenomeViewer)
                CurrentGenomeViewer.Control_Box.SkewOnRadioButton.Checked = True

                Exit For
            End If
        Next Component
    End Sub

    Private Sub IdentifyTranscriptionUnitsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IdentifyTranscriptionUnitsToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component
                TranscriptionUnitsIdentification.MyViewer = CurrentGenomeViewer

                Dim GroupList As New List(Of String)
                Dim Found As Boolean = False
                For Each Holder As PositionalValuesHolder In CurrentGenomeViewer.Positional_Values_Collection
                    Found = False

                    For Each Group As String In GroupList
                        If Group = Holder.Group Then
                            Found = True
                            Exit For
                        End If
                    Next

                    If Not Found Then
                        GroupList.Add(Holder.Group)
                    End If


                Next


                TranscriptionUnitsIdentification.AllHoldersListBox.Items.Clear()
                For Each Group As String In GroupList
                    TranscriptionUnitsIdentification.AllHoldersListBox.Items.Add(Group)
                Next

                TranscriptionUnitsIdentification.Show()
                TranscriptionUnitsIdentification.Focus()


                Exit For
            End If
        Next
    End Sub

    Private Sub PositionalQuantitationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PositionalQuantitationToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component

                PositionalIntegrator.MyGenomeViewer = CurrentGenomeViewer
                PositionalIntegrator.Show()
                PositionalIntegrator.Focus()

                Exit For
            End If
        Next
    End Sub

    Private Sub OverlayIntegratedValuesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OverlayIntegratedValuesToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component
                QuantControl.MyGenomeViewer = CurrentGenomeViewer
                QuantControl.Show()
                QuantControl.Focus()

                Exit For
            End If
        Next

    End Sub

    Private Sub AnalyzeERSLibraryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AnalyzeERSLibraryToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component
                ERS_analysis.MyViewer = CurrentGenomeViewer

                Dim GroupList As New List(Of String)
                Dim Found As Boolean = False
                For Each Holder As PositionalValuesHolder In CurrentGenomeViewer.Positional_Values_Collection
                    Found = False

                    For Each Group As String In GroupList
                        If Group = Holder.Group Then
                            Found = True
                            Exit For
                        End If
                    Next

                    If Not Found Then
                        GroupList.Add(Holder.Group)
                    End If


                Next


                ERS_analysis.AllHoldersListBox.Items.Clear()
                For Each Group As String In GroupList
                    ERS_analysis.AllHoldersListBox.Items.Add(Group)
                Next

                ERS_analysis.Show()
                ERS_analysis.Focus()


                Exit For
            End If
        Next
    End Sub

    Private Sub CountCoverageToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CountCoverageToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component
                CoverageCount.MyGenomeViewer = CurrentGenomeViewer

                CoverageCount.Show()
                CoverageCount.Focus()

            End If
        Next
    End Sub

    Private Sub SmoothCoverageToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SmoothCoverageToolStripMenuItem.Click

        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            For Each File As String In OpenFileDialog.FileNames
                Dim FS As New IO.FileStream(File, IO.FileMode.Open)
                Dim Reader As New IO.StreamReader(FS)

                Dim DataList As New List(Of Integer)
                Dim CurrentData As Integer = 0

                While Reader.Peek > -1
                    CurrentData = Reader.ReadLine
                    DataList.Add(CurrentData)
                End While

                Reader.Close()
                FS.Close()
                Reader.Dispose()
                FS.Dispose()

                Dim Smooting As Integer = 100

                SystemTextBox.Text = "Smoothing window"
                SystemTextBox.InputTextBox.Text = Smooting

                If SystemTextBox.DialogReturn = 1 Then
                    Smooting = SystemTextBox.InputTextBox.Text
                End If

                Dim SmoothedValue As Integer = 0
                Dim SmoothedList As New List(Of Integer)

                Dim SubList As New List(Of Integer)

                Dim StartPos As Integer = 0
                Dim EndPos As Integer = 0

                For i = 0 To DataList.Count - 1

                    StartPos = i - Smooting
                    EndPos = i + Smooting

                    If StartPos > DataList.Count Then
                        StartPos -= DataList.Count
                    End If

                    If EndPos > DataList.Count Then
                        EndPos -= DataList.Count
                    End If

                    If StartPos < 1 Then
                        StartPos += DataList.Count
                    End If

                    If EndPos < 1 Then
                        EndPos += DataList.Count
                    End If

                    If EndPos >= StartPos Then
                        SubList = Bioinformatics.GetIntSubList(DataList, StartPos - 1, EndPos - StartPos + 1)
                    Else
                        SubList = Bioinformatics.ConcatIntLists(Bioinformatics.GetIntSubList(DataList, StartPos - 1), Bioinformatics.GetIntSubList(DataList, 0, EndPos))
                    End If

                    For Each Val As Integer In SubList
                        SmoothedValue += Val
                    Next

                    SmoothedValue /= SubList.Count


                    SmoothedList.Add(SmoothedValue)

                Next

                Dim ResultFile As New IO.FileStream(File & "-smoothed_" & Smooting * 2 & ".txt", IO.FileMode.Create)
                Dim SmoothedWriter As New IO.StreamWriter(ResultFile)

                For Each SmoothedVal As Integer In SmoothedList
                    SmoothedWriter.WriteLine(SmoothedVal)
                Next

                SmoothedWriter.Close()
                ResultFile.Close()
                SmoothedWriter.Dispose()
                ResultFile.Dispose()
            Next

            SystemTextBox.Text = ""
        End If
    End Sub

    Private Sub MakeCoverageFromFeaturesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MakeCoverageFromFeaturesToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component

                    For Each Item As ListViewItem In CurrentGenomeViewer.FeaturesGroupsListBox.Items
                        If Item.Selected Then

                            'Make coverage
                            Dim CurrentGroup As FeaturesAssembly = DataIO.GetCurrentGroup(CurrentGenomeViewer.Features_Groups_List, Item.Text)
                            Dim MaxCoverageIndex As Integer = CurrentGenomeViewer.Genome_Sequence.Length - 1

                            Dim Coverage(MaxCoverageIndex) As Integer

                            Dim FeatureLength As Integer = 0
                            Dim CurrentCoverageIndex As Integer = 0

                            For Each F As Genome_Feature In CurrentGroup.FeaturesList

                                If F.AbsoluteEnd >= F.AbsoluteStart Then
                                    FeatureLength = F.AbsoluteEnd - F.AbsoluteStart + 1
                                Else
                                    FeatureLength = CurrentGenomeViewer.Genome_Sequence.Length - F.AbsoluteStart + F.AbsoluteEnd + 1
                                End If

                                CurrentCoverageIndex = F.AbsoluteStart - 1

                                For i = 1 To FeatureLength

                                    If CurrentCoverageIndex > MaxCoverageIndex Then
                                        CurrentCoverageIndex = 0
                                    End If

                                    Coverage(CurrentCoverageIndex) += 1
                                    CurrentCoverageIndex += 1
                                Next i


                            Next F

                           


                            If Me.SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

                                Dim WriteStream As New IO.FileStream(Me.SaveFileDialog.FileName, IO.FileMode.Create, IO.FileAccess.Write)
                                Dim Writer As New IO.StreamWriter(WriteStream)

                                For Each V As Integer In Coverage
                                    Writer.WriteLine(V)
                                Next V


                                'For Each S As String In Report
                                'Writer.WriteLine(S)
                                'Next S

                                Writer.Close()
                                WriteStream.Close()
                                Writer.Dispose()
                                WriteStream.Dispose()

                            End If



                        End If
                    Next Item

                End If
            Next
        Catch ex As Exception
            MsgBox("Genome viewer call error! " & ex.Message)
        End Try
    End Sub

#End Region

#Region "Tools menu"

    Private Sub OligocalculatorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OligocalculatorToolStripMenuItem.Click
        Oligocalculator.Show()
        Oligocalculator.Focus()
    End Sub

    Private Sub FindPrimersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindPrimersToolStripMenuItem.Click
        PrimerFinder.Show()
        PrimerFinder.Focus()
    End Sub

    Private Sub SequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SequenceToolStripMenuItem.Click
        SequenceDisplay.Show()
        SequenceDisplay.Focus()
    End Sub

    Private Sub ExpectWordCount_ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExpectWordCount_ToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component

                TextInputBox.SeqTextBox.Text = ""
                'TextInputBox.ShowDialog()

                If TextInputBox.ShowDialog = Windows.Forms.DialogResult.OK Then
                    If TextInputBox.SeqTextBox.Text.Length > 0 Then
                        MsgBox("Expect count of " & TextInputBox.SeqTextBox.Text & " = " & Bioinformatics.GetWordExpect(TextInputBox.SeqTextBox.Text, Bioinformatics.CalculateCGContentAsFraction(CurrentGenomeViewer.Genome_Sequence), CurrentGenomeViewer.Genome_Sequence.Length), MsgBoxStyle.Information, "Expected word count")
                    End If
                End If


                Exit For
            End If
        Next Component
    End Sub

    Private Sub IdentifyPromotersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IdentifyPromotersToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component

                Promoter_power_distribution.MyGenomeViewer = CurrentGenomeViewer
                Promoter_power_distribution.Show()
                Promoter_power_distribution.Focus()


                Exit For
            End If
        Next Component
    End Sub

    Private Sub RandomSequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RandomSequenceToolStripMenuItem.Click
        RandomSeq.Show()
    End Sub


    Private Sub KmerDistributionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KmerStatisticsToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component

                Dim PrevTitle As String = SaveFileDialog.Title
                Dim PrevExt As String = SaveFileDialog.DefaultExt
                SaveFileDialog.DefaultExt = "txt"
                SaveFileDialog.Title = "Save K-mer statistics"

                If SaveFileDialog.ShowDialog = DialogResult.OK Then
                    Dim K_mer As Integer = 6
                    SystemTextBox.InputTextBox.Text = K_mer
                    SystemTextBox.Text = "K-mer length"


                    If SystemTextBox.DialogReturn = 1 Then

                        SystemProgressBarBox.Show()
                        SystemProgressBarBox.Focus()

                        Dim WriteStream As New IO.FileStream(SaveFileDialog.FileName, IO.FileMode.Create)
                        Dim Writer As New IO.StreamWriter(WriteStream)


                        K_mer = CType(SystemTextBox.InputTextBox.Text, Integer)

                        Dim WordspaceStat As DataTable = Bioinformatics.GetWordStatistics(CurrentGenomeViewer.Genome_Sequence, K_mer, Bioinformatics.CalculateCGContentAsFraction(CurrentGenomeViewer.Genome_Sequence), , SystemProgressBarBox)

                        SystemProgressBarBox.Close()

                        Writer.WriteLine("K-mer" & Chr(9) & "Count" & Chr(9) & "Expect")

                        For i = 0 To WordspaceStat.Rows.Count - 1
                            Writer.WriteLine(WordspaceStat.Rows(i).Item(0) & Chr(9) & WordspaceStat.Rows(i).Item(1) & Chr(9) & WordspaceStat.Rows(i).Item(2))
                        Next

                        SystemTextBox.Text = ""
                        SystemTextBox.InputTextBox.Text = ""

                        Writer.Close()
                        WriteStream.Close()
                        Writer.Dispose()
                        WriteStream.Dispose()

                        MsgBox("File has been created!")

                    End If


                End If

                SaveFileDialog.Title = PrevTitle
                SaveFileDialog.DefaultExt = PrevExt

            End If
        Next Component
    End Sub

    Private Sub ArrayDesign_ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ArrayDesign_ToolStripMenuItem.Click
        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component


                ArrayDesigner.MyGenomeViewer = CurrentGenomeViewer

                ArrayDesigner.Show()



                'Dim ProbesList As List(Of K_Word_Thermodynamics) = Bioinformatics.FindProbesForGenome(CurrentGenomeViewer.Genome_Sequence, CurrentGenomeViewer.Features_Groups_List(0).FeaturesList, 60, -65, 2, -3, , 5, 10, , , )

                'Dim ReportString As String = ""
                'For Each Probe As K_Word_Thermodynamics In ProbesList
                'ReportString &= Probe.SeqName & Chr(9) & Probe.Word_Text & vbNewLine
                'Next

                'Clipboard.SetText(ReportString)


            End If

        Next Component
    End Sub

    Private Sub ThermodynamicsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ThermodynamicsToolStripMenuItem.Click
        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            Bioinformatics.CalculateSeqFunctions(OpenFileDialog.FileName, 37, False)
        End If
    End Sub

    Private Sub ODToPmolToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ODToPmolToolStripMenuItem.Click
        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            Bioinformatics.BatchCalculateOligoC(OpenFileDialog.FileName)
        End If
    End Sub

    Private Sub ProteinMWAndPIToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProteinMWAndPIToolStripMenuItem.Click
        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            Bioinformatics.CalculateProteinProperties(OpenFileDialog.FileName, AminoacidMWList, AminoacidPIList, AminoacidHIList)
        End If
    End Sub


    Private Sub CodonUsageToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CodonUsageToolStripMenuItem.Click

        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component
                Dim ResultTable As DataTable = Bioinformatics.SumCodonUsage(Bioinformatics.GetCodonUsage(CurrentGenomeViewer, SystemProgressBarBox))

                Select Case MsgBox("Export in full format (codon statistics for each CDS)? [No] for short format (used for reverse translation)", MsgBoxStyle.YesNoCancel, "Select export format")
                    Case MsgBoxResult.Yes
                        DataIO.SaveDataTable(ResultTable, SaveFileDialog, False)

                    Case MsgBoxResult.No
                        DataIO.SaveDataTable(Bioinformatics.FormatCodonUsage(ResultTable), SaveFileDialog, False)

                    Case MsgBoxResult.Cancel
                        MsgBox("Aborted!")
                End Select


            End If
        Next Component

    End Sub

    Private Sub DesignAssemblyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DesignAssemblyToolStripMenuItem.Click

        For Each Component As Control In MasterTabControl.SelectedTab.Controls
            If Component.GetType.Name = "Genome_Viewer" Then
                Dim CurrentGenomeViewer As Genome_Viewer = Component
                Disassembler.Text = "Assembly design - " & MasterTabControl.SelectedTab.Text

                Disassembler.MyGenomeViewer = CurrentGenomeViewer
                Disassembler.SeqNameTextBox.Text = MasterTabControl.SelectedTab.Text
                Disassembler.SeqMode = False
                Disassembler.Show()
                Disassembler.Focus()

                
            End If
        Next Component






    End Sub

    Private Sub HitPlotToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HitPlotToolStripMenuItem.Click
        HitPlot.SeqTextBox.Text = ""
        HitPlot.Show()
        HitPlot.Focus()
    End Sub

    Private Sub ReloadDataToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReloadDataToolStripMenuItem.Click
        LoadData()
    End Sub

#End Region

#Region "Service menu"
    Private Sub ReloadSourceDataToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReloadSourceDataToolStripMenuItem.Click
        LoadData()
    End Sub

    Private Sub LogWindowToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogWindowToolStripMenuItem.Click
        ReportForm.Show()
    End Sub

    Private Sub ViewHistoryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewHistoryToolStripMenuItem.Click
        Try
            For Each Component As Control In MasterTabControl.SelectedTab.Controls
                If Component.GetType.Name = "Genome_Viewer" Then
                    Dim CurrentGenomeViewer As Genome_Viewer = Component
                    ReportForm.ReportTextBox.Text = ""

                    For Each Str As String In CurrentGenomeViewer.Features_History
                        ReportForm.ReportTextBox.Text &= Str & vbNewLine

                    Next

                    ReportForm.Show()
                    ReportForm.Focus()
                    Exit For
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub CallTestFormToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CallTestFormToolStripMenuItem.Click
        TestForm.Show()
    End Sub

    Private Sub TestToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TestToolStripMenuItem.Click
        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            OpenMultyGenBank(OpenFileDialog.FileName)

        End If

    End Sub

#End Region










    'Private Sub WordSpaceTableToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WordSpaceTableToolStripMenuItem.Click
    'Dim InputFile As String = ""

    'OpenFileDialog.Title = "Sequences (multiFASTA)"
    'If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
    'InputFile = OpenFileDialog.FileName

    'Dim Words As List(Of String) = Bioinformatics.GenerateWordSpace(6)
    'Words.Add("TATAAT")
    'Words.Add("GAGTGCTAA")

    'Bioinformatics.GetWordSpaceFromMultifasta(InputFile, "AGTGCTAA")
    'Bioinformatics.GetWordSpaceFromMultifasta(InputFile, Words, )

    'End If



    'OpenFileDialog.Title = ""
    'End Sub



    'Code for GenBank import, not important now///////////////
    'Private Sub ImportGeneBankFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportGeneBankFileToolStripMenuItem.Click

    'If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

    'If SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

    'Dim NewAnnotation As List(Of Genome_Feature) = DataIO.ParseGBAnnotation(OpenFileDialog.FileName)
    'Dim NewSequence As String = DataIO.ReadGBFileToSequence(OpenFileDialog.FileName)

    'If NewSequence = "" Then

    'Select Case MsgBox("No sequence in GB file! Import sequence from external FASTA?", MsgBoxStyle.YesNoCancel)
    'Case MsgBoxResult.Yes
    'If OpenFileDialog.ShowDialog = DialogResult.OK Then
    'Dim DestinationSeqFile As String = String.Concat(SaveFileDialog.FileName, ".fasta")
    'IO.File.Copy(OpenFileDialog.FileName, DestinationSeqFile, True)
    'End If
    'Case MsgBoxResult.No
    'Write empty sequence
    'DataIO.WriteSequence(NewSequence, SaveFileDialog.FileName)

    'Case MsgBoxResult.Cancel
    'Exit Sub
    'End Select

    'Else
    'DataIO.WriteSequence(NewSequence, SaveFileDialog.FileName)

    'End If

    'DataIO.WriteAnnotation(NewAnnotation, SaveFileDialog.FileName, DataIO.ReadGBTopology(OpenFileDialog.FileName), DataIO.ReadGBCodeTable(OpenFileDialog.FileName), , , SystemProgressBarBox)

    'Try
    'OpenFile(String.Concat(SaveFileDialog.FileName, ".fasta"))
    'Catch ex As Exception

    'End Try

    'End If

    'End If






    'End Sub
    '/////////////////////////////////////

    'Code for SELEX library calculation, working, but not finished
    '  If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

    '  Dim FS As New IO.FileStream(OpenFileDialog.FileName, IO.FileMode.Open)
    '  Dim Reader As New IO.StreamReader(FS)

    ' Dim CurrentString As String = ""
    ' Dim Sequences As New List(Of String)

    ' Dim counter As Integer = 0
    ' Dim ReadStart As Integer = 0
    ' Dim ReadEnd As Integer = 200000

    ' While Reader.Peek > -1


    'CurrentString = Reader.ReadLine

    'If counter >= ReadStart And counter <= ReadEnd Then
    'If Not CurrentString.StartsWith(">") And CurrentString.Length > 4 Then
    'Sequences.Add(CurrentString)
    'End If
    'End If


    'counter += 1

    'End While

    'Reader.Close()
    'FS.Close()
    'Reader.Dispose()
    'FS.Dispose()

    'Dim Words As List(Of SELEX_Word) = Bioinformatics.GetSELEXWordStat(Sequences, 7, 1, SystemProgressBarBox)
    'Dim OutputFile As String = OpenFileDialog.FileName.Split(".")(0) & "-report.txt"

    'Dim WS As New IO.FileStream(OutputFile, IO.FileMode.Create)
    'Dim Writer As New IO.StreamWriter(WS)

    'For Each Word As SELEX_Word In Words

    'Writer.WriteLine(Word.Sequence & Chr(9) & Word.Count)

    'Next Word


    'Writer.Close()
    'WS.Close()
    'Writer.Dispose()
    'WS.Dispose()

    'End If




    'Another code for word statistics

    'Try
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'Dim InputSeq As New List(Of String)
    'InputSeq.Add(CurrentGenomeViewer.Genome_Sequence)

    'If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
    'For Each File As String In OpenFileDialog.FileNames
    'Dim FS As New IO.FileStream(File, IO.FileMode.Open)
    'Dim Reader As New IO.StreamReader(FS)

    'While Reader.Peek > -1
    'InputSeq.Add(Reader.ReadLine)
    'End While

    'Reader.Close()
    'FS.Close()
    'Reader.Dispose()
    'FS.Dispose()
    'Next
    'End If


    'Dim Result As DataTable = Bioinformatics.LexAnalysis(InputSeq, 6, 0.05)
    'DataIO.SaveDataTable(Result, SaveFileDialog)

    'End If
    'Next
    'Catch ex As Exception
    'MsgBox("Genome viewer call error! " & ex.Message)
    'End Try


    'Code for probe design for SNP
    '/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component


    'If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
    'Dim FS As New IO.FileStream(OpenFileDialog.FileName, IO.FileMode.Open)
    'Dim Reader As New IO.StreamReader(FS)

    'Dim IDList As New List(Of String)
    'Dim StartList As New List(Of Integer)
    'Dim EndList As New List(Of Integer)
    'Dim PolymorphList As New List(Of String)

    'Dim IDListColumnIndex As Integer = 0
    'Dim ChromosomeColumnIndex As Integer = 1
    'Dim StartColumnIndex As Integer = 2
    'Dim EndColumnIndex As Integer = 3
    'Dim PolymorphColumnIndex As Integer = 6



    'Dim CurrentString As String = Reader.ReadLine
    'Dim CurrentChr As String = ""

    'Dim ParentTabNameArray As String() = CurrentGenomeViewer.File_Name.Split("\")
    'Dim ParentTabName As String = ParentTabNameArray(ParentTabNameArray.GetUpperBound(0))

    'Dim Data As String()

    'While Reader.Peek > -1
    'CurrentString = Reader.ReadLine
    'Data = CurrentString.Split(Chr(9))

    'CurrentChr = Data(ChromosomeColumnIndex)
    'If CurrentChr = ParentTabName Then
    'IDList.Add(Data(IDListColumnIndex))
    'StartList.Add(Data(StartColumnIndex))
    'EndList.Add(Data(EndColumnIndex))
    'PolymorphList.Add(Data(PolymorphColumnIndex))
    'End If

    'End While

    'Reader.Close()
    'FS.Close()
    'Reader.Dispose()
    'FS.Dispose()

    'Dim ProbesList As List(Of ProbesBundle) = _
    'Bioinformatics.DesignProbesPerPolymorphList _
    '(CurrentGenomeViewer.Genome_Sequence, StartList, EndList, PolymorphList, IDList, -28, 1, 10, 17, 37, True, 10, True)

    'Dim UnitedDataFile As String = OpenFileDialog.FileName.Split(".")(0) & "-probes.txt"

    'Dim WS As New IO.FileStream(UnitedDataFile, IO.FileMode.Append) 'CurrentGenomeViewer.File_Name & "-probes.txt"
    'Dim Writer As New IO.StreamWriter(WS)
    'Writer.WriteLine("ID" & Chr(9) & "Seq" & Chr(9) & "dG")
    'Dim CurrentDG As Single = 0
    'Dim ProbeCounter As Integer = 1

    'For Each Bundle As ProbesBundle In ProbesList
    'ProbeCounter = 1
    'For Each Seq As String In Bundle.Probes
    'CurrentDG = Bioinformatics.CalculateOligoDG(Seq, 37, True)
    'Writer.WriteLine(Bundle.SNP_ID & "-" & ProbeCounter & Chr(9) & Seq & Chr(9) & CurrentDG)
    'ProbeCounter += 1
    'Next Seq
    'Next Bundle

    'Writer.Close()
    'WS.Close()
    'Writer.Dispose()
    'WS.Dispose()

    'End If



    'End If

    'Next Component
    '/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    '////// To extract sequence from FASTQ
    'If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
    'If SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

    'Dim CutSeqList As List(Of String) = Bioinformatics.CutAdapterGapped(Bioinformatics.ReadFASTQtoString(OpenFileDialog.FileName), "AAGCAGTGGTATCAACGCAGAGTACTGGAGT", , 3, 5, , , , True, "T", , MasterProgressBar) 'AAGCAGTGGTATCAACGCAGAGTACTGGAG - 3`adapter AAGCAGTGGTATCAACGCAGAGTGGCCATTACGGCC - 5`adapter

    'Dim FileString As String() = SaveFileDialog.FileName.Split("\")
    'Dim FileName As String = FileString(FileString.GetUpperBound(0)).Split(".")(0)

    'Dim WriteStream As New IO.FileStream(SaveFileDialog.FileName, IO.FileMode.Create)
    'Dim Writer As New IO.StreamWriter(WriteStream)
    'Dim counter As Integer = 1

    'For Each Seq As String In CutSeqList
    'Writer.WriteLine(">" & counter & FileName)
    'Writer.WriteLine(Seq)
    'counter += 1
    'Next

    'Writer.Close()
    'WriteStream.Close()
    'Writer.Dispose()
    'WriteStream.Dispose()

    'End If


    'End If




    'Another core for probes design for SNP
    '///////////////////////////////////////////////////////////////////////////////////////////////////////////////
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
    'Dim FS As New IO.FileStream(OpenFileDialog.FileName, IO.FileMode.Open)
    'Dim Reader As New IO.StreamReader(FS)
    'Dim SNPList As New List(Of Integer)
    'Dim IDList As New List(Of String)

    'Dim IDListColumnIndex As Integer = 0
    'Dim SNP_PosColumnIndex As Integer = 2
    'Dim ChromosomeColumnIndex As Integer = 1


    'Dim CurrentString As String = Reader.ReadLine
    'Dim CurrentChr As String = ""

    'Dim ParentTabNameArray As String() = CurrentGenomeViewer.File_Name.Split("\")
    'Dim ParentTabName As String = ParentTabNameArray(ParentTabNameArray.GetUpperBound(0))

    'Dim Data As String()

    'While Reader.Peek > -1
    'CurrentString = Reader.ReadLine
    'Data = CurrentString.Split(Chr(9))

    'CurrentChr = Data(ChromosomeColumnIndex) '.Split(":")(0)
    'If CurrentChr = ParentTabName Then
    'IDList.Add(Data(IDListColumnIndex))
    'SNPList.Add(Data(SNP_PosColumnIndex))
    'End If

    'End While

    'Reader.Close()
    'FS.Close()
    'Reader.Dispose()
    'FS.Dispose()



    'Dim ProbesList As List(Of ProbesBundle) = _
    'Bioinformatics.DesignProbesForSNPList _
    '(CurrentGenomeViewer.Genome_Sequence, SNPList, IDList, -28, 1, 10, 17, 37, True, 10)

    'Dim UnitedDataFile As String = OpenFileDialog.FileName.Split(".")(0) & "-probes.txt"

    'Dim WS As New IO.FileStream(UnitedDataFile, IO.FileMode.Append) 'CurrentGenomeViewer.File_Name & "-probes.txt"
    'Dim Writer As New IO.StreamWriter(WS)
    'Writer.WriteLine("ID" & Chr(9) & "Seq" & Chr(9) & "dG")
    'Dim CurrentDG As Single = 0
    'Dim ProbeCounter As Integer = 1

    'For Each Bundle As ProbesBundle In ProbesList
    'ProbeCounter = 1
    'For Each Seq As String In Bundle.Probes
    'CurrentDG = Bioinformatics.CalculateOligoDG(Seq, 37, True)
    'Writer.WriteLine(Bundle.SNP_ID & "-" & ProbeCounter & Chr(9) & Seq & Chr(9) & CurrentDG)
    'ProbeCounter += 1
    'Next Seq
    'Next Bundle

    'Writer.Close()
    'WS.Close()
    'Writer.Dispose()
    'WS.Dispose()


    'End If





    'End If

    'Next Component
    '///////////////////////////////////////////////////////////////////////////////////////////////////////////////


    '////////////////////Another code for K-mer statistics////////////////////////////////////////

    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'Dim InputSeq As New List(Of String)

    'If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
    'For Each File As String In OpenFileDialog.FileNames
    'Dim FS As New IO.FileStream(File, IO.FileMode.Open)
    'Dim Reader As New IO.StreamReader(FS)

    'While Reader.Peek > -1
    'InputSeq.Add(Reader.ReadLine)
    'End While

    'Reader.Close()
    'FS.Close()
    'Reader.Dispose()
    'FS.Dispose()
    'Next
    'End If

    'Dim InclusionList As New List(Of SequenceCoordinate)
    'If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
    'Dim FS As New IO.FileStream(OpenFileDialog.FileName, IO.FileMode.Open)
    'Dim Reader As New IO.StreamReader(FS)
    'Dim CurrentLine As String()

    'While Reader.Peek > -1
    'CurrentLine = Reader.ReadLine.Split(Chr(9))
    'InclusionList.Add(New SequenceCoordinate(CurrentLine(0), CurrentLine(1), CurrentLine(2)))
    'End While

    'Reader.Close()
    'FS.Close()
    'Reader.Dispose()
    'FS.Dispose()
    'End If

    'Dim Result As DataTable = Bioinformatics.WordDistribution(InputSeq, CurrentGenomeViewer.Genome_Sequence, InclusionList, 0.8, 4, 4)
    'DataIO.SaveDataTable(Result, SaveFileDialog)

    'End If
    'Next
    '////////////////////////////////////////



    'Code for repeat search////////////////////////////////////////////////////////////////////////////////
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'Static SearchCount As Integer = 0

    'Dim NewAssembly As New FeaturesAssembly
    'NewAssembly.AssemblyName = "Repeat search " & SearchCount
    'NewAssembly.Visible = True

    'SystemTextBox.Text = "Parameters"
    'SystemTextBox.InputTextBox.Text = ""
    'Dim Dialog_Result As Short = SystemTextBox.DialogReturn


    'If Dialog_Result = 1 Then

    'Dim Parameters As String() = SystemTextBox.InputTextBox.Text.Split("/")

    'Dim RepList As List(Of Genome_Feature) = Bioinformatics.MultiRepeatSearch(CurrentGenomeViewer.Genome_Sequence, Parameters(0), Parameters(1), Parameters(2))   ' Bioinformatics.RepeatSearch(CurrentGenomeViewer.Genome_Sequence, 7, 3, 0, False)

    'For Each NewFeature As Genome_Feature In RepList
    'NewFeature.Group = NewAssembly.AssemblyName
    'NewAssembly.FeaturesList.Add(NewFeature)

    'Next

    'CurrentGenomeViewer.ShowFeaturesFromGroup(NewAssembly.AssemblyName)
    'CurrentGenomeViewer.Features_Groups_List.Add(NewAssembly)
    'CurrentGenomeViewer.FeaturesGroupsListBox.Items.Add(NewAssembly.AssemblyName)
    'CurrentGenomeViewer.FeaturesGroupsListBox.Items(CurrentGenomeViewer.FeaturesGroupsListBox.Items.Count - 1).Checked = True
    'CurrentGenomeViewer.DisplayFeatures()

    'SearchCount += 1
    'End If





    'End If
    'Next
    '/////////////////////////////////////////////////////////////////





    'To be deleted!!!//////////////
#Region "Genomics menu"


    'Private Sub ExportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportToolStripMenuItem.Click
    'Try
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'If SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

    'Dim FS As New IO.FileStream(SaveFileDialog.FileName, IO.FileMode.Create)
    'Dim Writer As New IO.StreamWriter(FS)
    'Dim CurrentTranslationTable As DataTable = Bioinformatics.GetTranslationTable(CurrentGenomeViewer.Control_Box.TransComboBox.Text.Split("-")(0))


    'Dim Frame1_AAF As String = Bioinformatics.Translate(CurrentGenomeViewer.Genome_Sequence, CurrentTranslationTable)
    'Dim Prot_1F As String() = Frame1_AAF.Split("*")
    'For Each Prot As String In Prot_1F
    'Writer.WriteLine(Prot & Chr(9) & "Frame_1F")
    'Next Prot

    'Dim Frame2_NNF As String = CurrentGenomeViewer.Genome_Sequence.Substring(1)
    'Dim Frame2_AAF As String = Bioinformatics.Translate(Frame2_NNF, CurrentTranslationTable)
    'Dim Prot_2F As String() = Frame2_AAF.Split("*")
    'For Each Prot As String In Prot_2F
    'Writer.WriteLine(Prot & Chr(9) & "Frame_2F")
    'Next Prot

    'Dim Frame3_NNF As String = CurrentGenomeViewer.Genome_Sequence.Substring(2)
    'Dim Frame3_AAF As String = Bioinformatics.Translate(Frame3_NNF, CurrentTranslationTable)
    'Dim Prot_3F As String() = Frame3_AAF.Split("*")
    'For Each Prot As String In Prot_3F
    'Writer.WriteLine(Prot & Chr(9) & "Frame_3F")
    'Next Prot


    'Dim Frame1_NNR As String = Bioinformatics.GetReverseComplement(CurrentGenomeViewer.Genome_Sequence)
    'Dim Frame1_AAR As String = Bioinformatics.Translate(Frame1_NNR, CurrentTranslationTable)
    'Dim Prot_1R As String() = Frame1_AAR.Split("*")
    'For Each Prot As String In Prot_1R
    'Writer.WriteLine(Prot & Chr(9) & "Frame_1R")
    'Next Prot

    'Dim Frame2_NNR As String = Frame1_NNR.Substring(1)
    'Dim Frame2_AAR As String = Bioinformatics.Translate(Frame2_NNR, CurrentTranslationTable)
    'Dim Prot_2R As String() = Frame2_AAR.Split("*")
    'For Each Prot As String In Prot_2R
    'Writer.WriteLine(Prot & Chr(9) & "Frame_2R")
    'Next Prot

    'Dim Frame3_NNR As String = Frame1_NNR.Substring(2)
    'Dim Frame3_AAR As String = Bioinformatics.Translate(Frame3_NNR, CurrentTranslationTable)
    'Dim Prot_3R As String() = Frame3_AAR.Split("*")
    'For Each Prot As String In Prot_3R
    'Writer.WriteLine(Prot & Chr(9) & "Frame_3R")
    'Next Prot

    'Writer.Close()
    'FS.Close()
    'Writer.Dispose()
    'FS.Dispose()

    'End If



    'End If
    'Next Component

    'Catch ex As Exception
    'MsgBox("Genome viewer call error! " & ex.Message)
    'End Try

    'End Sub


    'Private Sub ViewInBrowserToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewInBrowserToolStripMenuItem.Click
    'Try
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component
    'Dim CodeTable As DataTable = Bioinformatics.GetTranslationTable(CurrentGenomeViewer.Control_Box.TransComboBox.Text.Split("-")(0))
    'CurrentGenomeViewer.TranslationList6Frame = Bioinformatics.Make6FrameTranslation(CurrentGenomeViewer.Genome_Sequence, CodeTable, CurrentGenomeViewer.GenomeTopology, True, True, SystemProgressBarBox)
    'CurrentGenomeViewer.Control_Box.TranslationOnButton.Checked = True
    'End If
    'Next
    'Catch ex As Exception
    'MsgBox(ex.Message)
    'End Try
    'End Sub

    'Private Sub ORFFinderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ORFFinderToolStripMenuItem.Click
    'Try
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component
    'ORF_Finder.MyGenomeViewer = CurrentGenomeViewer
    'ORF_Finder.Show()
    'ORF_Finder.Focus()
    'End If
    'Next
    'Catch ex As Exception
    'MsgBox("Genome viewer call error! " & ex.Message)
    'End Try

    'End Sub

    'Private Sub MotifFinderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MotifFinderToolStripMenuItem.Click
    'Try
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'MotifDetector.CurrentGenome = CurrentGenomeViewer
    'MotifDetector.Show()
    'MotifDetector.Focus()

    'End If
    'Next
    'Catch ex As Exception
    'MsgBox("Genome viewer call error! " & ex.Message)
    'End Try


    'End Sub

    'Private Sub HairpinsFinderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HairpinsFinderToolStripMenuItem.Click
    'Try
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component
    'HairpinFinder.MyViewer = CurrentGenomeViewer
    'HairpinFinder.Show()
    'HairpinFinder.Focus()

    'End If
    'Next
    'Catch ex As Exception
    'MsgBox("Genome viewer call error! " & ex.Message)
    'End Try
    'End Sub

    'Private Sub RBLASTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RBLASTToolStripMenuItem.Click
    'Try
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component
    'AlignmentSearchTool.MyGenomeViewer = CurrentGenomeViewer
    'AlignmentSearchTool.Text = AlignmentSearchTool.MyName & " - " & CurrentGenomeViewer.Parent.Text
    'AlignmentSearchTool.Show()
    'AlignmentSearchTool.Focus()
    'End If
    'Next
    'Catch ex As Exception
    'MsgBox("Genome viewer call error! " & ex.Message)
    'End Try
    'End Sub

    'Private Sub LargeScaleViewerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LargeScaleViewerToolStripMenuItem.Click
    'Try
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component
    'CurrentGenomeViewer.CreateGenomicView()
    'End If
    'Next
    'Catch ex As Exception
    'MsgBox("Genome viewer call error! " & ex.Message)
    'End Try
    'End Sub

    'Private Sub InSilico2DEFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InSilico2DEFToolStripMenuItem.Click
    'Try
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component
    'CurrentGenomeViewer.CreateProteomicsView()
    'End If
    'Next
    'Catch ex As Exception
    'MsgBox("Genome viewer call error! " & ex.Message)
    'End Try
    'End Sub

    'Private Sub ExpectWordCountToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExpectWordCountToolStripMenuItem.Click
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'TextInputBox.SeqTextBox.Text = ""
    'TextInputBox.ShowDialog()

    'If TextInputBox.ShowDialog = Windows.Forms.DialogResult.OK Then
    'If TextInputBox.SeqTextBox.Text.Length > 0 Then
    'MsgBox("Expect count of " & TextInputBox.SeqTextBox.Text & " = " & Bioinformatics.GetWordExpect(TextInputBox.SeqTextBox.Text, Bioinformatics.CalculateCGContentAsFraction(CurrentGenomeViewer.Genome_Sequence), CurrentGenomeViewer.Genome_Sequence.Length), MsgBoxStyle.Information, "Expected word count")
    'End If
    'End If


    'Exit For
    'End If
    'Next Component
    'End Sub

    'Private Sub StructureDistributionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StructureDistributionToolStripMenuItem.Click
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'Dim Values As List(Of Integer) = Bioinformatics.GetdGDistribution(CurrentGenomeViewer.Genome_Sequence, 15, CurrentGenomeViewer.GenomeTopology, 37, SystemProgressBarBox)

    'PositionalValuesChartControl.NameTextBox.Text = "dG_distr_func"
    'PositionalValuesChartControl.ColorPanel.BackColor = Color.Black
    'PositionalValuesChartControl.StrandComboBox.Text = "Plus"
    'PositionalValuesChartControl.ScaleComboBox.Text = "Linear"

    'Dim Strand As Short = 0
    'Dim Scale As Short = 0

    'If PositionalValuesChartControl.ShowDialog = DialogResult.OK Then


    'Select Case PositionalValuesChartControl.StrandComboBox.Text
    'Case "Plus"
    'Strand = 1
    'Case "Minus"
    'Strand = 2
    'Case "Undetermined"
    'Strand = 0
    'End Select


    'Select Case PositionalValuesChartControl.ScaleComboBox.Text
    'Case "Logarithm"
    'Scale = 1
    'Case "Linear"
    'Scale = 0
    'End Select

    'Else
    'Exit Sub
    'End If


    'Dim NewPositionalHolder As New PositionalValuesHolder(PositionalValuesChartControl.NameTextBox.Text, Strand, Values, PositionalValuesChartControl.ColorPanel.BackColor, Scale)
    'NewPositionalHolder.Visible = PositionalValuesChartControl.VisibleCheckBox.Checked

    'CurrentGenomeViewer.Control_Box.SkewOnRadioButton.Checked = True

    'CurrentGenomeViewer.Positional_Values_Collection.Add(NewPositionalHolder)

    'CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Add(NewPositionalHolder.Visible, PositionalValuesChartControl.NameTextBox.Text, PositionalValuesChartControl.StrandComboBox.Text, "", PositionalValuesChartControl.ScaleComboBox.Text, NewPositionalHolder.Group)
    'CurrentGenomeViewer.PositionalValuesDataGridView.Rows(CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = PositionalValuesChartControl.ColorPanel.BackColor


    'Exit For
    'End If
    'Next Component
    'End Sub

    'Private Sub RepeatFinderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RepeatFinderToolStripMenuItem.Click

    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component



    'Repeat_finder.MyGenomeViewer = CurrentGenomeViewer
    'Repeat_finder.Show()


    'Exit For
    'End If
    'Next Component

    'End Sub

    'Private Sub GCdistributionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GCdistributionToolStripMenuItem.Click
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'Static N As Integer = 0

    'SystemProgressBarBox.Show()
    'SystemProgressBarBox.Focus()


    'Dim Data As Integer() = Bioinformatics.CalculateGCDistribution(CurrentGenomeViewer.Genome_Sequence, , CurrentGenomeViewer.GenomeTopology, False, SystemProgressBarBox)

    'Dim Values As New List(Of Integer)
    'For Each V As Integer In Data
    'Values.Add(V)
    'Next

    'Dim NewPosHolderName As String = "GC-content " & N

    'Dim NewPositionalHolder As New PositionalValuesHolder(NewPosHolderName, 1, Values, Color.Black, 0)
    'NewPositionalHolder.Visible = True

    'CurrentGenomeViewer.Positional_Values_Collection.Add(NewPositionalHolder)

    'CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Add(NewPositionalHolder.Visible, NewPosHolderName, "Plus", "", "Linear", NewPositionalHolder.Group)
    'CurrentGenomeViewer.PositionalValuesDataGridView.Rows(CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = Color.Black

    'SystemProgressBarBox.Close()


    'End If
    'Next Component
    'End Sub

    'Private Sub GCskewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GCskewToolStripMenuItem.Click
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'Static N As Integer = 0

    'SystemProgressBarBox.Show()
    'SystemProgressBarBox.Focus()


    'Dim Data As Integer() = Bioinformatics.CalculateGCSkew(CurrentGenomeViewer.Genome_Sequence, , CurrentGenomeViewer.GenomeTopology, SystemProgressBarBox, )

    'Dim Values As New List(Of Integer)
    'For Each V As Integer In Data
    'Values.Add(V)
    'Next

    'Dim NewPosHolderName As String = "GC-skew " & N

    'Dim NewPositionalHolder As New PositionalValuesHolder(NewPosHolderName, 1, Values, Color.Black, 0)
    'NewPositionalHolder.Visible = True

    'CurrentGenomeViewer.Positional_Values_Collection.Add(NewPositionalHolder)

    'CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Add(NewPositionalHolder.Visible, NewPosHolderName, "Plus", "", "Linear", NewPositionalHolder.Group)
    'CurrentGenomeViewer.PositionalValuesDataGridView.Rows(CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = Color.Black

    'SystemProgressBarBox.Close()


    'End If
    'Next Component
    'End Sub

    'Private Sub ATskewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ATskewToolStripMenuItem.Click
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'Static N As Integer = 0

    'SystemProgressBarBox.Show()
    'SystemProgressBarBox.Focus()


    'Dim Data As Integer() = Bioinformatics.CalculateGCSkew(CurrentGenomeViewer.Genome_Sequence, , CurrentGenomeViewer.GenomeTopology, SystemProgressBarBox, False)

    'Dim Values As New List(Of Integer)
    'For Each V As Integer In Data
    'Values.Add(V)
    'Next

    'Dim NewPosHolderName As String = "AT-skew " & N

    'Dim NewPositionalHolder As New PositionalValuesHolder(NewPosHolderName, 1, Values, Color.Black, 0)
    'NewPositionalHolder.Visible = True

    'CurrentGenomeViewer.Positional_Values_Collection.Add(NewPositionalHolder)

    'CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Add(NewPositionalHolder.Visible, NewPosHolderName, "Plus", "", "Linear", NewPositionalHolder.Group)
    'CurrentGenomeViewer.PositionalValuesDataGridView.Rows(CurrentGenomeViewer.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = Color.Black

    'SystemProgressBarBox.Close()


    'End If
    'Next Component
    'End Sub

    'Private Sub PromoterPowerDistributionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PromoterPowerDistributionToolStripMenuItem.Click
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'Promoter_power_distribution.MyGenomeViewer = CurrentGenomeViewer
    'Promoter_power_distribution.Show()
    'Promoter_power_distribution.Focus()


    'Exit For
    'End If
    'Next Component
    'End Sub

    'Private Sub ViewTranslationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewTranslationToolStripMenuItem.Click
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'For Each Feature As Genome_Feature In CurrentGenomeViewer.Features_Groups_List(0).FeaturesList
    'If Feature.Type = 1 Then
    'Feature.SetTranslation(True, CurrentGenomeViewer.GetFeatureSequence(Feature), CurrentGenomeViewer.Control_Box.TransComboBox.Text.Split("-")(0))
    'End If

    'Next Feature

    'CurrentGenomeViewer.DisplayFeatures()
    'Exit For
    'End If

    'Next Component
    'End Sub

    'Private Sub ClearTranslationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearTranslationToolStripMenuItem.Click
    'For Each Component As Control In MasterTabControl.SelectedTab.Controls
    'If Component.GetType.Name = "Genome_Viewer" Then
    'Dim CurrentGenomeViewer As Genome_Viewer = Component

    'For Each Feature As Genome_Feature In CurrentGenomeViewer.Features_Groups_List(0).FeaturesList
    'If Feature.Type = 1 Then
    'Feature.SetTranslation(False)
    'End If

    'Next Feature

    'CurrentGenomeViewer.DisplayFeatures()
    'Exit For
    'End If
    'Next Component
    'End Sub

#End Region
    '//////////////////////////////



    'Code for RNA alignment of multiple sequences, has to be polished///////////////////////
    'Private Sub BatchAlignToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BatchAlignToolStripMenuItem.Click
    'If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

    'Dim ReadStream As New IO.FileStream(OpenFileDialog.FileName, IO.FileMode.Open)
    'Dim Reader As New IO.StreamReader(ReadStream)
    'Dim ReferenceString As String = "CUCCUU" 'UUACCUCCUUUCU - full SD CCUCCUUUC - cut SD CUCCU - core SD
    'Dim CurrentLine As String = ""
    'Dim CurrentHeader As String = ""

    'Dim FilePathArr As String() = OpenFileDialog.FileName.Split("\")
    'Dim AnalysisName As String = FilePathArr(FilePathArr.GetUpperBound(0)).Split(".")(0)
    'Dim FileDir As String = ""
    'For i = 0 To FilePathArr.GetUpperBound(0) - 1
    'FileDir &= FilePathArr(i) & "\"
    'Next

    'Dim WriteStream_txt As New IO.FileStream(FileDir & AnalysisName & "-thermodynamics_alignments.txt", IO.FileMode.Create)
    'Dim Writer_txt As New IO.StreamWriter(WriteStream_txt)

    'Dim WriteStream_xls As New IO.FileStream(FileDir & AnalysisName & "-thermodynamics_alignments.xls", IO.FileMode.Create)
    'Dim Writer_xls As New IO.StreamWriter(WriteStream_xls)

    'Dim WriteString As String = ""


    'While Reader.Peek > -1
    'CurrentLine = Reader.ReadLine
    'Dim AlignmentList As List(Of OligoAlignment) = Nothing

    'If CurrentLine.StartsWith(">") Then 'This is fasta header
    'CurrentHeader = CurrentLine.Substring(1)
    'Writer_txt.WriteLine(CurrentHeader)

    'Else 'This is sequence


    'AlignmentList = Bioinformatics.CreateAlignedList_RNA(Bioinformatics.ReverseStrand(ReferenceString), Bioinformatics.DNA_To_RNA(CurrentLine), 37)

    'WriteString = CurrentHeader & Chr(9)

    'If AlignmentList.Count > 0 Then
    'Dim MinDGAlign As OligoAlignment = AlignmentList(0)
    'Dim MaxComplementAlign As OligoAlignment = AlignmentList(0)

    'Dim OptimalPositionAlign As OligoAlignment = AlignmentList(0)

    'For Each Alignment As OligoAlignment In AlignmentList
    'If Alignment.SumDG < MinDGAlign.SumDG Then
    'MinDGAlign = Alignment
    'End If

    'If Alignment.MaxComplement > MaxComplementAlign.MaxComplement Then
    'MaxComplementAlign = Alignment
    'End If

    'If Alignment.SumDG < OptimalPositionAlign.SumDG And Alignment.Fadd3 = 7 Then
    'OptimalPositionAlign = Alignment
    'End If


    'Next

    'WriteString &= MinDGAlign.SumDG & Chr(9) & MaxComplementAlign.MaxComplement & Chr(9) & MinDGAlign.Fadd3 & Chr(9) & MinDGAlign.Fadd5 & Chr(9) & MaxComplementAlign.Fadd3 & Chr(9) & MaxComplementAlign.Fadd5 & Chr(9) & OptimalPositionAlign.SumDG
    'Writer_txt.WriteLine("Min dG")
    'Writer_txt.WriteLine("dG=" & MinDGAlign.SumDG)
    'Writer_txt.WriteLine("Max aligned=" & MinDGAlign.MaxComplement)
    'Writer_txt.WriteLine(MinDGAlign.ForSeq)
    'Writer_txt.WriteLine(MinDGAlign.MatchSeq)
    'Writer_txt.WriteLine(MinDGAlign.RevSeq)
    'Writer_txt.WriteLine()
    'Writer_txt.WriteLine("Max complement")
    'Writer_txt.WriteLine("dG=" & MaxComplementAlign.SumDG)
    'Writer_txt.WriteLine("Max aligned=" & MaxComplementAlign.MaxComplement)
    'Writer_txt.WriteLine(MaxComplementAlign.ForSeq)
    'Writer_txt.WriteLine(MaxComplementAlign.MatchSeq)
    'Writer_txt.WriteLine(MaxComplementAlign.RevSeq)

    'Else

    'WriteString &= "no alignments were found"
    'Writer_txt.WriteLine("no alignments were found")
    'End If

    'Writer_xls.WriteLine(WriteString)

    'Writer_txt.WriteLine()
    'Writer_txt.WriteLine("-----------------------------------------------")
    'Writer_txt.WriteLine()

    'End If


    'End While



    'Writer_xls.Close()
    'WriteStream_xls.Close()
    'Writer_xls.Dispose()
    'WriteStream_xls.Dispose()


    'Writer_txt.Close()
    'WriteStream_txt.Close()
    'Writer_txt.Dispose()
    'WriteStream_txt.Dispose()

    'Reader.Close()
    'ReadStream.Close()
    'Reader.Dispose()
    'ReadStream.Dispose()

    'End If
    'End Sub
    '/////////////////////////////





   
End Class