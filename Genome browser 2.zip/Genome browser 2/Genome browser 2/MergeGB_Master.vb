﻿Public Class MergeGB_Master


    Private Sub AddButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddButton.Click
        If Master.OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

            For Each File As String In Master.OpenFileDialog.FileNames
                GBFilesList.Items.Add(File)
            Next File

        End If
    End Sub

    Private Sub DeleteButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteButton.Click

        For i = GBFilesList.SelectedItems.Count - 1 To 0 Step -1
            GBFilesList.Items.Remove(GBFilesList.SelectedItems(i))
        Next i

    End Sub

    Private Sub DeleteAllButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteAllButton.Click
        GBFilesList.Items.Clear()
    End Sub

    Private Sub UpButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpButton.Click
        Try

            Dim SelectedIndex As Integer = GBFilesList.SelectedIndex
            Dim SelectedItem As String = GBFilesList.SelectedItem
            If SelectedIndex = 0 Then
                Exit Sub
            End If
            GBFilesList.Items.RemoveAt(SelectedIndex)
            GBFilesList.Items.Insert(SelectedIndex - 1, SelectedItem)
            GBFilesList.SelectedIndices.Add(SelectedIndex - 1)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub DownButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DownButton.Click
        Try

            Dim SelectedIndex As Integer = GBFilesList.SelectedIndex
            Dim SelectedItem As String = GBFilesList.SelectedItem
            If SelectedIndex = GBFilesList.Items.Count - 1 Then
                Exit Sub
            End If
            GBFilesList.Items.RemoveAt(SelectedIndex)
            GBFilesList.Items.Insert(SelectedIndex + 1, SelectedItem)
            GBFilesList.SelectedIndices.Add(SelectedIndex + 1)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub MergeButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MergeButton.Click

        If Master.SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then



            Dim MergedAnnotation As New List(Of Genome_Feature)
            Dim MergedSequence As String = ""
            Dim MergeMarker As String = MergeMarkerTextBox.Text
            Dim CoordShift As Integer = 0


            Dim CurrentAnnotation As List(Of Genome_Feature) = Nothing
            Dim CurrentSequence As String = ""


            For Each File As String In GBFilesList.Items
                CurrentAnnotation = DataIO.ParseGBAnnotation(File)
                CurrentSequence = DataIO.ReadGBFileToSequence(File)

                If Not CurrentSequence = "" Then


                    For Each Feature As Genome_Feature In CurrentAnnotation
                        Feature.AbsoluteStart += CoordShift
                        Feature.AbsoluteEnd += CoordShift
                        MergedAnnotation.Add(Feature)
                    Next Feature


                    MergedSequence &= CurrentSequence & MergeMarker


                    CoordShift += CurrentSequence.Length + MergeMarker.Length


                End If

            Next File

            DataIO.WriteSequence(MergedSequence, Master.SaveFileDialog.FileName)
            DataIO.WriteAnnotation(MergedAnnotation, Master.SaveFileDialog.FileName, False, TranslateComboBox.Text.Split("-")(0), , , SystemProgressBarBox)

            Try
                Master.OpenFile(String.Concat(Master.SaveFileDialog.FileName, ".fasta"))
            Catch ex As Exception
                MsgBox("Failed to open merged file!")
            End Try

        End If
    End Sub

 
    Private Sub MergeGB_Master_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim chk As Boolean = True
        For Each Row As DataRow In Master.CodeNamesList.Rows
            TranslateComboBox.Items.Add(Row.Item(0) & "-" & Row.Item(1))
            If chk Then
                TranslateComboBox.Text = Row.Item(0) & "-" & Row.Item(1)
                chk = False
            End If
        Next Row
    End Sub
End Class