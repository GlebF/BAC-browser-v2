﻿Public Class K_Word_Thermodynamics
    Inherits K_Word
    Private sglDG As Single
    Private sglSelfDG As Single
    Private intOverlap As Integer
    Private sglDGDifference As Single
    Private bIsBlocked As Boolean
    Private strSeqName As String = ""

    Public Property SeqName() As String
        Get
            SeqName = strSeqName
        End Get
        Set(ByVal value As String)
            strSeqName = value
        End Set
    End Property

    Public Property IsBlocked() As Boolean
        Get
            IsBlocked = bIsBlocked
        End Get
        Set(ByVal value As Boolean)
            bIsBlocked = value
        End Set
    End Property

    Public Property DG() As Single
        Get
            DG = sglDG
        End Get
        Set(ByVal value As Single)
            sglDG = value
        End Set
    End Property

    Public Property DGDifference() As Single
        Get
            DGDifference = sglDGDifference
        End Get
        Set(ByVal value As Single)
            sglDGDifference = value
        End Set
    End Property

    Public Property SelfDG() As Single
        Get
            SelfDG = sglSelfDG
        End Get
        Set(ByVal value As Single)
            sglSelfDG = value
        End Set
    End Property

    Public Property Overlap() As Integer
        Get
            Overlap = intOverlap
        End Get
        Set(ByVal value As Integer)
            intOverlap = value
        End Set
    End Property
End Class
