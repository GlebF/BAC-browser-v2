﻿Public Class MBMD_Result 'Motiff search result

    Private MotifHits As New List(Of K_Word_PWM_Hit)
    Private sglWeight As Single
    Private OriginalPWM As New PWM
    Private bBlocked As Boolean = False

    Public Property Weight() As Single
        Get
            Weight = sglWeight
        End Get
        Set(ByVal value As Single)
            sglWeight = value
        End Set
    End Property

    Public Property Motif_Hits() As List(Of K_Word_PWM_Hit)
        Get
            Motif_Hits = MotifHits
        End Get
        Set(ByVal value As List(Of K_Word_PWM_Hit))
            MotifHits = value
        End Set
    End Property

    Public Property Original_PWM() As PWM
        Get
            Original_PWM = OriginalPWM
        End Get
        Set(ByVal value As PWM)
            OriginalPWM = value
        End Set
    End Property

    Public Property Blocked() As Boolean
        Get
            Blocked = bBlocked
        End Get
        Set(ByVal value As Boolean)
            bBlocked = value
        End Set
    End Property

End Class
