﻿Public Class K_Word_WW
    Inherits K_Word_Weighted
    'This K-Word stores additional experimaental values for promoter activities

    Private listPeakData As New List(Of Single) 'Peaks for all experimental samples
    Private listBackgroundData As New List(Of Single) 'Background for all experimental samples
    Private listBestHitPos As New List(Of Integer) 'List of peak coordinates to control TSS position

    Public Property BestPos() As List(Of Integer)
        Get
            BestPos = listBestHitPos
        End Get
        Set(ByVal value As List(Of Integer))
            listBestHitPos = value
        End Set
    End Property

    Public Property PeakData() As List(Of Single)
        Get
            PeakData = listPeakData
        End Get
        Set(ByVal value As List(Of Single))
            listPeakData = value
        End Set
    End Property

    Public Property BackgroundData() As List(Of Single)
        Get
            BackgroundData = listBackgroundData
        End Get
        Set(ByVal value As List(Of Single))
            listBackgroundData = value
        End Set
    End Property

End Class
