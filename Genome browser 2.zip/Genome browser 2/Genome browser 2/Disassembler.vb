﻿Public Class Disassembler

    Public MyGenomeViewer As Genome_Viewer
    Public SeqMode As Boolean = False
    Public StartPos As Integer = 0
    Public EndPos As Integer = 0
    Public dGDistributionChart As ChartDisplay = Nothing
    Public SeqProfileChart As ChartDisplay = Nothing
    Public TmDistributionChart As ChartDisplay = Nothing

    Public AttemptCounter As Integer = 0


    Public Sub CheckAccess()

        OligoMaxTextBox.Enabled = GappedRadioButton.Checked
        OligoMaxTextBox.Visible = GappedRadioButton.Visible
        MaxOligoLabel.Visible = GappedRadioButton.Visible


        MaxOligosNumRadioButton.Enabled = UngappedRadioButton.Checked
        MaxOligosPerFragmentTextBox.Enabled = UngappedRadioButton.Checked

        AutoFragLengthRadioButton.Enabled = UniversalSplitRadioButton.Checked
        FragLTextBox.Enabled = UniversalSplitRadioButton.Checked
        TmMinTextBox.Enabled = UniversalSplitRadioButton.Checked
        TmMaxTextBox.Enabled = UniversalSplitRadioButton.Checked
        MinLTextBox.Enabled = UniversalSplitRadioButton.Checked
        MaxLTextBox.Enabled = UniversalSplitRadioButton.Checked
        AutoPrimersComboBox.Enabled = UniversalSplitRadioButton.Checked
        AutoPrimersCheckBox.Enabled = UniversalSplitRadioButton.Checked


        If MaxOligosNumRadioButton.Enabled = False Then
            MaxOligosNumRadioButton.Checked = False
            AutoFragDisabledRadioButton.Checked = True
        End If
        If AutoFragLengthRadioButton.Enabled = False Then
            AutoFragLengthRadioButton.Checked = False
            AutoFragDisabledRadioButton.Checked = True
        End If

        RegularGroupBox.Enabled = RegularRadioButton.Checked

        SpacerLengthTextBox.Enabled = UniversalSplitRadioButton.Checked

        dG_RangeTextBox.Enabled = UngappedRadioButton.Checked

        AsmGroupBox.Enabled = Not RegularRadioButton.Checked
        FragGroupBox.Enabled = Not RegularRadioButton.Checked

        'UniversalSplitRadioButton.Checked = AutoFragLengthRadioButton.Checked
    End Sub

    Private Sub SortOligos(ByRef OligoList As List(Of Genome_Feature))
        Dim Tmp As Genome_Feature = Nothing
        For i = 1 To OligoList.Count - 1
            For j = 0 To OligoList.Count - 1 - i
                If OligoList(j).AbsoluteStart > OligoList(j + 1).AbsoluteStart Then
                    Tmp = OligoList(j)
                    OligoList(j) = OligoList(j + 1)
                    OligoList(j + 1) = Tmp
                End If
            Next
        Next

    End Sub

    Private Sub DesignAssembly(Optional ByVal MaxOligosPerFragment = 0)
        Static Number As Integer = 0

        ReportTextBox.Text = ""

        Dim SeqName As String = ""
        If SeqNameTextBox.Text = "" Then
            SeqName = ""
        Else
            SeqName = SeqNameTextBox.Text & "_"
        End If

        Dim AssemblySet As New FeaturesAssembly
        AssemblySet.AssemblyName = "Assembly set " & Number

        If RegularRadioButton.Checked Then
            If SeqMode Then
                AssemblySet.FeaturesList = Bioinformatics.RegularDisassembly(LengthTextBox.Text, OverlapTextBox.Text, StartPos, EndPos)
            Else
                AssemblySet.FeaturesList = Bioinformatics.RegularDisassembly(LengthTextBox.Text, OverlapTextBox.Text, 1, MyGenomeViewer.Genome_Sequence.Length)
            End If
        ElseIf UngappedRadioButton.Checked Then


            If Not SeqMode Then
                StartPos = 1
                EndPos = MyGenomeViewer.Genome_Sequence.Length
            End If

            Dim Oligo_C As Single = CType(OligoCTextBox.Text, Single)
            Dim Mg_C As Single = CType(MgCTextBox.Text, Single)
            Dim Na_C As Single = CType(NaCTextBox.Text, Single)



            Dim dG_list As New List(Of Single)
            Dim Prescan_dG_Profile As New List(Of Single)
            Dim Tm_List As New List(Of Single)

            Dim SegmentSet As New FeaturesAssembly
            SegmentSet.AssemblyName = "Segments: " & Number
            SegmentSet.FeaturesList = Bioinformatics.SegmentedTmDisassembly(MyGenomeViewer.Genome_Sequence, StartPos, EndPos, AvLengthTextBox.Text, RangeTextBox.Text, TmTextBox.Text, dG_RangeTextBox.Text, Oligo_C, Mg_C, Na_C, dG_list, Prescan_dG_Profile, Tm_List)

            dGDistributionChart.Chart_Draw_Mode = 0
            dGDistributionChart.Chart_Color = Color.Green
            dGDistributionChart.ChartValues = dG_list
            dGDistributionChart.Invalidate()

            SeqProfileChart.Chart_Draw_Mode = 1
            SeqProfileChart.Chart_Color = Color.Gray
            SeqProfileChart.ChartValues = Prescan_dG_Profile
            SeqProfileChart.Invalidate()

            TmDistributionChart.Chart_Draw_Mode = 0
            TmDistributionChart.Chart_Color = Color.Orange
            TmDistributionChart.ChartValues = Tm_List
            TmDistributionChart.Invalidate()


            If Not PrescanModeCheckBox.Checked Then 'Form oligos from sticky segments


                For Each Segment As Genome_Feature In SegmentSet.FeaturesList
                    Segment.Group = SegmentSet.AssemblyName
                Next Segment


                If ShowSegmentsCheckBox.Checked Then
                    SegmentSet.Visible = True
                    MyGenomeViewer.Features_Groups_List.Add(SegmentSet)
                    MyGenomeViewer.FeaturesGroupsListBox.Items.Add(SegmentSet.AssemblyName)
                    MyGenomeViewer.FeaturesGroupsListBox.Items(MyGenomeViewer.FeaturesGroupsListBox.Items.Count - 1).Checked = True
                End If

                'Assemble oligos from segments

                'Assemble plus strand

                Dim CurrentIndex As Integer = 0
                Dim EndIndex As Integer = 0
                Dim MaxIndex As Integer = SegmentSet.FeaturesList.Count - 1
                Dim SegPerOligo As Integer = 1 'CType(SegPerOligoTextBox.Text, Integer) - 1
                Dim OligoNumber As Integer = 0

                Do

                    EndIndex = CurrentIndex + SegPerOligo

                    If EndIndex > MaxIndex Then
                        'Add last segments to oligo
                        Dim NewOligo As New Genome_Feature()
                        NewOligo.AbsoluteStart = SegmentSet.FeaturesList(CurrentIndex).AbsoluteStart
                        NewOligo.AbsoluteEnd = SegmentSet.FeaturesList(SegmentSet.FeaturesList.Count - 1).AbsoluteEnd
                        NewOligo.Direction = 1
                        NewOligo.Type = 8
                        NewOligo.TAG = "Oligo" & OligoNumber
                        NewOligo.Name = NewOligo.TAG
                        NewOligo.Group = AssemblySet.AssemblyName
                        OligoNumber += 1
                        AssemblySet.FeaturesList.Add(NewOligo)

                        'If this is a short segment, add it to previous assembly
                        'Maybe not important

                        Exit Do

                    Else

                        'Join segments
                        Dim NewOligo As New Genome_Feature()
                        NewOligo.AbsoluteStart = SegmentSet.FeaturesList(CurrentIndex).AbsoluteStart
                        NewOligo.AbsoluteEnd = SegmentSet.FeaturesList(EndIndex).AbsoluteEnd
                        NewOligo.Direction = 1
                        NewOligo.Type = 8
                        NewOligo.TAG = "Oligo" & OligoNumber
                        NewOligo.Name = NewOligo.TAG
                        NewOligo.Group = AssemblySet.AssemblyName
                        OligoNumber += 1
                        AssemblySet.FeaturesList.Add(NewOligo)

                    End If


                    CurrentIndex = EndIndex + 1

                    If CurrentIndex > MaxIndex Then
                        Exit Do
                    End If

                Loop


                'Assemble minus strand

                CurrentIndex = 1


                Dim FirstOligo As New Genome_Feature()
                FirstOligo.AbsoluteStart = SegmentSet.FeaturesList(0).AbsoluteStart
                FirstOligo.AbsoluteEnd = SegmentSet.FeaturesList(0).AbsoluteEnd
                FirstOligo.Direction = 2
                FirstOligo.Type = 8
                FirstOligo.TAG = "Oligo" & OligoNumber
                FirstOligo.Name = FirstOligo.TAG
                FirstOligo.Group = AssemblySet.AssemblyName
                OligoNumber += 1
                AssemblySet.FeaturesList.Add(FirstOligo)



                Do
                    EndIndex = CurrentIndex + SegPerOligo

                    If EndIndex > MaxIndex Then
                        'Add last segments to oligo
                        Dim NewOligo As New Genome_Feature()
                        NewOligo.AbsoluteStart = SegmentSet.FeaturesList(CurrentIndex).AbsoluteStart
                        NewOligo.AbsoluteEnd = SegmentSet.FeaturesList(SegmentSet.FeaturesList.Count - 1).AbsoluteEnd
                        NewOligo.Direction = 2
                        NewOligo.Type = 8
                        NewOligo.TAG = "Oligo" & OligoNumber
                        NewOligo.Name = NewOligo.TAG
                        NewOligo.Group = AssemblySet.AssemblyName
                        OligoNumber += 1
                        AssemblySet.FeaturesList.Add(NewOligo)

                        'If this is a short segment, add it to previous assembly
                        'Maybe not important

                        Exit Do

                    Else

                        'Join segments
                        Dim NewOligo As New Genome_Feature()
                        NewOligo.AbsoluteStart = SegmentSet.FeaturesList(CurrentIndex).AbsoluteStart
                        NewOligo.AbsoluteEnd = SegmentSet.FeaturesList(EndIndex).AbsoluteEnd
                        NewOligo.Direction = 2
                        NewOligo.Type = 8
                        NewOligo.TAG = "Oligo" & OligoNumber
                        NewOligo.Name = NewOligo.TAG
                        NewOligo.Group = AssemblySet.AssemblyName
                        OligoNumber += 1
                        AssemblySet.FeaturesList.Add(NewOligo)

                    End If


                    CurrentIndex = EndIndex + 1

                    If CurrentIndex > MaxIndex Then
                        Exit Do
                    End If


                Loop
            End If 'PrescanModeCheckBox.Checked

        ElseIf GappedRadioButton.Checked Then 'PCR assembly with gaps

            If Not SeqMode Then
                StartPos = 1
                EndPos = MyGenomeViewer.Genome_Sequence.Length
            End If

            Dim Oligo_C As Single = CType(OligoCTextBox.Text, Single)
            Dim Mg_C As Single = CType(MgCTextBox.Text, Single)
            Dim Na_C As Single = CType(NaCTextBox.Text, Single)


            Dim dG_list As New List(Of Single)
            Dim Prescan_dG_Profile As New List(Of Single)
            Dim Tm_List As New List(Of Single)


            Dim SegmentSet As New FeaturesAssembly
            SegmentSet.AssemblyName = "Segments: " & Number
            SegmentSet.FeaturesList = Bioinformatics.PCRDisassembly(MyGenomeViewer.Genome_Sequence, StartPos, EndPos, AvLengthTextBox.Text, RangeTextBox.Text, OligoMaxTextBox.Text, TmTextBox.Text, dG_RangeTextBox.Text, Oligo_C, Mg_C, Na_C, dG_list, Prescan_dG_Profile, Tm_List, True)

            'Shift the end of the last segment to the end of sequence
            SegmentSet.FeaturesList(SegmentSet.FeaturesList.Count - 1).AbsoluteEnd = EndPos


            dGDistributionChart.Chart_Draw_Mode = 0
            dGDistributionChart.Chart_Color = Color.Green
            dGDistributionChart.ChartValues = dG_list
            dGDistributionChart.Invalidate()

            SeqProfileChart.Chart_Draw_Mode = 1
            SeqProfileChart.Chart_Color = Color.Gray
            SeqProfileChart.ChartValues = Prescan_dG_Profile
            SeqProfileChart.Invalidate()

            TmDistributionChart.Chart_Draw_Mode = 0
            TmDistributionChart.Chart_Color = Color.Orange
            TmDistributionChart.ChartValues = Tm_List
            TmDistributionChart.Invalidate()

            If Not PrescanModeCheckBox.Checked Then 'Form oligos from sticky segments



                For Each Segment As Genome_Feature In SegmentSet.FeaturesList
                    Segment.Group = SegmentSet.AssemblyName
                Next Segment


                If ShowSegmentsCheckBox.Checked Then
                    SegmentSet.Visible = True
                    MyGenomeViewer.Features_Groups_List.Add(SegmentSet)
                    MyGenomeViewer.FeaturesGroupsListBox.Items.Add(SegmentSet.AssemblyName)
                    MyGenomeViewer.FeaturesGroupsListBox.Items(MyGenomeViewer.FeaturesGroupsListBox.Items.Count - 1).Checked = True
                End If
            End If 'Not PrescanModeCheckBox.Checked

            'Assemble oligos from segments

            Dim StartIndex As Integer = 0
            Dim EndIndex As Integer = 1
            Dim MaxIndex As Integer = SegmentSet.FeaturesList.Count - 1
            Dim OligoNumber As Integer = 0

            'Plus strand
            Do

                'If StartIndex > MaxIndex Then
                '    Exit Do
                'End If

                If EndIndex > MaxIndex Then
                    Exit Do
                End If

                'Join segments
                Dim NewOligo As New Genome_Feature()
                NewOligo.AbsoluteStart = SegmentSet.FeaturesList(StartIndex).AbsoluteStart
                NewOligo.AbsoluteEnd = SegmentSet.FeaturesList(EndIndex).AbsoluteEnd
                NewOligo.Direction = 1
                NewOligo.Type = 8
                NewOligo.TAG = "Oligo" & OligoNumber
                NewOligo.Name = NewOligo.TAG
                NewOligo.Group = AssemblySet.AssemblyName
                OligoNumber += 1
                AssemblySet.FeaturesList.Add(NewOligo)

                'Join two adjacent segments
                StartIndex += 2
                EndIndex += 2
            Loop


            'Minus strand
            StartIndex = 1
            EndIndex = 2
            Do

                'If StartIndex > MaxIndex Then
                '    Exit Do
                'End If

                If EndIndex > MaxIndex Then
                    Exit Do
                End If

                'Join segments
                Dim NewOligo As New Genome_Feature()
                NewOligo.AbsoluteStart = SegmentSet.FeaturesList(StartIndex).AbsoluteStart
                NewOligo.AbsoluteEnd = SegmentSet.FeaturesList(EndIndex).AbsoluteEnd
                NewOligo.Direction = 2
                NewOligo.Type = 8
                NewOligo.TAG = "Oligo" & OligoNumber
                NewOligo.Name = NewOligo.TAG
                NewOligo.Group = AssemblySet.AssemblyName
                OligoNumber += 1
                AssemblySet.FeaturesList.Add(NewOligo)

                'Join two adjacent segments
                StartIndex += 2
                EndIndex += 2
            Loop

            Dim MaxLength As Integer = AssemblySet.FeaturesList(0).AbsoluteEnd - AssemblySet.FeaturesList(0).AbsoluteStart + 1
            Dim MinLength As Integer = AssemblySet.FeaturesList(0).AbsoluteEnd - AssemblySet.FeaturesList(0).AbsoluteStart + 1
            Dim OligoL As Integer = 0
            Dim AvLength As Integer = 0

            For Each Oligo As Genome_Feature In AssemblySet.FeaturesList
                OligoL = Oligo.AbsoluteEnd - Oligo.AbsoluteStart + 1
                AvLength += OligoL
                If OligoL > MaxLength Then
                    MaxLength = OligoL
                End If
                If OligoL < MinLength Then
                    MinLength = OligoL
                End If
            Next Oligo

            ReportTextBox.Text &= vbNewLine & "Nucleotides: " & AvLength

            AvLength /= AssemblySet.FeaturesList.Count

            ReportTextBox.Text &= vbNewLine & "Minimum oligo length: " & MinLength & vbNewLine & "Maximum oligo length: " & MaxLength & vbNewLine & "Average oligo length: " & AvLength & vbNewLine & "Total oligos: " & AssemblySet.FeaturesList.Count


        End If


        'Sort oligos by start
        SortOligos(AssemblySet.FeaturesList)
        For i = 0 To AssemblySet.FeaturesList.Count - 1
            AssemblySet.FeaturesList(i).Name = "Oligo" & i
            AssemblySet.FeaturesList(i).TAG = SeqName & AssemblySet.FeaturesList(i).Name
        Next i


        If Not PrescanModeCheckBox.Checked Then

            If MaxOligosPerFragment > 0 Then

                'Find optimal number of oligos per fragment

                Dim FragmentsOK As Boolean = False
                Dim FragmentNumber As Single = 0
                Dim CompleteFragmentNumber As Single = 0
                Dim RemOlig As Single = 0
                Dim LastOligos As Integer = 0

                Do
                    'Identify the number of fragment
                    FragmentNumber = AssemblySet.FeaturesList.Count / MaxOligosPerFragment
                    CompleteFragmentNumber = Math.Floor(AssemblySet.FeaturesList.Count / MaxOligosPerFragment)
                    RemOlig = FragmentNumber - CompleteFragmentNumber
                    LastOligos = AssemblySet.FeaturesList.Count - CompleteFragmentNumber * MaxOligosPerFragment

                    'MsgBox("Fragments: " & FragmentNumber & vbNewLine & _
                    '       "Complete: " & CompleteFragmentNumber & vbNewLine & _
                    '       "Remaining: " & RemOlig & vbNewLine & _
                    '       "Oligos left: " & LastOligos)

                    If LastOligos <= 3 Then
                        FragmentsOK = True
                    End If


                    If RemOlig >= 0.4 Then
                        FragmentsOK = True
                    End If

                    If FragmentsOK Then
                        Exit Do
                    Else
                        MaxOligosPerFragment -= 1
                    End If

                Loop


                'Rename oligos according to fragments
                Dim CurrentOligoIndex = 1
                Dim FragmentCounter As Integer = 1
                'Dim FirstOligoInFragment As Boolean = True
                Dim LastOligoInFragment As Boolean = False

                For Each Oligo As Genome_Feature In AssemblySet.FeaturesList

                    Oligo.TAG = SeqName & "F" & FragmentCounter & "_" & Oligo.TAG
                    Oligo.Name = "F" & FragmentCounter & "_" & Oligo.TAG


                    CurrentOligoIndex += 1
                    If CurrentOligoIndex > MaxOligosPerFragment Then

                        If Oligo.Direction = 1 Then


                        ElseIf Oligo.Direction = 2 Then
                            LastOligoInFragment = True

                        End If


                    End If


                    If LastOligoInFragment Then
                        FragmentCounter += 1
                        CurrentOligoIndex = 1
                        LastOligoInFragment = False
                    End If

                Next Oligo



            End If



            AssemblySet.Visible = True

            MyGenomeViewer.Features_Groups_List.Add(AssemblySet)
            MyGenomeViewer.FeaturesGroupsListBox.Items.Add(AssemblySet.AssemblyName)
            MyGenomeViewer.FeaturesGroupsListBox.Items(MyGenomeViewer.FeaturesGroupsListBox.Items.Count - 1).Checked = True


            Number += 1
        End If

    End Sub

    Private Sub DesignAssemblyUniversal()

        ReportTextBox.Text = ""
        ReportLabel.Text = "Designing fragments..."
        ReportLabel.Refresh()

        Dim TargetFragmentLength As Integer = CType(FragLTextBox.Text, Integer)
        Dim MaxFragmentOverlap As Integer = CType(MaxLTextBox.Text, Integer)
        Dim MinFragmentOverlap As Integer = CType(MinLTextBox.Text, Integer)
        Dim MinFragmentTm As Integer = CType(TmMinTextBox.Text, Single)
        Dim MaxFragmentTm As Integer = CType(TmMaxTextBox.Text, Single)


        Dim Assembly_T As Single = CType(TmTextBox.Text, Single)
        Dim SegmentLength As Integer = CType(AvLengthTextBox.Text, Integer)
        Dim SegmentVar As Integer = CType(RangeTextBox.Text, Integer)
        Dim Oligo_C As Single = CType(OligoCTextBox.Text, Single)
        Dim Mg_C As Single = CType(MgCTextBox.Text, Single)
        Dim Na_C As Single = CType(NaCTextBox.Text, Single)
        Dim dNTP_C As Single = CType(dNTPCTextBox.Text, Single)
        Dim SpacerLength As Integer = CType(SpacerLengthTextBox.Text, Single)

        Dim SeqName As String = ""
        If SeqNameTextBox.Text = "" Then
            SeqName = ""
        Else
            SeqName = SeqNameTextBox.Text & "_"
        End If

        Dim TargetSequence As String = ""
        If SeqMode Then
            TargetSequence = DataIO.RetrieveSeqFromCache(MyGenomeViewer.Genome_Sequence, StartPos, EndPos)
        Else
            TargetSequence = MyGenomeViewer.Genome_Sequence
        End If



        AttemptCounter += 1
        Dim Fragments As List(Of Genome_Feature) = _
        Bioinformatics.DesignFragments(TargetSequence, _
        TargetFragmentLength, _
        MaxFragmentOverlap, _
        MinFragmentOverlap, _
        MinFragmentTm, _
        MaxFragmentTm, _
        Oligo_C, _
        Mg_C, _
        Na_C, _
        dNTP_C, _
        , ReportTextBox, , AutoFragDisabledRadioButton.Checked)


        Dim Segments_Set As New FeaturesAssembly
        Segments_Set.AssemblyName = "Segments-" & AttemptCounter

        Dim Oligo_Set As New FeaturesAssembly
        Oligo_Set.AssemblyName = "Oligos-" & AttemptCounter

        If Not PrescanModeCheckBox.Checked Then
            If ShowSegmentsCheckBox.Checked Then
                Dim Fragments_Set As New FeaturesAssembly
                Fragments_Set.AssemblyName = "Fragments-" & AttemptCounter
                Fragments_Set.FeaturesList = Fragments
                For Each Frag As Genome_Feature In Fragments_Set.FeaturesList
                    Frag.Group = Fragments_Set.AssemblyName
                    If SeqMode Then
                        Frag.AbsoluteStart += StartPos - 1
                        Frag.AbsoluteEnd += StartPos - 1
                    End If
                Next Frag
                Fragments_Set.Visible = True
                MyGenomeViewer.Features_Groups_List.Add(Fragments_Set)
                MyGenomeViewer.FeaturesGroupsListBox.Items.Add(Fragments_Set.AssemblyName)
                MyGenomeViewer.FeaturesGroupsListBox.Items(MyGenomeViewer.FeaturesGroupsListBox.Items.Count - 1).Checked = True
            End If
        End If





        Dim Seq_dG_Distribution As New List(Of Single)
        Dim Oligo_dG_Distribution As New List(Of Single)
        Dim Oligo_Tm_Distribution As New List(Of Single)

        Dim AutoPrimers As New List(Of Genome_Feature)


        Dim Target_dG As Single = Bioinformatics.GetTarget_dG(TargetSequence, SegmentLength, Assembly_T, Seq_dG_Distribution, )

        Dim TailName As String = ""
        Dim TailF As String = ""
        Dim TailR As String = ""
        Dim Add_Overlap As Boolean = False

        Select Case AutoPrimersComboBox.Text
            Case "None"

            Case "pTZ(Recombination_F)"
                TailName = "pTZ/F"
                TailF = "CGACGGGCCCGGGATCCGAT"
                TailR = "CCTCGCGAATGCATCTAGAT"
            Case "pTZ(Recombination_R)"
                TailName = "pTZ/R"
                TailF = "CCTCGCGAATGCATCTAGAT"
                TailR = "CGACGGGCCCGGGATCCGAT"
            Case "pET(BamHI/SalI)"
                TailName = "B/S"
                TailF = "TATAGGATCC"
                TailR = "TATAGTCGAC"
            Case "pET(BamHI/XhoI)"
                TailName = "B/X"
                TailF = "TATAGGATCC"
                TailR = "TATACTCGAG"

            Case "pTZ+overlap"
                TailName = "pTZ/F"
                TailF = "CGACGGGCCCGGGATCCGAT"
                TailR = "CCTCGCGAATGCATCTAGAT"
                Add_Overlap = True

        End Select

        Dim CurrentSeq As String = ""
        For Each F As Genome_Feature In Fragments

            ReportLabel.Text = "Designing oligos for the fragment: " & F.TAG & " of " & Fragments.Count
            ReportLabel.Refresh()

            CurrentSeq = F.Sequence 'DataIO.RetrieveSeqFromCache(TargetSequence, F.AbsoluteStart, F.AbsoluteEnd)
            'Target_dG = Bioinformatics.GetTarget_dG(CurrentSeq, SegmentLength, Assembly_T, , )


            Dim Local_Seq_dG_Distribution As New List(Of Single)


            Dim Segments As List(Of Genome_Feature) = Nothing
            If Not PrescanModeCheckBox.Checked Then
                If ShowSegmentsCheckBox.Checked Then
                    Segments = New List(Of Genome_Feature)
                End If
            End If


            Dim Oligos As List(Of Genome_Feature)
            Oligos = _
            Bioinformatics.DesignOligos(CurrentSeq, Assembly_T, Target_dG, SegmentLength, SegmentVar, SpacerLength, Oligo_C, Mg_C, Na_C, dNTP_C, False, True, Local_Seq_dG_Distribution, Oligo_dG_Distribution, Oligo_Tm_Distribution, , Segments, F.TAG)



            If AutoPrimersCheckBox.Checked Then
                Dim Primers As Genome_Feature() = Bioinformatics.DesignPrimersForFragments(CurrentSeq, F.TAG, , , , TailName, TailF, TailR, Add_Overlap)

                For Each P As Genome_Feature In Primers
                    If Not IsNothing(P) Then
                        'Oligos.Add(P)
                        P.AbsoluteStart += F.AbsoluteStart - 1
                        P.AbsoluteEnd += F.AbsoluteStart - 1
                        P.TAG = SeqName & P.TAG
                        AutoPrimers.Add(P)
                    End If
                Next P
            End If


            For Each Segment As Genome_Feature In Segments
                Segment.AbsoluteStart += F.AbsoluteStart - 1
                Segment.AbsoluteEnd += F.AbsoluteStart - 1
            Next Segment

            For Each Oligo As Genome_Feature In Oligos
                Oligo.AbsoluteStart += F.AbsoluteStart - 1
                Oligo.AbsoluteEnd += F.AbsoluteStart - 1
                Oligo.TAG = SeqName & Oligo.TAG
            Next Oligo

            If Not PrescanModeCheckBox.Checked Then

                If ShowSegmentsCheckBox.Checked Then
                    If Not IsNothing(Segments) Then
                        For Each Segment As Genome_Feature In Segments
                            Segments_Set.FeaturesList.Add(Segment)
                        Next Segment
                    End If
                End If

                For Each Oligo As Genome_Feature In Oligos
                    Oligo_Set.FeaturesList.Add(Oligo)
                Next Oligo

            End If

        Next F



        If AutoPrimersCheckBox.Checked Then
            Dim AutoPrimers_Set As New FeaturesAssembly
            AutoPrimers_Set.AssemblyName = "Primers-" & AttemptCounter
            AutoPrimers_Set.FeaturesList = AutoPrimers
            For Each Primer As Genome_Feature In AutoPrimers_Set.FeaturesList
                Primer.Group = AutoPrimers_Set.AssemblyName
            Next Primer
            AutoPrimers_Set.Visible = True
            MyGenomeViewer.Features_Groups_List.Add(AutoPrimers_Set)
            MyGenomeViewer.FeaturesGroupsListBox.Items.Add(AutoPrimers_Set.AssemblyName)
            MyGenomeViewer.FeaturesGroupsListBox.Items(MyGenomeViewer.FeaturesGroupsListBox.Items.Count - 1).Checked = True
        End If



        If Not PrescanModeCheckBox.Checked Then
            If ShowSegmentsCheckBox.Checked Then
                For Each Segment As Genome_Feature In Segments_Set.FeaturesList
                    Segment.Group = Segments_Set.AssemblyName
                Next Segment
                Segments_Set.Visible = True
                MyGenomeViewer.Features_Groups_List.Add(Segments_Set)
                MyGenomeViewer.FeaturesGroupsListBox.Items.Add(Segments_Set.AssemblyName)
                MyGenomeViewer.FeaturesGroupsListBox.Items(MyGenomeViewer.FeaturesGroupsListBox.Items.Count - 1).Checked = True
            End If

            For Each Oligo As Genome_Feature In Oligo_Set.FeaturesList
                Oligo.Group = Oligo_Set.AssemblyName
            Next Oligo
            Oligo_Set.Visible = True
            MyGenomeViewer.Features_Groups_List.Add(Oligo_Set)
            MyGenomeViewer.FeaturesGroupsListBox.Items.Add(Oligo_Set.AssemblyName)
            MyGenomeViewer.FeaturesGroupsListBox.Items(MyGenomeViewer.FeaturesGroupsListBox.Items.Count - 1).Checked = True
        End If

        Dim MaxOligo As Integer = 0
        Dim MinOligo As Integer = 1000
        Dim OligoLength As Integer = 0
        Dim SumOligo As Single = 0
        For Each Oligo As Genome_Feature In Oligo_Set.FeaturesList
            OligoLength = Oligo.AbsoluteEnd - Oligo.AbsoluteStart + 1
            SumOligo += OligoLength
            If OligoLength > MaxOligo Then
                MaxOligo = OligoLength
            End If

            If OligoLength < MinOligo Then
                MinOligo = OligoLength
            End If

        Next Oligo

        Dim Av As Single = SumOligo / Oligo_Set.FeaturesList.Count


        ReportTextBox.Text &= "Oligos number: " & Oligo_Set.FeaturesList.Count & vbNewLine & "Max length: " & MaxOligo & "; Min length: " & MinOligo & vbNewLine & "Average oligo length: " & Av & vbNewLine & "Nucleotides:" & SumOligo & "; % of total: " & Math.Round(SumOligo / (TargetSequence.Length * 2), 2) & vbNewLine

        'Draw charts
        dGDistributionChart.Chart_Draw_Mode = 0
        dGDistributionChart.Chart_Color = Color.Green
        dGDistributionChart.ChartValues = Oligo_dG_Distribution
        dGDistributionChart.Invalidate()

        TmDistributionChart.Chart_Draw_Mode = 0
        TmDistributionChart.Chart_Color = Color.Orange
        TmDistributionChart.ChartValues = Oligo_Tm_Distribution
        TmDistributionChart.Invalidate()

        SeqProfileChart.Chart_Draw_Mode = 1
        SeqProfileChart.Chart_Color = Color.Gray
        SeqProfileChart.ChartValues = Seq_dG_Distribution
        SeqProfileChart.Invalidate()

        ReportLabel.Text = ""
        ReportLabel.Refresh()

    End Sub

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click

        If RegularRadioButton.Checked Or UngappedRadioButton.Checked Or GappedRadioButton.Checked Then
            If AutoFragDisabledRadioButton.Checked Then
                DesignAssembly()
            ElseIf MaxOligosNumRadioButton.Checked Then
                DesignAssembly(CType(MaxOligosPerFragmentTextBox.Text, Integer))
            End If
        ElseIf UniversalSplitRadioButton.Checked Then

            DesignAssemblyUniversal()

        End If


    End Sub

    Private Sub Disassembler_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ReportLabel.Text = ""

        CheckAccess()

        dNTPCTextBox.Text = 0.2

        Dim dG_Chart As New ChartDisplay
        dG_Chart.Parent = DGGroupBox
        dG_Chart.Dock = DockStyle.Fill

        dGDistributionChart = dG_Chart

        Dim ProfileChart As New ChartDisplay
        ProfileChart.Parent = ProfileGroupBox
        ProfileChart.Dock = DockStyle.Fill

        SeqProfileChart = ProfileChart

        Dim Tm_Chart As New ChartDisplay
        Tm_Chart.Parent = TmGroupBox
        Tm_Chart.Dock = DockStyle.Fill

        TmDistributionChart = Tm_Chart

    End Sub

    Private Sub Disassembler_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        dGDistributionChart.Dispose()
        SeqProfileChart.Dispose()
        TmDistributionChart.Dispose()

    End Sub

    Private Sub RegularRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegularRadioButton.CheckedChanged
        CheckAccess()
    End Sub

    Private Sub UniversalSplitRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UniversalSplitRadioButton.CheckedChanged
        CheckAccess()
    End Sub

    Private Sub GappedRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GappedRadioButton.CheckedChanged
        CheckAccess()
    End Sub

    Private Sub UngappedRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UngappedRadioButton.CheckedChanged
        CheckAccess()
    End Sub

End Class