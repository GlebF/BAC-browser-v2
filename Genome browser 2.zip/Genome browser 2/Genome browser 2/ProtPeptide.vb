﻿Public Class ProtPeptide
    Private intAbsoluteStart As Integer = 0
    Private intAbsoluteEnd As Integer = 0
    Private bDirection As Short = 0
    Private strSeqAA As String = ""
    Private sglMW As Single = 0
    Private clsFeature As Genome_Feature = Nothing

    Public Property AbsoluteStart() As Integer
        Get
            AbsoluteStart = intAbsoluteStart
        End Get
        Set(ByVal value As Integer)
            intAbsoluteStart = value
        End Set
    End Property

    Public Property AbsoluteEnd() As Integer
        Get
            AbsoluteEnd = intAbsoluteEnd
        End Get
        Set(ByVal value As Integer)
            intAbsoluteEnd = value
        End Set
    End Property

    Public Property AA_Seq() As String
        Get
            AA_Seq = strSeqAA
        End Get
        Set(ByVal value As String)
            strSeqAA = value
        End Set
    End Property

    Public Property Pept_MW() As Single
        Get
            Pept_MW = sglMW
        End Get
        Set(ByVal value As Single)
            sglMW = value
        End Set
    End Property

    Public Property My_Feature() As Genome_Feature
        Get
            My_Feature = clsFeature
        End Get
        Set(ByVal value As Genome_Feature)
            clsFeature = value
        End Set
    End Property

    Public Property Direction() As Short
        Get
            Direction = bDirection
        End Get
        Set(ByVal value As Short)
            bDirection = value
        End Set
    End Property

    Public Sub New(ByVal AbsStart As Integer, ByVal AbsEnd As Integer, ByVal Dir As Short, ByVal SeqAA As String, ByVal MassTable As DataTable)
        intAbsoluteStart = AbsStart
        intAbsoluteEnd = AbsEnd
        bDirection = Dir
        strSeqAA = SeqAA
        sglMW = Bioinformatics.Calculate_Prot_Mass(strSeqAA, MassTable)

    End Sub

End Class
