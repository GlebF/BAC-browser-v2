﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Repeat_finder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.InvertedRepeatsRadioButton = New System.Windows.Forms.RadioButton
        Me.DirectRepeatsRadioButton = New System.Windows.Forms.RadioButton
        Me.RepLMinTextBox = New System.Windows.Forms.TextBox
        Me.RepLMaxTextBox = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.SpacerLMaxTextBox = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.SpacerLMinTextBox = New System.Windows.Forms.TextBox
        Me.SearchButton = New System.Windows.Forms.Button
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.MismatchesTextBox = New System.Windows.Forms.TextBox
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.InvertedRepeatsRadioButton)
        Me.GroupBox1.Controls.Add(Me.DirectRepeatsRadioButton)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(106, 76)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Repeats type"
        '
        'InvertedRepeatsRadioButton
        '
        Me.InvertedRepeatsRadioButton.AutoSize = True
        Me.InvertedRepeatsRadioButton.Checked = True
        Me.InvertedRepeatsRadioButton.Location = New System.Drawing.Point(6, 42)
        Me.InvertedRepeatsRadioButton.Name = "InvertedRepeatsRadioButton"
        Me.InvertedRepeatsRadioButton.Size = New System.Drawing.Size(64, 17)
        Me.InvertedRepeatsRadioButton.TabIndex = 1
        Me.InvertedRepeatsRadioButton.TabStop = True
        Me.InvertedRepeatsRadioButton.Text = "Inverted"
        Me.InvertedRepeatsRadioButton.UseVisualStyleBackColor = True
        '
        'DirectRepeatsRadioButton
        '
        Me.DirectRepeatsRadioButton.AutoSize = True
        Me.DirectRepeatsRadioButton.Location = New System.Drawing.Point(6, 19)
        Me.DirectRepeatsRadioButton.Name = "DirectRepeatsRadioButton"
        Me.DirectRepeatsRadioButton.Size = New System.Drawing.Size(53, 17)
        Me.DirectRepeatsRadioButton.TabIndex = 0
        Me.DirectRepeatsRadioButton.Text = "Direct"
        Me.DirectRepeatsRadioButton.UseVisualStyleBackColor = True
        '
        'RepLMinTextBox
        '
        Me.RepLMinTextBox.Location = New System.Drawing.Point(8, 39)
        Me.RepLMinTextBox.Name = "RepLMinTextBox"
        Me.RepLMinTextBox.Size = New System.Drawing.Size(30, 20)
        Me.RepLMinTextBox.TabIndex = 1
        Me.RepLMinTextBox.Text = "10"
        '
        'RepLMaxTextBox
        '
        Me.RepLMaxTextBox.Location = New System.Drawing.Point(44, 39)
        Me.RepLMaxTextBox.Name = "RepLMaxTextBox"
        Me.RepLMaxTextBox.Size = New System.Drawing.Size(30, 20)
        Me.RepLMaxTextBox.TabIndex = 3
        Me.RepLMaxTextBox.Text = "15"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.RepLMaxTextBox)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.RepLMinTextBox)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 94)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(106, 76)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Repeat length"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(44, 23)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(23, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "To:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(33, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "From:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.SpacerLMaxTextBox)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.SpacerLMinTextBox)
        Me.GroupBox3.Location = New System.Drawing.Point(124, 94)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(106, 76)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Spacer length"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(44, 23)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(23, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "To:"
        '
        'SpacerLMaxTextBox
        '
        Me.SpacerLMaxTextBox.Location = New System.Drawing.Point(44, 39)
        Me.SpacerLMaxTextBox.Name = "SpacerLMaxTextBox"
        Me.SpacerLMaxTextBox.Size = New System.Drawing.Size(30, 20)
        Me.SpacerLMaxTextBox.TabIndex = 3
        Me.SpacerLMaxTextBox.Text = "15"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(5, 23)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(33, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "From:"
        '
        'SpacerLMinTextBox
        '
        Me.SpacerLMinTextBox.Location = New System.Drawing.Point(8, 39)
        Me.SpacerLMinTextBox.Name = "SpacerLMinTextBox"
        Me.SpacerLMinTextBox.Size = New System.Drawing.Size(30, 20)
        Me.SpacerLMinTextBox.TabIndex = 1
        Me.SpacerLMinTextBox.Text = "10"
        '
        'SearchButton
        '
        Me.SearchButton.Location = New System.Drawing.Point(155, 176)
        Me.SearchButton.Name = "SearchButton"
        Me.SearchButton.Size = New System.Drawing.Size(75, 23)
        Me.SearchButton.TabIndex = 6
        Me.SearchButton.Text = "Search"
        Me.SearchButton.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.MismatchesTextBox)
        Me.GroupBox4.Location = New System.Drawing.Point(124, 12)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(106, 76)
        Me.GroupBox4.TabIndex = 8
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Mismatches"
        '
        'MismatchesTextBox
        '
        Me.MismatchesTextBox.Location = New System.Drawing.Point(8, 18)
        Me.MismatchesTextBox.Name = "MismatchesTextBox"
        Me.MismatchesTextBox.Size = New System.Drawing.Size(30, 20)
        Me.MismatchesTextBox.TabIndex = 4
        Me.MismatchesTextBox.Text = "1"
        '
        'Repeat_finder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(240, 216)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.SearchButton)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "Repeat_finder"
        Me.Text = "Repeat finder"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents InvertedRepeatsRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents DirectRepeatsRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents RepLMinTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RepLMaxTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents SpacerLMaxTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents SpacerLMinTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SearchButton As System.Windows.Forms.Button
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents MismatchesTextBox As System.Windows.Forms.TextBox
End Class
