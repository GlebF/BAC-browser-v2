﻿Public Class AddFeature
    Public MyParent As Genome_Viewer

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        Try

            If TagTextBox.Text = "" Then
                MsgBox("TAG field must not be empty! (Operation terminated)")
                Exit Sub
            End If

            For Each Feature As Genome_Feature In MyParent.Features_Groups_List(0).FeaturesList
                If Feature.TAG = TagTextBox.Text Then
                    MsgBox("This TAG already exists! (Operation terminated)")
                    Exit Sub
                End If
            Next

            Dim NewFeature As New Genome_Feature
            NewFeature.TAG = TagTextBox.Text
            NewFeature.Name = NameTextBox.Text
            NewFeature.Description = DescTextBox.Text
            NewFeature.AbsoluteStart = StartTextBox.Text
            NewFeature.AbsoluteEnd = EndTextBox.Text
            NewFeature.Orthology = OrthTextBox.Text
            NewFeature.Group = MyParent.MainFeaturesListName

            Select Case DirComboBox.Text
                Case "None"
                    NewFeature.Direction = 0
                Case "Plus"
                    NewFeature.Direction = 1
                Case "Minus"
                    NewFeature.Direction = 2
                Case "Symmetrical"
                    NewFeature.Direction = 3
                Case Else
                    NewFeature.Direction = 0
            End Select

            Select Case TypeComboBox.Text
                Case "ORF"
                    NewFeature.Type = 1
                Case "Structural RNA"
                    NewFeature.Type = 2
                Case "Antisense/Small RNA"
                    NewFeature.Type = 4
                Case "Regulatory sequence"
                    NewFeature.Type = 3
                Case "Transcription initiation site"
                    NewFeature.Type = 5
                Case "Transcription termination site"
                    NewFeature.Type = 6
                Case "Repeat"
                    NewFeature.Type = 9
                Case "User Feature"
                    NewFeature.Type = 10
                Case Else
                    NewFeature.Type = 10
            End Select


            If Not ReadTextBox.Text = "" Then
                Try
                    NewFeature.UseReadList = True
                    Dim RCItems As String() = ReadTextBox.Text.Split(",")
                    For Each RCItem As String In RCItems
                        NewFeature.ReadList.Add(New ReadItem(RCItem.Split("-")(0), RCItem.Split("-")(1)))
                    Next
                Catch ex As Exception
                    MsgBox("Wrong format of Read String! Segments must be separated by commas, Start and End positions must be separated by dashes.")
                    Exit Sub
                End Try
            End If


            MyParent.Features_Groups_List(0).FeaturesList.Add(NewFeature)
            MyParent.WriteFeatureRow(NewFeature, MyParent.FeaturesGroupDataGridView)
            MyParent.CountButton.Text = MyParent.FeaturesGroupDataGridView.Rows.Count - 1
            MyParent.DisplayFeatures()

            Dim HistoryRecord As String = "Add:" & NewFeature.TAG & "|Asm=" & MyParent.MainFeaturesListName
            MyParent.Features_History.Add(HistoryRecord)
            MyParent.Save_Required = True

            'MyParent.UndoButton.Enabled = True

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        TagTextBox.Text = ""
        NameTextBox.Text = ""
        DescTextBox.Text = ""
        StartTextBox.Text = ""
        EndTextBox.Text = ""
        DirComboBox.Text = ""
        TypeComboBox.Text = ""
        OrthTextBox.Text = ""

    End Sub

    Private Sub EscButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EscButton.Click
        Me.Close()
    End Sub
End Class