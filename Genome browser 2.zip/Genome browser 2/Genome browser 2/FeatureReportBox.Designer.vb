﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FeatureReportBox
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FeatureReportBox))
        Me.LocationTextBox = New System.Windows.Forms.TextBox
        Me.OrthologyLabel = New System.Windows.Forms.Label
        Me.OrthologyTextBox = New System.Windows.Forms.TextBox
        Me.DescriptionTextBox = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.LengthTextBox = New System.Windows.Forms.TextBox
        Me.StrandTextBox = New System.Windows.Forms.TextBox
        Me.NameTextBox = New System.Windows.Forms.TextBox
        Me.FeatureTextBox = New System.Windows.Forms.TextBox
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.FindButton = New System.Windows.Forms.ToolStripButton
        Me.FeatureSeqButton = New System.Windows.Forms.ToolStripButton
        Me.ToggleTranslationButton = New System.Windows.Forms.ToolStripButton
        Me.TuneButton = New System.Windows.Forms.ToolStripSplitButton
        Me.TGATGGToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GroupTextBox = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.AuxDataGridView = New System.Windows.Forms.DataGridView
        Me.HeaderCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ValueCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.ToolStrip1.SuspendLayout()
        CType(Me.AuxDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'LocationTextBox
        '
        Me.LocationTextBox.Location = New System.Drawing.Point(9, 162)
        Me.LocationTextBox.Name = "LocationTextBox"
        Me.LocationTextBox.ReadOnly = True
        Me.LocationTextBox.Size = New System.Drawing.Size(166, 20)
        Me.LocationTextBox.TabIndex = 24
        '
        'OrthologyLabel
        '
        Me.OrthologyLabel.AutoSize = True
        Me.OrthologyLabel.Location = New System.Drawing.Point(6, 113)
        Me.OrthologyLabel.Name = "OrthologyLabel"
        Me.OrthologyLabel.Size = New System.Drawing.Size(55, 13)
        Me.OrthologyLabel.TabIndex = 23
        Me.OrthologyLabel.Text = "Orthology:"
        '
        'OrthologyTextBox
        '
        Me.OrthologyTextBox.Location = New System.Drawing.Point(75, 110)
        Me.OrthologyTextBox.Name = "OrthologyTextBox"
        Me.OrthologyTextBox.ReadOnly = True
        Me.OrthologyTextBox.Size = New System.Drawing.Size(100, 20)
        Me.OrthologyTextBox.TabIndex = 22
        '
        'DescriptionTextBox
        '
        Me.DescriptionTextBox.Location = New System.Drawing.Point(9, 188)
        Me.DescriptionTextBox.Multiline = True
        Me.DescriptionTextBox.Name = "DescriptionTextBox"
        Me.DescriptionTextBox.ReadOnly = True
        Me.DescriptionTextBox.Size = New System.Drawing.Size(166, 64)
        Me.DescriptionTextBox.TabIndex = 21
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 87)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 13)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "Length:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 61)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 13)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "Strand:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 35)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "Name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 13)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Feature:"
        '
        'LengthTextBox
        '
        Me.LengthTextBox.Location = New System.Drawing.Point(75, 84)
        Me.LengthTextBox.Name = "LengthTextBox"
        Me.LengthTextBox.ReadOnly = True
        Me.LengthTextBox.Size = New System.Drawing.Size(100, 20)
        Me.LengthTextBox.TabIndex = 16
        '
        'StrandTextBox
        '
        Me.StrandTextBox.Location = New System.Drawing.Point(75, 58)
        Me.StrandTextBox.Name = "StrandTextBox"
        Me.StrandTextBox.ReadOnly = True
        Me.StrandTextBox.Size = New System.Drawing.Size(100, 20)
        Me.StrandTextBox.TabIndex = 15
        '
        'NameTextBox
        '
        Me.NameTextBox.Location = New System.Drawing.Point(75, 32)
        Me.NameTextBox.Name = "NameTextBox"
        Me.NameTextBox.ReadOnly = True
        Me.NameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.NameTextBox.TabIndex = 14
        '
        'FeatureTextBox
        '
        Me.FeatureTextBox.Location = New System.Drawing.Point(75, 6)
        Me.FeatureTextBox.Name = "FeatureTextBox"
        Me.FeatureTextBox.ReadOnly = True
        Me.FeatureTextBox.Size = New System.Drawing.Size(100, 20)
        Me.FeatureTextBox.TabIndex = 13
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FindButton, Me.FeatureSeqButton, Me.ToggleTranslationButton, Me.TuneButton})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 295)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(200, 25)
        Me.ToolStrip1.TabIndex = 25
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'FindButton
        '
        Me.FindButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.FindButton.Enabled = False
        Me.FindButton.Image = CType(resources.GetObject("FindButton.Image"), System.Drawing.Image)
        Me.FindButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.FindButton.Name = "FindButton"
        Me.FindButton.Size = New System.Drawing.Size(23, 22)
        Me.FindButton.Text = "Find in database"
        '
        'FeatureSeqButton
        '
        Me.FeatureSeqButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.FeatureSeqButton.Enabled = False
        Me.FeatureSeqButton.Image = CType(resources.GetObject("FeatureSeqButton.Image"), System.Drawing.Image)
        Me.FeatureSeqButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.FeatureSeqButton.Name = "FeatureSeqButton"
        Me.FeatureSeqButton.Size = New System.Drawing.Size(23, 22)
        Me.FeatureSeqButton.Text = "Feature sequence"
        '
        'ToggleTranslationButton
        '
        Me.ToggleTranslationButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToggleTranslationButton.Enabled = False
        Me.ToggleTranslationButton.Image = CType(resources.GetObject("ToggleTranslationButton.Image"), System.Drawing.Image)
        Me.ToggleTranslationButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToggleTranslationButton.Name = "ToggleTranslationButton"
        Me.ToggleTranslationButton.Size = New System.Drawing.Size(23, 22)
        Me.ToggleTranslationButton.Text = "Toggle translation"
        '
        'TuneButton
        '
        Me.TuneButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TuneButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TGATGGToolStripMenuItem})
        Me.TuneButton.Enabled = False
        Me.TuneButton.Image = CType(resources.GetObject("TuneButton.Image"), System.Drawing.Image)
        Me.TuneButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TuneButton.Name = "TuneButton"
        Me.TuneButton.Size = New System.Drawing.Size(32, 22)
        Me.TuneButton.Text = "Autoedit"
        '
        'TGATGGToolStripMenuItem
        '
        Me.TGATGGToolStripMenuItem.Name = "TGATGGToolStripMenuItem"
        Me.TGATGGToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.TGATGGToolStripMenuItem.Text = "TGA->TGG"
        '
        'GroupTextBox
        '
        Me.GroupTextBox.Location = New System.Drawing.Point(75, 136)
        Me.GroupTextBox.Name = "GroupTextBox"
        Me.GroupTextBox.ReadOnly = True
        Me.GroupTextBox.Size = New System.Drawing.Size(100, 20)
        Me.GroupTextBox.TabIndex = 26
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 139)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(39, 13)
        Me.Label5.TabIndex = 27
        Me.Label5.Text = "Group:"
        '
        'AuxDataGridView
        '
        Me.AuxDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.AuxDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.HeaderCol, Me.ValueCol})
        Me.AuxDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.AuxDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.AuxDataGridView.Name = "AuxDataGridView"
        Me.AuxDataGridView.Size = New System.Drawing.Size(186, 263)
        Me.AuxDataGridView.TabIndex = 28
        '
        'HeaderCol
        '
        Me.HeaderCol.HeaderText = "Key"
        Me.HeaderCol.Name = "HeaderCol"
        Me.HeaderCol.Width = 75
        '
        'ValueCol
        '
        Me.ValueCol.HeaderText = "Value"
        Me.ValueCol.Name = "ValueCol"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(200, 295)
        Me.TabControl1.TabIndex = 29
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.FeatureTextBox)
        Me.TabPage1.Controls.Add(Me.NameTextBox)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.StrandTextBox)
        Me.TabPage1.Controls.Add(Me.GroupTextBox)
        Me.TabPage1.Controls.Add(Me.LengthTextBox)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.LocationTextBox)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.OrthologyLabel)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.OrthologyTextBox)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.DescriptionTextBox)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(192, 269)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Main data"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.AuxDataGridView)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(192, 269)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Additional data"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'FeatureReportBox
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Name = "FeatureReportBox"
        Me.Size = New System.Drawing.Size(200, 320)
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        CType(Me.AuxDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LocationTextBox As System.Windows.Forms.TextBox
    Friend WithEvents OrthologyLabel As System.Windows.Forms.Label
    Friend WithEvents OrthologyTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DescriptionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LengthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StrandTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FeatureTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents FindButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents GroupTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents FeatureSeqButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToggleTranslationButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents AuxDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents HeaderCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ValueCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TuneButton As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents TGATGGToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
