﻿Public Class RBLAST_Result

    Private strSubjectSequence As String = ""
    Private strQuerySequence As String = ""
    Private strMatchString As String = ""

    Private intSubjectStartPos As Integer = 0
    Private intQueryStartPos As Integer = 0
    Private intSubjectEndPos As Integer = 0
    Private intQueryEndPos As Integer = 0

    Private sglIdentityNumber As Integer = 0

    Private bDirection As Boolean = False


    Public Property SubjectSequence() As String
        Get
            SubjectSequence = strSubjectSequence
        End Get
        Set(ByVal value As String)
            strSubjectSequence = value
        End Set
    End Property

    Public Property QuerySequence() As String
        Get
            QuerySequence = strQuerySequence
        End Get
        Set(ByVal value As String)
            strQuerySequence = value
        End Set
    End Property

    Public Property MatchString() As String
        Get
            MatchString = strMatchString
        End Get
        Set(ByVal value As String)
            strMatchString = value
        End Set
    End Property

    Public Property SubjectStartPos() As Integer
        Get
            SubjectStartPos = intSubjectStartPos
        End Get
        Set(ByVal value As Integer)
            intSubjectStartPos = value
        End Set
    End Property

    Public Property QueryStartPos() As Integer
        Get
            QueryStartPos = intQueryStartPos
        End Get
        Set(ByVal value As Integer)
            intQueryStartPos = value
        End Set
    End Property

    Public Property SubjectEndPos() As Integer
        Get
            SubjectEndPos = intSubjectEndPos
        End Get
        Set(ByVal value As Integer)
            intSubjectEndPos = value
        End Set
    End Property

    Public Property QueryEndPos() As Integer
        Get
            QueryEndPos = intQueryEndPos
        End Get
        Set(ByVal value As Integer)
            intQueryEndPos = value
        End Set
    End Property

    Public Property IdentityNumber() As Integer
        Get
            IdentityNumber = sglIdentityNumber
        End Get
        Set(ByVal value As Integer)
            sglIdentityNumber = value
        End Set
    End Property

    Public Property Direction() As Boolean
        Get
            Direction = bDirection
        End Get
        Set(ByVal value As Boolean)
            bDirection = value
        End Set
    End Property

End Class
