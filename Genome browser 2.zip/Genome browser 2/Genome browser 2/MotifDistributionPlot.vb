﻿Public Class MotifDistributionPlot
    Private bReady As Boolean = False
    Private MotifsDistribution As New List(Of MotifDistributionData)
    Private Y_Step As Integer = 20 'Distance between lanes

    Private SeqAlign As Boolean = False

    Public Property AlignToRight() As Boolean
        Get
            AlignToRight = SeqAlign
        End Get
        Set(ByVal value As Boolean)
            SeqAlign = value
        End Set
    End Property

    Public Sub CalculatePositions(ByVal MotifHits As List(Of K_Word_PWM_Hit), _
                                   ByVal SeqList As List(Of String), _
                                   ByVal SeqIDlist As List(Of String))


        For i = 0 To SeqIDlist.Count - 1 'Calculate motif positions for each seq

            Dim NewDistribution As New MotifDistributionData
            NewDistribution.SeqID = SeqIDlist(i)
            NewDistribution.Seq = SeqList(i)

            For Each MotifHit As K_Word_PWM_Hit In MotifHits
                If SeqIDlist(i) = MotifHit.Aligned_Seq_ID Then

                    NewDistribution.MotifStart.Add(MotifHit.Aligned_Pos / SeqList(i).Length)
                    NewDistribution.MotifEnd.Add((MotifHit.Aligned_Pos + MotifHit.Word_Text.Length) / SeqList(i).Length)

                End If
            Next

            If NewDistribution.MotifStart.Count > 0 Then
                MotifsDistribution.Add(NewDistribution)
                bReady = True
            End If

        Next

    End Sub

    Public Sub GetSize()
        Me.Size = New Size(400, (MotifsDistribution.Count + 2) * Y_Step)
    End Sub

    Private Sub DrawMotifs(ByVal g As Graphics)

        Dim StartX As Integer = 0
        Dim StartY As Integer = 20

        Dim CurrentY As Integer = StartY

        Dim L_Proj As Integer = 300
        Dim L_Max As Integer = 0
        Dim Current_L As Integer = 0

        Dim CurrentMotifStart As Integer = 0
        Dim CurrentMotifEnd As Integer = 0

        Dim MotifPen As New Pen(Color.Red, 4)

        Me.Size = New Size(400, (MotifsDistribution.Count + 2) * StartY)

        For Each Seq As MotifDistributionData In MotifsDistribution
            If Seq.Seq.Length > L_Max Then
                L_Max = Seq.Seq.Length
            End If
        Next

        Dim Proj_K As Single = L_Proj / L_Max

        If SeqAlign Then 'Align to right
            StartX = 10 + L_Proj

            For Each Seq As MotifDistributionData In MotifsDistribution
                Current_L = Seq.Seq.Length * Proj_K

                g.DrawLine(Pens.Black, StartX - Current_L, CurrentY, StartX, CurrentY)

                g.DrawString(Seq.SeqID, Me.Font, Brushes.Black, StartX, CurrentY - 5)

                For i = 0 To Seq.MotifStart.Count - 1
                    CurrentMotifStart = Current_L * Seq.MotifStart(i)
                    CurrentMotifEnd = Current_L * Seq.MotifEnd(i)
                    g.DrawLine(MotifPen, StartX - Current_L + CurrentMotifStart, CurrentY, StartX - Current_L + CurrentMotifEnd, CurrentY)

                Next


                CurrentY += Y_Step
            Next

        Else 'Align to left
            StartX = 10

            For Each Seq As MotifDistributionData In MotifsDistribution
                Current_L = Seq.Seq.Length * Proj_K

                g.DrawLine(Pens.Black, StartX, CurrentY, StartX + Current_L, CurrentY)

                g.DrawString(Seq.SeqID, Me.Font, Brushes.Black, StartX + Current_L, CurrentY - 5)

                For i = 0 To Seq.MotifStart.Count - 1
                    CurrentMotifStart = Current_L * Seq.MotifStart(i)
                    CurrentMotifEnd = Current_L * Seq.MotifEnd(i)
                    g.DrawLine(MotifPen, StartX + CurrentMotifStart, CurrentY, StartX + CurrentMotifEnd, CurrentY)

                Next


                CurrentY += Y_Step
            Next


        End If



    End Sub

    Private Sub MotifDistributionPlot_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        If bReady Then
            DrawMotifs(e.Graphics)
        End If

    End Sub
End Class
