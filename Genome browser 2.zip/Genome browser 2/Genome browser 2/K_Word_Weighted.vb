﻿Public Class K_Word_Weighted
    Inherits K_Word

    Private BoolTag As Boolean = False
    Private sglWeight As Single

    Public Property Weight() As Single
        Get
            Weight = sglWeight
        End Get
        Set(ByVal value As Single)
            sglWeight = value
        End Set
    End Property

    Public Property Bool_TAG() As Boolean
        Get
            Bool_TAG = BoolTag
        End Get
        Set(ByVal value As Boolean)
            BoolTag = value
        End Set
    End Property

End Class
