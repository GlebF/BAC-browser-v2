﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SystemProgressBarBox
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MasterProgressBar = New System.Windows.Forms.ProgressBar
        Me.StatusLabel = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'MasterProgressBar
        '
        Me.MasterProgressBar.Location = New System.Drawing.Point(12, 12)
        Me.MasterProgressBar.Name = "MasterProgressBar"
        Me.MasterProgressBar.Size = New System.Drawing.Size(300, 23)
        Me.MasterProgressBar.Step = 1
        Me.MasterProgressBar.TabIndex = 0
        '
        'StatusLabel
        '
        Me.StatusLabel.AutoSize = True
        Me.StatusLabel.Location = New System.Drawing.Point(12, 38)
        Me.StatusLabel.Name = "StatusLabel"
        Me.StatusLabel.Size = New System.Drawing.Size(38, 13)
        Me.StatusLabel.TabIndex = 1
        Me.StatusLabel.Text = "Ready"
        '
        'SystemProgressBarBox
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(326, 70)
        Me.Controls.Add(Me.StatusLabel)
        Me.Controls.Add(Me.MasterProgressBar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "SystemProgressBarBox"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SystemProgressBarBox"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MasterProgressBar As System.Windows.Forms.ProgressBar
    Friend WithEvents StatusLabel As System.Windows.Forms.Label
End Class
