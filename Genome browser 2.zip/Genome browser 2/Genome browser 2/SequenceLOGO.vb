﻿Public Class SequenceLOGO

#Region "Variables"

    Private Sequences As New List(Of Char())
    Private MotiffPWM As New PWM

    Private bXInverse As Boolean = False

    Private SizePerLetter As Integer = 30

    Private A_Heights As New List(Of Single)
    Private T_Heights As New List(Of Single)
    Private G_Heights As New List(Of Single)
    Private C_Heights As New List(Of Single)

    Private A_Brush As New SolidBrush(Color.Red)
    Private T_Brush As New SolidBrush(Color.Gold)
    Private G_Brush As New SolidBrush(Color.Blue)
    Private C_Brush As New SolidBrush(Color.Green)

    Private FontSize As Integer = 8

    Private MyFont As New Font("Arial", FontSize, FontStyle.Bold)
    Private MyFontFamily As New FontFamily("Arial")
    Private MyStringFormat As New StringFormat

    Private Vertical_Chart_Offset As Integer = 20
    Private Horizontal_Chart_Offset As Integer = 20

    Private DefaultChartPenWidth As Integer = 2
    Private ChartPen As New Pen(Color.Black, DefaultChartPenWidth)

    Private bReady As Boolean = False

#End Region

#Region "Properties"

    Public Property Sequences_List() As List(Of Char())
        Get
            Sequences_List = Sequences
        End Get
        Set(ByVal value As List(Of Char()))
            Sequences = value
        End Set
    End Property

    Public Property Motiff_PWM() As PWM
        Get
            Motiff_PWM = MotiffPWM
        End Get
        Set(ByVal value As PWM)
            MotiffPWM = value
        End Set
    End Property

    Public Property InverseX() As Boolean
        Get
            InverseX = bXInverse
        End Get
        Set(ByVal value As Boolean)
            bXInverse = value
        End Set
    End Property

#End Region

#Region "Bioinformatics"

    Private Sub SequenceLOGO_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        MyStringFormat.Alignment = StringAlignment.Center
        MyStringFormat.LineAlignment = StringAlignment.Center

    End Sub

    Public Sub CalculateInformationContent(ByVal SampleSizeCorrection As Boolean)

        A_Heights.Clear()
        T_Heights.Clear()
        G_Heights.Clear()
        C_Heights.Clear()

        Dim A_Count As Integer = 0
        Dim T_Count As Integer = 0
        Dim G_Count As Integer = 0
        Dim C_Count As Integer = 0
        Dim TotalCount As Integer = 0

        Dim A_P As Single = 0
        Dim T_P As Single = 0
        Dim G_P As Single = 0
        Dim C_P As Single = 0

        Dim Bar_Y As Single = 0
        Dim A_Y As Single = 0
        Dim T_Y As Single = 0
        Dim G_Y As Single = 0
        Dim C_Y As Single = 0

        Dim Entropy_A As Single = 0
        Dim Entropy_T As Single = 0
        Dim Entropy_G As Single = 0
        Dim Entropy_C As Single = 0


        Dim ShannonEntropy As Single = 0

        Dim Correction As Single = 0

        If SampleSizeCorrection Then
            Correction = 3 / (2 * Math.Log(2) * Sequences.Count)
        End If

        For i = 0 To Sequences(0).Length - 1
            A_Count = 0
            T_Count = 0
            G_Count = 0
            C_Count = 0

            For j = 0 To Sequences.Count - 1
                Select Case Sequences(j)(i)
                    Case "A"
                        A_Count += 1
                    Case "T"
                        T_Count += 1
                    Case "G"
                        G_Count += 1
                    Case "C"
                        C_Count += 1
                End Select
            Next

            TotalCount = A_Count + T_Count + G_Count + C_Count


            A_P = A_Count / TotalCount
            T_P = T_Count / TotalCount
            G_P = G_Count / TotalCount
            C_P = C_Count / TotalCount


            If Not A_P = 0 Then
                Entropy_A = A_P * Math.Log(A_P) '/ Math.Log(2)
            Else
                Entropy_A = 0
            End If

            If Not T_P = 0 Then
                Entropy_T = T_P * Math.Log(T_P) '/ Math.Log(2)
            Else
                Entropy_T = 0
            End If

            If Not G_P = 0 Then
                Entropy_G = G_P * Math.Log(G_P) '/ Math.Log(2)
            Else
                Entropy_G = 0
            End If

            If Not C_P = 0 Then
                Entropy_C = C_P * Math.Log(C_P) '/ Math.Log(2)
            Else
                Entropy_C = 0
            End If


            ShannonEntropy = -(Entropy_A + _
                               Entropy_T + _
                               Entropy_G + _
                               Entropy_C)


            Bar_Y = 2 - ShannonEntropy - Correction
            A_Y = Bar_Y * A_P
            T_Y = Bar_Y * T_P
            G_Y = Bar_Y * G_P
            C_Y = Bar_Y * C_P


            A_Heights.Add(A_Y)
            T_Heights.Add(T_Y)
            G_Heights.Add(G_Y)
            C_Heights.Add(C_Y)

        Next

        bReady = True

    End Sub

    Public Sub ConvertPWMToLOGO(ByVal ShannonNormalization As Boolean)

        A_Heights.Clear()
        T_Heights.Clear()
        G_Heights.Clear()
        C_Heights.Clear()

        Dim GlobalMaxRange As Single = Motiff_PWM.GetMaxRange 'Maximum bar height, is scaled to 2
        Dim LocalRange As Single = 0

        Dim N_Min As Single = 0
        Dim A_Percentile As Single = 0
        Dim T_Percentile As Single = 0
        Dim G_Percentile As Single = 0
        Dim C_Percentile As Single = 0
        Dim Total_Percentile As Single = 0

        Dim A_P As Single = 0
        Dim T_P As Single = 0
        Dim G_P As Single = 0
        Dim C_P As Single = 0



        Dim Bar_Y As Single = 0
        Dim A_Y As Single = 0
        Dim T_Y As Single = 0
        Dim G_Y As Single = 0
        Dim C_Y As Single = 0

        Dim A_Correction As Single = 1
        Dim T_Correction As Single = 1
        Dim G_Correction As Single = 1
        Dim C_Correction As Single = 1

        Dim PositiveCorrection As Single = 2

        Dim GlobalMaxBar As Single = 2 'Maximum height of LOGO

        If ShannonNormalization Then
            'Find the most extreme cell at PWM as calculate its shannon entropy
            For i = 0 To Motiff_PWM.PWM_Table.Count - 1
                LocalRange = Motiff_PWM.GetRangeAt(i)
                If LocalRange = GlobalMaxRange Then
                    Dim MaxShannonEntropy As Single = 0

                    N_Min = Motiff_PWM.GetMinWeightAt(i)

                    If Motiff_PWM.PWM_Table(i).A_Weight > 0 Then
                        A_Correction = PositiveCorrection
                    Else
                        A_Correction = 1
                    End If

                    If Motiff_PWM.PWM_Table(i).T_Weight > 0 Then
                        T_Correction = PositiveCorrection
                    Else
                        T_Correction = 1
                    End If

                    If Motiff_PWM.PWM_Table(i).G_Weight > 0 Then
                        G_Correction = PositiveCorrection
                    Else
                        G_Correction = 1
                    End If

                    If Motiff_PWM.PWM_Table(i).C_Weight > 0 Then
                        C_Correction = PositiveCorrection
                    Else
                        C_Correction = 1
                    End If

                    If Not LocalRange = 0 Then
                        A_Percentile = (Motiff_PWM.PWM_Table(i).A_Weight - N_Min) * A_Correction / LocalRange
                        T_Percentile = (Motiff_PWM.PWM_Table(i).T_Weight - N_Min) * T_Correction / LocalRange
                        G_Percentile = (Motiff_PWM.PWM_Table(i).G_Weight - N_Min) * G_Correction / LocalRange
                        C_Percentile = (Motiff_PWM.PWM_Table(i).C_Weight - N_Min) * C_Correction / LocalRange
                    Else
                        A_Percentile = 1
                        T_Percentile = 1
                        G_Percentile = 1
                        C_Percentile = 1
                    End If


                    Total_Percentile = A_Percentile + T_Percentile + G_Percentile + C_Percentile


                    A_P = A_Percentile / Total_Percentile
                    T_P = T_Percentile / Total_Percentile
                    G_P = G_Percentile / Total_Percentile
                    C_P = C_Percentile / Total_Percentile

                    Dim Entropy_A As Single = 0
                    Dim Entropy_T As Single = 0
                    Dim Entropy_G As Single = 0
                    Dim Entropy_C As Single = 0

                    If Not A_P = 0 Then
                        Entropy_A = A_P * Math.Log(A_P) '/ Math.Log(2)
                    Else
                        Entropy_A = 0
                    End If

                    If Not T_P = 0 Then
                        Entropy_T = T_P * Math.Log(T_P) '/ Math.Log(2)
                    Else
                        Entropy_T = 0
                    End If

                    If Not G_P = 0 Then
                        Entropy_G = G_P * Math.Log(G_P) '/ Math.Log(2)
                    Else
                        Entropy_G = 0
                    End If

                    If Not C_P = 0 Then
                        Entropy_C = C_P * Math.Log(C_P) '/ Math.Log(2)
                    Else
                        Entropy_C = 0
                    End If


                    MaxShannonEntropy = -(Entropy_A + _
                                       Entropy_T + _
                                       Entropy_G + _
                                       Entropy_C)

                    GlobalMaxBar = 2 - MaxShannonEntropy
                    Exit For
                End If
            Next

        End If 'Shannon normalization


        'Calculate Y heights for PWM
        For i = 0 To Motiff_PWM.PWM_Table.Count - 1
            LocalRange = Motiff_PWM.GetRangeAt(i)


            N_Min = Motiff_PWM.GetMinWeightAt(i)

            If Motiff_PWM.PWM_Table(i).A_Weight > 0 Then
                A_Correction = PositiveCorrection
            Else
                A_Correction = 1
            End If

            If Motiff_PWM.PWM_Table(i).T_Weight > 0 Then
                T_Correction = PositiveCorrection
            Else
                T_Correction = 1
            End If

            If Motiff_PWM.PWM_Table(i).G_Weight > 0 Then
                G_Correction = PositiveCorrection
            Else
                G_Correction = 1
            End If

            If Motiff_PWM.PWM_Table(i).C_Weight > 0 Then
                C_Correction = PositiveCorrection
            Else
                C_Correction = 1
            End If

            If Not LocalRange = 0 Then
                A_Percentile = (Motiff_PWM.PWM_Table(i).A_Weight - N_Min) * A_Correction / LocalRange
                T_Percentile = (Motiff_PWM.PWM_Table(i).T_Weight - N_Min) * T_Correction / LocalRange
                G_Percentile = (Motiff_PWM.PWM_Table(i).G_Weight - N_Min) * G_Correction / LocalRange
                C_Percentile = (Motiff_PWM.PWM_Table(i).C_Weight - N_Min) * C_Correction / LocalRange
            Else
                A_Percentile = 1
                T_Percentile = 1
                G_Percentile = 1
                C_Percentile = 1
            End If


            Total_Percentile = A_Percentile + T_Percentile + G_Percentile + C_Percentile


            A_P = A_Percentile / Total_Percentile
            T_P = T_Percentile / Total_Percentile
            G_P = G_Percentile / Total_Percentile
            C_P = C_Percentile / Total_Percentile



            Bar_Y = GlobalMaxBar * LocalRange / GlobalMaxRange
            A_Y = Bar_Y * A_P
            T_Y = Bar_Y * T_P
            G_Y = Bar_Y * G_P
            C_Y = Bar_Y * C_P

            A_Heights.Add(A_Y)
            T_Heights.Add(T_Y)
            G_Heights.Add(G_Y)
            C_Heights.Add(C_Y)


        Next

        bReady = True

    End Sub

#End Region

#Region "Graphics"

    Private Function RateLettersAt(ByVal index As Integer)
        Dim LocalRate(3) As String
        LocalRate(0) = "A"
        LocalRate(1) = "T"
        LocalRate(2) = "G"
        LocalRate(3) = "C"

        Dim LocalScores(3) As Single
        LocalScores(0) = A_Heights(index)
        LocalScores(1) = T_Heights(index)
        LocalScores(2) = G_Heights(index)
        LocalScores(3) = C_Heights(index)

        Dim TmpScore As Single = 0
        Dim TmpRate As String = 0

        For i = 1 To LocalScores.Count - 1
            For j = 0 To LocalScores.Count - 1 - i
                If LocalScores(j) < LocalScores(j + 1) Then
                    TmpScore = LocalScores(j)
                    TmpRate = LocalRate(j)
                    LocalScores(j) = LocalScores(j + 1)
                    LocalRate(j) = LocalRate(j + 1)
                    LocalScores(j + 1) = TmpScore
                    LocalRate(j + 1) = TmpRate
                End If
            Next
        Next

        Return LocalRate

    End Function

    Private Sub ExtendLOGO(ByRef g As Graphics, ByVal index As Integer, ByVal Letter As String, ByRef Y_Point As Integer, ByRef Y_Point_Prev As Integer, ByVal X_Point As Integer, ByVal Chart_Step_X As Integer, ByVal Projection As Single)
        Y_Point_Prev = Y_Point
        Dim LocalBrush As SolidBrush = Brushes.Black

        Try
            Select Case Letter
                Case "A"
                    Y_Point -= A_Heights(index) * Projection
                    LocalBrush = A_Brush
                Case "T"
                    Y_Point -= T_Heights(index) * Projection
                    LocalBrush = T_Brush
                Case "G"
                    Y_Point -= G_Heights(index) * Projection
                    LocalBrush = G_Brush
                Case "C"
                    Y_Point -= C_Heights(index) * Projection
                    LocalBrush = C_Brush
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


        Dim rect As New Rectangle
        rect.Location = New Point(X_Point, Y_Point)
        rect.Width = Chart_Step_X
        rect.Height = Y_Point_Prev - Y_Point


        Draw_Letter(g, Letter, LocalBrush, rect, MyFontFamily, MyStringFormat)

    End Sub

    Private Sub Draw_Letter(ByRef g As Graphics, ByVal Letter As String, ByVal LetterBrush As SolidBrush, ByVal LayoutRectangle As Rectangle, ByVal LayoutFontFamily As FontFamily, ByVal LayoutStringFormat As StringFormat)
        If Not LayoutRectangle.Height = 0 Then
            Dim LetterLayout As New Drawing2D.GraphicsPath
            LetterLayout.AddString(Letter, LayoutFontFamily, 1, LayoutRectangle.Height, New PointF(0, 0), LayoutStringFormat)
            Dim Letter_Rect As RectangleF = LetterLayout.GetBounds()
            Dim Layout_Points() As PointF = { _
             New PointF(LayoutRectangle.Left, LayoutRectangle.Top), _
             New PointF(LayoutRectangle.Right, LayoutRectangle.Top), _
             New PointF(LayoutRectangle.Left, LayoutRectangle.Bottom) _
             }

            g.Transform = New Drawing2D.Matrix(Letter_Rect, Layout_Points)
            g.FillPath(LetterBrush, LetterLayout)
            g.ResetTransform()
            LetterLayout.Dispose()
        End If
    End Sub

    Public Sub DrawLogo(ByVal g As Graphics, Optional ByVal ResolutionFactor As Integer = 1)
        Dim X_Axis_Length As Integer = (Me.Width - Horizontal_Chart_Offset * 2) * ResolutionFactor
        Dim Y_Axis_Length As Integer = (Me.Height - Vertical_Chart_Offset * 2) * ResolutionFactor
        Dim half_Y As Integer = Y_Axis_Length / 2

        Dim FontHalf As Integer = FontSize / 2 * ResolutionFactor

        Dim Chart_Step_X As Integer = X_Axis_Length / A_Heights.Count
        Dim Font_Offset As Integer = Chart_Step_X / 2 - FontHalf

        Dim Projection As Single = Y_Axis_Length / 2

        Dim Baseline As Integer = (Me.Height - Vertical_Chart_Offset) * ResolutionFactor
        Dim X_Point As Integer = Horizontal_Chart_Offset * ResolutionFactor
        Dim Y_Point_Prev As Integer = Baseline
        Dim Y_Point As Integer = Baseline

        Dim LabelFont As New Font("Microsoft Sans Serif", FontSize * ResolutionFactor, FontStyle.Bold)
        ChartPen.Width = DefaultChartPenWidth * ResolutionFactor

        Dim LocalRate(3) As String

        For i = 0 To A_Heights.Count - 1

            LocalRate = RateLettersAt(i)
            For j = 3 To 0 Step -1
                ExtendLOGO(g, i, LocalRate(j), Y_Point, Y_Point_Prev, X_Point, Chart_Step_X, Projection)
            Next

            If bXInverse Then
                g.DrawString(Sequences(0).Length - i, LabelFont, Brushes.Black, X_Point + Font_Offset, Baseline)
            Else
                g.DrawString(i + 1, LabelFont, Brushes.Black, X_Point + Font_Offset, Baseline)
            End If

            X_Point += Chart_Step_X
            Y_Point = Baseline
        Next

        X_Point = Horizontal_Chart_Offset * ResolutionFactor

        g.DrawString("bits", LabelFont, Brushes.Black, X_Point - 18 * ResolutionFactor, Baseline - Y_Axis_Length - 20 * ResolutionFactor)


        g.DrawLine(ChartPen, X_Point, Baseline, X_Point - FontHalf, Baseline)
        g.DrawString("0", LabelFont, Brushes.Black, X_Point - 18 * ResolutionFactor, Baseline - FontHalf)

        g.DrawLine(ChartPen, X_Point, Baseline - Y_Axis_Length, X_Point - FontHalf, Baseline - Y_Axis_Length)
        g.DrawString("2", LabelFont, Brushes.Black, X_Point - 18 * ResolutionFactor, Baseline - Y_Axis_Length - FontHalf)


        g.DrawLine(ChartPen, X_Point, Baseline - half_Y, X_Point - FontHalf, Baseline - half_Y)
        g.DrawString("1", LabelFont, Brushes.Black, X_Point - 18 * ResolutionFactor, Baseline - half_Y - FontHalf)


        g.DrawLine(ChartPen, X_Point, Baseline, X_Point, Baseline - Y_Axis_Length)

    End Sub


    Private Sub SequenceLOGO_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint




        If bReady Then

            DrawLogo(e.Graphics)

            'Dim X_Axis_Length As Integer = Me.Width - Horizontal_Chart_Offset * 2
            'Dim Y_Axis_Length As Integer = Me.Height - Vertical_Chart_Offset * 2
            'Dim half_Y As Integer = Y_Axis_Length / 2

            'Dim FontHalf As Integer = FontSize / 2

            'Dim Chart_Step_X As Integer = X_Axis_Length / A_Heights.Count
            'Dim Font_Offset As Integer = Chart_Step_X / 2 - FontHalf

            'Dim Projection As Single = Y_Axis_Length / 2

            'Dim Baseline As Integer = Me.Height - Vertical_Chart_Offset
            'Dim X_Point As Integer = Horizontal_Chart_Offset
            'Dim Y_Point_Prev As Integer = Baseline
            'Dim Y_Point As Integer = Baseline

            'Dim LocalRate(3) As String

            'For i = 0 To A_Heights.Count - 1

            'LocalRate = RateLettersAt(i)
            'For j = 3 To 0 Step -1
            'ExtendLOGO(e.Graphics, i, LocalRate(j), Y_Point, Y_Point_Prev, X_Point, Chart_Step_X, Projection)
            'Next

            'If bXInverse Then
            'e.Graphics.DrawString(Sequences(0).Length - i, MyFont, Brushes.Black, X_Point + Font_Offset, Baseline)
            'Else
            'e.Graphics.DrawString(i + 1, MyFont, Brushes.Black, X_Point + Font_Offset, Baseline)
            'End If

            'X_Point += Chart_Step_X
            'Y_Point = Baseline
            'Next

            'X_Point = Horizontal_Chart_Offset

            'e.Graphics.DrawString("bits", MyFont, Brushes.Black, X_Point - 18, Baseline - Y_Axis_Length - 20)


            'e.Graphics.DrawLine(ChartPen, X_Point, Baseline, X_Point - FontHalf, Baseline)
            'e.Graphics.DrawString("0", MyFont, Brushes.Black, X_Point - 18, Baseline - FontHalf)

            'e.Graphics.DrawLine(ChartPen, X_Point, Baseline - Y_Axis_Length, X_Point - FontHalf, Baseline - Y_Axis_Length)
            'e.Graphics.DrawString("2", MyFont, Brushes.Black, X_Point - 18, Baseline - Y_Axis_Length - FontHalf)


            'e.Graphics.DrawLine(ChartPen, X_Point, Baseline - half_Y, X_Point - FontHalf, Baseline - half_Y)
            'e.Graphics.DrawString("1", MyFont, Brushes.Black, X_Point - 18, Baseline - half_Y - FontHalf)


            'e.Graphics.DrawLine(ChartPen, X_Point, Baseline, X_Point, Baseline - Y_Axis_Length)


        End If



    End Sub

#End Region

End Class
