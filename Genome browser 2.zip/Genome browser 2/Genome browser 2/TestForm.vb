﻿Public Class TestForm

    Private ForAlignedHitMap As List(Of K_Word_Hashed) = Nothing
    Private RevAlignedHitMap As List(Of K_Word_Hashed) = Nothing

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        ResultBox.Text = DataIO.FormatStringForGB(InputTextBox.Text)
    End Sub


    Private Sub TestChartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TestChartButton.Click

        Dim WordL As Integer = WLTextBox.Text


        ForAlignedHitMap = Bioinformatics.Make_Hashed_Hit_List(InputTextBox.Text, InputTextBox.Text, WordL)

        RevAlignedHitMap = Bioinformatics.Make_Hashed_Hit_List(InputTextBox.Text, Bioinformatics.GetReverseComplement(InputTextBox.Text), WordL)





        HitMap.Invalidate()


    End Sub

    Private Sub HitMap_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles HitMap.Paint

        If Not IsNothing(ForAlignedHitMap) Then



            Dim X_Proj_K As Single = HitMap.Width / ForAlignedHitMap.Count
            Dim Y_Proj_K As Single = HitMap.Height / ForAlignedHitMap.Count


            For x = 0 To ForAlignedHitMap.Count - 1

                If ForAlignedHitMap(x).Aligned_Positions.Count > 0 Then
                    For y = 0 To ForAlignedHitMap(x).Aligned_Positions.Count - 1
                        e.Graphics.DrawRectangle(Pens.Red, ForAlignedHitMap(x).Relative_Position * X_Proj_K, ForAlignedHitMap(x).Aligned_Positions(y) * Y_Proj_K, 1, 1)

                    Next y
                End If


                If RevAlignedHitMap(x).Aligned_Positions.Count > 0 Then
                    For y = 0 To RevAlignedHitMap(x).Aligned_Positions.Count - 1
                        e.Graphics.DrawRectangle(Pens.Blue, RevAlignedHitMap(x).Relative_Position * X_Proj_K, (RevAlignedHitMap.Count - RevAlignedHitMap(x).Aligned_Positions(y)) * Y_Proj_K, 1, 1)

                    Next y
                End If

            Next x






        End If


    End Sub
End Class