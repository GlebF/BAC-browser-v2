﻿Public Class CodonUsageCell
    Private strAA As String = ""
    Private strCodonList As New List(Of String)
    Private sglFreqList As New List(Of Single)


    Public Property AA() As String
        Get
            AA = strAA
        End Get
        Set(ByVal value As String)
            strAA = value
        End Set
    End Property

    Public Property CodonList() As List(Of String)
        Get
            CodonList = strCodonList
        End Get
        Set(ByVal value As List(Of String))
            strCodonList = value
        End Set
    End Property

    Public Property FreqList() As List(Of Single)
        Get
            FreqList = sglFreqList
        End Get
        Set(ByVal value As List(Of Single))
            sglFreqList = value
        End Set
    End Property



    Public Sub AddCodon(ByVal Codon As String, ByVal Frequency As Single)
        strCodonList.Add(Codon)
        sglFreqList.Add(Frequency)
    End Sub

    Public Sub ClearCodons()
        strCodonList.Clear()
        sglFreqList.Clear()
    End Sub

    Public Function ReturnCodonByFreq()
        Dim CurrentCodon As String = ""
        Dim LastFVal As Integer = 0
        Dim NextFVal As Integer = 1
        Dim CurrentHit As Integer = Bioinformatics.Get_Random(1, 100)

        For i = 0 To strCodonList.Count - 1
            If Not sglFreqList(i) = 0 Then
                LastFVal = NextFVal
                NextFVal += 100 * sglFreqList(i)

                If CurrentHit >= LastFVal And CurrentHit <= NextFVal Then
                    CurrentCodon = strCodonList(i)
                    Exit For
                End If
            End If
        Next

        If CurrentCodon = "" Then
            CurrentCodon = strCodonList(0)
        End If


        Return CurrentCodon
    End Function

End Class
