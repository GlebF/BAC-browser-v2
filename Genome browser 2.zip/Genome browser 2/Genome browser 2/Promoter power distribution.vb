﻿Public Class Promoter_power_distribution

    Public MyGenomeViewer As Genome_Viewer = Nothing




    Private Sub SearchButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchButton.Click
        If Master.SaveFileDialog.ShowDialog = DialogResult.OK Then
            Dim FS As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.Create)
            Dim Writer As New IO.StreamWriter(FS)

            Dim minus10_PWM As New PWM
            minus10_PWM = DataIO.LoadPWM(PWM10TextBox.Text)
            Dim minus35_PWM As New PWM
            minus35_PWM = DataIO.LoadPWM(PWM35TextBox.Text)
            Dim ext_PWM As New PWM
            ext_PWM = DataIO.LoadPWM(PWMExtTextBox.Text)
            Dim spacer_PWM As New PWM
            spacer_PWM = DataIO.LoadPWM(SpacerTextBox.Text)

            Dim Threshold_10 As Single = Threshold10TextBox.Text
            Dim Minus10_35SpacerL As Integer = Minus10_35spacerLTextBox.Text
            Dim Minus10_35SpacerDiv As Integer = Minus10_35spacerDivTextBox.Text
            Dim Minus10_TSSSpacerL As Integer = Minus10_TSSspacerLTextBox.Text
            Dim Minus10_TSSSpacerDiv As Integer = Minus10_TSSspacerDivTextBox.Text



            Dim Result As New List(Of List(Of PromoterAssembly))
            Result = Bioinformatics.SearchPromoters(MyGenomeViewer.Genome_Sequence, MyGenomeViewer.Positional_Values_Collection, minus10_PWM, Threshold_10, ext_PWM, 0, minus35_PWM, 0, spacer_PWM, Minus10_35SpacerL, Minus10_35SpacerDiv, Minus10_TSSSpacerL, Minus10_TSSSpacerDiv, 1, 1, )


            'For Each PromoterFor As PromoterAssembly In Result(0)
            'Writer.WriteLine(PromoterFor.PromoterSequence & Chr(9) & PromoterFor.minus10.Word_Text & Chr(9) & PromoterFor.minus10.Weight & Chr(9) & PromoterFor.Extension.Word_Text & Chr(9) & PromoterFor.Extension.Weight & Chr(9) & PromoterFor.minus35.Word_Text & Chr(9) & PromoterFor.minus35.Weight & Chr(9) & PromoterFor.Initiator(0) & Chr(9) & PromoterFor.PeakData(0) & Chr(9) & PromoterFor.BackgroundData(0))
            'Next PromoterFor

            'For Each PromoterRev As PromoterAssembly In Result(1)
            'Writer.WriteLine(PromoterRev.PromoterSequence & Chr(9) & PromoterRev.minus10.Word_Text & Chr(9) & PromoterRev.minus10.Weight & Chr(9) & PromoterRev.Extension.Word_Text & Chr(9) & PromoterRev.Extension.Weight & Chr(9) & PromoterRev.minus35.Word_Text & Chr(9) & PromoterRev.minus35.Weight & Chr(9) & PromoterRev.Initiator(0) & Chr(9) & PromoterRev.PeakData(0) & Chr(9) & PromoterRev.BackgroundData(0))
            'Next PromoterRev

            Dim ResultData As String = _
            "Seq" & Chr(9) & _
            "Strand" & Chr(9) & _
            "TATA_pos" & Chr(9) & _
            "-10s" & Chr(9) & "-10w" & Chr(9) & _
            "EXTs" & Chr(9) & "EXTw" & Chr(9) & _
            "-35s" & Chr(9) & "-35w" & Chr(9) & _
            "-10 to -35 spacer" & Chr(9) & "-10 to TSS spacer"

            Writer.WriteLine(ResultData)


            For Each Promoter As PromoterAssembly In Result(0)

                ResultData = ""

                ResultData &= Promoter.PromoterSequence & Chr(9)
                ResultData &= "plus" & Chr(9)
                ResultData &= Promoter.minus10.Relative_Position & Chr(9)
                ResultData &= Promoter.minus10.Word_Text & Chr(9)
                ResultData &= Promoter.minus10.Weight & Chr(9)
                ResultData &= Promoter.Extension.Word_Text & Chr(9)
                ResultData &= Promoter.Extension.Weight & Chr(9)
                ResultData &= Promoter.minus35.Word_Text & Chr(9)
                ResultData &= Promoter.minus35.Weight & Chr(9)
                ResultData &= Promoter.minus10_To_minus35_SpacerWeight & Chr(9)
                ResultData &= Promoter.minus10_To_TSS_SpacerWeight & Chr(9)

                For i = 0 To Promoter.PeakData.Count - 1
                    ResultData &= Promoter.Initiator(i) & Chr(9) & Promoter.PeakData(i) & Chr(9) & Promoter.BackgroundData(i) & Chr(9) & Promoter.PeakData(i) / Promoter.BackgroundData(i) & Chr(9)
                Next i


                Writer.WriteLine(ResultData)
            Next Promoter

            For Each Promoter As PromoterAssembly In Result(1)

                ResultData = ""

                ResultData &= Promoter.PromoterSequence & Chr(9)
                ResultData &= "minus" & Chr(9)
                ResultData &= Promoter.minus10.Relative_Position & Chr(9)
                ResultData &= Promoter.minus10.Word_Text & Chr(9)
                ResultData &= Promoter.minus10.Weight & Chr(9)
                ResultData &= Promoter.Extension.Word_Text & Chr(9)
                ResultData &= Promoter.Extension.Weight & Chr(9)
                ResultData &= Promoter.minus35.Word_Text & Chr(9)
                ResultData &= Promoter.minus35.Weight & Chr(9)
                ResultData &= Promoter.minus10_To_minus35_SpacerWeight & Chr(9)
                ResultData &= Promoter.minus10_To_TSS_SpacerWeight & Chr(9)

                For i = 0 To Promoter.PeakData.Count - 1
                    ResultData &= Promoter.Initiator(i) & Chr(9) & Promoter.PeakData(i) & Chr(9) & Promoter.BackgroundData(i) & Chr(9) & Promoter.PeakData(i) / Promoter.BackgroundData(i) & Chr(9)
                Next i


                Writer.WriteLine(ResultData)
            Next Promoter


            Writer.Close()
            FS.Close()
            Writer.Dispose()
            FS.Dispose()
        End If

    End Sub
End Class