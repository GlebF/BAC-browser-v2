﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PrimerFinder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PrimerFinder))
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Label1 = New System.Windows.Forms.Label
        Me.AmpMinTextBox = New System.Windows.Forms.TextBox
        Me.AmpMaxTextBox = New System.Windows.Forms.TextBox
        Me.TmMinTextBox = New System.Windows.Forms.TextBox
        Me.SeqTextBox = New System.Windows.Forms.RichTextBox
        Me.SeqMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TmMaxTextBox = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.PrimerMinTextBox = New System.Windows.Forms.TextBox
        Me.RevStart = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ForStart = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TotalDG = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Amplicon = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.RevGC = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ExtDG = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.GCMaxTextBox = New System.Windows.Forms.TextBox
        Me.ClearSeqCheckBox = New System.Windows.Forms.CheckBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.ForLimTextBox = New System.Windows.Forms.TextBox
        Me.RevLimTextBox = New System.Windows.Forms.TextBox
        Me.LimCheckBox = New System.Windows.Forms.CheckBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.DeltaTMTextBox = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.ClampSizeTextBox = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.PrimerMaxTextBox = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.GCMinTextBox = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.GCClampCheckBox = New System.Windows.Forms.CheckBox
        Me.InfoTextBox = New System.Windows.Forms.TextBox
        Me.DrawPanel = New System.Windows.Forms.Panel
        Me.RightBorderButton = New System.Windows.Forms.Button
        Me.LeftBorderButton = New System.Windows.Forms.Button
        Me.CLSButton = New System.Windows.Forms.Button
        Me.GoButton = New System.Windows.Forms.Button
        Me.ForGC = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.RevLength = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.RevPrimer = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TmFor = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TmRev = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ForLength = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ForPrimer = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PrimersDataGridView = New System.Windows.Forms.DataGridView
        Me.MainSplitContainer = New System.Windows.Forms.SplitContainer
        Me.SecSplitContainer = New System.Windows.Forms.SplitContainer
        Me.TerContainer = New System.Windows.Forms.SplitContainer
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.BisulphiteSeq = New System.Windows.Forms.CheckBox
        Me.CpG_Button = New System.Windows.Forms.RadioButton
        Me.SeqMenu.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.DrawPanel.SuspendLayout()
        CType(Me.PrimersDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MainSplitContainer.Panel1.SuspendLayout()
        Me.MainSplitContainer.Panel2.SuspendLayout()
        Me.MainSplitContainer.SuspendLayout()
        Me.SecSplitContainer.Panel1.SuspendLayout()
        Me.SecSplitContainer.Panel2.SuspendLayout()
        Me.SecSplitContainer.SuspendLayout()
        Me.TerContainer.Panel1.SuspendLayout()
        Me.TerContainer.Panel2.SuspendLayout()
        Me.TerContainer.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(85, 13)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Amplicon length:"
        '
        'AmpMinTextBox
        '
        Me.AmpMinTextBox.Location = New System.Drawing.Point(97, 13)
        Me.AmpMinTextBox.Name = "AmpMinTextBox"
        Me.AmpMinTextBox.Size = New System.Drawing.Size(40, 20)
        Me.AmpMinTextBox.TabIndex = 1
        Me.AmpMinTextBox.Text = "300"
        '
        'AmpMaxTextBox
        '
        Me.AmpMaxTextBox.Location = New System.Drawing.Point(164, 13)
        Me.AmpMaxTextBox.Name = "AmpMaxTextBox"
        Me.AmpMaxTextBox.Size = New System.Drawing.Size(40, 20)
        Me.AmpMaxTextBox.TabIndex = 2
        Me.AmpMaxTextBox.Text = "310"
        '
        'TmMinTextBox
        '
        Me.TmMinTextBox.Location = New System.Drawing.Point(97, 39)
        Me.TmMinTextBox.Name = "TmMinTextBox"
        Me.TmMinTextBox.Size = New System.Drawing.Size(40, 20)
        Me.TmMinTextBox.TabIndex = 3
        Me.TmMinTextBox.Text = "58"
        '
        'SeqTextBox
        '
        Me.SeqTextBox.ContextMenuStrip = Me.SeqMenu
        Me.SeqTextBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SeqTextBox.Location = New System.Drawing.Point(0, 0)
        Me.SeqTextBox.Name = "SeqTextBox"
        Me.SeqTextBox.Size = New System.Drawing.Size(999, 105)
        Me.SeqTextBox.TabIndex = 0
        Me.SeqTextBox.Text = ""
        '
        'SeqMenu
        '
        Me.SeqMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyToolStripMenuItem, Me.PasteToolStripMenuItem})
        Me.SeqMenu.Name = "SeqMenu"
        Me.SeqMenu.Size = New System.Drawing.Size(103, 48)
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Image = CType(resources.GetObject("CopyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(102, 22)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'PasteToolStripMenuItem
        '
        Me.PasteToolStripMenuItem.Image = CType(resources.GetObject("PasteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PasteToolStripMenuItem.Name = "PasteToolStripMenuItem"
        Me.PasteToolStripMenuItem.Size = New System.Drawing.Size(102, 22)
        Me.PasteToolStripMenuItem.Text = "Paste"
        '
        'TmMaxTextBox
        '
        Me.TmMaxTextBox.Location = New System.Drawing.Point(164, 39)
        Me.TmMaxTextBox.Name = "TmMaxTextBox"
        Me.TmMaxTextBox.Size = New System.Drawing.Size(40, 20)
        Me.TmMaxTextBox.TabIndex = 4
        Me.TmMaxTextBox.Text = "62"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label2.Location = New System.Drawing.Point(143, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(15, 20)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "-"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label3.Location = New System.Drawing.Point(143, 39)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(15, 20)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "-"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(50, 42)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 13)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Tm (C):"
        '
        'PrimerMinTextBox
        '
        Me.PrimerMinTextBox.Location = New System.Drawing.Point(355, 13)
        Me.PrimerMinTextBox.Name = "PrimerMinTextBox"
        Me.PrimerMinTextBox.Size = New System.Drawing.Size(40, 20)
        Me.PrimerMinTextBox.TabIndex = 5
        Me.PrimerMinTextBox.Text = "22"
        '
        'RevStart
        '
        Me.RevStart.HeaderText = "Rev start"
        Me.RevStart.Name = "RevStart"
        Me.RevStart.ReadOnly = True
        Me.RevStart.Width = 40
        '
        'ForStart
        '
        Me.ForStart.HeaderText = "For start"
        Me.ForStart.Name = "ForStart"
        Me.ForStart.ReadOnly = True
        Me.ForStart.Width = 40
        '
        'TotalDG
        '
        Me.TotalDG.HeaderText = "Total dimer dG"
        Me.TotalDG.Name = "TotalDG"
        Me.TotalDG.ReadOnly = True
        Me.TotalDG.Width = 50
        '
        'Amplicon
        '
        Me.Amplicon.HeaderText = "Amplicon"
        Me.Amplicon.Name = "Amplicon"
        Me.Amplicon.ReadOnly = True
        Me.Amplicon.Width = 55
        '
        'RevGC
        '
        Me.RevGC.HeaderText = "Rev GC"
        Me.RevGC.Name = "RevGC"
        Me.RevGC.ReadOnly = True
        Me.RevGC.Width = 40
        '
        'ExtDG
        '
        Me.ExtDG.HeaderText = "Ext. dimer dG"
        Me.ExtDG.Name = "ExtDG"
        Me.ExtDG.ReadOnly = True
        Me.ExtDG.Width = 50
        '
        'GCMaxTextBox
        '
        Me.GCMaxTextBox.Location = New System.Drawing.Point(422, 39)
        Me.GCMaxTextBox.Name = "GCMaxTextBox"
        Me.GCMaxTextBox.Size = New System.Drawing.Size(40, 20)
        Me.GCMaxTextBox.TabIndex = 8
        Me.GCMaxTextBox.Text = "60"
        '
        'ClearSeqCheckBox
        '
        Me.ClearSeqCheckBox.AutoSize = True
        Me.ClearSeqCheckBox.Location = New System.Drawing.Point(168, 110)
        Me.ClearSeqCheckBox.Name = "ClearSeqCheckBox"
        Me.ClearSeqCheckBox.Size = New System.Drawing.Size(203, 17)
        Me.ClearSeqCheckBox.TabIndex = 36
        Me.ClearSeqCheckBox.Text = "Clear text input from waste characters"
        Me.ClearSeqCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.ForLimTextBox)
        Me.GroupBox2.Controls.Add(Me.RevLimTextBox)
        Me.GroupBox2.Controls.Add(Me.LimCheckBox)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Location = New System.Drawing.Point(489, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(179, 97)
        Me.GroupBox2.TabIndex = 35
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Bounds"
        '
        'ForLimTextBox
        '
        Me.ForLimTextBox.Location = New System.Drawing.Point(128, 19)
        Me.ForLimTextBox.Name = "ForLimTextBox"
        Me.ForLimTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ForLimTextBox.TabIndex = 27
        Me.ForLimTextBox.Text = "0"
        '
        'RevLimTextBox
        '
        Me.RevLimTextBox.Location = New System.Drawing.Point(128, 45)
        Me.RevLimTextBox.Name = "RevLimTextBox"
        Me.RevLimTextBox.Size = New System.Drawing.Size(40, 20)
        Me.RevLimTextBox.TabIndex = 28
        Me.RevLimTextBox.Text = "0"
        '
        'LimCheckBox
        '
        Me.LimCheckBox.AutoSize = True
        Me.LimCheckBox.Location = New System.Drawing.Point(128, 71)
        Me.LimCheckBox.Name = "LimCheckBox"
        Me.LimCheckBox.Size = New System.Drawing.Size(15, 14)
        Me.LimCheckBox.TabIndex = 29
        Me.LimCheckBox.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(21, 71)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(104, 13)
        Me.Label14.TabIndex = 32
        Me.Label14.Text = "Use internal bounds:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(6, 22)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(119, 13)
        Me.Label12.TabIndex = 30
        Me.Label12.Text = "For primer upper bound:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(3, 48)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(122, 13)
        Me.Label13.TabIndex = 31
        Me.Label13.Text = "Rev primer lower bound:"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.AmpMinTextBox)
        Me.GroupBox1.Controls.Add(Me.AmpMaxTextBox)
        Me.GroupBox1.Controls.Add(Me.TmMinTextBox)
        Me.GroupBox1.Controls.Add(Me.TmMaxTextBox)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.DeltaTMTextBox)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.ClampSizeTextBox)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.PrimerMinTextBox)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.PrimerMaxTextBox)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.GCMinTextBox)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.GCMaxTextBox)
        Me.GroupBox1.Controls.Add(Me.GCClampCheckBox)
        Me.GroupBox1.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(480, 97)
        Me.GroupBox1.TabIndex = 34
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Amplicon"
        '
        'DeltaTMTextBox
        '
        Me.DeltaTMTextBox.Location = New System.Drawing.Point(97, 65)
        Me.DeltaTMTextBox.Name = "DeltaTMTextBox"
        Me.DeltaTMTextBox.Size = New System.Drawing.Size(40, 20)
        Me.DeltaTMTextBox.TabIndex = 18
        Me.DeltaTMTextBox.Text = "2"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(344, 68)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(72, 13)
        Me.Label11.TabIndex = 24
        Me.Label11.Text = "G/C in clamp:"
        '
        'ClampSizeTextBox
        '
        Me.ClampSizeTextBox.Location = New System.Drawing.Point(422, 65)
        Me.ClampSizeTextBox.Name = "ClampSizeTextBox"
        Me.ClampSizeTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ClampSizeTextBox.TabIndex = 23
        Me.ClampSizeTextBox.Text = "3"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(0, 68)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(91, 13)
        Me.Label10.TabIndex = 21
        Me.Label10.Text = "Tm difference (C):"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(218, 68)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(99, 13)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "3' clamp (last 5 Ns):"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(231, 42)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(118, 13)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "Primers GC content (%):"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label7.Location = New System.Drawing.Point(401, 39)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(15, 20)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "-"
        '
        'PrimerMaxTextBox
        '
        Me.PrimerMaxTextBox.Location = New System.Drawing.Point(422, 13)
        Me.PrimerMaxTextBox.Name = "PrimerMaxTextBox"
        Me.PrimerMaxTextBox.Size = New System.Drawing.Size(40, 20)
        Me.PrimerMaxTextBox.TabIndex = 6
        Me.PrimerMaxTextBox.Text = "26"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label6.Location = New System.Drawing.Point(401, 13)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(15, 20)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "-"
        '
        'GCMinTextBox
        '
        Me.GCMinTextBox.Location = New System.Drawing.Point(355, 39)
        Me.GCMinTextBox.Name = "GCMinTextBox"
        Me.GCMinTextBox.Size = New System.Drawing.Size(40, 20)
        Me.GCMinTextBox.TabIndex = 7
        Me.GCMinTextBox.Text = "40"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(273, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 13)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Primers length:"
        '
        'GCClampCheckBox
        '
        Me.GCClampCheckBox.AutoSize = True
        Me.GCClampCheckBox.Checked = True
        Me.GCClampCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.GCClampCheckBox.Location = New System.Drawing.Point(323, 68)
        Me.GCClampCheckBox.Name = "GCClampCheckBox"
        Me.GCClampCheckBox.Size = New System.Drawing.Size(15, 14)
        Me.GCClampCheckBox.TabIndex = 9
        Me.GCClampCheckBox.UseVisualStyleBackColor = True
        '
        'InfoTextBox
        '
        Me.InfoTextBox.Location = New System.Drawing.Point(817, 3)
        Me.InfoTextBox.Multiline = True
        Me.InfoTextBox.Name = "InfoTextBox"
        Me.InfoTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.InfoTextBox.Size = New System.Drawing.Size(170, 97)
        Me.InfoTextBox.TabIndex = 33
        '
        'DrawPanel
        '
        Me.DrawPanel.BackColor = System.Drawing.Color.White
        Me.DrawPanel.Controls.Add(Me.RightBorderButton)
        Me.DrawPanel.Controls.Add(Me.LeftBorderButton)
        Me.DrawPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DrawPanel.Location = New System.Drawing.Point(0, 0)
        Me.DrawPanel.Name = "DrawPanel"
        Me.DrawPanel.Size = New System.Drawing.Size(999, 88)
        Me.DrawPanel.TabIndex = 26
        '
        'RightBorderButton
        '
        Me.RightBorderButton.BackColor = System.Drawing.Color.Red
        Me.RightBorderButton.Location = New System.Drawing.Point(560, 10)
        Me.RightBorderButton.Name = "RightBorderButton"
        Me.RightBorderButton.Size = New System.Drawing.Size(10, 23)
        Me.RightBorderButton.TabIndex = 5
        Me.RightBorderButton.Text = "Button4"
        Me.RightBorderButton.UseVisualStyleBackColor = False
        Me.RightBorderButton.Visible = False
        '
        'LeftBorderButton
        '
        Me.LeftBorderButton.BackColor = System.Drawing.Color.Red
        Me.LeftBorderButton.Location = New System.Drawing.Point(369, 0)
        Me.LeftBorderButton.Name = "LeftBorderButton"
        Me.LeftBorderButton.Size = New System.Drawing.Size(10, 23)
        Me.LeftBorderButton.TabIndex = 4
        Me.LeftBorderButton.Text = "Button4"
        Me.LeftBorderButton.UseVisualStyleBackColor = False
        Me.LeftBorderButton.Visible = False
        '
        'CLSButton
        '
        Me.CLSButton.Location = New System.Drawing.Point(87, 106)
        Me.CLSButton.Name = "CLSButton"
        Me.CLSButton.Size = New System.Drawing.Size(75, 23)
        Me.CLSButton.TabIndex = 25
        Me.CLSButton.Text = "Clear"
        Me.CLSButton.UseVisualStyleBackColor = True
        '
        'GoButton
        '
        Me.GoButton.Location = New System.Drawing.Point(3, 106)
        Me.GoButton.Name = "GoButton"
        Me.GoButton.Size = New System.Drawing.Size(75, 23)
        Me.GoButton.TabIndex = 0
        Me.GoButton.Text = "Find primers"
        Me.GoButton.UseVisualStyleBackColor = True
        '
        'ForGC
        '
        Me.ForGC.HeaderText = "For GC"
        Me.ForGC.Name = "ForGC"
        Me.ForGC.ReadOnly = True
        Me.ForGC.Width = 40
        '
        'RevLength
        '
        Me.RevLength.HeaderText = "Rev length"
        Me.RevLength.Name = "RevLength"
        Me.RevLength.ReadOnly = True
        Me.RevLength.Width = 40
        '
        'RevPrimer
        '
        Me.RevPrimer.HeaderText = "Reverse"
        Me.RevPrimer.Name = "RevPrimer"
        Me.RevPrimer.ReadOnly = True
        Me.RevPrimer.Width = 200
        '
        'TmFor
        '
        Me.TmFor.HeaderText = "Tm For"
        Me.TmFor.Name = "TmFor"
        Me.TmFor.ReadOnly = True
        Me.TmFor.Width = 40
        '
        'TmRev
        '
        Me.TmRev.HeaderText = "Tm Rev"
        Me.TmRev.Name = "TmRev"
        Me.TmRev.ReadOnly = True
        Me.TmRev.Width = 40
        '
        'ForLength
        '
        Me.ForLength.HeaderText = "For length"
        Me.ForLength.Name = "ForLength"
        Me.ForLength.ReadOnly = True
        Me.ForLength.Width = 40
        '
        'ForPrimer
        '
        Me.ForPrimer.HeaderText = "Forward"
        Me.ForPrimer.Name = "ForPrimer"
        Me.ForPrimer.ReadOnly = True
        Me.ForPrimer.Width = 200
        '
        'ID
        '
        Me.ID.HeaderText = "№"
        Me.ID.Name = "ID"
        Me.ID.ReadOnly = True
        Me.ID.Width = 30
        '
        'PrimersDataGridView
        '
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PrimersDataGridView.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle6
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PrimersDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.PrimersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PrimersDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ID, Me.ForPrimer, Me.RevPrimer, Me.TmFor, Me.TmRev, Me.ForLength, Me.RevLength, Me.ForGC, Me.RevGC, Me.ForStart, Me.RevStart, Me.Amplicon, Me.ExtDG, Me.TotalDG})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PrimersDataGridView.DefaultCellStyle = DataGridViewCellStyle8
        Me.PrimersDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PrimersDataGridView.Location = New System.Drawing.Point(0, 0)
        Me.PrimersDataGridView.Name = "PrimersDataGridView"
        Me.PrimersDataGridView.ReadOnly = True
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PrimersDataGridView.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PrimersDataGridView.RowsDefaultCellStyle = DataGridViewCellStyle10
        Me.PrimersDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.PrimersDataGridView.Size = New System.Drawing.Size(999, 214)
        Me.PrimersDataGridView.TabIndex = 0
        '
        'MainSplitContainer
        '
        Me.MainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MainSplitContainer.Location = New System.Drawing.Point(0, 0)
        Me.MainSplitContainer.Name = "MainSplitContainer"
        Me.MainSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'MainSplitContainer.Panel1
        '
        Me.MainSplitContainer.Panel1.Controls.Add(Me.SeqTextBox)
        '
        'MainSplitContainer.Panel2
        '
        Me.MainSplitContainer.Panel2.Controls.Add(Me.SecSplitContainer)
        Me.MainSplitContainer.Size = New System.Drawing.Size(999, 562)
        Me.MainSplitContainer.SplitterDistance = 105
        Me.MainSplitContainer.TabIndex = 5
        '
        'SecSplitContainer
        '
        Me.SecSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SecSplitContainer.Location = New System.Drawing.Point(0, 0)
        Me.SecSplitContainer.Name = "SecSplitContainer"
        Me.SecSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SecSplitContainer.Panel1
        '
        Me.SecSplitContainer.Panel1.Controls.Add(Me.PrimersDataGridView)
        '
        'SecSplitContainer.Panel2
        '
        Me.SecSplitContainer.Panel2.Controls.Add(Me.TerContainer)
        Me.SecSplitContainer.Size = New System.Drawing.Size(999, 453)
        Me.SecSplitContainer.SplitterDistance = 214
        Me.SecSplitContainer.TabIndex = 7
        '
        'TerContainer
        '
        Me.TerContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TerContainer.Location = New System.Drawing.Point(0, 0)
        Me.TerContainer.Name = "TerContainer"
        Me.TerContainer.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'TerContainer.Panel1
        '
        Me.TerContainer.Panel1.Controls.Add(Me.GroupBox3)
        Me.TerContainer.Panel1.Controls.Add(Me.ClearSeqCheckBox)
        Me.TerContainer.Panel1.Controls.Add(Me.GroupBox1)
        Me.TerContainer.Panel1.Controls.Add(Me.CLSButton)
        Me.TerContainer.Panel1.Controls.Add(Me.InfoTextBox)
        Me.TerContainer.Panel1.Controls.Add(Me.GoButton)
        Me.TerContainer.Panel1.Controls.Add(Me.GroupBox2)
        '
        'TerContainer.Panel2
        '
        Me.TerContainer.Panel2.Controls.Add(Me.DrawPanel)
        Me.TerContainer.Size = New System.Drawing.Size(999, 235)
        Me.TerContainer.SplitterDistance = 143
        Me.TerContainer.TabIndex = 0
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.GroupBox3.Controls.Add(Me.CpG_Button)
        Me.GroupBox3.Controls.Add(Me.BisulphiteSeq)
        Me.GroupBox3.Location = New System.Drawing.Point(674, 3)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(137, 97)
        Me.GroupBox3.TabIndex = 37
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Metylation options"
        '
        'BisulphiteSeq
        '
        Me.BisulphiteSeq.AutoSize = True
        Me.BisulphiteSeq.Location = New System.Drawing.Point(6, 19)
        Me.BisulphiteSeq.Name = "BisulphiteSeq"
        Me.BisulphiteSeq.Size = New System.Drawing.Size(71, 17)
        Me.BisulphiteSeq.TabIndex = 0
        Me.BisulphiteSeq.Text = "Bisulphite"
        Me.BisulphiteSeq.UseVisualStyleBackColor = True
        '
        'CpG_Button
        '
        Me.CpG_Button.AutoSize = True
        Me.CpG_Button.Checked = True
        Me.CpG_Button.Enabled = False
        Me.CpG_Button.Location = New System.Drawing.Point(6, 42)
        Me.CpG_Button.Name = "CpG_Button"
        Me.CpG_Button.Size = New System.Drawing.Size(89, 17)
        Me.CpG_Button.TabIndex = 1
        Me.CpG_Button.TabStop = True
        Me.CpG_Button.Text = "Standart CpG"
        Me.CpG_Button.UseVisualStyleBackColor = True
        '
        'PrimerFinder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(999, 562)
        Me.Controls.Add(Me.MainSplitContainer)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "PrimerFinder"
        Me.Text = "Primers design"
        Me.SeqMenu.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.DrawPanel.ResumeLayout(False)
        CType(Me.PrimersDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MainSplitContainer.Panel1.ResumeLayout(False)
        Me.MainSplitContainer.Panel2.ResumeLayout(False)
        Me.MainSplitContainer.ResumeLayout(False)
        Me.SecSplitContainer.Panel1.ResumeLayout(False)
        Me.SecSplitContainer.Panel2.ResumeLayout(False)
        Me.SecSplitContainer.ResumeLayout(False)
        Me.TerContainer.Panel1.ResumeLayout(False)
        Me.TerContainer.Panel1.PerformLayout()
        Me.TerContainer.Panel2.ResumeLayout(False)
        Me.TerContainer.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents AmpMinTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AmpMaxTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TmMinTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SeqTextBox As System.Windows.Forms.RichTextBox
    Friend WithEvents SeqMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CopyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TmMaxTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PrimerMinTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RevStart As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ForStart As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TotalDG As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Amplicon As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RevGC As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExtDG As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GCMaxTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ClearSeqCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents ForLimTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RevLimTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LimCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents DeltaTMTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents ClampSizeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents PrimerMaxTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GCMinTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GCClampCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents InfoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DrawPanel As System.Windows.Forms.Panel
    Friend WithEvents RightBorderButton As System.Windows.Forms.Button
    Friend WithEvents LeftBorderButton As System.Windows.Forms.Button
    Friend WithEvents CLSButton As System.Windows.Forms.Button
    Friend WithEvents GoButton As System.Windows.Forms.Button
    Friend WithEvents ForGC As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RevLength As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RevPrimer As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TmFor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TmRev As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ForLength As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ForPrimer As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PrimersDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents MainSplitContainer As System.Windows.Forms.SplitContainer
    Friend WithEvents SecSplitContainer As System.Windows.Forms.SplitContainer
    Friend WithEvents TerContainer As System.Windows.Forms.SplitContainer
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents BisulphiteSeq As System.Windows.Forms.CheckBox
    Friend WithEvents CpG_Button As System.Windows.Forms.RadioButton
End Class
