﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GB_Importer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MegreGenesAndCDSsCheckBox = New System.Windows.Forms.CheckBox
        Me.OKButton = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'MegreGenesAndCDSsCheckBox
        '
        Me.MegreGenesAndCDSsCheckBox.AutoSize = True
        Me.MegreGenesAndCDSsCheckBox.Location = New System.Drawing.Point(12, 12)
        Me.MegreGenesAndCDSsCheckBox.Name = "MegreGenesAndCDSsCheckBox"
        Me.MegreGenesAndCDSsCheckBox.Size = New System.Drawing.Size(212, 17)
        Me.MegreGenesAndCDSsCheckBox.TabIndex = 0
        Me.MegreGenesAndCDSsCheckBox.Text = "Merge genes and CDSs where possible"
        Me.MegreGenesAndCDSsCheckBox.UseVisualStyleBackColor = True
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(162, 42)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.Size = New System.Drawing.Size(75, 23)
        Me.OKButton.TabIndex = 1
        Me.OKButton.Text = "OK"
        Me.OKButton.UseVisualStyleBackColor = True
        '
        'GB_Importer
        '
        Me.AcceptButton = Me.OKButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(249, 77)
        Me.Controls.Add(Me.OKButton)
        Me.Controls.Add(Me.MegreGenesAndCDSsCheckBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "GB_Importer"
        Me.Text = "GB_Importer"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MegreGenesAndCDSsCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents OKButton As System.Windows.Forms.Button
End Class
