﻿Public Class Genome_Minimap
    'This is NEW Minimap control

    Const MbLabel As String = " Mb"
    Const KbLabel As String = " Kb"

    Private MinimapLocationX As Integer = 40
    Private StartMouseDown As Boolean = False
    Private EndMouseDown As Boolean = False
    Private MoveMouseDown As Boolean = False
    Private StartInitLocation As Integer = 0
    Private EndInitLocation As Integer = 0
    Private InitCursorPosition As Point
    Private SelectedRangeStart As Integer = 0
    Private SelectedRangeEnd As Integer = 0
    Private cMyParent As Genome_Viewer

    Public Property MyParent() As Genome_Viewer
        Get
            MyParent = cMyParent
        End Get
        Set(ByVal value As Genome_Viewer)
            cMyParent = value
        End Set
    End Property

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Public Sub UpdateRange()
        ReplaceButtons()
        Me.Invalidate()
    End Sub

    Protected Overrides Sub OnSizeChanged(ByVal e As System.EventArgs)
        MyBase.OnSizeChanged(e)
        ReplaceButtons()
        Invalidate()

    End Sub

    Private Sub DrawMinimap(ByVal e As System.Windows.Forms.PaintEventArgs)
        Dim MinimapLocationY As Integer = Height / 2
        Dim MinimapLength As Integer = Width - MinimapLocationX * 2

        Dim CalculatedStartX As Integer = (cMyParent.RangeStart - 1) / cMyParent.Genome_Sequence.Length * MinimapLength
        Dim CalculatedEndX As Integer = cMyParent.RangeEnd / cMyParent.Genome_Sequence.Length * MinimapLength

        Dim TrackbarOffset As Integer = 5


        ' Dim MidMark As Integer = GenomeLength / 2
        Dim CalculatedMidMark As Integer = MinimapLength / 2 ' MidMark / GenomeLength * MinimapLength

        Dim CalculatedMark_1_4 As Integer = CalculatedMidMark / 2
        Dim CalculatedMark_3_4 As Integer = 3 * CalculatedMidMark / 2

        Dim LabelMU As String = ""

        Dim GenomeLengthString As String = ""
        Dim GenomeLengthString_2 As String = ""
        Dim GenomeLengthString_1_4 As String = ""
        Dim GenomeLengthString_3_4 As String = ""

        If MyParent.Genome_Sequence.Length < 100000 Then
            LabelMU = KbLabel
            GenomeLengthString = String.Concat(Math.Round((cMyParent.Genome_Sequence.Length / 1000), 2), LabelMU)
            GenomeLengthString_2 = String.Concat(Math.Round((cMyParent.Genome_Sequence.Length / 2000), 2), LabelMU)
            GenomeLengthString_1_4 = String.Concat(Math.Round((cMyParent.Genome_Sequence.Length / 4000), 2), LabelMU)
            GenomeLengthString_3_4 = String.Concat(Math.Round((3 * cMyParent.Genome_Sequence.Length / 4000), 2), LabelMU)
        Else
            LabelMU = MbLabel
            GenomeLengthString = String.Concat(Math.Round((cMyParent.Genome_Sequence.Length / 1000000), 2), LabelMU)
            GenomeLengthString_2 = String.Concat(Math.Round((cMyParent.Genome_Sequence.Length / 2000000), 2), LabelMU)
            GenomeLengthString_1_4 = String.Concat(Math.Round((cMyParent.Genome_Sequence.Length / 4000000), 2), LabelMU)
            GenomeLengthString_3_4 = String.Concat(Math.Round((3 * cMyParent.Genome_Sequence.Length / 4000000), 2), LabelMU)
        End If

        e.Graphics.DrawLine(Pens.Black, MinimapLocationX, MinimapLocationY, MinimapLocationX + MinimapLength, MinimapLocationY)


        e.Graphics.DrawLine(Pens.Black, MinimapLocationX, MinimapLocationY + TrackbarOffset, MinimapLocationX, MinimapLocationY - TrackbarOffset)
        e.Graphics.DrawLine(Pens.Black, MinimapLocationX + CalculatedMark_1_4, MinimapLocationY + TrackbarOffset, MinimapLocationX + CalculatedMark_1_4, MinimapLocationY - TrackbarOffset)
        e.Graphics.DrawLine(Pens.Black, MinimapLocationX + CalculatedMidMark, MinimapLocationY + TrackbarOffset, MinimapLocationX + CalculatedMidMark, MinimapLocationY - TrackbarOffset)
        e.Graphics.DrawLine(Pens.Black, MinimapLocationX + CalculatedMark_3_4, MinimapLocationY + TrackbarOffset, MinimapLocationX + CalculatedMark_3_4, MinimapLocationY - TrackbarOffset)
        e.Graphics.DrawLine(Pens.Black, MinimapLocationX + MinimapLength, MinimapLocationY + TrackbarOffset, MinimapLocationX + MinimapLength, MinimapLocationY - TrackbarOffset)

        e.Graphics.DrawString("0", Me.Font, Brushes.Black, MinimapLocationX - 10, MinimapLocationY + 10)
        e.Graphics.DrawString(GenomeLengthString, Me.Font, Brushes.Black, MinimapLocationX + MinimapLength - 10, MinimapLocationY + 10)
        e.Graphics.DrawString(GenomeLengthString_2, Me.Font, Brushes.Black, MinimapLocationX + MinimapLength / 2 - 10, MinimapLocationY + 10)

        e.Graphics.DrawString(GenomeLengthString_1_4, Me.Font, Brushes.Black, MinimapLocationX + MinimapLength / 4 - 10, MinimapLocationY + 10)
        e.Graphics.DrawString(GenomeLengthString_3_4, Me.Font, Brushes.Black, MinimapLocationX + 3 * MinimapLength / 4 - 10, MinimapLocationY + 10)



        Dim GenomeType As String = "Topology: "
        If cMyParent.GenomeTopology = True Then
            GenomeType = String.Concat(GenomeType, "Circular")
        Else
            GenomeType = String.Concat(GenomeType, "Linear")
        End If

        e.Graphics.DrawString(GenomeType, Me.Font, Brushes.Black, MinimapLocationX + 20, MinimapLocationY + 10)


        Dim PolyBrush As New SolidBrush(Color.FromArgb(80, 200, 0, 100))

        If CalculatedEndX >= CalculatedStartX Then
            Dim pt(3) As Point
            pt(0) = New Point(MinimapLocationX + CalculatedStartX, MinimapLocationY + TrackbarOffset)
            pt(1) = New Point(MinimapLocationX + CalculatedStartX, MinimapLocationY - TrackbarOffset)
            pt(2) = New Point(MinimapLocationX + CalculatedEndX, MinimapLocationY - TrackbarOffset)
            pt(3) = New Point(MinimapLocationX + CalculatedEndX, MinimapLocationY + TrackbarOffset)

            e.Graphics.FillPolygon(PolyBrush, pt)
        Else
            Dim pt_left(3) As Point

            pt_left(0) = New Point(MinimapLocationX, MinimapLocationY - TrackbarOffset)
            pt_left(1) = New Point(MinimapLocationX, MinimapLocationY + TrackbarOffset)
            pt_left(2) = New Point(MinimapLocationX + CalculatedEndX, MinimapLocationY + TrackbarOffset)
            pt_left(3) = New Point(MinimapLocationX + CalculatedEndX, MinimapLocationY - TrackbarOffset)

            Dim pt_right(3) As Point

            pt_right(0) = New Point(MinimapLocationX + CalculatedStartX, MinimapLocationY + TrackbarOffset)
            pt_right(1) = New Point(MinimapLocationX + CalculatedStartX, MinimapLocationY - TrackbarOffset)
            pt_right(2) = New Point(MinimapLocationX + MinimapLength, MinimapLocationY - TrackbarOffset)
            pt_right(3) = New Point(MinimapLocationX + MinimapLength, MinimapLocationY + TrackbarOffset)

            e.Graphics.FillPolygon(PolyBrush, pt_left)
            e.Graphics.FillPolygon(PolyBrush, pt_right)


        End If

    End Sub

    Private Sub GetNewRange()
        Dim MinimapLength As Integer = Width - MinimapLocationX * 2

        Dim StartCoordCalc As Long = RangeStartButton.Location.X + RangeStartButton.Width - MinimapLocationX
        Dim EndCoordCalc As Long = RangeEndButton.Location.X - MinimapLocationX

        Dim TransformCoefficient As Double = cMyParent.Genome_Sequence.Length / MinimapLength

        SelectedRangeStart = StartCoordCalc * TransformCoefficient + 1 '(RangeStartButton.Location.X + RangeStartButton.Width - MinimapLocationX) * GenomeLength / MinimapLength
        SelectedRangeEnd = EndCoordCalc * TransformCoefficient ' (RangeEndButton.Location.X - MinimapLocationX) * GenomeLength / MinimapLength

        Try
            cMyParent.StartTextBox.Text = SelectedRangeStart
            cMyParent.EndTextBox.Text = SelectedRangeEnd
            cMyParent.RangeStart = SelectedRangeStart
            cMyParent.RangeEnd = SelectedRangeEnd
            cMyParent.DisplayFeatures()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub ReplaceButtons()
        If Not IsNothing(cMyParent) Then
            If Not cMyParent.Genome_Sequence.Length = 0 Then

                Dim MinimapLocationY As Integer = Height / 2
                Dim MinimapLength As Integer = Width - MinimapLocationX * 2

                Dim CalculatedStartX As Integer = (cMyParent.RangeStart - 1) / cMyParent.Genome_Sequence.Length * MinimapLength
                Dim CalculatedEndX As Integer = cMyParent.RangeEnd / cMyParent.Genome_Sequence.Length * MinimapLength


                RangeStartButton.Location = New Point(MinimapLocationX + CalculatedStartX - RangeStartButton.Width, MinimapLocationY - 2 - RangeStartButton.Height)
                RangeEndButton.Location = New Point(MinimapLocationX + CalculatedEndX, MinimapLocationY - 2 - RangeStartButton.Height)

                UpdateMoveButton()

            End If
        End If
    End Sub

    Private Sub UpdateMoveButton()
        Dim Median As Integer = (RangeStartButton.Location.X + RangeStartButton.Width + RangeEndButton.Location.X) / 2
        MoveButton.Location = New Point(Median - MoveButton.Width / 2, Height / 2 + 2)

    End Sub

    Private Sub RangeStartButton_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RangeStartButton.MouseDown
        StartMouseDown = True
        StartInitLocation = RangeStartButton.Location.X
        InitCursorPosition = Windows.Forms.Cursor.Position
    End Sub

    Private Sub RangeStartButton_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RangeStartButton.MouseMove
        If StartMouseDown = True Then
            Dim deltaX As Integer = Windows.Forms.Cursor.Position.X - InitCursorPosition.X

            If Not StartInitLocation + deltaX < MinimapLocationX - RangeStartButton.Width Then
                If (Not StartInitLocation + deltaX + RangeStartButton.Width >= RangeEndButton.Location.X And cMyParent.GenomeTopology = False) Or cMyParent.GenomeTopology = True Then
                    RangeStartButton.Location = New Point(StartInitLocation + deltaX, RangeStartButton.Location.Y)
                    UpdateMoveButton()
                End If

            End If

        End If
    End Sub

    Private Sub RangeStartButton_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RangeStartButton.MouseUp
        StartMouseDown = False
        GetNewRange()
    End Sub

    Private Sub RangeEndButton_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RangeEndButton.MouseDown
        EndMouseDown = True
        EndInitLocation = RangeEndButton.Location.X
        InitCursorPosition = Windows.Forms.Cursor.Position
    End Sub

    Private Sub RangeEndButton_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RangeEndButton.MouseMove
        If EndMouseDown = True Then
            Dim deltaX As Integer = Windows.Forms.Cursor.Position.X - InitCursorPosition.X

            If Not EndInitLocation + deltaX > Width - MinimapLocationX Then
                If (Not EndInitLocation + deltaX <= RangeStartButton.Location.X + RangeStartButton.Width And cMyParent.GenomeTopology = False) Or cMyParent.GenomeTopology = True Then
                    RangeEndButton.Location = New Point(EndInitLocation + deltaX, RangeEndButton.Location.Y)
                    UpdateMoveButton()
                End If
            End If

        End If
    End Sub

    Private Sub RangeEndButton_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RangeEndButton.MouseUp
        EndMouseDown = False
        GetNewRange()
    End Sub

    Private Sub MoveButton_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MoveButton.MouseDown
        MoveMouseDown = True
        UpdateMoveButton()
        StartInitLocation = RangeStartButton.Location.X
        EndInitLocation = RangeEndButton.Location.X

        InitCursorPosition = Windows.Forms.Cursor.Position
    End Sub

    Private Sub MoveButton_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MoveButton.MouseMove
        If MoveMouseDown Then
            Dim deltaX As Integer = Windows.Forms.Cursor.Position.X - InitCursorPosition.X
            If Not StartInitLocation + deltaX < MinimapLocationX - RangeStartButton.Width And Not EndInitLocation + deltaX > Width - MinimapLocationX Then
                RangeStartButton.Location = New Point(StartInitLocation + deltaX, RangeStartButton.Location.Y)
                RangeEndButton.Location = New Point(EndInitLocation + deltaX, RangeEndButton.Location.Y)
                UpdateMoveButton()
            End If

        End If
    End Sub

    Private Sub MoveButton_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MoveButton.MouseUp
        MoveMouseDown = False
        GetNewRange()
    End Sub

    Private Sub Genome_Minimap_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        DrawMinimap(e)
    End Sub


End Class
