﻿Public Class FeaturesAssembly
    Private cntFeaturesList As New List(Of Genome_Feature)
    Private strName As String = ""
    Private bVisible As Boolean = False

    Public Property FeaturesList() As List(Of Genome_Feature)
        Get
            FeaturesList = cntFeaturesList
        End Get
        Set(ByVal value As List(Of Genome_Feature))
            cntFeaturesList = value
        End Set
    End Property

    Public Property AssemblyName() As String
        Get
            AssemblyName = strName
        End Get
        Set(ByVal value As String)
            strName = value
        End Set
    End Property

    Public Property Visible() As Boolean
        Get
            Visible = bVisible
        End Get
        Set(ByVal value As Boolean)
            bVisible = value
        End Set
    End Property

End Class
