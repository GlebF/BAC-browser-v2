﻿Public Class SequenceDisplay
    Public Locus_Name As String = ""
    Public Locus_ID As String = ""
    Public ReadList As New List(Of ReadItem)

    Public MyTranslationViever As Translation_Viewer = New Translation_Viewer


    Private Sub ReverseComplementButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReverseComplementButton.Click
        SeqTextBox.Text = Bioinformatics.GetReverseComplement(SeqTextBox.Text)
    End Sub

    Private Sub ComplementButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComplementButton.Click
        SeqTextBox.Text = Bioinformatics.GetComplement(SeqTextBox.Text)
    End Sub

    Private Sub ReverseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReverseButton.Click
        SeqTextBox.Text = Bioinformatics.ReverseStrand(SeqTextBox.Text)
    End Sub

    Private Sub CopyProtButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyProtButton.Click
        If Not TranslationTextBox.Text = "" Then
            Clipboard.SetText(TranslationTextBox.Text)
        End If

    End Sub

    Private Sub CopyButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyGeneButton.Click
        Clipboard.SetText(SeqTextBox.Text)
    End Sub

    Private Sub TranslateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TranslateButton.Click
        Try

      
            If ClearSeqCheckBox.Checked Then
                Dim ClearedSeq As String = ""
                Dim ChrSeq As Char() = SeqTextBox.Text.ToCharArray
                For Each schar As Char In ChrSeq
                    If schar = "G" Or schar = "g" Then
                        ClearedSeq &= "G"
                    End If

                    If schar = "A" Or schar = "a" Then
                        ClearedSeq &= "A"
                    End If

                    If schar = "T" Or schar = "t" Then
                        ClearedSeq &= "T"
                    End If

                    If schar = "C" Or schar = "c" Then
                        ClearedSeq &= "C"
                    End If

                    If schar = "N" Or schar = "n" Then
                        ClearedSeq &= "N"
                    End If

                    If schar = "R" Or schar = "r" Then
                        ClearedSeq &= "R"
                    End If

                    If schar = "Y" Or schar = "y" Then
                        ClearedSeq &= "Y"
                    End If

                Next
                SeqTextBox.Text = ClearedSeq
            End If


            If ReadListCheckBox.Checked And ReadList.Count > 0 Then
                MRNATextBox.Text = ""
                For Each Read As ReadItem In ReadList
                    MRNATextBox.Text &= SeqTextBox.Text.Substring(Read.ReadAbsoluteStart, Read.ReadAbsoluteEnd - Read.ReadAbsoluteStart + 1)
                Next
            Else
                MRNATextBox.Text = SeqTextBox.Text
            End If

            Dim GeneticCode As Short = TranslateComboBox.Text.Split("-")(0)
            Dim CodeTable As DataTable = Bioinformatics.GetTranslationTable(GeneticCode)

            MyTranslationViever.GeneticCode = GeneticCode
            MyTranslationViever.NucleotideSequence = MRNATextBox.Text 'SeqTextBox.Text


            If Code3CheckBox.Checked Then
                Dim SingleCode As String = Bioinformatics.Translate(MRNATextBox.Text, CodeTable)
                Dim Seq As Char() = SingleCode.ToCharArray
                Dim StopCounter As Integer = 0
                For Each SeqChr As Char In Seq
                    If SeqChr = Chr(42) Then
                        StopCounter += 1
                    End If
                Next
                StopTextBox.Text = StopCounter
                AATextBox.Text = SingleCode.Length
                TranslationTextBox.Text = Bioinformatics.Code1ToCode3(SingleCode, Master.AminoacidNamesList)

            Else
                TranslationTextBox.Text = Bioinformatics.Translate(MRNATextBox.Text, CodeTable)
                Dim Seq As Char() = TranslationTextBox.Text.ToCharArray
                Dim StopCounter As Integer = 0
                For Each SeqChr As Char In Seq
                    If SeqChr = Chr(42) Then
                        StopCounter += 1
                    End If
                Next
                StopTextBox.Text = StopCounter
                AATextBox.Text = TranslationTextBox.Text.Length
            End If

        Catch ex As Exception
            MsgBox("Error in translation! Code table may be incorrect." & vbNewLine & ex.Message)
        End Try
    End Sub

    Private Sub SeqTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SeqTextBox.TextChanged
        SeqLengthTextBox.Text = SeqTextBox.Text.Length

    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        SeqTextBox.Text = ""
        MRNATextBox.Text = ""
        TranslationTextBox.Text = ""
    End Sub

    Private Sub EF2DButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EF2DButton.Click

        If ReadListCheckBox.Checked And ReadList.Count > 0 Then
            MRNATextBox.Text = ""
            For Each Read As ReadItem In ReadList
                MRNATextBox.Text &= SeqTextBox.Text.Substring(Read.ReadAbsoluteStart, Read.ReadAbsoluteEnd - Read.ReadAbsoluteStart + 1)
            Next
        Else
            MRNATextBox.Text = SeqTextBox.Text
        End If

        Dim CodeTable As DataTable = Bioinformatics.GetTranslationTable(TranslateComboBox.Text.Split("-")(0))
        TranslationTextBox.Text = Bioinformatics.Translate(MRNATextBox.Text, CodeTable)

        Dim Found As Boolean = False

        For Each Page As TabPage In Master.MasterTabControl.TabPages
            If Page.Text = "2D view" Then
                For Each Component As Control In Page.Controls
                    If Component.GetType.Name = "Virtual2D_EF" Then
                        Found = True
                        Dim Current2DViewer As Virtual2D_EF = Component
                        Current2DViewer.ProtDataGridView.Rows.Add(True, True, _
                                                                  Locus_Name, _
                                                                  Locus_ID, _
                                                                  Bioinformatics.Calculate_Prot_pI(TranslationTextBox.Text, Master.AminoacidPIList), _
                                                                  Bioinformatics.Calculate_Prot_Mass(TranslationTextBox.Text, Master.AminoacidMWList), _
                                                                  Bioinformatics.Calculate_Prot_Hydrophobisity(TranslationTextBox.Text, Master.AminoacidHIList), _
                                                                  "Red")
                        Master.MasterTabControl.SelectedTab = Page
                        Exit For
                    End If
                Next
            End If
        Next

        If Not Found Then
            Dim NewTab As New TabPage("2D view")
            Dim New2DViewer As New Virtual2D_EF
            New2DViewer.Dock = DockStyle.Fill
            New2DViewer.ProtDataGridView.Rows.Add(True, True, _
                                                  Locus_Name, _
                                                  Locus_ID, _
                                                  Bioinformatics.Calculate_Prot_pI(TranslationTextBox.Text, Master.AminoacidPIList), _
                                                  Bioinformatics.Calculate_Prot_Mass(TranslationTextBox.Text, Master.AminoacidMWList), _
                                                  Bioinformatics.Calculate_Prot_Hydrophobisity(TranslationTextBox.Text, Master.AminoacidHIList), _
                                                  "Red")
            NewTab.Controls.Add(New2DViewer)
            Master.MasterTabControl.TabPages.Add(NewTab)
            Master.MasterTabControl.SelectedTab = NewTab
        End If


    End Sub

    Private Sub SequenceDisplay_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MyTranslationViever.Size = New Size(100, 85)
        MyTranslationViever.Dock = DockStyle.Top
        SeqPanel.Controls.Add(MyTranslationViever)
        MyTranslationViever.BringToFront()


        TranslateComboBox.Items.Clear()
        StopTextBox.Text = ""
        Dim chk As Boolean = True

        For Each Row As DataRow In Master.CodeNamesList.Rows
            TranslateComboBox.Items.Add(Row.Item(0) & "-" & Row.Item(1))
            If chk Then
                TranslateComboBox.Text = Row.Item(0) & "-" & Row.Item(1)
                chk = False
            End If
        Next

    End Sub

    Private Sub ReverseTranslationButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReverseTranslationButton.Click
        Dim OldHeader As String = Master.OpenFileDialog.Title
        Master.OpenFileDialog.Title = "Codon usage table"

        If Master.OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim ReadStream As New IO.FileStream(Master.OpenFileDialog.FileName, IO.FileMode.Open)
            Dim Reader As New IO.StreamReader(ReadStream)

            Dim CurrentLine() As String
            Dim CodonUsageTable As New List(Of CodonUsageCell)
            Dim found As Boolean = False
            Dim counter As Integer = 0

            While Reader.Peek > -1
                CurrentLine = Reader.ReadLine.Split(Chr(9))

                found = False
                counter = 0
                For Each Codon As CodonUsageCell In CodonUsageTable
                    If Codon.AA = CurrentLine(1) Then
                        found = True
                        Exit For
                    End If
                    counter += 1
                Next

                If found Then
                    CodonUsageTable(counter).AddCodon(CurrentLine(0), CurrentLine(2))
                Else
                    Dim NewAA As New CodonUsageCell
                    NewAA.AA = CurrentLine(1)
                    NewAA.AddCodon(CurrentLine(0), CurrentLine(2))
                    CodonUsageTable.Add(NewAA)
                End If

            End While


            Reader.Close()
            ReadStream.Close()
            Reader.Dispose()
            ReadStream.Dispose()

            SeqTextBox.Text = Bioinformatics.GetReverseTranslation(TranslationTextBox.Text, CodonUsageTable)



        End If

        Master.OpenFileDialog.Title = OldHeader

    End Sub

End Class