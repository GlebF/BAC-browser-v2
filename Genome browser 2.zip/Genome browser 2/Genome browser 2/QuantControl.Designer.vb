﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class QuantControl
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ImportButton = New System.Windows.Forms.Button
        Me.ColorButton = New System.Windows.Forms.Button
        Me.ColorPanel = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.TAGComboBox = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.DirectionComboBox = New System.Windows.Forms.ComboBox
        Me.EndComboBox = New System.Windows.Forms.ComboBox
        Me.StartComboBox = New System.Windows.Forms.ComboBox
        Me.DescrComboBox = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.FileTextBox = New System.Windows.Forms.TextBox
        Me.OpenButton = New System.Windows.Forms.Button
        Me.ValuesComboBox = New System.Windows.Forms.ComboBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'ImportButton
        '
        Me.ImportButton.Location = New System.Drawing.Point(12, 230)
        Me.ImportButton.Name = "ImportButton"
        Me.ImportButton.Size = New System.Drawing.Size(75, 23)
        Me.ImportButton.TabIndex = 18
        Me.ImportButton.Text = "Import"
        Me.ImportButton.UseVisualStyleBackColor = True
        '
        'ColorButton
        '
        Me.ColorButton.Location = New System.Drawing.Point(133, 200)
        Me.ColorButton.Name = "ColorButton"
        Me.ColorButton.Size = New System.Drawing.Size(75, 23)
        Me.ColorButton.TabIndex = 11
        Me.ColorButton.Text = "Color"
        Me.ColorButton.UseVisualStyleBackColor = True
        '
        'ColorPanel
        '
        Me.ColorPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ColorPanel.Location = New System.Drawing.Point(87, 200)
        Me.ColorPanel.Name = "ColorPanel"
        Me.ColorPanel.Size = New System.Drawing.Size(40, 24)
        Me.ColorPanel.TabIndex = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(49, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 13)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "TAG:"
        '
        'TAGComboBox
        '
        Me.TAGComboBox.FormattingEnabled = True
        Me.TAGComboBox.Location = New System.Drawing.Point(87, 12)
        Me.TAGComboBox.Name = "TAGComboBox"
        Me.TAGComboBox.Size = New System.Drawing.Size(121, 21)
        Me.TAGComboBox.TabIndex = 20
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(29, 96)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 27
        Me.Label5.Text = "Direction:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(52, 69)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 13)
        Me.Label4.TabIndex = 26
        Me.Label4.Text = "End:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(49, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "Start:"
        '
        'DirectionComboBox
        '
        Me.DirectionComboBox.FormattingEnabled = True
        Me.DirectionComboBox.Location = New System.Drawing.Point(87, 93)
        Me.DirectionComboBox.Name = "DirectionComboBox"
        Me.DirectionComboBox.Size = New System.Drawing.Size(121, 21)
        Me.DirectionComboBox.TabIndex = 24
        '
        'EndComboBox
        '
        Me.EndComboBox.FormattingEnabled = True
        Me.EndComboBox.Location = New System.Drawing.Point(87, 66)
        Me.EndComboBox.Name = "EndComboBox"
        Me.EndComboBox.Size = New System.Drawing.Size(121, 21)
        Me.EndComboBox.TabIndex = 23
        '
        'StartComboBox
        '
        Me.StartComboBox.FormattingEnabled = True
        Me.StartComboBox.Location = New System.Drawing.Point(87, 39)
        Me.StartComboBox.Name = "StartComboBox"
        Me.StartComboBox.Size = New System.Drawing.Size(121, 21)
        Me.StartComboBox.TabIndex = 22
        '
        'DescrComboBox
        '
        Me.DescrComboBox.FormattingEnabled = True
        Me.DescrComboBox.Location = New System.Drawing.Point(87, 120)
        Me.DescrComboBox.Name = "DescrComboBox"
        Me.DescrComboBox.Size = New System.Drawing.Size(121, 21)
        Me.DescrComboBox.TabIndex = 29
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(18, 123)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 13)
        Me.Label6.TabIndex = 28
        Me.Label6.Text = "Description:"
        '
        'FileTextBox
        '
        Me.FileTextBox.Location = New System.Drawing.Point(93, 174)
        Me.FileTextBox.Name = "FileTextBox"
        Me.FileTextBox.Size = New System.Drawing.Size(115, 20)
        Me.FileTextBox.TabIndex = 31
        '
        'OpenButton
        '
        Me.OpenButton.Location = New System.Drawing.Point(12, 172)
        Me.OpenButton.Name = "OpenButton"
        Me.OpenButton.Size = New System.Drawing.Size(75, 23)
        Me.OpenButton.TabIndex = 30
        Me.OpenButton.Text = "Open file"
        Me.OpenButton.UseVisualStyleBackColor = True
        '
        'ValuesComboBox
        '
        Me.ValuesComboBox.FormattingEnabled = True
        Me.ValuesComboBox.Location = New System.Drawing.Point(87, 147)
        Me.ValuesComboBox.Name = "ValuesComboBox"
        Me.ValuesComboBox.Size = New System.Drawing.Size(121, 21)
        Me.ValuesComboBox.TabIndex = 33
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(39, 150)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(42, 13)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "Values:"
        '
        'QuantumControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(216, 262)
        Me.Controls.Add(Me.ValuesComboBox)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.FileTextBox)
        Me.Controls.Add(Me.OpenButton)
        Me.Controls.Add(Me.DescrComboBox)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.DirectionComboBox)
        Me.Controls.Add(Me.EndComboBox)
        Me.Controls.Add(Me.StartComboBox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TAGComboBox)
        Me.Controls.Add(Me.ImportButton)
        Me.Controls.Add(Me.ColorButton)
        Me.Controls.Add(Me.ColorPanel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "QuantumControl"
        Me.Text = "Integrated values"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ImportButton As System.Windows.Forms.Button
    Friend WithEvents ColorButton As System.Windows.Forms.Button
    Friend WithEvents ColorPanel As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TAGComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents DirectionComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents EndComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents StartComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents DescrComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents FileTextBox As System.Windows.Forms.TextBox
    Friend WithEvents OpenButton As System.Windows.Forms.Button
    Friend WithEvents ValuesComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
End Class
