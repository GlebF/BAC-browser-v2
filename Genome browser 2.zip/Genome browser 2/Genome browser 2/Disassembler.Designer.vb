﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Disassembler
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Disassembler))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.UniversalSplitRadioButton = New System.Windows.Forms.RadioButton
        Me.GappedRadioButton = New System.Windows.Forms.RadioButton
        Me.UngappedRadioButton = New System.Windows.Forms.RadioButton
        Me.RegularRadioButton = New System.Windows.Forms.RadioButton
        Me.OverlapTextBox = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.LengthTextBox = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.ShowSegmentsCheckBox = New System.Windows.Forms.CheckBox
        Me.ReportTextBox = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.TmTextBox = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.AvLengthTextBox = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.RangeTextBox = New System.Windows.Forms.TextBox
        Me.OKButton = New System.Windows.Forms.Button
        Me.DGGroupBox = New System.Windows.Forms.GroupBox
        Me.AsmGroupBox = New System.Windows.Forms.GroupBox
        Me.SpacerLengthTextBox = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.dNTPCTextBox = New System.Windows.Forms.TextBox
        Me.MaxOligoLabel = New System.Windows.Forms.Label
        Me.OligoMaxTextBox = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.dG_RangeTextBox = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.OligoCTextBox = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.NaCTextBox = New System.Windows.Forms.TextBox
        Me.MgCTextBox = New System.Windows.Forms.TextBox
        Me.PrescanModeCheckBox = New System.Windows.Forms.CheckBox
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.TmGroupBox = New System.Windows.Forms.GroupBox
        Me.ProfileGroupBox = New System.Windows.Forms.GroupBox
        Me.FragGroupBox = New System.Windows.Forms.GroupBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.AutoPrimersCheckBox = New System.Windows.Forms.CheckBox
        Me.AutoPrimersComboBox = New System.Windows.Forms.ComboBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.MinLTextBox = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.TmMinTextBox = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.MaxLTextBox = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.TmMaxTextBox = New System.Windows.Forms.TextBox
        Me.MaxOligosPerFragmentTextBox = New System.Windows.Forms.TextBox
        Me.MaxOligosNumRadioButton = New System.Windows.Forms.RadioButton
        Me.FragLTextBox = New System.Windows.Forms.TextBox
        Me.AutoFragLengthRadioButton = New System.Windows.Forms.RadioButton
        Me.AutoFragDisabledRadioButton = New System.Windows.Forms.RadioButton
        Me.RegularGroupBox = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.SeqNameTextBox = New System.Windows.Forms.TextBox
        Me.ReportLabel = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.AsmGroupBox.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.FragGroupBox.SuspendLayout()
        Me.RegularGroupBox.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.UniversalSplitRadioButton)
        Me.GroupBox1.Controls.Add(Me.GappedRadioButton)
        Me.GroupBox1.Controls.Add(Me.UngappedRadioButton)
        Me.GroupBox1.Controls.Add(Me.RegularRadioButton)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 69)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Assembly type"
        '
        'UniversalSplitRadioButton
        '
        Me.UniversalSplitRadioButton.AutoSize = True
        Me.UniversalSplitRadioButton.Location = New System.Drawing.Point(109, 19)
        Me.UniversalSplitRadioButton.Name = "UniversalSplitRadioButton"
        Me.UniversalSplitRadioButton.Size = New System.Drawing.Size(63, 17)
        Me.UniversalSplitRadioButton.TabIndex = 3
        Me.UniversalSplitRadioButton.Text = "Gapped"
        Me.UniversalSplitRadioButton.UseVisualStyleBackColor = True
        '
        'GappedRadioButton
        '
        Me.GappedRadioButton.AutoSize = True
        Me.GappedRadioButton.Location = New System.Drawing.Point(109, 42)
        Me.GappedRadioButton.Name = "GappedRadioButton"
        Me.GappedRadioButton.Size = New System.Drawing.Size(86, 17)
        Me.GappedRadioButton.TabIndex = 2
        Me.GappedRadioButton.TabStop = True
        Me.GappedRadioButton.Text = "Gapped (old)"
        Me.GappedRadioButton.UseVisualStyleBackColor = True
        Me.GappedRadioButton.Visible = False
        '
        'UngappedRadioButton
        '
        Me.UngappedRadioButton.AutoSize = True
        Me.UngappedRadioButton.Checked = True
        Me.UngappedRadioButton.Location = New System.Drawing.Point(6, 42)
        Me.UngappedRadioButton.Name = "UngappedRadioButton"
        Me.UngappedRadioButton.Size = New System.Drawing.Size(75, 17)
        Me.UngappedRadioButton.TabIndex = 1
        Me.UngappedRadioButton.TabStop = True
        Me.UngappedRadioButton.Text = "Ungapped"
        Me.UngappedRadioButton.UseVisualStyleBackColor = True
        '
        'RegularRadioButton
        '
        Me.RegularRadioButton.AutoSize = True
        Me.RegularRadioButton.Location = New System.Drawing.Point(6, 19)
        Me.RegularRadioButton.Name = "RegularRadioButton"
        Me.RegularRadioButton.Size = New System.Drawing.Size(62, 17)
        Me.RegularRadioButton.TabIndex = 0
        Me.RegularRadioButton.Text = "Regular"
        Me.RegularRadioButton.UseVisualStyleBackColor = True
        '
        'OverlapTextBox
        '
        Me.OverlapTextBox.Location = New System.Drawing.Point(144, 16)
        Me.OverlapTextBox.Name = "OverlapTextBox"
        Me.OverlapTextBox.Size = New System.Drawing.Size(50, 20)
        Me.OverlapTextBox.TabIndex = 6
        Me.OverlapTextBox.Text = "20"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(91, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Overlap:"
        '
        'LengthTextBox
        '
        Me.LengthTextBox.Location = New System.Drawing.Point(144, 42)
        Me.LengthTextBox.Name = "LengthTextBox"
        Me.LengthTextBox.Size = New System.Drawing.Size(50, 20)
        Me.LengthTextBox.TabIndex = 2
        Me.LengthTextBox.Text = "40"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(72, 45)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 13)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Oligo length:"
        '
        'ShowSegmentsCheckBox
        '
        Me.ShowSegmentsCheckBox.AutoSize = True
        Me.ShowSegmentsCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ShowSegmentsCheckBox.Checked = True
        Me.ShowSegmentsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ShowSegmentsCheckBox.Location = New System.Drawing.Point(60, 45)
        Me.ShowSegmentsCheckBox.Name = "ShowSegmentsCheckBox"
        Me.ShowSegmentsCheckBox.Size = New System.Drawing.Size(134, 17)
        Me.ShowSegmentsCheckBox.TabIndex = 17
        Me.ShowSegmentsCheckBox.Text = "Show sticky segments:"
        Me.ShowSegmentsCheckBox.UseVisualStyleBackColor = True
        '
        'ReportTextBox
        '
        Me.ReportTextBox.Location = New System.Drawing.Point(6, 19)
        Me.ReportTextBox.Multiline = True
        Me.ReportTextBox.Name = "ReportTextBox"
        Me.ReportTextBox.Size = New System.Drawing.Size(288, 80)
        Me.ReportTextBox.TabIndex = 16
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(69, 74)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(69, 13)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Anneal T (C):"
        '
        'TmTextBox
        '
        Me.TmTextBox.Location = New System.Drawing.Point(144, 71)
        Me.TmTextBox.Name = "TmTextBox"
        Me.TmTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TmTextBox.TabIndex = 14
        Me.TmTextBox.Text = "60"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(13, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(125, 13)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Average segment length:"
        '
        'AvLengthTextBox
        '
        Me.AvLengthTextBox.Location = New System.Drawing.Point(144, 19)
        Me.AvLengthTextBox.Name = "AvLengthTextBox"
        Me.AvLengthTextBox.Size = New System.Drawing.Size(50, 20)
        Me.AvLengthTextBox.TabIndex = 9
        Me.AvLengthTextBox.Text = "24"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(127, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Segment length variation:"
        '
        'RangeTextBox
        '
        Me.RangeTextBox.Location = New System.Drawing.Point(144, 45)
        Me.RangeTextBox.Name = "RangeTextBox"
        Me.RangeTextBox.Size = New System.Drawing.Size(50, 20)
        Me.RangeTextBox.TabIndex = 7
        Me.RangeTextBox.Text = "5"
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(12, 440)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.Size = New System.Drawing.Size(75, 23)
        Me.OKButton.TabIndex = 1
        Me.OKButton.Text = "Generate"
        Me.OKButton.UseVisualStyleBackColor = True
        '
        'DGGroupBox
        '
        Me.DGGroupBox.Location = New System.Drawing.Point(424, 12)
        Me.DGGroupBox.Name = "DGGroupBox"
        Me.DGGroupBox.Size = New System.Drawing.Size(300, 307)
        Me.DGGroupBox.TabIndex = 2
        Me.DGGroupBox.TabStop = False
        Me.DGGroupBox.Text = "Sticky segments dG distribution"
        '
        'AsmGroupBox
        '
        Me.AsmGroupBox.Controls.Add(Me.SpacerLengthTextBox)
        Me.AsmGroupBox.Controls.Add(Me.Label17)
        Me.AsmGroupBox.Controls.Add(Me.Label16)
        Me.AsmGroupBox.Controls.Add(Me.dNTPCTextBox)
        Me.AsmGroupBox.Controls.Add(Me.MaxOligoLabel)
        Me.AsmGroupBox.Controls.Add(Me.OligoMaxTextBox)
        Me.AsmGroupBox.Controls.Add(Me.Label9)
        Me.AsmGroupBox.Controls.Add(Me.dG_RangeTextBox)
        Me.AsmGroupBox.Controls.Add(Me.Label8)
        Me.AsmGroupBox.Controls.Add(Me.OligoCTextBox)
        Me.AsmGroupBox.Controls.Add(Me.Label7)
        Me.AsmGroupBox.Controls.Add(Me.Label5)
        Me.AsmGroupBox.Controls.Add(Me.NaCTextBox)
        Me.AsmGroupBox.Controls.Add(Me.MgCTextBox)
        Me.AsmGroupBox.Controls.Add(Me.Label6)
        Me.AsmGroupBox.Controls.Add(Me.AvLengthTextBox)
        Me.AsmGroupBox.Controls.Add(Me.TmTextBox)
        Me.AsmGroupBox.Controls.Add(Me.RangeTextBox)
        Me.AsmGroupBox.Controls.Add(Me.Label3)
        Me.AsmGroupBox.Controls.Add(Me.Label2)
        Me.AsmGroupBox.Location = New System.Drawing.Point(12, 87)
        Me.AsmGroupBox.Name = "AsmGroupBox"
        Me.AsmGroupBox.Size = New System.Drawing.Size(200, 232)
        Me.AsmGroupBox.TabIndex = 3
        Me.AsmGroupBox.TabStop = False
        Me.AsmGroupBox.Text = "Assembly parameters"
        '
        'SpacerLengthTextBox
        '
        Me.SpacerLengthTextBox.Location = New System.Drawing.Point(144, 97)
        Me.SpacerLengthTextBox.Name = "SpacerLengthTextBox"
        Me.SpacerLengthTextBox.Size = New System.Drawing.Size(50, 20)
        Me.SpacerLengthTextBox.TabIndex = 12
        Me.SpacerLengthTextBox.Text = "10"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(76, 100)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(62, 13)
        Me.Label17.TabIndex = 13
        Me.Label17.Text = "Gap length:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(2, 178)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(61, 13)
        Me.Label16.TabIndex = 28
        Me.Label16.Text = "dNTP(mM):"
        '
        'dNTPCTextBox
        '
        Me.dNTPCTextBox.Location = New System.Drawing.Point(69, 175)
        Me.dNTPCTextBox.Name = "dNTPCTextBox"
        Me.dNTPCTextBox.Size = New System.Drawing.Size(30, 20)
        Me.dNTPCTextBox.TabIndex = 27
        Me.dNTPCTextBox.Text = "0,2"
        '
        'MaxOligoLabel
        '
        Me.MaxOligoLabel.AutoSize = True
        Me.MaxOligoLabel.Location = New System.Drawing.Point(51, 204)
        Me.MaxOligoLabel.Name = "MaxOligoLabel"
        Me.MaxOligoLabel.Size = New System.Drawing.Size(87, 13)
        Me.MaxOligoLabel.TabIndex = 25
        Me.MaxOligoLabel.Text = "Max oligo length:"
        '
        'OligoMaxTextBox
        '
        Me.OligoMaxTextBox.Location = New System.Drawing.Point(144, 201)
        Me.OligoMaxTextBox.Name = "OligoMaxTextBox"
        Me.OligoMaxTextBox.Size = New System.Drawing.Size(50, 20)
        Me.OligoMaxTextBox.TabIndex = 24
        Me.OligoMaxTextBox.Text = "65"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(84, 126)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(54, 13)
        Me.Label9.TabIndex = 25
        Me.Label9.Text = "dG range:"
        '
        'dG_RangeTextBox
        '
        Me.dG_RangeTextBox.Location = New System.Drawing.Point(144, 123)
        Me.dG_RangeTextBox.Name = "dG_RangeTextBox"
        Me.dG_RangeTextBox.Size = New System.Drawing.Size(50, 20)
        Me.dG_RangeTextBox.TabIndex = 24
        Me.dG_RangeTextBox.Text = "2"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(5, 152)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(58, 13)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "Oligo (nM):"
        '
        'OligoCTextBox
        '
        Me.OligoCTextBox.Location = New System.Drawing.Point(69, 149)
        Me.OligoCTextBox.Name = "OligoCTextBox"
        Me.OligoCTextBox.Size = New System.Drawing.Size(30, 20)
        Me.OligoCTextBox.TabIndex = 22
        Me.OligoCTextBox.Text = "25"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(106, 152)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 13)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "Mg (mM):"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(107, 178)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 13)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "Na (mM):"
        '
        'NaCTextBox
        '
        Me.NaCTextBox.Location = New System.Drawing.Point(164, 175)
        Me.NaCTextBox.Name = "NaCTextBox"
        Me.NaCTextBox.Size = New System.Drawing.Size(30, 20)
        Me.NaCTextBox.TabIndex = 19
        Me.NaCTextBox.Text = "50"
        '
        'MgCTextBox
        '
        Me.MgCTextBox.Location = New System.Drawing.Point(164, 149)
        Me.MgCTextBox.Name = "MgCTextBox"
        Me.MgCTextBox.Size = New System.Drawing.Size(30, 20)
        Me.MgCTextBox.TabIndex = 18
        Me.MgCTextBox.Text = "10"
        '
        'PrescanModeCheckBox
        '
        Me.PrescanModeCheckBox.AutoSize = True
        Me.PrescanModeCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.PrescanModeCheckBox.Location = New System.Drawing.Point(86, 68)
        Me.PrescanModeCheckBox.Name = "PrescanModeCheckBox"
        Me.PrescanModeCheckBox.Size = New System.Drawing.Size(108, 17)
        Me.PrescanModeCheckBox.TabIndex = 24
        Me.PrescanModeCheckBox.Text = "Show report only:"
        Me.PrescanModeCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.ReportTextBox)
        Me.GroupBox5.Location = New System.Drawing.Point(218, 325)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(300, 111)
        Me.GroupBox5.TabIndex = 18
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Report"
        '
        'TmGroupBox
        '
        Me.TmGroupBox.Location = New System.Drawing.Point(730, 12)
        Me.TmGroupBox.Name = "TmGroupBox"
        Me.TmGroupBox.Size = New System.Drawing.Size(300, 307)
        Me.TmGroupBox.TabIndex = 19
        Me.TmGroupBox.TabStop = False
        Me.TmGroupBox.Text = "Sticky segments Tm distribution"
        '
        'ProfileGroupBox
        '
        Me.ProfileGroupBox.Location = New System.Drawing.Point(524, 325)
        Me.ProfileGroupBox.Name = "ProfileGroupBox"
        Me.ProfileGroupBox.Size = New System.Drawing.Size(506, 111)
        Me.ProfileGroupBox.TabIndex = 20
        Me.ProfileGroupBox.TabStop = False
        Me.ProfileGroupBox.Text = "Sequence dG profile"
        '
        'FragGroupBox
        '
        Me.FragGroupBox.Controls.Add(Me.Label11)
        Me.FragGroupBox.Controls.Add(Me.Label15)
        Me.FragGroupBox.Controls.Add(Me.AutoPrimersCheckBox)
        Me.FragGroupBox.Controls.Add(Me.AutoPrimersComboBox)
        Me.FragGroupBox.Controls.Add(Me.Label14)
        Me.FragGroupBox.Controls.Add(Me.MinLTextBox)
        Me.FragGroupBox.Controls.Add(Me.Label13)
        Me.FragGroupBox.Controls.Add(Me.TmMinTextBox)
        Me.FragGroupBox.Controls.Add(Me.Label12)
        Me.FragGroupBox.Controls.Add(Me.MaxLTextBox)
        Me.FragGroupBox.Controls.Add(Me.Label10)
        Me.FragGroupBox.Controls.Add(Me.TmMaxTextBox)
        Me.FragGroupBox.Controls.Add(Me.MaxOligosPerFragmentTextBox)
        Me.FragGroupBox.Controls.Add(Me.MaxOligosNumRadioButton)
        Me.FragGroupBox.Controls.Add(Me.FragLTextBox)
        Me.FragGroupBox.Controls.Add(Me.AutoFragLengthRadioButton)
        Me.FragGroupBox.Controls.Add(Me.AutoFragDisabledRadioButton)
        Me.FragGroupBox.Location = New System.Drawing.Point(218, 87)
        Me.FragGroupBox.Name = "FragGroupBox"
        Me.FragGroupBox.Size = New System.Drawing.Size(200, 232)
        Me.FragGroupBox.TabIndex = 21
        Me.FragGroupBox.TabStop = False
        Me.FragGroupBox.Text = "Automatic fragment design"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(12, 126)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(81, 13)
        Me.Label11.TabIndex = 43
        Me.Label11.Text = "Overlap design:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(12, 100)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(126, 13)
        Me.Label15.TabIndex = 42
        Me.Label15.Text = "Average fragment length:"
        '
        'AutoPrimersCheckBox
        '
        Me.AutoPrimersCheckBox.AutoSize = True
        Me.AutoPrimersCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.AutoPrimersCheckBox.Checked = True
        Me.AutoPrimersCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.AutoPrimersCheckBox.Location = New System.Drawing.Point(3, 203)
        Me.AutoPrimersCheckBox.Name = "AutoPrimersCheckBox"
        Me.AutoPrimersCheckBox.Size = New System.Drawing.Size(63, 17)
        Me.AutoPrimersCheckBox.TabIndex = 25
        Me.AutoPrimersCheckBox.Text = "Primers:"
        Me.AutoPrimersCheckBox.UseVisualStyleBackColor = True
        '
        'AutoPrimersComboBox
        '
        Me.AutoPrimersComboBox.FormattingEnabled = True
        Me.AutoPrimersComboBox.Items.AddRange(New Object() {"None", "pTZ+overlap", "pTZ(Recombination_F)", "pTZ(Recombination_R)", "pET(BamHI/SalI)", "pET(BamHI/XhoI)"})
        Me.AutoPrimersComboBox.Location = New System.Drawing.Point(72, 201)
        Me.AutoPrimersComboBox.Name = "AutoPrimersComboBox"
        Me.AutoPrimersComboBox.Size = New System.Drawing.Size(122, 21)
        Me.AutoPrimersComboBox.TabIndex = 26
        Me.AutoPrimersComboBox.Text = "None"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(128, 174)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(10, 13)
        Me.Label14.TabIndex = 41
        Me.Label14.Text = "-"
        '
        'MinLTextBox
        '
        Me.MinLTextBox.Location = New System.Drawing.Point(72, 171)
        Me.MinLTextBox.Name = "MinLTextBox"
        Me.MinLTextBox.Size = New System.Drawing.Size(50, 20)
        Me.MinLTextBox.TabIndex = 40
        Me.MinLTextBox.Text = "15"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(128, 148)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(10, 13)
        Me.Label13.TabIndex = 38
        Me.Label13.Text = "-"
        '
        'TmMinTextBox
        '
        Me.TmMinTextBox.Location = New System.Drawing.Point(72, 145)
        Me.TmMinTextBox.Name = "TmMinTextBox"
        Me.TmMinTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TmMinTextBox.TabIndex = 37
        Me.TmMinTextBox.Text = "55"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(23, 174)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(43, 13)
        Me.Label12.TabIndex = 36
        Me.Label12.Text = "Length:"
        '
        'MaxLTextBox
        '
        Me.MaxLTextBox.Location = New System.Drawing.Point(144, 171)
        Me.MaxLTextBox.Name = "MaxLTextBox"
        Me.MaxLTextBox.Size = New System.Drawing.Size(50, 20)
        Me.MaxLTextBox.TabIndex = 35
        Me.MaxLTextBox.Text = "20"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(25, 148)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(41, 13)
        Me.Label10.TabIndex = 34
        Me.Label10.Text = "Tm (C):"
        '
        'TmMaxTextBox
        '
        Me.TmMaxTextBox.Location = New System.Drawing.Point(144, 145)
        Me.TmMaxTextBox.Name = "TmMaxTextBox"
        Me.TmMaxTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TmMaxTextBox.TabIndex = 33
        Me.TmMaxTextBox.Text = "70"
        '
        'MaxOligosPerFragmentTextBox
        '
        Me.MaxOligosPerFragmentTextBox.Location = New System.Drawing.Point(144, 45)
        Me.MaxOligosPerFragmentTextBox.Name = "MaxOligosPerFragmentTextBox"
        Me.MaxOligosPerFragmentTextBox.Size = New System.Drawing.Size(50, 20)
        Me.MaxOligosPerFragmentTextBox.TabIndex = 32
        Me.MaxOligosPerFragmentTextBox.Text = "50"
        '
        'MaxOligosNumRadioButton
        '
        Me.MaxOligosNumRadioButton.AutoSize = True
        Me.MaxOligosNumRadioButton.Location = New System.Drawing.Point(6, 48)
        Me.MaxOligosNumRadioButton.Name = "MaxOligosNumRadioButton"
        Me.MaxOligosNumRadioButton.Size = New System.Drawing.Size(138, 17)
        Me.MaxOligosNumRadioButton.TabIndex = 31
        Me.MaxOligosNumRadioButton.Text = "Set max oiigos per frag.:"
        Me.MaxOligosNumRadioButton.UseVisualStyleBackColor = True
        '
        'FragLTextBox
        '
        Me.FragLTextBox.Location = New System.Drawing.Point(144, 97)
        Me.FragLTextBox.Name = "FragLTextBox"
        Me.FragLTextBox.Size = New System.Drawing.Size(50, 20)
        Me.FragLTextBox.TabIndex = 26
        Me.FragLTextBox.Text = "1000"
        '
        'AutoFragLengthRadioButton
        '
        Me.AutoFragLengthRadioButton.AutoSize = True
        Me.AutoFragLengthRadioButton.Location = New System.Drawing.Point(6, 74)
        Me.AutoFragLengthRadioButton.Name = "AutoFragLengthRadioButton"
        Me.AutoFragLengthRadioButton.Size = New System.Drawing.Size(148, 17)
        Me.AutoFragLengthRadioButton.TabIndex = 1
        Me.AutoFragLengthRadioButton.Text = "Thermodynamic alignment"
        Me.AutoFragLengthRadioButton.UseVisualStyleBackColor = True
        '
        'AutoFragDisabledRadioButton
        '
        Me.AutoFragDisabledRadioButton.AutoSize = True
        Me.AutoFragDisabledRadioButton.Checked = True
        Me.AutoFragDisabledRadioButton.Location = New System.Drawing.Point(6, 22)
        Me.AutoFragDisabledRadioButton.Name = "AutoFragDisabledRadioButton"
        Me.AutoFragDisabledRadioButton.Size = New System.Drawing.Size(66, 17)
        Me.AutoFragDisabledRadioButton.TabIndex = 0
        Me.AutoFragDisabledRadioButton.TabStop = True
        Me.AutoFragDisabledRadioButton.Text = "Disabled"
        Me.AutoFragDisabledRadioButton.UseVisualStyleBackColor = True
        '
        'RegularGroupBox
        '
        Me.RegularGroupBox.Controls.Add(Me.OverlapTextBox)
        Me.RegularGroupBox.Controls.Add(Me.Label1)
        Me.RegularGroupBox.Controls.Add(Me.Label4)
        Me.RegularGroupBox.Controls.Add(Me.LengthTextBox)
        Me.RegularGroupBox.Location = New System.Drawing.Point(218, 12)
        Me.RegularGroupBox.Name = "RegularGroupBox"
        Me.RegularGroupBox.Size = New System.Drawing.Size(200, 69)
        Me.RegularGroupBox.TabIndex = 22
        Me.RegularGroupBox.TabStop = False
        Me.RegularGroupBox.Text = "Regular assembly"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.SeqNameTextBox)
        Me.GroupBox2.Controls.Add(Me.ShowSegmentsCheckBox)
        Me.GroupBox2.Controls.Add(Me.PrescanModeCheckBox)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 325)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(200, 111)
        Me.GroupBox2.TabIndex = 25
        Me.GroupBox2.TabStop = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(31, 22)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(58, 13)
        Me.Label18.TabIndex = 26
        Me.Label18.Text = "Seq name:"
        '
        'SeqNameTextBox
        '
        Me.SeqNameTextBox.Location = New System.Drawing.Point(95, 19)
        Me.SeqNameTextBox.Name = "SeqNameTextBox"
        Me.SeqNameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.SeqNameTextBox.TabIndex = 25
        '
        'ReportLabel
        '
        Me.ReportLabel.AutoSize = True
        Me.ReportLabel.Location = New System.Drawing.Point(93, 445)
        Me.ReportLabel.Name = "ReportLabel"
        Me.ReportLabel.Size = New System.Drawing.Size(39, 13)
        Me.ReportLabel.TabIndex = 26
        Me.ReportLabel.Text = "Report"
        '
        'Disassembler
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1044, 471)
        Me.Controls.Add(Me.ReportLabel)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.RegularGroupBox)
        Me.Controls.Add(Me.FragGroupBox)
        Me.Controls.Add(Me.ProfileGroupBox)
        Me.Controls.Add(Me.TmGroupBox)
        Me.Controls.Add(Me.OKButton)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.AsmGroupBox)
        Me.Controls.Add(Me.DGGroupBox)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Disassembler"
        Me.Text = "Assembly design"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.AsmGroupBox.ResumeLayout(False)
        Me.AsmGroupBox.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.FragGroupBox.ResumeLayout(False)
        Me.FragGroupBox.PerformLayout()
        Me.RegularGroupBox.ResumeLayout(False)
        Me.RegularGroupBox.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents UngappedRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents RegularRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents LengthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents OKButton As System.Windows.Forms.Button
    Friend WithEvents OverlapTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents RangeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents AvLengthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TmTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ReportTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ShowSegmentsCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents DGGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents GappedRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents AsmGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents TmGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents OligoCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents NaCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MgCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProfileGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents PrescanModeCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents MaxOligoLabel As System.Windows.Forms.Label
    Friend WithEvents OligoMaxTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents dG_RangeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FragGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents AutoFragLengthRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents AutoFragDisabledRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents FragLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MaxOligosPerFragmentTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MaxOligosNumRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TmMinTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents MaxLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TmMaxTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents MinLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents UniversalSplitRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents dNTPCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SpacerLengthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents RegularGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents AutoPrimersCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents AutoPrimersComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ReportLabel As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents SeqNameTextBox As System.Windows.Forms.TextBox
End Class
