﻿Public Class ORF_Finder

    Public Shared SearchCount As Integer = 0
    Public MyGenomeViewer As Genome_Viewer

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click


        Dim NewORFList As New List(Of Genome_Feature)
        Dim InitList As New List(Of String)
        Dim TerList As New List(Of String)

        If UnivarsalInitCheckBox.Checked Then
            InitList.Add("ATG")
        End If

        If TTGGTGCheckBox.Checked Then
            InitList.Add("TTG")
            InitList.Add("GTG")
        End If

        If ATAATTCheckBox.Checked Then
            InitList.Add("ATA")
            InitList.Add("ATT")
        End If

        If ManualStartCheckBox.Checked Then
            Dim Starts As String() = ManualStartTextBox.Text.Split(",")
            For Each StartC As String In Starts
                InitList.Add(StartC)
            Next
        End If

        If TAACheckBox.Checked Then
            TerList.Add("TAA")
        End If

        If TAGCheckBox.Checked Then
            TerList.Add("TAG")
        End If

        If TGACheckBox.Checked Then
            TerList.Add("TGA")
        End If

        If ManualStopCheckBox.Checked Then
            Dim Stops As String() = ManualStopCheckBox.Text.Split(",")
            For Each StopC As String In Stops
                TerList.Add(StopC)
            Next
        End If

        NewORFList = Bioinformatics.FindORFs(MyGenomeViewer.Genome_Sequence, InitList, TerList, LengthTextBox.Text)

        Dim NewAssembly As New FeaturesAssembly
        NewAssembly.AssemblyName = "ORF search " & SearchCount
        NewAssembly.Visible = True


        For Each NewORF As Genome_Feature In NewORFList
            NewORF.Group = NewAssembly.AssemblyName
            NewAssembly.FeaturesList.Add(NewORF)

        Next

        MyGenomeViewer.ShowFeaturesFromGroup(NewAssembly.AssemblyName)
        MyGenomeViewer.Features_Groups_List.Add(NewAssembly)
        MyGenomeViewer.FeaturesGroupsListBox.Items.Add(NewAssembly.AssemblyName)
        MyGenomeViewer.FeaturesGroupsListBox.Items(MyGenomeViewer.FeaturesGroupsListBox.Items.Count - 1).Checked = True
        MyGenomeViewer.DisplayFeatures()

        SearchCount += 1
        Me.Close()
    End Sub

    Private Sub ManualStartCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ManualStartCheckBox.CheckedChanged
        If ManualStartCheckBox.Checked Then
            UnivarsalInitCheckBox.Checked = False
            TTGGTGCheckBox.Checked = False
            ATAATTCheckBox.Checked = False
            ManualStartCheckBox.Checked = True
        End If
    End Sub

    Private Sub ManualStopCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ManualStopCheckBox.CheckedChanged
        If ManualStopCheckBox.Checked Then
            TAACheckBox.Checked = False
            TAGCheckBox.Checked = False
            TGACheckBox.Checked = False
            ManualStopCheckBox.Checked = True
        End If
    End Sub

    Private Sub UnivarsalInitCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UnivarsalInitCheckBox.CheckedChanged, TTGGTGCheckBox.CheckedChanged, ATAATTCheckBox.CheckedChanged
        If ManualStartCheckBox.Checked Then
            ManualStartCheckBox.Checked = False
        End If
    End Sub

    Private Sub TAACheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TAACheckBox.CheckedChanged, TAACheckBox.CheckedChanged, TAGCheckBox.CheckedChanged, TGACheckBox.CheckedChanged
        If ManualStopCheckBox.Checked Then
            ManualStopCheckBox.Checked = False
        End If
    End Sub

End Class