﻿Public Class FeatureData
    'This class is used for compatibility between genbank and local formats

    Private ProperyNameList As New List(Of String)
    Private PropertyValueList As New List(Of String)

    Public Property DataHeaders() As List(Of String)
        Get
            DataHeaders = ProperyNameList
        End Get
        Set(ByVal value As List(Of String))
            ProperyNameList = value
        End Set
    End Property

    Public Property DataValues() As List(Of String)
        Get
            DataValues = PropertyValueList
        End Get
        Set(ByVal value As List(Of String))
            PropertyValueList = value
        End Set
    End Property

End Class
