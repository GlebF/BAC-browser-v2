﻿Public Class SystemTextBox
    Private DialogValue As Short = -1

    Public Function DialogReturn()
        Me.ShowDialog()
        Return DialogValue
    End Function

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        DialogValue = 1
        Me.Close()
    End Sub

    Private Sub AbortButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AbortButton.Click
        DialogValue = -1
        Me.Close()
    End Sub

End Class