﻿Public Class ChartDisplay

    Private ChartMode As Short = 0

    '0 - Distridution plot
    '1 - Profile plot

    Private Values As List(Of Single) = Nothing

    Private ChartMargin As Integer = 24
    Private ScaleMargin As Integer = 12
    Private BarMargin As Integer = 2
    Private ChartColor As Color = Color.Black
    Private BinsNumber As Integer = 24

    Public Property Chart_Draw_Mode() As Short
        Get
            Chart_Draw_Mode = ChartMode
        End Get
        Set(ByVal value As Short)
            ChartMode = value
        End Set
    End Property

    Public Property ChartValues() As List(Of Single)
        Get
            ChartValues = Values
        End Get
        Set(ByVal value As List(Of Single))
            Values = value
        End Set
    End Property

    Public Property Chart_Color() As Color
        Get
            Chart_Color = ChartColor
        End Get
        Set(ByVal value As Color)
            ChartColor = value
        End Set
    End Property

    Private Sub DrawCumulativeDistribution(ByVal g As Graphics)

        Dim MaxVal As Single = Math.Round(Bioinformatics.Maximum(Values), 2)
        Dim MinVal As Single = Math.Round(Bioinformatics.Minimum(Values), 2)

        Dim ValRange As Single = MaxVal - MinVal

        Dim BinSize As Single = Math.Round(ValRange / BinsNumber, 2)

        Dim Bins(BinsNumber) As Integer

        Dim BinBottom As Single = MinVal
        Dim BinTop As Single = MinVal + BinSize
        Dim CurrentBin As Integer = 0

        For i = 1 To BinsNumber
            CurrentBin = 0

            If i = BinsNumber Then 'Shift the top margin of the last bin to include the biggest value
                BinTop += 2
            End If



            For Each Val As Single In Values
                If Val >= BinBottom And Val < BinTop Then
                    CurrentBin += 1
                End If
            Next Val

            Bins(i) = CurrentBin

            BinBottom += BinSize
            BinTop += BinSize

        Next i


        'Draw axis
        Dim AxisPen As Pen = New Pen(Color.Black, 2)
        Dim StartOfY As Integer = Me.Height - ChartMargin
        Dim CoordinateStart As Point = New Point(ChartMargin, StartOfY)
        Dim X_MaxPoint As Point = New Point(Me.Width - ScaleMargin, StartOfY)
        Dim Y_MaxPoint As Point = New Point(ChartMargin, ScaleMargin)
        g.DrawLine(AxisPen, CoordinateStart, X_MaxPoint)
        g.DrawLine(AxisPen, CoordinateStart, Y_MaxPoint)


        'Draw bins
        Dim Xstep As Integer = (Me.Width - ChartMargin * 2) / BinsNumber
        Dim CurrentX As Integer = ChartMargin



        Dim MaxBin As Integer = Bioinformatics.Maximum(Bins)
        Dim Y As Integer = Me.Height - ChartMargin * 2
        Dim Ystep As Integer = Y / MaxBin

        'Draw Y axis scale
        Dim HalfBin As Integer = MaxBin * 0.5
        Dim Bin75 As Integer = MaxBin * 0.75
        Dim Bin25 As Integer = MaxBin * 0.25

        g.DrawLine(AxisPen, ScaleMargin, StartOfY - Ystep * HalfBin, ChartMargin, StartOfY - Ystep * HalfBin)
        g.DrawLine(AxisPen, ScaleMargin, StartOfY - Ystep * Bin75, ChartMargin, StartOfY - Ystep * Bin75)
        g.DrawLine(AxisPen, ScaleMargin, StartOfY - Ystep * Bin25, ChartMargin, StartOfY - Ystep * Bin25)
        g.DrawLine(AxisPen, ScaleMargin, StartOfY - Ystep * MaxBin, ChartMargin, StartOfY - Ystep * MaxBin)

        g.DrawString(MaxBin, Me.Font, Brushes.Black, 1, StartOfY - Ystep * MaxBin - Me.Font.Height - 1)
        g.DrawString(HalfBin, Me.Font, Brushes.Black, 1, StartOfY - Ystep * HalfBin - Me.Font.Height - 1)
        g.DrawString(Bin75, Me.Font, Brushes.Black, 1, StartOfY - Ystep * Bin75 - Me.Font.Height - 1)
        g.DrawString(Bin25, Me.Font, Brushes.Black, 1, StartOfY - Ystep * Bin25 - Me.Font.Height - 1)



        'Draw X axis scale
        Dim Y_Of_Label As Integer = Me.Height - ScaleMargin
        Dim Shift0 As Integer = g.MeasureString(MinVal, Me.Font).Width / 2
        g.DrawString(MinVal, Me.Font, Brushes.Black, ChartMargin - Shift0, Y_Of_Label + 1)
        g.DrawLine(AxisPen, ChartMargin, StartOfY, ChartMargin, Y_Of_Label)

        Dim Shift100 As Integer = g.MeasureString(MaxVal, Me.Font).Width / 2
        g.DrawString(MaxVal, Me.Font, Brushes.Black, ChartMargin + Xstep * BinsNumber - Shift100, Y_Of_Label + 1)
        g.DrawLine(AxisPen, ChartMargin + Xstep * BinsNumber, StartOfY, ChartMargin + Xstep * BinsNumber, Y_Of_Label)

        Dim HalfBinsNumber As Integer = BinsNumber * 0.5
        Dim MidVal As Single = Math.Round((MaxVal + MinVal) * 0.5, 2)
        Dim MidShift As Integer = g.MeasureString(MidVal, Me.Font).Width / 2
        g.DrawString(MidVal, Me.Font, Brushes.Black, ChartMargin + Xstep * HalfBinsNumber - MidShift, Y_Of_Label + 1)
        g.DrawLine(AxisPen, ChartMargin + Xstep * HalfBinsNumber, StartOfY, ChartMargin + Xstep * HalfBinsNumber, Y_Of_Label)


        Dim BinsNum75 As Integer = BinsNumber * 0.75
        Dim BinsNum25 As Integer = BinsNumber * 0.25
        Dim BinsVal75 As Single = Math.Round((MaxVal + MidVal) * 0.5, 2)
        Dim BinsVal25 As Single = Math.Round((MidVal + MinVal) * 0.5, 2)
        Dim Shift75 As Integer = g.MeasureString(BinsVal75, Me.Font).Width / 2
        Dim Shift25 As Integer = g.MeasureString(BinsVal25, Me.Font).Width / 2

        g.DrawString(BinsVal75, Me.Font, Brushes.Black, ChartMargin + Xstep * BinsNum75 - Shift75, Y_Of_Label + 1)
        g.DrawString(BinsVal25, Me.Font, Brushes.Black, ChartMargin + Xstep * BinsNum25 - Shift25, Y_Of_Label + 1)
        g.DrawLine(AxisPen, ChartMargin + Xstep * BinsNum75, StartOfY, ChartMargin + Xstep * BinsNum75, Y_Of_Label)
        g.DrawLine(AxisPen, ChartMargin + Xstep * BinsNum25, StartOfY, ChartMargin + Xstep * BinsNum25, Y_Of_Label)

        Dim BarBrush As Brush = New SolidBrush(ChartColor)


        'Draw bar chart
        For i = 1 To BinsNumber

            Dim r As New Rectangle(CurrentX + BarMargin, Y - Bins(i) * Ystep + ChartMargin, Xstep - BarMargin * 2, Bins(i) * Ystep)

            g.FillRectangle(BarBrush, r)

            CurrentX += Xstep
        Next i



    End Sub

    Private Sub DrawProfile(ByVal g As Graphics)
        Dim MaxVal As Single = Math.Round(Bioinformatics.Maximum(Values), 2)
        Dim MinVal As Single = Math.Round(Bioinformatics.Minimum(Values), 2)

        Dim ValRange As Single = MaxVal - MinVal









        'Draw axis
        Dim AxisPen As Pen = New Pen(Color.Black, 2)
        Dim StartOfY As Integer = Me.Height - ChartMargin
        Dim Y As Integer = Me.Height - ChartMargin * 2
        Dim CoordinateStart As Point = New Point(ChartMargin, StartOfY)
        Dim X_MaxPoint As Point = New Point(Me.Width - ScaleMargin, StartOfY)
        Dim Y_MaxPoint As Point = New Point(ChartMargin, ScaleMargin)
        g.DrawLine(AxisPen, CoordinateStart, X_MaxPoint)
        g.DrawLine(AxisPen, CoordinateStart, Y_MaxPoint)

        g.DrawString(MinVal, Me.Font, Brushes.Black, 1, StartOfY)
        g.DrawString(MaxVal, Me.Font, Brushes.Black, 1, 0)


        Dim X_Range As Integer = Me.Width - ChartMargin * 2
        Dim X_Step As Single = X_Range / Values.Count


        Dim R_Width As Integer = X_Step
        If R_Width < 1 Then
            R_Width = 1
        End If



        Dim ChartBrush As Brush = New SolidBrush(ChartColor)
        Dim CurrentX As Integer = 0
        Dim CurrentY As Integer = 0
        'Draw chart
        For i = 0 To Values.Count - 1

            CurrentX = ChartMargin + X_Step * i
            CurrentY = Y * (Values(i) - MinVal) / ValRange

            g.FillRectangle(ChartBrush, CurrentX, StartOfY - CurrentY, R_Width, CurrentY)

        Next i


    End Sub


    Private Sub ChartDisplay_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint

        If Not IsNothing(Values) Then

            Select Case ChartMode
                Case 0
                    DrawCumulativeDistribution(e.Graphics)
                Case 1
                    DrawProfile(e.Graphics)
            End Select


        End If


    End Sub



End Class
