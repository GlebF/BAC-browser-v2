﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MBMD_Search
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MBMD_Search))
        Me.SeqTextBox = New System.Windows.Forms.TextBox
        Me.SeqFileTextBox = New System.Windows.Forms.TextBox
        Me.OpenButton = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.PrimeMismatchTextBox = New System.Windows.Forms.TextBox
        Me.GoButton = New System.Windows.Forms.Button
        Me.Label10 = New System.Windows.Forms.Label
        Me.PrimeMatchTextBox = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.PWMSelTextBox = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.ExtCutoffTextBox = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.PrimeCutoffTextBox = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.WordLTextBox = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.TextBox_CP = New System.Windows.Forms.TextBox
        Me.TextBox_GP = New System.Windows.Forms.TextBox
        Me.TextBox_TP = New System.Windows.Forms.TextBox
        Me.TextBox_AP = New System.Windows.Forms.TextBox
        Me.ManualPButton = New System.Windows.Forms.RadioButton
        Me.AutoPButton = New System.Windows.Forms.RadioButton
        Me.GCButton = New System.Windows.Forms.RadioButton
        Me.GCTextBox = New System.Windows.Forms.TextBox
        Me.ReportPanel = New System.Windows.Forms.Panel
        Me.ClearButton = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.DistanceTextBox = New System.Windows.Forms.TextBox
        Me.CombineMotifsCheckBox = New System.Windows.Forms.CheckBox
        Me.MinLTextBox = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.TrimThresholdTextBox = New System.Windows.Forms.TextBox
        Me.TrimCheckBox = New System.Windows.Forms.CheckBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.InvertXCheckBox = New System.Windows.Forms.CheckBox
        Me.RightAlignCheckBox = New System.Windows.Forms.CheckBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'SeqTextBox
        '
        Me.SeqTextBox.Location = New System.Drawing.Point(12, 25)
        Me.SeqTextBox.Multiline = True
        Me.SeqTextBox.Name = "SeqTextBox"
        Me.SeqTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.SeqTextBox.Size = New System.Drawing.Size(310, 170)
        Me.SeqTextBox.TabIndex = 30
        '
        'SeqFileTextBox
        '
        Me.SeqFileTextBox.Location = New System.Drawing.Point(12, 214)
        Me.SeqFileTextBox.Name = "SeqFileTextBox"
        Me.SeqFileTextBox.Size = New System.Drawing.Size(198, 20)
        Me.SeqFileTextBox.TabIndex = 31
        '
        'OpenButton
        '
        Me.OpenButton.Location = New System.Drawing.Point(216, 212)
        Me.OpenButton.Name = "OpenButton"
        Me.OpenButton.Size = New System.Drawing.Size(50, 23)
        Me.OpenButton.TabIndex = 32
        Me.OpenButton.Text = "Open"
        Me.OpenButton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 198)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(143, 13)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "OR load sequences from file:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.PrimeMismatchTextBox)
        Me.GroupBox1.Controls.Add(Me.GoButton)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.PrimeMatchTextBox)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.PWMSelTextBox)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.ExtCutoffTextBox)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.PrimeCutoffTextBox)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.WordLTextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(328, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(237, 232)
        Me.GroupBox1.TabIndex = 34
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Search parameters"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(72, 153)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(109, 13)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "Prime negative score:"
        '
        'PrimeMismatchTextBox
        '
        Me.PrimeMismatchTextBox.Location = New System.Drawing.Point(187, 150)
        Me.PrimeMismatchTextBox.Name = "PrimeMismatchTextBox"
        Me.PrimeMismatchTextBox.Size = New System.Drawing.Size(40, 20)
        Me.PrimeMismatchTextBox.TabIndex = 10
        Me.PrimeMismatchTextBox.Text = "0,15"
        '
        'GoButton
        '
        Me.GoButton.Location = New System.Drawing.Point(177, 192)
        Me.GoButton.Name = "GoButton"
        Me.GoButton.Size = New System.Drawing.Size(50, 23)
        Me.GoButton.TabIndex = 41
        Me.GoButton.Text = "Find"
        Me.GoButton.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(77, 127)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(104, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Prime positive score:"
        '
        'PrimeMatchTextBox
        '
        Me.PrimeMatchTextBox.Location = New System.Drawing.Point(187, 124)
        Me.PrimeMatchTextBox.Name = "PrimeMatchTextBox"
        Me.PrimeMatchTextBox.Size = New System.Drawing.Size(40, 20)
        Me.PrimeMatchTextBox.TabIndex = 8
        Me.PrimeMatchTextBox.Text = "0,6"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 101)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(175, 13)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Min average selectivity per position:"
        '
        'PWMSelTextBox
        '
        Me.PWMSelTextBox.Location = New System.Drawing.Point(187, 98)
        Me.PWMSelTextBox.Name = "PWMSelTextBox"
        Me.PWMSelTextBox.Size = New System.Drawing.Size(40, 20)
        Me.PWMSelTextBox.TabIndex = 6
        Me.PWMSelTextBox.Text = "3"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(60, 74)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(121, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Extention score cutoff%:"
        '
        'ExtCutoffTextBox
        '
        Me.ExtCutoffTextBox.Location = New System.Drawing.Point(187, 71)
        Me.ExtCutoffTextBox.Name = "ExtCutoffTextBox"
        Me.ExtCutoffTextBox.Size = New System.Drawing.Size(40, 20)
        Me.ExtCutoffTextBox.TabIndex = 4
        Me.ExtCutoffTextBox.Text = "0,5"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(78, 48)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(103, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Prime score cutoff%:"
        '
        'PrimeCutoffTextBox
        '
        Me.PrimeCutoffTextBox.Location = New System.Drawing.Point(187, 45)
        Me.PrimeCutoffTextBox.Name = "PrimeCutoffTextBox"
        Me.PrimeCutoffTextBox.Size = New System.Drawing.Size(40, 20)
        Me.PrimeCutoffTextBox.TabIndex = 2
        Me.PrimeCutoffTextBox.Text = "0,6"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(113, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(68, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Word lenght:"
        '
        'WordLTextBox
        '
        Me.WordLTextBox.Location = New System.Drawing.Point(187, 19)
        Me.WordLTextBox.Name = "WordLTextBox"
        Me.WordLTextBox.Size = New System.Drawing.Size(40, 20)
        Me.WordLTextBox.TabIndex = 0
        Me.WordLTextBox.Text = "10"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.TextBox_CP)
        Me.GroupBox2.Controls.Add(Me.TextBox_GP)
        Me.GroupBox2.Controls.Add(Me.TextBox_TP)
        Me.GroupBox2.Controls.Add(Me.TextBox_AP)
        Me.GroupBox2.Controls.Add(Me.ManualPButton)
        Me.GroupBox2.Controls.Add(Me.AutoPButton)
        Me.GroupBox2.Controls.Add(Me.GCButton)
        Me.GroupBox2.Controls.Add(Me.GCTextBox)
        Me.GroupBox2.Location = New System.Drawing.Point(571, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(146, 232)
        Me.GroupBox2.TabIndex = 40
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Background"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(67, 114)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(17, 13)
        Me.Label6.TabIndex = 39
        Me.Label6.Text = "C:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(4, 114)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(18, 13)
        Me.Label7.TabIndex = 38
        Me.Label7.Text = "G:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(67, 88)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(17, 13)
        Me.Label8.TabIndex = 37
        Me.Label8.Text = "T:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(5, 88)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(17, 13)
        Me.Label9.TabIndex = 36
        Me.Label9.Text = "A:"
        '
        'TextBox_CP
        '
        Me.TextBox_CP.Location = New System.Drawing.Point(90, 111)
        Me.TextBox_CP.Name = "TextBox_CP"
        Me.TextBox_CP.Size = New System.Drawing.Size(33, 20)
        Me.TextBox_CP.TabIndex = 35
        Me.TextBox_CP.Text = "0,25"
        '
        'TextBox_GP
        '
        Me.TextBox_GP.Location = New System.Drawing.Point(28, 111)
        Me.TextBox_GP.Name = "TextBox_GP"
        Me.TextBox_GP.Size = New System.Drawing.Size(33, 20)
        Me.TextBox_GP.TabIndex = 34
        Me.TextBox_GP.Text = "0,25"
        '
        'TextBox_TP
        '
        Me.TextBox_TP.Location = New System.Drawing.Point(90, 85)
        Me.TextBox_TP.Name = "TextBox_TP"
        Me.TextBox_TP.Size = New System.Drawing.Size(33, 20)
        Me.TextBox_TP.TabIndex = 33
        Me.TextBox_TP.Text = "0,25"
        '
        'TextBox_AP
        '
        Me.TextBox_AP.Location = New System.Drawing.Point(28, 85)
        Me.TextBox_AP.Name = "TextBox_AP"
        Me.TextBox_AP.Size = New System.Drawing.Size(33, 20)
        Me.TextBox_AP.TabIndex = 32
        Me.TextBox_AP.Text = "0,25"
        '
        'ManualPButton
        '
        Me.ManualPButton.AutoSize = True
        Me.ManualPButton.Location = New System.Drawing.Point(6, 65)
        Me.ManualPButton.Name = "ManualPButton"
        Me.ManualPButton.Size = New System.Drawing.Size(60, 17)
        Me.ManualPButton.TabIndex = 2
        Me.ManualPButton.Text = "Manual"
        Me.ManualPButton.UseVisualStyleBackColor = True
        '
        'AutoPButton
        '
        Me.AutoPButton.AutoSize = True
        Me.AutoPButton.Checked = True
        Me.AutoPButton.Location = New System.Drawing.Point(6, 42)
        Me.AutoPButton.Name = "AutoPButton"
        Me.AutoPButton.Size = New System.Drawing.Size(89, 17)
        Me.AutoPButton.TabIndex = 1
        Me.AutoPButton.TabStop = True
        Me.AutoPButton.Text = "Auto (sample)"
        Me.AutoPButton.UseVisualStyleBackColor = True
        '
        'GCButton
        '
        Me.GCButton.AutoSize = True
        Me.GCButton.Location = New System.Drawing.Point(6, 19)
        Me.GCButton.Name = "GCButton"
        Me.GCButton.Size = New System.Drawing.Size(48, 17)
        Me.GCButton.TabIndex = 0
        Me.GCButton.Text = "%GC"
        Me.GCButton.UseVisualStyleBackColor = True
        '
        'GCTextBox
        '
        Me.GCTextBox.Location = New System.Drawing.Point(60, 18)
        Me.GCTextBox.Name = "GCTextBox"
        Me.GCTextBox.Size = New System.Drawing.Size(33, 20)
        Me.GCTextBox.TabIndex = 31
        Me.GCTextBox.Text = "0,5"
        '
        'ReportPanel
        '
        Me.ReportPanel.AutoScroll = True
        Me.ReportPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ReportPanel.Location = New System.Drawing.Point(0, 244)
        Me.ReportPanel.Name = "ReportPanel"
        Me.ReportPanel.Size = New System.Drawing.Size(881, 274)
        Me.ReportPanel.TabIndex = 43
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(272, 212)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(50, 23)
        Me.ClearButton.TabIndex = 44
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.GroupBox4)
        Me.Panel1.Controls.Add(Me.GroupBox3)
        Me.Panel1.Controls.Add(Me.SeqTextBox)
        Me.Panel1.Controls.Add(Me.ClearButton)
        Me.Panel1.Controls.Add(Me.GroupBox2)
        Me.Panel1.Controls.Add(Me.SeqFileTextBox)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Controls.Add(Me.OpenButton)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(881, 244)
        Me.Panel1.TabIndex = 45
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.DistanceTextBox)
        Me.GroupBox4.Controls.Add(Me.CombineMotifsCheckBox)
        Me.GroupBox4.Controls.Add(Me.MinLTextBox)
        Me.GroupBox4.Controls.Add(Me.Label12)
        Me.GroupBox4.Controls.Add(Me.TrimThresholdTextBox)
        Me.GroupBox4.Controls.Add(Me.TrimCheckBox)
        Me.GroupBox4.Location = New System.Drawing.Point(723, 3)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(146, 140)
        Me.GroupBox4.TabIndex = 46
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Motif optimization"
        '
        'DistanceTextBox
        '
        Me.DistanceTextBox.Location = New System.Drawing.Point(100, 43)
        Me.DistanceTextBox.Name = "DistanceTextBox"
        Me.DistanceTextBox.Size = New System.Drawing.Size(40, 20)
        Me.DistanceTextBox.TabIndex = 50
        Me.DistanceTextBox.Text = "0,2"
        '
        'CombineMotifsCheckBox
        '
        Me.CombineMotifsCheckBox.AutoSize = True
        Me.CombineMotifsCheckBox.Checked = True
        Me.CombineMotifsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CombineMotifsCheckBox.Location = New System.Drawing.Point(6, 45)
        Me.CombineMotifsCheckBox.Name = "CombineMotifsCheckBox"
        Me.CombineMotifsCheckBox.Size = New System.Drawing.Size(79, 17)
        Me.CombineMotifsCheckBox.TabIndex = 49
        Me.CombineMotifsCheckBox.Text = "Align motifs"
        Me.CombineMotifsCheckBox.UseVisualStyleBackColor = True
        '
        'MinLTextBox
        '
        Me.MinLTextBox.Location = New System.Drawing.Point(100, 69)
        Me.MinLTextBox.Name = "MinLTextBox"
        Me.MinLTextBox.Size = New System.Drawing.Size(40, 20)
        Me.MinLTextBox.TabIndex = 48
        Me.MinLTextBox.Text = "4"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(6, 72)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(77, 13)
        Me.Label12.TabIndex = 47
        Me.Label12.Text = "Minimal lenght:"
        '
        'TrimThresholdTextBox
        '
        Me.TrimThresholdTextBox.Location = New System.Drawing.Point(100, 17)
        Me.TrimThresholdTextBox.Name = "TrimThresholdTextBox"
        Me.TrimThresholdTextBox.Size = New System.Drawing.Size(40, 20)
        Me.TrimThresholdTextBox.TabIndex = 46
        Me.TrimThresholdTextBox.Text = "0,25"
        '
        'TrimCheckBox
        '
        Me.TrimCheckBox.AutoSize = True
        Me.TrimCheckBox.Location = New System.Drawing.Point(6, 19)
        Me.TrimCheckBox.Name = "TrimCheckBox"
        Me.TrimCheckBox.Size = New System.Drawing.Size(92, 17)
        Me.TrimCheckBox.TabIndex = 45
        Me.TrimCheckBox.Text = "Trim motifs (S)"
        Me.TrimCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.InvertXCheckBox)
        Me.GroupBox3.Controls.Add(Me.RightAlignCheckBox)
        Me.GroupBox3.Location = New System.Drawing.Point(723, 149)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(146, 85)
        Me.GroupBox3.TabIndex = 45
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Graphics and output"
        '
        'InvertXCheckBox
        '
        Me.InvertXCheckBox.AutoSize = True
        Me.InvertXCheckBox.Location = New System.Drawing.Point(6, 41)
        Me.InvertXCheckBox.Name = "InvertXCheckBox"
        Me.InvertXCheckBox.Size = New System.Drawing.Size(117, 17)
        Me.InvertXCheckBox.TabIndex = 44
        Me.InvertXCheckBox.Text = "Invert LOGO X axis"
        Me.InvertXCheckBox.UseVisualStyleBackColor = True
        '
        'RightAlignCheckBox
        '
        Me.RightAlignCheckBox.AutoSize = True
        Me.RightAlignCheckBox.Location = New System.Drawing.Point(6, 18)
        Me.RightAlignCheckBox.Name = "RightAlignCheckBox"
        Me.RightAlignCheckBox.Size = New System.Drawing.Size(139, 17)
        Me.RightAlignCheckBox.TabIndex = 42
        Me.RightAlignCheckBox.Text = "Align sequences to right"
        Me.RightAlignCheckBox.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(12, 9)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(90, 13)
        Me.Label13.TabIndex = 47
        Me.Label13.Text = "Enter sequences:"
        '
        'MBMD_Search
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(881, 518)
        Me.Controls.Add(Me.ReportPanel)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "MBMD_Search"
        Me.Text = "De novo motif search"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SeqTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SeqFileTextBox As System.Windows.Forms.TextBox
    Friend WithEvents OpenButton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents WordLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PrimeCutoffTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ExtCutoffTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PWMSelTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextBox_CP As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_GP As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_TP As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_AP As System.Windows.Forms.TextBox
    Friend WithEvents ManualPButton As System.Windows.Forms.RadioButton
    Friend WithEvents AutoPButton As System.Windows.Forms.RadioButton
    Friend WithEvents GCButton As System.Windows.Forms.RadioButton
    Friend WithEvents GCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents PrimeMatchTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PrimeMismatchTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GoButton As System.Windows.Forms.Button
    Friend WithEvents ReportPanel As System.Windows.Forms.Panel
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents RightAlignCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents InvertXCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents TrimThresholdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TrimCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents MinLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents CombineMotifsCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents DistanceTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
End Class
