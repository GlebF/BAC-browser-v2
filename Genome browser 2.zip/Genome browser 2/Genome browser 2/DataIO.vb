﻿Public Class DataIO

    Public Shared Sub ReadMultiFASTA(ByVal FileName As String)
        Dim FS As New IO.FileStream(FileName, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)

        Dim CurrentFolder As String = FileName.Split(".")(0) 'Folder will be named as a multifasta file

        IO.Directory.CreateDirectory(CurrentFolder)

        Dim CurrentSequence As String = ""
        Dim CurrentHeader As String = ""

        Dim CurrentLine As String = ""

        Dim CurrentFileName As String = ""
        Dim CurrentFiles As New List(Of String)

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine

            If Not CurrentLine = "" Then
                If CurrentLine.StartsWith(">") Then
                    'Initialize new FASTA

                    If Not CurrentSequence = "" Then
                        CurrentFileName = CurrentFolder & "\" & CurrentHeader.Substring(1)
                        CurrentFiles.Add(CurrentFileName)
                        WriteSequence(CurrentSequence, CurrentFileName, CurrentHeader)

                        Dim AnnotStream As New IO.FileStream(CurrentFileName & ".annot", IO.FileMode.Create, IO.FileAccess.Write)
                        Dim AnnotWriter As New IO.StreamWriter(AnnotStream)
                        AnnotWriter.WriteLine("<General>")
                        AnnotWriter.WriteLine("GenomeTopology=False")
                        AnnotWriter.WriteLine("GeneticCode=1")
                        AnnotWriter.WriteLine("Comment=")
                        AnnotWriter.WriteLine("<General/>")
                        AnnotWriter.Close()
                        AnnotStream.Close()
                        AnnotWriter.Dispose()
                        AnnotStream.Dispose()

                    End If

                    CurrentSequence = ""
                    CurrentHeader = CurrentLine


                Else
                    CurrentSequence &= CurrentLine

                End If
            End If
        End While

        'Add last sequence
        If Not CurrentSequence = "" Then
            CurrentFileName = CurrentFolder & "\" & CurrentHeader.Substring(1)
            CurrentFiles.Add(CurrentFileName)
            WriteSequence(CurrentSequence, CurrentFileName, CurrentHeader)

            Dim AnnotStream As New IO.FileStream(CurrentFileName & ".annot", IO.FileMode.Create, IO.FileAccess.Write)
            Dim AnnotWriter As New IO.StreamWriter(AnnotStream)
            AnnotWriter.WriteLine("<General>")
            AnnotWriter.WriteLine("GenomeTopology=False")
            AnnotWriter.WriteLine("GeneticCode=1")
            AnnotWriter.WriteLine("Comment=")
            AnnotWriter.WriteLine("<General/>")
            AnnotWriter.Close()
            AnnotStream.Close()
            AnnotWriter.Dispose()
            AnnotStream.Dispose()
        End If

        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()


        For Each FileString As String In CurrentFiles
            Master.OpenFile(FileString & ".fasta")
        Next

    End Sub

#Region "Open GenBank"

    Public Shared Function ReadGBFile(ByVal FileName As String)
        Dim FS As New IO.FileStream(FileName, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)

        Dim DataList As New List(Of String)

        While Reader.Peek > -1
            DataList.Add(Reader.ReadLine)
        End While


        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()

        Return DataList
    End Function

    Public Shared Function ReadGBFileToInfo(ByVal FileName As String, Optional ByVal CloseMark As String = "FEATURES")
        Dim InfoData As New FeatureData
        Dim FS As New IO.FileStream(FileName, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)

        Dim CurrentLine As String = ""
        Dim CurrentHeader As String = ""
        Dim CurrentData As String = ""
        Dim DataBuffer As String = ""


        While Reader.Peek > -1

            CurrentLine = Reader.ReadLine

            If CurrentLine.Length >= 12 Then

                CurrentHeader = CurrentLine.Substring(0, 12)
                CurrentHeader = CurrentHeader.Replace(Chr(32), vbNullString)
                CurrentData = CurrentLine.Substring(12)

                If CurrentHeader = vbNullString Then
                    DataBuffer &= CurrentData
                ElseIf CurrentHeader = CloseMark Then
                    'End of the document
                    InfoData.DataValues.Add(DataBuffer)
                    Exit While
                Else
                    'Add previous data from the buffer
                    If Not DataBuffer = "" Then
                        InfoData.DataValues.Add(DataBuffer)
                        DataBuffer = ""
                    End If


                    'Add header, start to collect data
                    InfoData.DataHeaders.Add(CurrentHeader)
                    DataBuffer = CurrentData
                End If


            End If
        End While

        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()

        Return InfoData
    End Function

    Public Shared Function ReadGBFileToSequence(ByVal FileName As String, Optional ByVal StartTag As String = "ORIGIN")
        Dim FS As New IO.FileStream(FileName, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)
        Dim CurrentLine As String = ""

        Dim SeqRegion As String = ""


        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            If CurrentLine.StartsWith(StartTag) Then
                SeqRegion = Reader.ReadToEnd
                Exit While
            End If
        End While

        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()


        Dim Seq As String = ""

        If Not SeqRegion = "" Then

            Seq = SeqRegion.Substring(0, SeqRegion.IndexOf("//"))
            Seq = Seq.Replace(Chr(10), vbNullString)
            Seq = Seq.Replace(Chr(13), vbNullString)
            Seq = Seq.Replace(Chr(32), vbNullString)
            Seq = Seq.Replace("0", vbNullString)
            Seq = Seq.Replace("1", vbNullString)
            Seq = Seq.Replace("2", vbNullString)
            Seq = Seq.Replace("3", vbNullString)
            Seq = Seq.Replace("4", vbNullString)
            Seq = Seq.Replace("5", vbNullString)
            Seq = Seq.Replace("6", vbNullString)
            Seq = Seq.Replace("7", vbNullString)
            Seq = Seq.Replace("8", vbNullString)
            Seq = Seq.Replace("9", vbNullString)
            Seq = Seq.ToUpper

        End If


        Return Seq
    End Function

    Public Shared Function ReadGBFileToAnnotation(ByVal FileName As String, Optional ByVal StartTag As String = "FEATURES", Optional ByVal EndTag As String = "ORIGIN")
        Dim FS As New IO.FileStream(FileName, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)

        Dim CurrentLine As String = ""
        Dim StartReading As Boolean = False
        Dim AnnotationStrings As New List(Of String)

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine

            If CurrentLine.StartsWith(EndTag) Then
                StartReading = False
            End If

            If StartReading Then
                AnnotationStrings.Add(CurrentLine)
            End If

            If CurrentLine.StartsWith(StartTag) Then
                StartReading = True
            End If

        End While

        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()

        Dim TempFeatureID As Integer = 1 'Features are numbered in in case there is no other available ID

        Dim Features As New List(Of Genome_Feature)
        Dim CurrentFeature As Genome_Feature = Nothing
        Dim CurrentHeader As String = "" 'Current key on the current line

        Dim OperationalData As String = "" 'To look forward relatively to current data
        Dim RecordBuffer As String = "" 'To collect potentially multiline data

        Dim IgnoreData As Boolean = False


        Dim MaxString As Integer = AnnotationStrings.Count - 1

        For i = 0 To MaxString
            Try


                If AnnotationStrings(i).Length >= 21 Then

                    CurrentHeader = AnnotationStrings(i).Substring(0, 21)
                    CurrentHeader = CurrentHeader.Replace(Chr(32), vbNullString)


                    If CurrentHeader = vbNullString Then

                        'Feature continues
                        'Read lines one by one, data may be ultiline, expect that new property is initiated by /
                        'The idea of the algorithm is to load all data into auxilliary datalist and then reassign key fields of the feature.

                        If Not IgnoreData Then 'Do not assign strange or service data to regular features

                            'Initiate new data record
                            RecordBuffer = AnnotationStrings(i).Substring(21)

                            For j = i + 1 To MaxString 'Look at next line
                                'Look forward if property continues on the next line


                                If AnnotationStrings(j).Length > 0 Then
                                    'Ignore empty lines in the file

                                    OperationalData = AnnotationStrings(j).Substring(21)

                                    If OperationalData.StartsWith("/") Then
                                        'Single-line record
                                        'Add new record

                                        Exit For

                                    ElseIf AnnotationStrings(j).Substring(0, 21).Replace(Chr(32), vbNullString).Length > 0 Then
                                        'Here starts new feature

                                        Exit For

                                    Else
                                        'Record continues

                                        If RecordBuffer.StartsWith("/translation") Then
                                            RecordBuffer &= AnnotationStrings(j).Substring(21) 'No spaces in translation
                                        Else
                                            RecordBuffer &= Chr(32) & AnnotationStrings(j).Substring(21) 'Use space to separate data from next line
                                        End If


                                        i = j
                                    End If

                                    'Ignore empty lines in the file
                                End If 'AnnotationStrings(j).Length > 0
                            Next j

                            If RecordBuffer.Contains("=") Then
                                Dim DataValues() As String = RecordBuffer.Split("=")
                                CurrentFeature.AdditionalProperties.DataHeaders.Add(DataValues(0).Substring(1))
                                CurrentFeature.AdditionalProperties.DataValues.Add(DataValues(1).Replace(Chr(34), vbNullString))
                            ElseIf RecordBuffer.StartsWith("/") Then
                                CurrentFeature.AdditionalProperties.DataHeaders.Add(RecordBuffer.Substring(1))
                                CurrentFeature.AdditionalProperties.DataValues.Add("Empty_Qualifier")
                            End If

                        End If

                    Else

                        'New Feature
                        'The very basic properties of the feature is its position, direction and exon structure, then type.
                        'All other propertis are first loaded into auxilliary list.


                        'Ignore redundant, service or strange records
                        If IgnoreKey(CurrentHeader) Then
                            IgnoreData = True
                        Else
                            IgnoreData = False


                            Dim NewFeature As New Genome_Feature
                            Dim NewFeatureData As New FeatureData
                            NewFeature.AdditionalProperties = NewFeatureData
                            NewFeature.TAG = "Feature_" & TempFeatureID
                            TempFeatureID += 1

                            NewFeature.AdditionalProperties.DataHeaders.Add("Universal_Type")
                            NewFeature.AdditionalProperties.DataValues.Add(CurrentHeader)


                            CurrentFeature = NewFeature 'All further references to CurrentFeature

                            Features.Add(CurrentFeature) 'Add feature to the main list

                            AssignFeatureType(CurrentFeature, CurrentHeader)

                            RecordBuffer = AnnotationStrings(i).Substring(21)

                            'Look for feature position data on next lines
                            For j = i + 1 To MaxString 'Start collecting data from next line
                                'Look forward if information about feature's position continues on next lines

                                If AnnotationStrings(j).Length > 0 Then
                                    'Ignore empty lines in the file

                                    OperationalData = AnnotationStrings(j).Substring(21)
                                    If OperationalData.StartsWith("/") Then
                                        'Here starts the list of properties also it may be empty

                                        Exit For

                                    ElseIf AnnotationStrings(j).Substring(0, 21).Replace(Chr(32), vbNullString).Length > 0 Then
                                        'Here starts new feature

                                        Exit For

                                    Else

                                        RecordBuffer &= OperationalData
                                        i = j 'Move enclosing cycle to the last position
                                    End If

                                    'Ignore empty lines in the file
                                End If 'AnnotationStrings(j).Length > 0
                            Next j

                            'Parse position string


                            AssignFeatureCoordinates(CurrentFeature, RecordBuffer)


                        End If 'IgnoreKey(CurrentHeader)

                    End If 'CurrentHeader = vbNullString

                End If 'Not AnnotationStrings(i).Length >= 21


            Catch ex As Exception
                MsgBox("Error at annotation line: " & vbNewLine & AnnotationStrings(i) & vbNewLine & ex.Message)
            End Try
        Next i


        'Attempt to assign ID name and description for features
        For Each Feature As Genome_Feature In Features
            AssignFeatureIDandName(Feature)
        Next Feature


        Return Features
    End Function

    Public Shared Function ReadStringListToInfo(ByVal DataList As List(Of String), Optional ByVal CloseMark As String = "FEATURES")
        Dim InfoData As New FeatureData
        Dim CurrentDataHeader As String = ""
        Dim CurrentData As String = ""
        Dim DataBuffer As String = ""

        For j = 0 To DataList.Count - 1

            If DataList(j).Length >= 12 Then

                CurrentDataHeader = DataList(j).Substring(0, 12)
                CurrentDataHeader = CurrentDataHeader.Replace(Chr(32), vbNullString)
                CurrentData = DataList(j).Substring(12)

                If CurrentDataHeader = vbNullString Then
                    DataBuffer &= CurrentData
                ElseIf CurrentDataHeader = CloseMark Then
                    'End of the document
                    InfoData.DataValues.Add(DataBuffer)
                    Exit For
                Else
                    'Add previous data from the buffer
                    If Not DataBuffer = "" Then
                        InfoData.DataValues.Add(DataBuffer)
                        DataBuffer = ""
                    End If


                    'Add header, start to collect data
                    InfoData.DataHeaders.Add(CurrentDataHeader)
                    DataBuffer = CurrentData
                End If


            End If

        Next j



        Return InfoData
    End Function

    Public Shared Function ReadStringListToSequence(ByVal DataList As List(Of String), Optional ByVal StartTag As String = "ORIGIN")
        Dim Sequence As String = ""

        Dim AcquireSeq As Boolean = False

        For j = 0 To DataList.Count - 1

            If AcquireSeq Then
                Sequence &= DataList(j)
            End If

            If DataList(j).StartsWith(StartTag) Then
                AcquireSeq = True
            End If

        Next j


        Sequence = Sequence.Replace(Chr(10), vbNullString)
        Sequence = Sequence.Replace(Chr(13), vbNullString)
        Sequence = Sequence.Replace(Chr(32), vbNullString)
        Sequence = Sequence.Replace("0", vbNullString)
        Sequence = Sequence.Replace("1", vbNullString)
        Sequence = Sequence.Replace("2", vbNullString)
        Sequence = Sequence.Replace("3", vbNullString)
        Sequence = Sequence.Replace("4", vbNullString)
        Sequence = Sequence.Replace("5", vbNullString)
        Sequence = Sequence.Replace("6", vbNullString)
        Sequence = Sequence.Replace("7", vbNullString)
        Sequence = Sequence.Replace("8", vbNullString)
        Sequence = Sequence.Replace("9", vbNullString)
        Sequence = Sequence.ToUpper


        Return Sequence
    End Function

    Public Shared Function ReadStringListToAnnotation(ByVal DataList As List(Of String), Optional ByVal StartTag As String = "FEATURES", Optional ByVal EndTag As String = "ORIGIN")


        Dim StartReading As Boolean = False
        Dim AnnotationStrings As New List(Of String)

        For i = 0 To DataList.Count - 1
            If DataList(i).StartsWith(EndTag) Then
                StartReading = False
            End If

            If StartReading Then
                AnnotationStrings.Add(DataList(i))
            End If

            If DataList(i).StartsWith(StartTag) Then
                StartReading = True
            End If
        Next i



        Dim TempFeatureID As Integer = 1 'Features are numbered in in case there is no other available ID

        Dim Features As New List(Of Genome_Feature)
        Dim CurrentFeature As Genome_Feature = Nothing
        Dim CurrentHeader As String = "" 'Current key on the current line

        Dim OperationalData As String = "" 'To look forward relatively to current data
        Dim RecordBuffer As String = "" 'To collect potentially multiline data

        Dim IgnoreData As Boolean = False


        Dim MaxString As Integer = AnnotationStrings.Count - 1

        For i = 0 To MaxString
            Try


                If AnnotationStrings(i).Length >= 21 Then

                    CurrentHeader = AnnotationStrings(i).Substring(0, 21)
                    CurrentHeader = CurrentHeader.Replace(Chr(32), vbNullString)


                    If CurrentHeader = vbNullString Then

                        'Feature continues
                        'Read lines one by one, data may be ultiline, expect that new property is initiated by /
                        'The idea of the algorithm is to load all data into auxilliary datalist and then reassign key fields of the feature.

                        If Not IgnoreData Then 'Do not assign strange or service data to regular features

                            'Initiate new data record
                            RecordBuffer = AnnotationStrings(i).Substring(21)

                            For j = i + 1 To MaxString 'Look at next line
                                'Look forward if property continues on the next line


                                If AnnotationStrings(j).Length > 0 Then
                                    'Ignore empty lines in the file

                                    OperationalData = AnnotationStrings(j).Substring(21)

                                    If OperationalData.StartsWith("/") Then
                                        'Single-line record
                                        'Add new record

                                        Exit For

                                    ElseIf AnnotationStrings(j).Substring(0, 21).Replace(Chr(32), vbNullString).Length > 0 Then
                                        'Here starts new feature

                                        Exit For

                                    Else
                                        'Record continues

                                        If RecordBuffer.StartsWith("/translation") Then
                                            RecordBuffer &= AnnotationStrings(j).Substring(21) 'No spaces in translation
                                        Else
                                            RecordBuffer &= Chr(32) & AnnotationStrings(j).Substring(21) 'Use space to separate data from next line
                                        End If


                                        i = j
                                    End If

                                    'Ignore empty lines in the file
                                End If 'AnnotationStrings(j).Length > 0
                            Next j

                            If RecordBuffer.Contains("=") Then
                                Dim DataValues() As String = RecordBuffer.Split("=")
                                CurrentFeature.AdditionalProperties.DataHeaders.Add(DataValues(0).Substring(1))
                                CurrentFeature.AdditionalProperties.DataValues.Add(DataValues(1).Replace(Chr(34), vbNullString))
                            ElseIf RecordBuffer.StartsWith("/") Then
                                CurrentFeature.AdditionalProperties.DataHeaders.Add(RecordBuffer.Substring(1))
                                CurrentFeature.AdditionalProperties.DataValues.Add("Empty_Qualifier")
                            End If

                        End If

                    Else

                        'New Feature
                        'The very basic properties of the feature is its position, direction and exon structure, then type.
                        'All other propertis are first loaded into auxilliary list.


                        'Ignore redundant, service or strange records
                        If IgnoreKey(CurrentHeader) Then
                            IgnoreData = True
                        Else
                            IgnoreData = False


                            Dim NewFeature As New Genome_Feature
                            Dim NewFeatureData As New FeatureData
                            NewFeature.AdditionalProperties = NewFeatureData
                            NewFeature.TAG = "Feature_" & TempFeatureID
                            TempFeatureID += 1

                            NewFeature.AdditionalProperties.DataHeaders.Add("Universal_Type")
                            NewFeature.AdditionalProperties.DataValues.Add(CurrentHeader)


                            CurrentFeature = NewFeature 'All further references to CurrentFeature

                            Features.Add(CurrentFeature) 'Add feature to the main list

                            AssignFeatureType(CurrentFeature, CurrentHeader)

                            RecordBuffer = AnnotationStrings(i).Substring(21)

                            'Look for feature position data on next lines
                            For j = i + 1 To MaxString 'Start collecting data from next line
                                'Look forward if information about feature's position continues on next lines

                                If AnnotationStrings(j).Length > 0 Then
                                    'Ignore empty lines in the file

                                    OperationalData = AnnotationStrings(j).Substring(21)
                                    If OperationalData.StartsWith("/") Then
                                        'Here starts the list of properties also it may be empty

                                        Exit For

                                    ElseIf AnnotationStrings(j).Substring(0, 21).Replace(Chr(32), vbNullString).Length > 0 Then
                                        'Here starts new feature

                                        Exit For

                                    Else

                                        RecordBuffer &= OperationalData
                                        i = j 'Move enclosing cycle to the last position
                                    End If

                                    'Ignore empty lines in the file
                                End If 'AnnotationStrings(j).Length > 0
                            Next j

                            'Parse position string


                            AssignFeatureCoordinates(CurrentFeature, RecordBuffer)


                        End If 'IgnoreKey(CurrentHeader)

                    End If 'CurrentHeader = vbNullString

                End If 'Not AnnotationStrings(i).Length >= 21


            Catch ex As Exception
                MsgBox("Error at annotation line: " & vbNewLine & AnnotationStrings(i) & vbNewLine & ex.Message)
            End Try
        Next i


        'Attempt to assign ID name and description for features
        For Each Feature As Genome_Feature In Features
            AssignFeatureIDandName(Feature)
        Next Feature


        Return Features
    End Function


    Public Shared Function IgnoreKey(ByVal Header As String)
        Dim Result As Boolean = False

        Dim BanList As New List(Of String)
        BanList.Add("CONTIG")
        BanList.Add("BASE COUNT")

        For Each BannedKey As String In BanList
            If Header.StartsWith(BannedKey) Then
                Result = True
                Exit For
            End If
        Next BannedKey

        Return Result
    End Function

    Public Shared Sub AssignFeatureIDandName(ByRef Feature As Genome_Feature)

        Dim MaxData As Integer = Feature.AdditionalProperties.DataHeaders.Count - 1


        For i = 0 To MaxData

            If Feature.AdditionalProperties.DataHeaders(i) = "locus_tag" Then

                Feature.TAG = Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)

            End If

        Next i


        Select Case Feature.Type

            Case 1 'CDS
                For i = 0 To MaxData
                    If Feature.AdditionalProperties.DataHeaders(i) = "gene" Then
                        Feature.Name = Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)

                    End If

                    If Feature.AdditionalProperties.DataHeaders(i) = "product" Then
                        Feature.Description = Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)
                    End If

                Next i

                'Try to look for additional notes
                If Feature.Description = "" Then
                    For i = 0 To MaxData
                        If Feature.AdditionalProperties.DataHeaders(i) = "note" Then
                            Feature.Description = Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)
                        End If
                    Next i
                End If


            Case 2 'structural RNA
                For i = 0 To MaxData
                    If Feature.AdditionalProperties.DataHeaders(i) = "gene" Then
                        Feature.Name = Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)

                    End If

                    If Feature.AdditionalProperties.DataHeaders(i) = "product" Then
                        Feature.Description = Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)
                    End If

                Next i

                'Try to look for additional notes
                If Feature.Description = "" Then
                    For i = 0 To MaxData
                        If Feature.AdditionalProperties.DataHeaders(i) = "note" Then
                            Feature.Description = Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)
                        End If
                    Next i
                End If


            Case 3 'Special asignment for binding sites
                For i = 0 To MaxData
                    If Feature.AdditionalProperties.DataHeaders(i) = "note" Then
                        Feature.Description &= Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString) & "; "
                    ElseIf Feature.AdditionalProperties.DataHeaders(i) = "bound_moiety" Then
                        Feature.Description &= "binds " & Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString) & "; "
                    ElseIf Feature.AdditionalProperties.DataHeaders(i) = "regulatory_class" Then
                        Feature.Description &= Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString) & "; "
                    End If
                Next i

                Feature.Description = Feature.Description.Substring(0, Feature.Description.Length - 2)


            Case 4 'ncRNA
                For i = 0 To MaxData
                    If Feature.AdditionalProperties.DataHeaders(i) = "gene" Then
                        Feature.Name = Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)

                    End If

                    If Feature.AdditionalProperties.DataHeaders(i) = "product" Then
                        Feature.Description = Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)
                    End If

                Next i

                'Try to look for additional notes
                If Feature.Description = "" Then
                    For i = 0 To MaxData
                        If Feature.AdditionalProperties.DataHeaders(i) = "note" Then
                            Feature.Description = Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)
                        End If
                    Next i
                End If


            Case Else
                For i = 0 To MaxData
                    If Feature.AdditionalProperties.DataHeaders(i) = "gene" Then
                        Feature.Name = Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)

                    End If

                    If Feature.AdditionalProperties.DataHeaders(i) = "product" Then
                        If Feature.Description = "" Then
                            Feature.Description = Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)
                        Else
                            Feature.Description &= "; " & Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)
                        End If

                    End If

                    If Feature.AdditionalProperties.DataHeaders(i) = "note" Then
                        If Feature.Description = "" Then
                            Feature.Description = Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)
                        Else
                            Feature.Description &= "; " & Feature.AdditionalProperties.DataValues(i).Replace(Chr(34), vbNullString)
                        End If

                    End If

                Next i
        End Select


        If Feature.Name = "" Then
            Feature.Name = Feature.TAG
        End If

    End Sub

    Public Shared Sub AssignFeatureType(ByRef CurrentFeature As Genome_Feature, ByVal Data As String)
        Select Case Data
            Case "gene"
                CurrentFeature.Type = 10
            Case "CDS"
                CurrentFeature.Type = 1
            Case "mRNA"
                CurrentFeature.Type = 12
            Case "rRNA"
                CurrentFeature.Type = 2
            Case "tRNA"
                CurrentFeature.Type = 2
            Case "tmRNA"
                CurrentFeature.Type = 2
            Case "misc_RNA"
                CurrentFeature.Type = 2
            Case "asRNA"
                CurrentFeature.Type = 4
            Case "regulatory"
                CurrentFeature.Type = 3
            Case "protein_bind"
                CurrentFeature.Type = 3
            Case "misc_structure"
                CurrentFeature.Type = 3
            Case "repeat_region"
                CurrentFeature.Type = 9
            Case "source"
                CurrentFeature.Type = 99
            Case Else
                CurrentFeature.Type = 10
        End Select
    End Sub

    Public Shared Sub AssignFeatureCoordinates(ByRef CurrentFeature As Genome_Feature, ByVal Data As String, _
                                               Optional ByVal DirectionOperator As String = "complement", Optional ByVal JoinOperator As String = "join")


        'Partial features
        Data = Data.Replace(">", vbNullString)
        Data = Data.Replace("<", vbNullString)

        If Data.StartsWith(DirectionOperator) Then

            'Minus strand
            CurrentFeature.Direction = 2

            'Clear complement operator
            Data = Data.Substring(DirectionOperator.Length + 1) '+1 for (
            Data = Data.Substring(0, Data.Length - 1) 'to remove )


            If Data.StartsWith(JoinOperator) Then
                'Exons are present, clear join operator
                Data = Data.Substring(JoinOperator.Length + 1)
                Data = Data.Substring(0, Data.Length - 1)


                Dim Exons() As String = Data.Split(",")
                Dim ExonPos() As String

                For Each Exon As String In Exons
                    ExonPos = Exon.Split("..")
                    Dim NewReadItem As New ReadItem(CType(ExonPos(0), Integer), CType(ExonPos(2), Integer))
                    CurrentFeature.ReadList.Add(NewReadItem)
                Next Exon

                'Identify the most left and right coordinates of the exons and assign relative coordinates to exons
                CurrentFeature.AbsoluteStart = CurrentFeature.ReadList(0).ReadAbsoluteStart
                CurrentFeature.AbsoluteEnd = CurrentFeature.ReadList(CurrentFeature.ReadList.Count - 1).ReadAbsoluteEnd

                For Each RItem As ReadItem In CurrentFeature.ReadList
                    RItem.ReadAbsoluteStart -= CurrentFeature.AbsoluteStart
                    RItem.ReadAbsoluteEnd -= CurrentFeature.AbsoluteStart
                Next RItem

                CurrentFeature.UseReadList = True

            Else
                'Continuos rna, suppose that coordinates take one string in this case

                Dim Pos() As String = Data.Split("..")
                CurrentFeature.AbsoluteStart = Pos(0)
                CurrentFeature.AbsoluteEnd = Pos(2)

            End If

        Else

            'Plus strand
            CurrentFeature.Direction = 1

            If Data.StartsWith(JoinOperator) Then
                'Exons are present, clear join operator
                Data = Data.Substring(JoinOperator.Length + 1)
                Data = Data.Substring(0, Data.Length - 1)


                Dim Exons() As String = Data.Split(",")
                Dim ExonPos() As String

                For Each Exon As String In Exons
                    ExonPos = Exon.Split("..")
                    Dim NewReadItem As New ReadItem(CType(ExonPos(0), Integer), CType(ExonPos(2), Integer))
                    CurrentFeature.ReadList.Add(NewReadItem)
                Next Exon

                'Identify the most left and right coordinates of the exons and assign relative coordinates to exons
                CurrentFeature.AbsoluteStart = CurrentFeature.ReadList(0).ReadAbsoluteStart
                CurrentFeature.AbsoluteEnd = CurrentFeature.ReadList(CurrentFeature.ReadList.Count - 1).ReadAbsoluteEnd

                For Each RItem As ReadItem In CurrentFeature.ReadList
                    RItem.ReadAbsoluteStart -= CurrentFeature.AbsoluteStart
                    RItem.ReadAbsoluteEnd -= CurrentFeature.AbsoluteStart
                Next RItem

                CurrentFeature.UseReadList = True

            Else
                'Continuos rna, suppose that coordinates take one string in this case

                Dim Pos() As String = Data.Split("..")
                CurrentFeature.AbsoluteStart = Pos(0)

                Try
                    CurrentFeature.AbsoluteEnd = Pos(2)
                Catch ex As Exception
                    CurrentFeature.AbsoluteEnd = CurrentFeature.AbsoluteStart
                End Try

            End If


        End If




    End Sub

#End Region

#Region "Open GFF"

    Public Shared Function ReadGFFHeader(ByVal FilePath As String)
        Dim ReadStream As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(ReadStream)
        Dim CurrentLine As String = ""

        Dim InfoData As New FeatureData
        Dim SpacerPos As Integer = 0

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine

            If Not CurrentLine = vbNullString Then
                If CurrentLine.StartsWith("#") Then

                    SpacerPos = CurrentLine.IndexOf(Chr(32))

                    Try
                        InfoData.DataHeaders.Add(CurrentLine.Substring(0, SpacerPos))
                        InfoData.DataValues.Add(CurrentLine.Substring(SpacerPos + 1))
                    Catch ex As Exception
                        MsgBox("Error in GFF header!" & vbNewLine & ex.Message)
                    End Try

                Else
                    Exit While
                End If
            End If
        End While

        Return InfoData
    End Function

    Public Shared Function ParseGFFAttributes(ByVal Attributes As String)
        Dim DataList As New FeatureData

        Dim DataPairList As String() = Attributes.Split(";")

        Dim CurrentValues() As String = Nothing

        For Each DataPair As String In DataPairList
            CurrentValues = DataPair.Split("=")
            DataList.DataHeaders.Add(CurrentValues(0))
            DataList.DataValues.Add(CurrentValues(1))
        Next DataPair


        Return DataList
    End Function

    Public Shared Function InitializeFeatureFromGFF(ByVal GFF_String() As String, ByVal GroupName As String)
        Dim NewFeature As New Genome_Feature
        NewFeature.Group = GroupName

        Dim ID_Identifiers_List As New List(Of String)

        ID_Identifiers_List.Add("locus_tag")
        ID_Identifiers_List.Add("ID")

        Dim Name_Identifiers_List As New List(Of String)

        Name_Identifiers_List.Add("Name")
        Name_Identifiers_List.Add("locus_tag")
        Name_Identifiers_List.Add("ID")

        Dim Desrciption_Identifiers_List As New List(Of String)

        Desrciption_Identifiers_List.Add("Note")
        Desrciption_Identifiers_List.Add("product")

        Dim CurrentAttributes As FeatureData = Nothing


        'Identify coordinates and strand
        NewFeature.AbsoluteStart = CType(GFF_String(3), Integer)
        NewFeature.AbsoluteEnd = CType(GFF_String(4), Integer)

        Select Case GFF_String(6) 'Strand
            Case "+"
                NewFeature.Direction = 1
            Case "-"
                NewFeature.Direction = 2
            Case Else
                NewFeature.Direction = 0
        End Select



        'Identify feature type
        Select Case GFF_String(2) 'Type
            Case "CDS"
                NewFeature.Type = 1
            Case "rRNA"
                NewFeature.Type = 2
            Case "tRNA"
                NewFeature.Type = 2
            Case "tmRNA"
                NewFeature.Type = 2
            Case "mRNA"
                NewFeature.Type = 12
            Case "exon"
                NewFeature.Type = 102 'Specific mark for GFF

            Case "region"
                NewFeature.Type = 99

            Case Else
                NewFeature.Type = 10
        End Select


        'Add data from field 1 of GFF file
        NewFeature.AdditionalProperties = New FeatureData
        NewFeature.AdditionalProperties.DataHeaders.Add("source")
        NewFeature.AdditionalProperties.DataValues.Add(GFF_String(1))

        'Add data from field 2 of GFF file
        NewFeature.AdditionalProperties.DataHeaders.Add("Universal_Type")
        NewFeature.AdditionalProperties.DataValues.Add(GFF_String(2))

        'Add data from field 5 of GFF file
        NewFeature.AdditionalProperties.DataHeaders.Add("score")
        NewFeature.AdditionalProperties.DataValues.Add(GFF_String(5))


        'Add data from field 7 of GFF file
        NewFeature.AdditionalProperties.DataHeaders.Add("phase")
        NewFeature.AdditionalProperties.DataValues.Add(GFF_String(7))


        'Identify feature attributes
        CurrentAttributes = ParseGFFAttributes(GFF_String(8))
        NewFeature.AdditionalProperties.DataHeaders.AddRange(CurrentAttributes.DataHeaders)
        NewFeature.AdditionalProperties.DataValues.AddRange(CurrentAttributes.DataValues)



        'Try to identify ID, Name and description of the feature using attributes
        For i = 0 To NewFeature.AdditionalProperties.DataHeaders.Count - 1
            'Try to assign ID
            For Each Val As String In ID_Identifiers_List
                If NewFeature.AdditionalProperties.DataHeaders(i) = Val Then
                    NewFeature.TAG = NewFeature.AdditionalProperties.DataValues(i)
                    Exit For
                End If
            Next Val

            'Try to assign name
            For Each Val As String In Name_Identifiers_List
                If NewFeature.AdditionalProperties.DataHeaders(i) = Val Then
                    NewFeature.Name = NewFeature.AdditionalProperties.DataValues(i)
                    Exit For
                End If
            Next Val

            'Try to assign description
            For Each Val As String In Desrciption_Identifiers_List
                If NewFeature.AdditionalProperties.DataHeaders(i) = Val Then
                    NewFeature.Description = NewFeature.AdditionalProperties.DataValues(i)
                    Exit For
                End If
            Next Val

        Next i


        Return NewFeature
    End Function

    Public Shared Function ReadGFFData(ByVal FilePath As String, ByVal GroupName As String)

        Dim FeatureAsmList As New List(Of FeaturesAssembly)


        Dim ReadStream As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(ReadStream)
        Dim CurrentLine As String = ""
        Dim GFFDataArray() As String
        Dim AsmListExists As Boolean = False
        Dim CurrentAsm As FeaturesAssembly = Nothing



        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine

            If Not CurrentLine = vbNullString Then
                If Not CurrentLine.StartsWith("#") Then
                    GFFDataArray = CurrentLine.Split(Chr(9))

                    'Check if current assembly already exists
                    AsmListExists = False
                    For Each FeatureAsm As FeaturesAssembly In FeatureAsmList
                        If FeatureAsm.AssemblyName = GFFDataArray(0) Then
                            AsmListExists = True
                            CurrentAsm = FeatureAsm
                            Exit For
                        End If
                    Next FeatureAsm

                    If AsmListExists Then
                        'Add feature to existing list

                        CurrentAsm.FeaturesList.Add(InitializeFeatureFromGFF(GFFDataArray, GroupName))

                    Else 'Initialize new list

                        Dim NewAsm As New FeaturesAssembly
                        NewAsm.AssemblyName = GFFDataArray(0)
                        FeatureAsmList.Add(NewAsm)
                        NewAsm.FeaturesList.Add(InitializeFeatureFromGFF(GFFDataArray, GroupName))

                    End If 'AsmListExists

                End If
            End If


        End While




        'Assign exons to mRNAs and assemble CDSs from isolated parts

        For Each Asm As FeaturesAssembly In FeatureAsmList


            'Assemble exons and assign them to parent mRNA
            AssembleExonsFromGFF(Asm)


            'Assemble CDS's with identical parent into one feature with read list
            AssembleCDSsFromGFF(Asm, GroupName)


            'Remove redundant data and turn new CDSs on
            For i = Asm.FeaturesList.Count - 1 To 0 Step -1
                If Asm.FeaturesList(i).Type = 100 Then
                    Asm.FeaturesList(i).Type = 1
                End If

                If Asm.FeaturesList(i).Type = 101 Then
                    Asm.FeaturesList.RemoveAt(i)
                End If
            Next i


            'Sort read data
            SortReadListsForFeatures(Asm)


        Next Asm



        Return FeatureAsmList
    End Function

    Public Shared Sub AssembleExonsFromGFF(ByRef Asm As FeaturesAssembly)
        Dim ParentID As String = ""

        For i = Asm.FeaturesList.Count - 1 To 0 Step -1

            If Asm.FeaturesList(i).Type = 102 Then
                'It is exon, look for parent
                'Find parent's ID

                ParentID = ""
                For k = 0 To Asm.FeaturesList(i).AdditionalProperties.DataHeaders.Count - 1
                    If Asm.FeaturesList(i).AdditionalProperties.DataHeaders(k) = "Parent" Then
                        ParentID = Asm.FeaturesList(i).AdditionalProperties.DataValues(k)
                        Exit For
                    End If
                Next k

                If Not ParentID = "" Then
                    'Now find parent
                    For j = Asm.FeaturesList.Count - 1 To 0 Step -1

                        If Asm.FeaturesList(j).TAG = ParentID Then
                            'Create read item

                            Dim NewReadItem As New ReadItem(Asm.FeaturesList(i).AbsoluteStart - Asm.FeaturesList(j).AbsoluteStart, Asm.FeaturesList(i).AbsoluteEnd - Asm.FeaturesList(j).AbsoluteStart)
                            Asm.FeaturesList(j).ReadList.Add(NewReadItem)
                            Asm.FeaturesList(j).UseReadList = True

                        End If

                    Next j

                    Asm.FeaturesList.RemoveAt(i)

                End If


            End If 'Asm.FeaturesList(i).Type

        Next i
    End Sub

    Public Shared Sub AssembleCDSsFromGFF(ByRef Asm As FeaturesAssembly, ByVal TargetFeaturesGroup As String)
        Dim ParentID As String = ""
        Dim MasterParentID As String = ""
        Dim TmpList As New List(Of Genome_Feature)

        For i = 0 To Asm.FeaturesList.Count - 1

            If Asm.FeaturesList(i).Type = 1 Then 'Assemble coding features only


                TmpList.Clear()

                TmpList.Add(Asm.FeaturesList(i)) 'Add self


                'Look if there is another CDS with the same parent
                MasterParentID = Asm.FeaturesList(i).GetAdditionalValue("Parent")


                For j = 0 To Asm.FeaturesList.Count - 1
                    If Asm.FeaturesList(j).Type = 1 Then
                        'Filter for CDS only


                        If Not Asm.FeaturesList(i).AbsoluteStart = Asm.FeaturesList(j).AbsoluteStart And Not Asm.FeaturesList(i).AbsoluteEnd = Asm.FeaturesList(j).AbsoluteEnd And Asm.FeaturesList(i).Direction = Asm.FeaturesList(j).Direction Then

                            ParentID = Asm.FeaturesList(j).GetAdditionalValue("Parent")

                            If Not ParentID = "" And ParentID = MasterParentID Then
                                Asm.FeaturesList(i).Type = 101
                                TmpList.Add(Asm.FeaturesList(j)) 'Add another feature with same ID
                            End If

                        End If


                    End If 'Asm.FeaturesList(j).Type = 1 
                Next j


                If TmpList.Count > 1 Then 'Not only self

                    Dim NewCDS As New Genome_Feature

                    'Identify coordinates
                    Dim MinStart As Integer = TmpList(0).AbsoluteStart
                    Dim MaxEnd As Integer = TmpList(0).AbsoluteEnd

                    For Each Feature As Genome_Feature In TmpList
                        Feature.Type = 101

                        If Feature.AbsoluteStart < MinStart Then
                            MinStart = Feature.AbsoluteStart
                        End If

                        If Feature.AbsoluteEnd > MaxEnd Then
                            MaxEnd = Feature.AbsoluteEnd
                        End If

                    Next Feature

                    NewCDS.AbsoluteStart = MinStart
                    NewCDS.AbsoluteEnd = MaxEnd
                    NewCDS.Direction = Asm.FeaturesList(i).Direction
                    NewCDS.TAG = MasterParentID & "_CDS"
                    NewCDS.Group = TargetFeaturesGroup
                    NewCDS.Type = 100 'Not to confuse with existing CDSs from GFF, later turn to 1
                    NewCDS.UseReadList = True
                    NewCDS.AdditionalProperties = New FeatureData
                    NewCDS.AdditionalProperties.DataHeaders = Asm.FeaturesList(i).AdditionalProperties.DataHeaders
                    NewCDS.AdditionalProperties.DataValues = Asm.FeaturesList(i).AdditionalProperties.DataValues
                    NewCDS.AdditionalProperties.DataHeaders.Add("JoinedCDS")
                    NewCDS.AdditionalProperties.DataValues.Add("True")


                    'Assign read list
                    For Each Feature As Genome_Feature In TmpList
                        Dim NewRead As New ReadItem(Feature.AbsoluteStart - NewCDS.AbsoluteStart, Feature.AbsoluteEnd - NewCDS.AbsoluteStart)
                        NewCDS.ReadList.Add(NewRead)
                    Next Feature

                    For k = 0 To TmpList(0).AdditionalProperties.DataHeaders.Count - 1
                        If TmpList(0).AdditionalProperties.DataHeaders(k) = "product" Then
                            NewCDS.Description = TmpList(0).AdditionalProperties.DataValues(k)
                        End If
                        If TmpList(0).AdditionalProperties.DataHeaders(k) = "gene" Then
                            NewCDS.Name = TmpList(0).AdditionalProperties.DataValues(k)
                        End If
                    Next k

                    Asm.FeaturesList.Add(NewCDS)

                End If 'TmpList.Count > 1 



            End If 'Asm.FeaturesList(i).Type = 1
        Next i
    End Sub

    Public Shared Sub SortReadListsForFeatures(ByRef Asm As FeaturesAssembly)
        Dim Max As Integer = 0
        Dim TmpRead As ReadItem = Nothing

        For k = 0 To Asm.FeaturesList.Count - 1
            If Asm.FeaturesList(k).UseReadList Then

                'Sort
                Max = Asm.FeaturesList(k).ReadList.Count - 1
                For i = 0 To Max
                    For j = i + 1 To Max
                        If Asm.FeaturesList(k).ReadList(i).ReadAbsoluteStart > Asm.FeaturesList(k).ReadList(j).ReadAbsoluteStart Then
                            TmpRead = Asm.FeaturesList(k).ReadList(j)
                            Asm.FeaturesList(k).ReadList.RemoveAt(j)
                            Asm.FeaturesList(k).ReadList.Insert(i, TmpRead)
                        End If
                    Next j
                Next i

            End If
        Next k
    End Sub

#End Region

#Region "Open ANNOT"

    Public Shared Function ReadAnnotationHeader(ByVal FilePath As String)
        Dim AnnotationHeader As New List(Of String)
        Dim ReadStream As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(ReadStream)
        Dim CurrentLine As String = ""
        Dim StartRead As Boolean = False

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine

            Select Case CurrentLine

                Case "<General>"
                    StartRead = True
                Case "<General/>"
                    Exit While

                Case Else
                    If StartRead Then
                        AnnotationHeader.Add(CurrentLine)
                    End If
            End Select

        End While

        Reader.Close()
        ReadStream.Close()
        Reader.Dispose()
        ReadStream.Dispose()

        Return AnnotationHeader
    End Function

    Public Shared Function ReadAnnotationData(ByVal FilePath As String, ByVal GroupName As String)

        Dim Features As New List(Of Genome_Feature)

        Dim ReadStream As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(ReadStream)
        Dim CurrentLine As String = ""
        Dim ReadFeature As Genome_Feature = Nothing
        Dim DataPair As String()
        Dim RCItems As String()

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            If CurrentLine = "<General/>" Then
                Exit While
            End If
        End While

        While Reader.Peek > -1

            CurrentLine = Reader.ReadLine

            Select Case CurrentLine
                Case ""
                    'Do nothing
                Case "<F>"
                    ReadFeature = New Genome_Feature
                    ReadFeature.Group = GroupName
                Case "<Feature>"
                    ReadFeature = New Genome_Feature
                    ReadFeature.Group = GroupName
                Case "<F/>"
                    Features.Add(ReadFeature)
                Case "<Feature/>"
                    Features.Add(ReadFeature)
                Case Else
                    DataPair = CurrentLine.Split("=")

                    If DataPair(0).StartsWith("/") Then

                        If IsNothing(ReadFeature.AdditionalProperties) Then
                            ReadFeature.AdditionalProperties = New FeatureData
                            ReadFeature.AdditionalProperties.DataHeaders.Add(DataPair(0).Substring(1))
                            ReadFeature.AdditionalProperties.DataValues.Add(DataPair(1))
                        Else
                            ReadFeature.AdditionalProperties.DataHeaders.Add(DataPair(0).Substring(1))
                            ReadFeature.AdditionalProperties.DataValues.Add(DataPair(1))
                        End If

                    Else

                        Select Case DataPair(0)
                            Case "TG"
                                ReadFeature.TAG = DataPair(1)
                            Case "TAG"
                                ReadFeature.TAG = DataPair(1)
                            Case "NM"
                                ReadFeature.Name = DataPair(1)
                            Case "Name"
                                ReadFeature.Name = DataPair(1)
                            Case "DC"
                                ReadFeature.Description = DataPair(1)
                            Case "Description"
                                ReadFeature.Description = DataPair(1)
                            Case "ST"
                                ReadFeature.AbsoluteStart = DataPair(1)
                            Case "Start"
                                ReadFeature.AbsoluteStart = DataPair(1)
                            Case "ED"
                                ReadFeature.AbsoluteEnd = DataPair(1)
                            Case "End"
                                ReadFeature.AbsoluteEnd = DataPair(1)
                            Case "DR"
                                ReadFeature.Direction = DataPair(1)
                            Case "Direction"
                                ReadFeature.Direction = DataPair(1)
                            Case "TP"
                                ReadFeature.Type = DataPair(1)
                            Case "Type"
                                ReadFeature.Type = DataPair(1)
                            Case "OT"
                                ReadFeature.Orthology = DataPair(1)
                            Case "Orthology"
                                ReadFeature.Orthology = DataPair(1)
                            Case "RD"
                                ReadFeature.UseReadList = True
                                RCItems = DataPair(1).Split(",")
                                For Each RCItem As String In RCItems
                                    ReadFeature.ReadList.Add(New ReadItem(RCItem.Split(".")(0), RCItem.Split(".")(1)))
                                Next
                            Case "Translation"
                                ReadFeature.UseReadList = True
                                RCItems = DataPair(1).Split(",")
                                For Each RCItem As String In RCItems
                                    ReadFeature.ReadList.Add(New ReadItem(RCItem.Split(".")(0), RCItem.Split(".")(1)))
                                Next

                        End Select

                    End If 'DataPair(0).StartsWith("/")

            End Select

        End While


        Reader.Close()
        ReadStream.Close()
        Reader.Dispose()
        ReadStream.Dispose()


        Return Features
    End Function

#End Region

    'Public Shared Function ReadGBFileToSequence(ByVal FileName As String)
    'Dim FS As New IO.FileStream(FileName, IO.FileMode.Open)
    'Dim Reader As New IO.StreamReader(FS)
    'Dim CurrentLine As String = ""
    'Dim Seq As String = ""
    'Dim StartSeqRead As Boolean = False

    'While Reader.Peek > -1
    'CurrentLine = Reader.ReadLine

    'If CurrentLine.StartsWith("//") Then
    'StartSeqRead = False
    'End If


    'If StartSeqRead Then
    'If CurrentLine.Length > 10 Then
    'Seq &= CurrentLine.Substring(10).Replace(Chr(32), vbNullString).ToUpper()
    'End If
    'End If




    'If CurrentLine.StartsWith("ORIGIN") Then
    'StartSeqRead = True
    'End If



    'End While

    'Reader.Close()
    'FS.Close()
    'Reader.Dispose()
    'FS.Dispose()

    'Return Seq
    'End Function

    Public Shared Function Read_GB_Annotation(ByVal FileName As String)
        Dim FS As New IO.FileStream(FileName, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)

        Dim CurrentLine As String = ""
        Dim ReadAnnotation As Boolean = False
        Dim DataList As New List(Of String)

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine

            If ReadAnnotation Then
                If CurrentLine.Length > 21 Then 'Otherwise it is junk
                    DataList.Add(CurrentLine)
                End If
            End If


            If CurrentLine.StartsWith("FEATURES") Then
                ReadAnnotation = True 'Here begins annotation (features)
            End If

            If CurrentLine.StartsWith("ORIGIN") Or CurrentLine = "//" Then
                ReadAnnotation = False 'Stop reading
            End If

        End While

        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()

        Return DataList
    End Function

    Public Shared Function InitializeFeatureByKey(ByVal FeatureKey As String, Optional ByVal KeepGBType As Boolean = True, Optional ByVal AlternateFeatureID As String = "")
        Dim NewFeature As Genome_Feature = Nothing

        Select Case FeatureKey
            Case "source"
                NewFeature = Nothing 'This is informational key about the sequence
            Case "gene"
                NewFeature = New Genome_Feature
                NewFeature.Type = 10
            Case "CDS"
                NewFeature = New Genome_Feature
                NewFeature.Type = 1
            Case "rRNA"
                NewFeature = New Genome_Feature
                NewFeature.Type = 2
            Case "tRNA"
                NewFeature = New Genome_Feature
                NewFeature.Type = 2
            Case "mRNA"
                NewFeature = New Genome_Feature
                NewFeature.Type = 12
            Case "tmRNA"
                NewFeature = New Genome_Feature
                NewFeature.Type = 2
            Case "ncRNA"
                NewFeature = New Genome_Feature
                NewFeature.Type = 4
            Case "protein_bind"
                NewFeature = New Genome_Feature
                NewFeature.Type = 3
            Case "misc_binding"
                NewFeature = New Genome_Feature
                NewFeature.Type = 3
            Case "repeat_region"
                NewFeature = New Genome_Feature
                NewFeature.Type = 9
            Case "primer_bind"
                NewFeature = New Genome_Feature
                NewFeature.Type = 10
            Case "promoter"
                NewFeature = New Genome_Feature
                NewFeature.Type = 3
            Case "misc_feature"
                NewFeature = New Genome_Feature
                NewFeature.Type = 10
            Case Else
                NewFeature = New Genome_Feature
                NewFeature.Type = 10
        End Select

        If Not IsNothing(NewFeature) Then
            NewFeature.TAG = AlternateFeatureID
        End If

        If Not IsNothing(NewFeature) And KeepGBType Then
            Dim NewAdditionalInfo As New FeatureData
            NewFeature.AdditionalProperties = NewAdditionalInfo
            NewFeature.AdditionalProperties.DataHeaders.Add("#GBType")
            NewFeature.AdditionalProperties.DataValues.Add(FeatureKey)
        End If


        Return NewFeature
    End Function

    Public Shared Sub ParseCoorditatesForFeature(ByRef TargetFeature As Genome_Feature, ByVal CoordString As String)

        If CoordString.Contains(">") Then
            CoordString = CoordString.Replace(">", "")
        End If

        If CoordString.Contains("<") Then
            CoordString = CoordString.Replace("<", "")
        End If

        Dim FeatureCoord As String() = Nothing

        If CoordString.Contains("join") Then 'There are frameshifts/introns
            If CoordString.Contains("complement") Then 'Minus
                FeatureCoord = CoordString.Substring(16, CoordString.Length - 18).Split(",")

                TargetFeature.AbsoluteStart = Split(FeatureCoord(0), ".")(0)
                TargetFeature.AbsoluteEnd = Split(FeatureCoord(FeatureCoord.GetUpperBound(0)), ".")(2)
                TargetFeature.Direction = 2

                Dim NewReadItem As ReadItem = Nothing
                For Each Exon As String In FeatureCoord
                    NewReadItem = New ReadItem(Split(Exon, ".")(0) - TargetFeature.AbsoluteStart, _
                                             Split(Exon, ".")(2) - TargetFeature.AbsoluteStart)
                    TargetFeature.ReadList.Add(NewReadItem)
                Next

            Else 'Plus
                FeatureCoord = CoordString.Substring(5, CoordString.Length - 6).Split(",")

                TargetFeature.AbsoluteStart = Split(FeatureCoord(0), ".")(0)
                TargetFeature.AbsoluteEnd = Split(FeatureCoord(FeatureCoord.GetUpperBound(0)), ".")(2)
                TargetFeature.Direction = 1

                Dim NewReadItem As ReadItem = Nothing
                For Each Exon As String In FeatureCoord
                    NewReadItem = New ReadItem(Split(Exon, ".")(0) - TargetFeature.AbsoluteStart, _
                                             Split(Exon, ".")(2) - TargetFeature.AbsoluteStart)
                    TargetFeature.ReadList.Add(NewReadItem)
                Next

            End If
        Else
            If CoordString.Contains("complement") Then 'Minus
                FeatureCoord = CoordString.Substring(11, CoordString.Length - 12).Split(".")
                TargetFeature.AbsoluteStart = FeatureCoord(0)
                TargetFeature.AbsoluteEnd = FeatureCoord(2)
                TargetFeature.Direction = 2
            Else 'Plus
                FeatureCoord = CoordString.Split(".")
                TargetFeature.AbsoluteStart = FeatureCoord(0)
                TargetFeature.AbsoluteEnd = FeatureCoord(2)
                TargetFeature.Direction = 1
            End If
        End If



    End Sub

    Public Shared Sub AssignFeatureProperty(ByRef TargetFeature As Genome_Feature, ByVal QualifierKey As String, Optional ByVal QualifierValue As String = "Unknown")
        Select Case QualifierKey
            Case "/locus_tag"
                TargetFeature.TAG = QualifierValue.Trim(Chr(34))
            Case "/transcript_id"
                TargetFeature.TAG = QualifierValue.Trim(Chr(34))
            Case "/protein_id"
                TargetFeature.TAG = QualifierValue.Trim(Chr(34))
            Case "/gene"
                TargetFeature.Name = QualifierValue.Trim(Chr(34))
            Case "/bound_moiety"
                If TargetFeature.Name = "" Then
                    TargetFeature.Name = QualifierValue.Trim(Chr(34)) & " binding site"
                End If
                TargetFeature.Description = QualifierValue.Trim(Chr(34)) & " binding site"
            Case "/note"
                If TargetFeature.Name = "" Then
                    TargetFeature.Name = QualifierValue.Trim(Chr(34))
                End If
                If TargetFeature.Description = "" Then
                    TargetFeature.Description = QualifierValue.Trim(Chr(34))
                End If
            Case "/product"
                TargetFeature.Description = QualifierValue.Trim(Chr(34))
            Case "/pseudo"
                TargetFeature.Description &= " Pseudogene"


                If IsNothing(TargetFeature.AdditionalProperties) Then
                    Dim NewAdditionalInfo As New FeatureData
                    TargetFeature.AdditionalProperties = NewAdditionalInfo
                End If

                TargetFeature.AdditionalProperties.DataHeaders.Add(QualifierKey)
                TargetFeature.AdditionalProperties.DataValues.Add("#NotUsed")

            Case "/note"
                If IsNothing(TargetFeature.AdditionalProperties) Then
                    Dim NewAdditionalInfo As New FeatureData
                    TargetFeature.AdditionalProperties = NewAdditionalInfo
                End If

                TargetFeature.AdditionalProperties.DataHeaders.Add(QualifierKey)
                TargetFeature.AdditionalProperties.DataValues.Add(QualifierValue)

            Case "/inference"
                If IsNothing(TargetFeature.AdditionalProperties) Then
                    Dim NewAdditionalInfo As New FeatureData
                    TargetFeature.AdditionalProperties = NewAdditionalInfo
                End If

                TargetFeature.AdditionalProperties.DataHeaders.Add(QualifierKey)
                TargetFeature.AdditionalProperties.DataValues.Add(QualifierValue)

            Case "/protein_id"
                If IsNothing(TargetFeature.AdditionalProperties) Then
                    Dim NewAdditionalInfo As New FeatureData
                    TargetFeature.AdditionalProperties = NewAdditionalInfo
                End If

                TargetFeature.AdditionalProperties.DataHeaders.Add(QualifierKey)
                TargetFeature.AdditionalProperties.DataValues.Add(QualifierValue)

            Case "/db_xref"
                If IsNothing(TargetFeature.AdditionalProperties) Then
                    Dim NewAdditionalInfo As New FeatureData
                    TargetFeature.AdditionalProperties = NewAdditionalInfo
                End If

                TargetFeature.AdditionalProperties.DataHeaders.Add(QualifierKey)
                TargetFeature.AdditionalProperties.DataValues.Add(QualifierValue)

        End Select
    End Sub

    Public Shared Function ParseGBAnnotation(ByVal FileName As String)
        Dim Features As New List(Of Genome_Feature)

        Dim MergeGenesAndCDSs As Boolean = GB_Importer.DialogReturn

        Dim DataList As List(Of String) = Read_GB_Annotation(FileName)

        SystemProgressBarBox.MasterProgressBar.Value = 0
        SystemProgressBarBox.MasterProgressBar.Maximum = DataList.Count
        SystemProgressBarBox.Show()
        SystemProgressBarBox.Focus()

        SystemProgressBarBox.StatusLabel.Text = "Parsing data..."
        SystemProgressBarBox.StatusLabel.Refresh()


        'Now analyze data
        Dim FeatureKey As String = ""
        Dim FeatureValue As String = ""
        Dim QualifierKey As String = ""
        Dim QualifierValue As String = ""

        Dim NewFeature As Genome_Feature = Nothing


        Dim LocalPos As Integer = 0
        Dim LocalString As String = ""
        Dim LocalCoords(2) As Integer

        Dim MaxLines As Integer = DataList.Count - 1

        Dim FeatureCounter As Integer = 0 'To use for alternate ID

        For StrPos As Integer = 0 To MaxLines
            FeatureKey = DataList(StrPos).Substring(0, 21).Trim()
            FeatureValue = DataList(StrPos).Substring(21)

            'Variables to check next string
            LocalString = FeatureValue
            LocalPos = StrPos + 1

            If FeatureKey.Length > 0 Then 'This is a new feature
                'Close previous feature and prime a new one

                If Not IsNothing(NewFeature) Then
                    'Add New Feature to the list
                    If NewFeature.TAG = "" And Not NewFeature.Name = "" Then
                        NewFeature.TAG = NewFeature.Name
                    End If

                    If NewFeature.Name = "" And Not NewFeature.TAG = "" Then
                        NewFeature.Name = NewFeature.TAG
                    End If

                    Features.Add(NewFeature)
                End If

                'Initialize New Feature

                NewFeature = InitializeFeatureByKey(FeatureKey, , "Feature_" & FeatureCounter)
                FeatureCounter += 1

                'Now parse coordinates
                'Collect full string with coordinates

                Do
                    If LocalPos > DataList.Count - 1 Then
                        Exit Do
                    End If

                    If DataList(LocalPos).Substring(21).StartsWith("/") Or _
                    DataList(LocalPos).Substring(0, 21).Trim().Length > 0 Then 'There starts next info or next feature
                        'Stop and parse
                        Exit Do
                    Else
                        'Collect
                        LocalString &= DataList(LocalPos).Substring(21)
                        LocalPos += 1
                    End If
                Loop

                If Not IsNothing(NewFeature) Then
                    ParseCoorditatesForFeature(NewFeature, LocalString)
                End If


            Else 'Here is feature data


                If FeatureValue.StartsWith("/") Then

                    Do
                        If LocalPos > DataList.Count - 1 Then
                            Exit Do
                        End If

                        If DataList(LocalPos).Substring(21).StartsWith("/") Or _
                        DataList(LocalPos).Substring(0, 21).Trim().Length > 0 Then 'There starts next info or next feature
                            'Stop and parse
                            Exit Do
                        Else
                            'Collect
                            LocalString &= DataList(LocalPos).Substring(21)
                            LocalPos += 1
                        End If

                    Loop

                    If Not IsNothing(NewFeature) Then
                        If LocalString.Contains("=") Then
                            QualifierKey = LocalString.Split("=")(0)
                            QualifierValue = LocalString.Split("=")(1)
                            AssignFeatureProperty(NewFeature, QualifierKey, QualifierValue)
                        Else
                            QualifierKey = LocalString.Split("=")(0)
                            AssignFeatureProperty(NewFeature, QualifierKey)
                        End If
                    End If



                    'Else it is continuation of previous data, it should not be treated as new value
                End If



            End If



            If StrPos = MaxLines Then 'Add the last one feature
                If Not IsNothing(NewFeature) Then
                    Features.Add(NewFeature)
                End If
            End If

            SystemProgressBarBox.MasterProgressBar.PerformStep()

        Next


        If MergeGenesAndCDSs Then

            Dim counter As Integer = 0
            Dim RemovedCounter As Integer = 0

            Do
                If counter = Features.Count Then
                    Exit Do
                End If

                If Features(counter).Type = 1 Then 'This is CDS


                    For Each Feature As Genome_Feature In Features
                        If Feature.Type = 10 And _
                        Features(counter).Name = Feature.Name And _
                        Feature.AbsoluteStart = Features(counter).AbsoluteStart And _
                        Feature.AbsoluteEnd = Features(counter).AbsoluteEnd And _
                        Feature.Direction = Features(counter).Direction Then 'Search for respective gene

                            Features.Remove(Feature)
                            RemovedCounter += 1
                            counter -= 1
                            Exit For
                        End If
                    Next
                End If


                counter += 1
            Loop

            ' MsgBox("Removed: " & RemovedCounter & " items")
        End If

        SystemProgressBarBox.Close()

        Return Features
    End Function

    Public Shared Function ReadGBTopology(ByVal FileName As String)
        Dim Topology As Boolean = False

        Dim FS As New IO.FileStream(FileName, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)
        Dim CurrentLine As String = Reader.ReadLine

        If CurrentLine.Contains("circular") Then
            Topology = True
        End If

        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()


        Return Topology
    End Function

    Public Shared Function ReadGBCodeTable(ByVal FileName As String)
        Dim FS As New IO.FileStream(FileName, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)

        Dim CurrentLine As String = ""
        Dim ReadAnnotation As Boolean = False
        Dim DataList As New List(Of String)

        Dim CodeTable As Short = 1

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine

            If CurrentLine.Contains("/transl_table") Then
                CodeTable = CurrentLine.Substring(35)
                Exit While
            End If

        End While

        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()

        Return CodeTable

    End Function

#Region "Write Annot and Fasta"

    Public Shared Sub WriteAnnotationFull(ByVal DataArray As List(Of Genome_Feature), ByVal FileName As String, _
                                          Optional ByVal GenomeTopology As Boolean = False, _
                                          Optional ByVal GeneticCode As Short = 1, _
                                          Optional ByVal Comment As String = "", _
                                          Optional ByVal ProgressIndicator As ProgressBar = Nothing, _
                                          Optional ByVal ProgressControlBox As SystemProgressBarBox = Nothing, _
                                          Optional ByVal WriteAdditionalValues As Boolean = False, _
                                          Optional ByVal AdditionalGeneralData As FeatureData = Nothing)

        If Not IsNothing(ProgressIndicator) Then
            ProgressIndicator.Value = 0
        End If

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.MasterProgressBar.Value = 0
            ProgressControlBox.StatusLabel.Text = "Saving annotation..."
            ProgressControlBox.StatusLabel.Refresh()
        End If



        'Make new annotation file
        If Not IsNothing(ProgressIndicator) Then
            ProgressIndicator.Maximum = DataArray.Count + 2
        End If

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.MasterProgressBar.Maximum = DataArray.Count
        End If


        Dim AnnotFileName As String = String.Concat(FileName, ".annot")
        Dim WriteStream As New IO.FileStream(AnnotFileName, IO.FileMode.Create, IO.FileAccess.Write)
        Dim Writer As New IO.StreamWriter(WriteStream)
        Writer.WriteLine("<General>")
        Writer.WriteLine(String.Concat("GenomeTopology=", GenomeTopology))
        Writer.WriteLine(String.Concat("GeneticCode=", GeneticCode))
        Writer.WriteLine(String.Concat("Comment=", Comment))

        If Not IsNothing(AdditionalGeneralData) Then
            For k = 0 To AdditionalGeneralData.DataHeaders.Count - 1
                Writer.WriteLine(String.Concat("/", AdditionalGeneralData.DataHeaders(k), "=", AdditionalGeneralData.DataValues(k)))
            Next k
        End If

        Writer.WriteLine("<General/>")

        For Each Feature As Genome_Feature In DataArray
            Writer.WriteLine("<Feature>")
            Writer.WriteLine(String.Concat("TAG=", Feature.TAG)) 'TAG
            Writer.WriteLine(String.Concat("Name=", Feature.Name)) 'Name
            Writer.WriteLine(String.Concat("Description=", Feature.Description)) 'Description
            Writer.WriteLine(String.Concat("Start=", Feature.AbsoluteStart)) 'Start
            Writer.WriteLine(String.Concat("End=", Feature.AbsoluteEnd)) 'End
            Writer.WriteLine(String.Concat("Direction=", Feature.Direction)) 'Direction
            Writer.WriteLine(String.Concat("Type=", Feature.Type)) 'Type
            Writer.WriteLine(String.Concat("Orthology=", Feature.Orthology)) 'Orthology

            If Feature.ReadList.Count > 0 Then
                Dim ReadString As String = ""
                For Each RItem As ReadItem In Feature.ReadList
                    ReadString &= String.Concat(RItem.ReadAbsoluteStart, ".", RItem.ReadAbsoluteEnd, ",")
                Next
                ReadString = ReadString.Remove(ReadString.Length - 1, 1)
                Writer.WriteLine(String.Concat("Translation=", ReadString)) 'Read string
            End If

            If WriteAdditionalValues Then
                For k = 0 To Feature.AdditionalProperties.DataHeaders.Count - 1
                    Writer.WriteLine(String.Concat("/", Feature.AdditionalProperties.DataHeaders(k) & "=" & Feature.AdditionalProperties.DataValues(k)))
                Next k
            End If

            If Not IsNothing(ProgressIndicator) Then
                ProgressIndicator.Value += 1
            End If

            If Not IsNothing(ProgressControlBox) Then
                ProgressControlBox.MasterProgressBar.PerformStep()
            End If

            Writer.WriteLine("<Feature/>")
        Next

        If Not IsNothing(ProgressIndicator) Then
            ProgressIndicator.Value = 0
        End If

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.Close()
        End If



        Writer.Close()
        WriteStream.Close()
        Writer.Dispose()
        WriteStream.Dispose()
    End Sub

    Public Shared Sub WriteAnnotation(ByVal DataArray As List(Of Genome_Feature), ByVal FileName As String, Optional ByVal GenomeTopology As Boolean = False, Optional ByVal GeneticCode As Short = 0, Optional ByVal Comment As String = "", Optional ByVal ProgressIndicator As ProgressBar = Nothing, Optional ByVal ProgressControlBox As SystemProgressBarBox = Nothing)

        If Not IsNothing(ProgressIndicator) Then
            ProgressIndicator.Value = 0
        End If

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.MasterProgressBar.Value = 0
            ProgressControlBox.StatusLabel.Text = "Saving annotation..."
            ProgressControlBox.StatusLabel.Refresh()
        End If



        'Make new annotation file
        If Not IsNothing(ProgressIndicator) Then
            ProgressIndicator.Maximum = DataArray.Count + 2
        End If

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.MasterProgressBar.Maximum = DataArray.Count
        End If


        Dim AnnotFileName As String = String.Concat(FileName, ".annot")
        Dim WriteStream As New IO.FileStream(AnnotFileName, IO.FileMode.Create, IO.FileAccess.Write)
        Dim Writer As New IO.StreamWriter(WriteStream)
        Writer.WriteLine("<General>")
        Writer.WriteLine(String.Concat("GenomeTopology=", GenomeTopology))
        Writer.WriteLine(String.Concat("GeneticCode=", GeneticCode))
        Writer.WriteLine(String.Concat("Comment=", Comment))
        Writer.WriteLine("<General/>")

        For Each Feature As Genome_Feature In DataArray
            Writer.WriteLine("<F>")
            Writer.WriteLine(String.Concat("TG=", Feature.TAG)) 'TAG
            Writer.WriteLine(String.Concat("NM=", Feature.Name)) 'Name
            Writer.WriteLine(String.Concat("DC=", Feature.Description)) 'Description
            Writer.WriteLine(String.Concat("ST=", Feature.AbsoluteStart)) 'Start
            Writer.WriteLine(String.Concat("ED=", Feature.AbsoluteEnd)) 'End
            Writer.WriteLine(String.Concat("DR=", Feature.Direction)) 'Direction
            Writer.WriteLine(String.Concat("TP=", Feature.Type)) 'Type
            Writer.WriteLine(String.Concat("OT=", Feature.Orthology)) 'Orthology

            If Feature.ReadList.Count > 0 Then
                Dim ReadString As String = ""
                For Each RItem As ReadItem In Feature.ReadList
                    ReadString &= String.Concat(RItem.ReadAbsoluteStart, ".", RItem.ReadAbsoluteEnd, ",")
                Next
                ReadString = ReadString.Remove(ReadString.Length - 1, 1)
                Writer.WriteLine(String.Concat("RD=", ReadString)) 'Read string
            End If


            If Not IsNothing(ProgressIndicator) Then
                ProgressIndicator.Value += 1
            End If

            If Not IsNothing(ProgressControlBox) Then
                ProgressControlBox.MasterProgressBar.PerformStep()
            End If

            Writer.WriteLine("<F/>")
        Next

        If Not IsNothing(ProgressIndicator) Then
            ProgressIndicator.Value = 0
        End If

        If Not IsNothing(ProgressControlBox) Then
            ProgressControlBox.Close()
        End If



        Writer.Close()
        WriteStream.Close()
        Writer.Dispose()
        WriteStream.Dispose()
    End Sub

    Public Shared Sub WriteSequence(ByVal Sequence As String, ByVal FileName As String, Optional ByVal Header As String = ">")
        Dim FastaFileName As String = String.Concat(FileName, ".fasta")
        Dim WriteStream As New IO.FileStream(FastaFileName, IO.FileMode.Create, IO.FileAccess.Write)
        Dim Writer As New IO.StreamWriter(WriteStream)
        Writer.WriteLine(Header)
        Writer.Write(Sequence)
        Writer.Close()
        WriteStream.Close()
        Writer.Dispose()
        WriteStream.Dispose()
    End Sub

#End Region

#Region "Write GB" 'The format is pure shit

    Public Shared Function FormatStringForGB(ByVal TotalString As String, Optional ByVal FormatStep As Integer = 58, Optional ByVal ShiftMode As Short = 0) 'GB files have fucking formatting of 58 characters per line
        Dim FormattedString As String = ""
        Dim Sub_String As String = ""
        Dim Marker As Integer = 0
        Dim LocalStep As Integer = 0

        Dim TableShift As String = ""
        Dim FirstLine As Boolean = True

        Select Case ShiftMode
            Case 0
                TableShift = "                     "
            Case 1
                TableShift = "            "
        End Select



        Do

            If Marker + FormatStep > TotalString.Length - 1 Then

                Sub_String = TotalString.Substring(Marker)
                ' FormattedString &= TableShift & Sub_String

                If FirstLine And ShiftMode = 1 Then
                    FormattedString &= Sub_String
                Else
                    FormattedString &= TableShift & Sub_String
                End If


                Exit Do
            End If


            If Not TotalString.Substring(Marker + FormatStep, 1) = " " Then
                LocalStep = 0
                For i = Marker + FormatStep To Marker + FormatStep - 20 Step -1
                    LocalStep += 1
                    If TotalString.Substring(i, 1) = " " Then

                        Sub_String = TotalString.Substring(Marker, FormatStep - LocalStep + 2)
                        Marker += FormatStep - LocalStep + 2
                        Exit For
                    End If
                Next i


            Else

                Sub_String = TotalString.Substring(Marker, FormatStep)
                Marker += FormatStep
            End If


            If FirstLine And ShiftMode = 1 Then
                FormattedString &= Sub_String & vbNewLine
            Else
                FormattedString &= TableShift & Sub_String & vbNewLine
            End If

            FirstLine = False




        Loop

        'No empty line characters within the body of the GB file
        If FormattedString.Substring(FormattedString.Length - 1) = vbNewLine Then
            FormattedString = FormattedString.Substring(0, FormattedString.Length - 1)
        End If


        Return FormattedString
    End Function

    Public Shared Function FormatCoordinates(ByVal Feature As Genome_Feature)
        Dim Result As String = ""

        Select Case Feature.Direction
            Case 1
                Result = Feature.AbsoluteStart & ".." & Feature.AbsoluteEnd
            Case 2
                Result = "complement(" & Feature.AbsoluteStart & ".." & Feature.AbsoluteEnd & ")"
            Case Else
                Result = Feature.AbsoluteStart & ".." & Feature.AbsoluteEnd
        End Select

        Return Result
    End Function

    Public Shared Sub WriteGBFormat(ByVal FileName As String, _
                                    ByVal DataArray As List(Of Genome_Feature), _
                                    ByVal Sequence As String, _
                                    Optional ByVal GenomeTopology As Boolean = False, _
                                    Optional ByVal GeneticCode As Short = 1, _
                                    Optional ByVal SeqName As String = "Unknown", _
                                    Optional ByVal Locus As String = "Unknown", _
                                    Optional ByVal Source As String = "", _
                                    Optional ByVal Organism As String = "", _
                                    Optional ByVal Accession As String = "", _
                                    Optional ByVal Version As String = "", _
                                    Optional ByVal DBlink As String = "", _
                                    Optional ByVal Keywords As String = "", _
                                    Optional ByVal Comment As String = "", _
                                    Optional ByVal RefData As String = "")


        Dim WriteStream As New IO.FileStream(FileName & ".gb", IO.FileMode.Create, IO.FileAccess.Write)
        Dim Writer As New IO.StreamWriter(WriteStream)


        'Write header
        Dim TextTopology As String = "linear"
        If GenomeTopology Then
            TextTopology = "circular"
        End If

        Dim CurrentMonth As String = ""
        Select Case Date.Now.Month
            Case 1
                CurrentMonth = "JAN"
            Case 2
                CurrentMonth = "FEB"
            Case 3
                CurrentMonth = "MAR"
            Case 4
                CurrentMonth = "APR"
            Case 5
                CurrentMonth = "MAY"
            Case 6
                CurrentMonth = "JUN"
            Case 7
                CurrentMonth = "JUL"
            Case 8
                CurrentMonth = "AUG"
            Case 9
                CurrentMonth = "SEP"
            Case 10
                CurrentMonth = "OCT"
            Case 11
                CurrentMonth = "NOV"
            Case 12
                CurrentMonth = "DEC"
        End Select

        Dim CurrentDate As String = Date.Now.Day & "-" & CurrentMonth & "-" & Date.Now.Year


        Writer.WriteLine("LOCUS       " & Locus & " " & Sequence.Length & " bp DNA " & TextTopology & " " & CurrentDate)
        Writer.WriteLine("DEFINITION  " & SeqName) 'This is "True" name of the sequence

        If Not Accession = "" Then
            Writer.WriteLine("ACCESSION   " & FormatStringForGB(Accession, , 1))
        End If

        If Not Version = "" Then
            Writer.WriteLine("VERSION     " & Version)
        End If

        If Not DBlink = "" Then
            Writer.WriteLine("DBLINK      " & FormatStringForGB(DBlink, , 1))
        End If

        If Not Keywords = "" Then
            Writer.WriteLine("KEYWORDS    " & FormatStringForGB(Keywords, , 1))
        End If

        If Not Source = "" Then
            Writer.WriteLine("SOURCE      " & Source)
        End If

        If Not Organism = "" Then
            Writer.WriteLine("  ORGANISM  " & FormatStringForGB(Organism, , 1))
        End If

        If Not RefData = "" Then
            Writer.Write(RefData)
        End If

        If Not Comment = "" Then
            Writer.WriteLine("COMMENT     " & FormatStringForGB(Comment, , 1))
        End If

        'Write Features
        Writer.WriteLine("FEATURES             Location/Qualifiers")

        'Write header for the whole sequence (redundant bullshit)
        Writer.WriteLine("     source          1.." & Sequence.Length)
        Writer.WriteLine(FormatStringForGB("/organism=" & Chr(34) & Organism & Chr(34)))
        'Writer.WriteLine("                     /mol_type=" & Chr(34) & SeqName & Chr(34))
        'Writer.WriteLine("                     /strain=" & Chr(34) & SeqName & Chr(34))
        'Writer.WriteLine("                     /db_xref=" & Chr(34) & SeqName & Chr(34))



        For Each Feature As Genome_Feature In DataArray

            Select Case Feature.Type
                Case 1
                    Writer.WriteLine("     CDS             " & FormatCoordinates(Feature))
                    Writer.WriteLine("                     /locus_tag=" & Chr(34) & Feature.TAG & Chr(34))
                    Writer.WriteLine("                     /gene=" & Chr(34) & Feature.Name & Chr(34))
                    Writer.WriteLine("                     /transl_table=" & GeneticCode)
                    Writer.WriteLine(FormatStringForGB("/product=" & Chr(34) & Feature.Description & Chr(34)))


                Case 2
                    Writer.WriteLine("     misc_RNA        " & FormatCoordinates(Feature))
                    Writer.WriteLine("                     /locus_tag=" & Chr(34) & Feature.TAG & Chr(34))
                    Writer.WriteLine("                     /gene=" & Chr(34) & Feature.Name & Chr(34))
                    Writer.WriteLine(FormatStringForGB("/product=" & Chr(34) & Feature.Description & Chr(34)))

                Case 3
                    Writer.WriteLine("     regulatory      " & FormatCoordinates(Feature))
                    Writer.WriteLine("                     /locus_tag=" & Chr(34) & Feature.TAG & Chr(34))
                    Writer.WriteLine("                     /gene=" & Chr(34) & Feature.Name & Chr(34))
                    Writer.WriteLine(FormatStringForGB("/note=" & Chr(34) & Feature.Description & Chr(34)))

                Case 4
                    Writer.WriteLine("     ncRNA           " & FormatCoordinates(Feature))
                    Writer.WriteLine("                     /locus_tag=" & Chr(34) & Feature.TAG & Chr(34))
                    Writer.WriteLine("                     /gene=" & Chr(34) & Feature.Name & Chr(34))
                    Writer.WriteLine(FormatStringForGB("/product=" & Chr(34) & Feature.Description & Chr(34)))

                Case 9
                    Writer.WriteLine("     repeat_region   " & FormatCoordinates(Feature))
                    Writer.WriteLine("                     /locus_tag=" & Chr(34) & Feature.TAG & Chr(34))
                    Writer.WriteLine("                     /gene=" & Chr(34) & Feature.Name & Chr(34))
                    Writer.WriteLine(FormatStringForGB("/note=" & Chr(34) & Feature.Description & Chr(34)))


                Case Else
                    Writer.WriteLine("     misc_feature    " & FormatCoordinates(Feature))
                    Writer.WriteLine("                     /locus_tag=" & Chr(34) & Feature.TAG & Chr(34))
                    Writer.WriteLine("                     /gene=" & Chr(34) & Feature.Name & Chr(34))
                    Writer.WriteLine(FormatStringForGB("/note=" & Chr(34) & Feature.Description & Chr(34)))



            End Select


        Next Feature




        'Write Sequence
        Writer.WriteLine("ORIGIN")

        Dim SubSeqLine_60 As String = ""
        Dim LastSeqLine As String = ""
        Dim WriteSeqLine As String = ""
        Dim StringMarker As String = ""
        Dim Marker As Integer = 0
        Dim SpaceRegion As String = ""


        Do

            If Marker + 60 > Sequence.Length - 1 Then
                LastSeqLine = Sequence.Substring(Marker).ToLower

                Dim InternalMarker As Integer = 0
                Dim Substring_10 As String = ""

                StringMarker = (Marker + 1).ToString
                SpaceRegion = ""
                For i = 1 To 9 - StringMarker.Length
                    SpaceRegion &= " "
                Next i

                Dim FormattedLastLine As String = SpaceRegion & StringMarker

                Do

                    If InternalMarker + 10 > LastSeqLine.Length - 1 Then

                        FormattedLastLine &= " " & LastSeqLine.Substring(InternalMarker)

                        Exit Do
                    End If

                    Substring_10 = LastSeqLine.Substring(InternalMarker, 10)

                    FormattedLastLine &= " " & Substring_10

                    InternalMarker += 10

                Loop

                Writer.WriteLine(FormattedLastLine)

                Exit Do
            End If



            SubSeqLine_60 = Sequence.Substring(Marker, 60).ToLower


            'Format subsequence
            StringMarker = (Marker + 1).ToString
            SpaceRegion = ""
            For i = 1 To 9 - StringMarker.Length
                SpaceRegion &= " "
            Next i


            WriteSeqLine = SpaceRegion & StringMarker & " " _
            & SubSeqLine_60.Substring(0, 10) & " " _
            & SubSeqLine_60.Substring(10, 10) & " " _
            & SubSeqLine_60.Substring(20, 10) & " " _
            & SubSeqLine_60.Substring(30, 10) & " " _
            & SubSeqLine_60.Substring(40, 10) & " " _
            & SubSeqLine_60.Substring(50, 10)

            Writer.WriteLine(WriteSeqLine)


            Marker += 60

        Loop

        Writer.WriteLine("//")

        Writer.Close()
        WriteStream.Close()
        Writer.Dispose()
        WriteStream.Dispose()
    End Sub

#End Region

#Region "Write GFF3"

    Public Shared Sub WriteGFF3(ByVal DataArray As List(Of Genome_Feature), ByVal FileName As String, _
                                          Optional ByVal GenomeTopology As Boolean = False, _
                                          Optional ByVal GeneticCode As Short = 0, _
                                          Optional ByVal RegionData As FeatureData = Nothing)




    End Sub

#End Region

    Public Shared Function GetColumnIndex(ByVal Column_Name As String, ByVal DataGrid As DataGridView, Optional ByVal NamingType As Int16 = 0)
        Dim ColNum As Integer = 0


        For Each Column As DataGridViewColumn In DataGrid.Columns
            Select Case NamingType
                Case 0
                    If Column.Name = Column_Name Then
                        ColNum = Column.Index
                        Exit For
                    End If
                Case 1
                    If Column.DataPropertyName = Column_Name Then
                        ColNum = Column.Index
                        Exit For
                    End If
            End Select

        Next

        Return ColNum
    End Function

    Public Shared Function GetCurrentGroup(ByVal GroupList As List(Of FeaturesAssembly), ByVal GroupName As String)

        Dim CurrentGroup As FeaturesAssembly = Nothing

        For Each Group As FeaturesAssembly In GroupList
            If Group.AssemblyName = GroupName Then
                CurrentGroup = Group
                Exit For
            End If
        Next

        Return CurrentGroup

    End Function

    Public Shared Function GetCurrentBlockHolder(ByVal HolderList As List(Of QuantBlockHolder), ByVal HolderName As String)
        Dim CurrentBlockHolder As QuantBlockHolder = Nothing

        For Each Holder As QuantBlockHolder In HolderList
            If Holder.Name = HolderName Then
                CurrentBlockHolder = Holder
                Exit For
            End If
        Next

        Return CurrentBlockHolder

    End Function

    Public Shared Function LoadHeader(ByVal FileName As String)
        Dim FS As New IO.FileStream(String.Concat(FileName, ".fasta"), IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(FS)
        Dim InfoString As String = Reader.ReadLine()
        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()

        Return InfoString
    End Function

    Public Shared Function LoadSequence(ByVal FileName As String, ByVal SeqFormat As String)

        Dim SeqFile As String = FileName & SeqFormat

        Dim FS As New IO.FileStream(SeqFile, IO.FileMode.Open, IO.FileAccess.Read)
        Dim Reader As New IO.StreamReader(FS)

        Dim InfoString As String = Reader.ReadLine()

        Dim InputSeq As String = Reader.ReadToEnd()

        InputSeq = InputSeq.Replace(Chr(13), vbNullString)
        InputSeq = InputSeq.Replace(Chr(10), vbNullString)
        InputSeq = InputSeq.ToUpper()

        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()

        Return InputSeq
    End Function

    Public Shared Function RetrieveSeqFromCache(ByVal Sequence As String, ByVal StartPos As Integer, ByVal EndPos As Integer)
        Dim Seq As String = ""

        If StartPos > Sequence.Length Then
            StartPos -= Sequence.Length
        End If

        If EndPos > Sequence.Length Then
            EndPos -= Sequence.Length
        End If

        If StartPos < 1 Then
            StartPos += Sequence.Length
        End If

        If EndPos < 1 Then
            EndPos += Sequence.Length
        End If


        Try

            If EndPos >= StartPos Then
                Seq = Sequence.Substring(StartPos - 1, EndPos - StartPos + 1)
            Else
                Seq = String.Concat(Sequence.Substring(StartPos - 1), Sequence.Substring(0, EndPos))
            End If

        Catch ex As Exception
            MsgBox("Seq Error")
        End Try

        Seq = Seq.ToUpper()




        Return Seq
    End Function

    Public Shared Sub ImportMultiplePositionalValues(ByVal GenomeViewBox As Genome_Viewer, Optional ByVal ProgressControlBox As SystemProgressBarBox = Nothing)
        If Master.OpenFileDialog.ShowDialog = DialogResult.OK Then

            Dim Strand As Short = SystemStrandSelectionBox.DialogReturn


            If Strand = -1 Then
                Exit Sub
            End If

            Dim StrandText As String = ""
            Select Case Strand
                Case 1
                    StrandText = "Plus"
                Case 2
                    StrandText = "Minus"
            End Select

            If Not IsNothing(ProgressControlBox) Then
                ProgressControlBox.Show()
                ProgressControlBox.Focus()
                ProgressControlBox.MasterProgressBar.Maximum = Master.OpenFileDialog.FileNames.Count
                ProgressControlBox.MasterProgressBar.Value = 0
                ProgressControlBox.StatusLabel.Text = ""
            End If

            For Each File As String In Master.OpenFileDialog.FileNames
                Dim FileNameArr() As String = File.Split("\")
                Dim HolderName As String = FileNameArr(FileNameArr.GetUpperBound(0))

                If Not IsNothing(ProgressControlBox) Then
                    ProgressControlBox.MasterProgressBar.PerformStep()
                    ProgressControlBox.StatusLabel.Text = HolderName
                    ProgressControlBox.StatusLabel.Refresh()
                End If



                Dim FS As New IO.FileStream(File, IO.FileMode.Open)
                Dim Reader As New IO.StreamReader(FS)
                Dim Values As New List(Of Integer)
                Dim CurrentLine As String = ""

                While Reader.Peek > -1
                    CurrentLine = Reader.ReadLine
                    If Not CurrentLine = "" Then
                        Values.Add(CType(CurrentLine, Integer))
                    End If

                End While

                Reader.Close()
                FS.Close()
                Reader.Dispose()
                FS.Dispose()

                Dim NewPositionalHolder As New PositionalValuesHolder(HolderName, Strand, Values, Color.Black, 1)
                NewPositionalHolder.Visible = False

                GenomeViewBox.Positional_Values_Collection.Add(NewPositionalHolder)

                GenomeViewBox.PositionalValuesDataGridView.Rows.Add(False, HolderName, StrandText, "", "Logarithm", NewPositionalHolder.Group)
                GenomeViewBox.PositionalValuesDataGridView.Rows(GenomeViewBox.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = Color.Black

            Next

            If Not IsNothing(ProgressControlBox) Then
                SystemProgressBarBox.Close()
            End If


        End If
    End Sub

    Public Shared Sub RetrievePositionalDataset(ByVal GenomeViewBox As Genome_Viewer)
        If Master.OpenFileDialog.ShowDialog = DialogResult.OK Then
            Dim FileNameArr() As String = Master.OpenFileDialog.FileName.Split("\")
            Dim HolderName As String = FileNameArr(FileNameArr.GetUpperBound(0))


            Dim FS As New IO.FileStream(Master.OpenFileDialog.FileName, IO.FileMode.Open)
            Dim Reader As New IO.StreamReader(FS)
            Dim CurrentLine As String = ""
            Dim DataValues() As String
            Dim Header() As String = Reader.ReadLine.Split(Chr(9))
            Dim ColumnsMax As Integer = Header.GetUpperBound(0)
            Dim Values(ColumnsMax) As List(Of Integer)
            For i = 0 To ColumnsMax
                Values(i) = New List(Of Integer)
            Next i

            While Reader.Peek > -1
                CurrentLine = Reader.ReadLine
                If Not CurrentLine = "" Then
                    DataValues = CurrentLine.Split(Chr(9))

                    For i = 0 To ColumnsMax
                        Values(i).Add(DataValues(i))
                    Next i

                End If

            End While



            Reader.Close()
            FS.Close()
            Reader.Dispose()
            FS.Dispose()


            Dim CurrentStrand As Short = 0
            Dim StrandText As String = ""
            Dim ColumnName As String = ""
            Dim GroupTag As String = ""

            For i = 0 To ColumnsMax
                Select Case Header(i).Split("#")(1)
                    Case "+"
                        CurrentStrand = 1
                        StrandText = "Plus"
                    Case "-"
                        CurrentStrand = 2
                        StrandText = "Minus"
                    Case "0"
                        CurrentStrand = 0
                        StrandText = "Undefined"
                End Select


                GroupTag = Header(i).Split("#")(2)


                ColumnName = Header(i).Split("#")(0)


                Dim NewPositionalHolder As New PositionalValuesHolder(HolderName & "-" & ColumnName, CurrentStrand, Values(i), Color.Black, 1)
                NewPositionalHolder.Group = GroupTag
                NewPositionalHolder.Visible = True

                GenomeViewBox.Positional_Values_Collection.Add(NewPositionalHolder)

                GenomeViewBox.PositionalValuesDataGridView.Rows.Add(True, HolderName & "-" & ColumnName, StrandText, "", "Logarithm", NewPositionalHolder.Group)
                GenomeViewBox.PositionalValuesDataGridView.Rows(GenomeViewBox.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = Color.Black

            Next i


        End If
    End Sub

    Public Shared Sub RetrievePositionalValues(ByVal GenomeViewBox As Genome_Viewer)


        If Master.OpenFileDialog.ShowDialog = DialogResult.OK Then

            Dim FileNameArr() As String = Master.OpenFileDialog.FileName.Split("\")
            PositionalValuesChartControl.NameTextBox.Text = FileNameArr(FileNameArr.GetUpperBound(0))
            PositionalValuesChartControl.ColorPanel.BackColor = Color.Black


            Dim Strand As Short = 0
            Dim Scale As Short = 0

            If PositionalValuesChartControl.ShowDialog = DialogResult.OK Then


                Select Case PositionalValuesChartControl.StrandComboBox.Text
                    Case "Plus"
                        Strand = 1
                    Case "Minus"
                        Strand = 2
                    Case "Undetermined"
                        Strand = 0
                End Select


                Select Case PositionalValuesChartControl.ScaleComboBox.Text
                    Case "Logarithm"
                        Scale = 1
                    Case "Linear"
                        Scale = 0
                End Select

            Else
                Exit Sub
            End If

            Dim FS As New IO.FileStream(Master.OpenFileDialog.FileName, IO.FileMode.Open)
            Dim Reader As New IO.StreamReader(FS)
            Dim Values As New List(Of Integer)
            Dim CurrentLine As String = ""

            While Reader.Peek > -1
                CurrentLine = Reader.ReadLine
                If Not CurrentLine = "" Then
                    Values.Add(CType(CurrentLine, Integer))
                End If

            End While

            Reader.Close()
            FS.Close()
            Reader.Dispose()
            FS.Dispose()

            Dim NewPositionalHolder As New PositionalValuesHolder(PositionalValuesChartControl.NameTextBox.Text, Strand, Values, PositionalValuesChartControl.ColorPanel.BackColor, Scale)
            NewPositionalHolder.Visible = PositionalValuesChartControl.VisibleCheckBox.Checked

            GenomeViewBox.Positional_Values_Collection.Add(NewPositionalHolder)

            GenomeViewBox.PositionalValuesDataGridView.Rows.Add(NewPositionalHolder.Visible, PositionalValuesChartControl.NameTextBox.Text, PositionalValuesChartControl.StrandComboBox.Text, "", PositionalValuesChartControl.ScaleComboBox.Text, NewPositionalHolder.Group)
            GenomeViewBox.PositionalValuesDataGridView.Rows(GenomeViewBox.PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = PositionalValuesChartControl.ColorPanel.BackColor


        End If

    End Sub

    Public Shared Function RetrievePositionalValuesIntoListOfInteger(ByVal FilePath As String)
        Dim FS As New IO.FileStream(FilePath, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)

        Dim Pileup As New List(Of Integer)

        Dim CurrentLine As String = ""

        While Reader.Peek > -1
            CurrentLine = Reader.ReadLine
            If Not CurrentLine = "" Then
                Pileup.Add(CType(CurrentLine, Integer))
            End If

        End While

        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()

        Return Pileup
    End Function

    Public Shared Function RetrievePositionalValuesFromCache(ByVal ValuesHolder As PositionalValuesHolder, ByVal StartPos As Integer, ByVal EndPos As Integer)
        Dim TotalLength As Integer = ValuesHolder.Positional_Values.Count

        Dim SubList As New List(Of Integer)

        If StartPos > TotalLength Then
            StartPos -= TotalLength
        End If

        If EndPos > TotalLength Then
            EndPos -= TotalLength
        End If

        If StartPos < 1 Then
            StartPos += TotalLength
        End If

        If EndPos < 1 Then
            EndPos += TotalLength
        End If


        Try

            If EndPos >= StartPos Then
                SubList = Bioinformatics.GetIntSubList(ValuesHolder.Positional_Values, StartPos - 1, EndPos - StartPos + 1)
            Else
                SubList = Bioinformatics.ConcatIntLists(Bioinformatics.GetIntSubList(ValuesHolder.Positional_Values, StartPos - 1), Bioinformatics.GetIntSubList(ValuesHolder.Positional_Values, 0, EndPos))
            End If

        Catch ex As Exception
            MsgBox("Data Error")
        End Try


        Return SubList
    End Function

    Public Shared Function RetrievePositionalLogValuesFromCache(ByVal ValuesHolder As PositionalValuesHolder, ByVal StartPos As Integer, ByVal EndPos As Integer)
        Dim TotalLength As Integer = ValuesHolder.Log_Values.Count

        Dim SubList As New List(Of Single)

        If StartPos > TotalLength Then
            StartPos -= TotalLength
        End If

        If EndPos > TotalLength Then
            EndPos -= TotalLength
        End If

        If StartPos < 1 Then
            StartPos += TotalLength
        End If

        If EndPos < 1 Then
            EndPos += TotalLength
        End If


        Try

            If EndPos >= StartPos Then
                SubList = Bioinformatics.GetSglSubList(ValuesHolder.Log_Values, StartPos - 1, EndPos - StartPos + 1)
            Else
                SubList = Bioinformatics.ConcatSglLists(Bioinformatics.GetSglSubList(ValuesHolder.Log_Values, StartPos - 1), Bioinformatics.GetSglSubList(ValuesHolder.Log_Values, 0, EndPos))
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


        Return SubList
    End Function

    Public Shared Sub RetrieveIntegratedValues(ByVal ImportFile As String, ByVal Values_col As String, ByVal ID_col As String, ByVal Start_col As String, ByVal End_col As String, ByVal Dir_col As String, ByVal Descr_col As String, ByVal ChartColor As Color, ByRef Viewer As Genome_Viewer)

        Dim FS As New IO.FileStream(ImportFile, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)
        Dim HeaderString As String() = Reader.ReadLine.Split(Chr(9))

        Dim ID_i As Integer = 0
        Dim Start_i As Integer = 0
        Dim End_i As Integer = 0
        Dim Dir_i As Integer = 0
        Dim Descr_i As Integer = 0
        Dim Val_i As Integer = 0


        For i = 0 To HeaderString.Count - 1
            If HeaderString(i) = Values_col Then
                Val_i = i
            End If

            If HeaderString(i) = ID_col Then
                ID_i = i
            End If

            If HeaderString(i) = Start_col Then
                Start_i = i
            End If

            If HeaderString(i) = End_col Then
                End_i = i
            End If

            If HeaderString(i) = Dir_col Then
                Dir_i = i
            End If

            If HeaderString(i) = Descr_col Then
                Descr_i = i
            End If

        Next


        Dim ImportFilePathArr As String() = ImportFile.Split("\")
        Dim QuantumName As String = ImportFilePathArr(ImportFilePathArr.GetUpperBound(0)).Split(".")(0)

        Dim Qholder As New QuantBlockHolder
        Qholder.Name = QuantumName

        Dim CurrentString As String()

        While Reader.Peek > -1
            Try
                CurrentString = Reader.ReadLine.Split(Chr(9))
                Dim NewQ As New QuantitationBlock
                NewQ.Holder_Name = QuantumName
                NewQ.TAG = CurrentString(ID_i)
                NewQ.AbsoluteStart = CurrentString(Start_i)
                NewQ.AbsoluteEnd = CurrentString(End_i)
                NewQ.Direction = CurrentString(Dir_i)
                NewQ.Value = CurrentString(Val_i)
                NewQ.Draw_Color = ChartColor
                NewQ.Visible = True

                If Not Descr_col = "-cancel-" Then
                    NewQ.Description = CurrentString(Descr_i)
                Else
                    NewQ.Description = ""
                End If

                Qholder.BlocksList.Add(NewQ)
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End While



        Viewer.Integrated_Values.Add(Qholder)
        Viewer.Control_Box.SkewOnRadioButton.Checked = True

        Viewer.IntervalsListView.Items.Add(QuantumName)
        Viewer.IntervalsListView.Items(Viewer.IntervalsListView.Items.Count - 1).Checked = True
        Viewer.IntervalsListView.Items(Viewer.IntervalsListView.Items.Count - 1).ForeColor = QuantControl.ColorPanel.BackColor

        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()

    End Sub

    Public Shared Function LoadPWM(ByVal FilePath As String)
        Dim FS As New IO.FileStream(FilePath, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)

        Dim CurrentString As String = ""
        Dim NewTable As New DataTable
        Dim ColArray As String()
        Dim FirstLine As Boolean = True

        While Reader.Peek > -1
            CurrentString = Reader.ReadLine
            ColArray = CurrentString.Split(Chr(9))

            If FirstLine Then
                For i = 0 To ColArray.GetUpperBound(0)
                    NewTable.Columns.Add(i)
                Next
                FirstLine = False
            End If

            NewTable.Rows.Add(ColArray)

        End While

        Dim A_index As Integer = 0
        Dim T_index As Integer = 0
        Dim G_index As Integer = 0
        Dim C_index As Integer = 0

        For i = 0 To NewTable.Rows.Count - 1
            Select Case NewTable.Rows(i).Item(0)
                Case "A"
                    A_index = i
                Case "T"
                    T_index = i
                Case "G"
                    G_index = i
                Case "C"
                    C_index = i
            End Select
        Next


        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()

        Dim NewPWM As New PWM

        For i = 1 To NewTable.Columns.Count - 1
            Dim NewPWMCell As New PWM_cell
            'Dim DecimalFormat As System.Globalization.NumberFormatInfo = System.Globalization.CultureInfo.InstalledUICulture.NumberFormat.Clone
            'DecimalFormat.NumberDecimalSeparator = "."
            'Single.Parse(Row.Item(1), DecimalFormat)
            NewPWMCell.A_Weight = NewTable.Rows(A_index).Item(i)
            NewPWMCell.T_Weight = NewTable.Rows(T_index).Item(i)
            NewPWMCell.G_Weight = NewTable.Rows(G_index).Item(i)
            NewPWMCell.C_Weight = NewTable.Rows(C_index).Item(i)

            NewPWM.PWM_Table.Add(NewPWMCell)
        Next

        Return NewPWM
    End Function

    Public Shared Sub ImportFeaturesToAnnotation(ByVal ImportFile As String, ByVal ID_col As String, ByVal Name_col As String, ByVal Start_col As String, ByVal End_col As String, ByVal Dir_col As String, ByVal Type_col As String, ByVal Descr_col As String, ByVal Orthology_col As String, ByRef Viewer As Genome_Viewer, Optional ByVal ImportIntoMainList As Boolean = True, Optional ByVal AppendImportMark As Boolean = False)

        Dim FS As New IO.FileStream(ImportFile, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(FS)
        Dim HeaderString As String() = Reader.ReadLine.Split(Chr(9))



        Dim ID_i As Integer = 0
        Dim Name_i As Integer = 0
        Dim Start_i As Integer = 0
        Dim End_i As Integer = 0
        Dim Dir_i As Integer = 0
        Dim Type_i As Integer = 0
        Dim Descr_i As Integer = 0
        Dim Ortho_i As Integer = 0

        For i = 0 To HeaderString.Count - 1
            If HeaderString(i) = ID_col Then
                ID_i = i
            End If

            If HeaderString(i) = Name_col Then
                Name_i = i
            End If

            If HeaderString(i) = Start_col Then
                Start_i = i
            End If

            If HeaderString(i) = End_col Then
                End_i = i
            End If

            If HeaderString(i) = Dir_col Then
                Dir_i = i
            End If

            If HeaderString(i) = Type_col Then
                Type_i = i
            End If

            If HeaderString(i) = Descr_col Then
                Descr_i = i
            End If

            If HeaderString(i) = Orthology_col Then
                Ortho_i = i
            End If
        Next

        Dim ImportMark As String = ""
        If AppendImportMark Then
            ImportMark = "Import#"
        End If


        Dim ImportFilePathArr As String() = ImportFile.Split("\")
        Dim AssemblyName As String = ImportFilePathArr(ImportFilePathArr.GetUpperBound(0)).Split(".")(0)

        Dim NewAssembly As New FeaturesAssembly
        NewAssembly.AssemblyName = AssemblyName
        NewAssembly.Visible = True

        Dim CurrentString As String()
        While Reader.Peek > -1
            CurrentString = Reader.ReadLine.Split(Chr(9))
            Dim NewFeature As New Genome_Feature
            NewFeature.Group = AssemblyName
            NewFeature.TAG = ImportMark & CurrentString(ID_i)
            NewFeature.Name = CurrentString(Name_i)
            NewFeature.AbsoluteStart = CurrentString(Start_i)
            NewFeature.AbsoluteEnd = CurrentString(End_i)
            NewFeature.Direction = CurrentString(Dir_i)

            If Not Descr_col = "-cancel-" Then
                NewFeature.Description = CurrentString(Descr_i)
            Else
                NewFeature.Description = ""
            End If


            Select Case Type_col
                Case "-CDS-"
                    NewFeature.Type = 1
                Case "-Structural RNA-"
                    NewFeature.Type = 2
                Case "-Regulatory site-"
                    NewFeature.Type = 3
                Case "-Non-coding RNA-"
                    NewFeature.Type = 4
                Case "-TSS-"
                    NewFeature.Type = 5
                Case "-TTS-"
                    NewFeature.Type = 6
                Case "-Operon-"
                    NewFeature.Type = 12
                Case "-User feature-"
                    NewFeature.Type = 11
                Case Else

                    NewFeature.Type = CurrentString(Type_i)

            End Select



            If Not Orthology_col = "-cancel-" Then
                NewFeature.Orthology = CurrentString(Ortho_i)
            Else
                NewFeature.Orthology = ""
            End If



            If ImportIntoMainList Then
                Viewer.Features_Groups_List(0).FeaturesList.Add(NewFeature)
            Else
                NewAssembly.FeaturesList.Add(NewFeature)
            End If

            Viewer.WriteFeatureRow(NewFeature, Viewer.FeaturesGroupDataGridView)

        End While


        If Not ImportIntoMainList Then
            Viewer.Features_Groups_List.Add(NewAssembly)
            Viewer.FeaturesGroupsListBox.Items.Add(NewAssembly.AssemblyName)
            Viewer.FeaturesGroupsListBox.Items(Viewer.FeaturesGroupsListBox.Items.Count - 1).Checked = True

        End If

        Reader.Close()
        FS.Close()
        Reader.Dispose()
        FS.Dispose()


    End Sub

    Public Shared Sub ReplaceFeatures(ByVal ImportFile As String, ByVal Old_ID_col As String, ByVal ID_col As String, ByVal Name_col As String, ByVal Start_col As String, ByVal End_col As String, ByVal Dir_col As String, ByVal Type_col As String, ByVal Descr_col As String, ByVal Orthology_col As String, ByRef Viewer As Genome_Viewer)
        Dim ReadStream As New IO.FileStream(ImportFile, IO.FileMode.Open)
        Dim Reader As New IO.StreamReader(ReadStream)

        Dim HeaderString As String() = Reader.ReadLine.Split(Chr(9))

        Dim Old_id_i As Integer = 0
        Dim ID_i As Integer = 0
        Dim Name_i As Integer = 0
        Dim Start_i As Integer = 0
        Dim End_i As Integer = 0
        Dim Dir_i As Integer = 0
        Dim Type_i As Integer = 0
        Dim Descr_i As Integer = 0
        Dim Ortho_i As Integer = 0


        For i = 0 To HeaderString.Count - 1

            If HeaderString(i) = Old_ID_col Then
                Old_id_i = i
            End If

            If HeaderString(i) = ID_col Then
                ID_i = i
            End If

            If HeaderString(i) = Name_col Then
                Name_i = i
            End If

            If HeaderString(i) = Start_col Then
                Start_i = i
            End If

            If HeaderString(i) = End_col Then
                End_i = i
            End If

            If HeaderString(i) = Dir_col Then
                Dir_i = i
            End If

            If HeaderString(i) = Type_col Then
                Type_i = i
            End If

            If HeaderString(i) = Descr_col Then
                Descr_i = i
            End If

            If HeaderString(i) = Orthology_col Then
                Ortho_i = i
            End If
        Next


        Dim CurrentString As String()
        Dim TagCounter As Integer = 0

        While Reader.Peek > -1
            CurrentString = Reader.ReadLine.Split(Chr(9))


            TagCounter = 0
            For Each Feature As Genome_Feature In Viewer.Features_Groups_List(0).FeaturesList
                If Feature.TAG = CurrentString(ID_i) Then
                    TagCounter += 1
                End If
            Next

            If TagCounter = 0 Then
                For Each Feature As Genome_Feature In Viewer.Features_Groups_List(0).FeaturesList
                    If Feature.TAG = CurrentString(Old_id_i) Then

                        If Not ID_col = "-cancel-" Then
                            Feature.TAG = CurrentString(ID_i)
                        End If

                        If Not Name_col = "-cancel-" Then
                            Feature.Name = CurrentString(Name_i)
                        End If

                        If Not Start_col = "-cancel-" Then
                            Feature.AbsoluteStart = CurrentString(Start_i)
                        End If

                        If Not End_col = "-cancel-" Then
                            Feature.AbsoluteEnd = CurrentString(End_i)
                        End If

                        If Not Dir_col = "-cancel-" Then
                            Feature.Direction = CurrentString(Dir_i)
                        End If

                        If Not Descr_col = "-cancel-" Then
                            Feature.Description = CurrentString(Descr_i)
                        End If

                        If Not Type_col = "-cancel-" Then
                            Feature.Type = CurrentString(Type_i)
                        End If

                        If Not Orthology_col = "-cancel-" Then
                            Feature.Orthology = CurrentString(Ortho_i)
                        End If

                    End If
                Next
            Else
                MsgBox(CurrentString(ID_i) & " ID already exists!")
            End If



        End While


        Reader.Close()
        ReadStream.Close()
        Reader.Dispose()
        ReadStream.Dispose()

    End Sub

    Public Shared Function RetrieveTranslatedSeqFromCache(ByVal TranslatedSequence As List(Of String), ByVal StartPos As Integer, ByVal EndPos As Integer, _
                                                          Optional ByVal FrameF1 As Boolean = True, _
                                                          Optional ByVal FrameF2 As Boolean = True, _
                                                          Optional ByVal FrameF3 As Boolean = True, _
                                                          Optional ByVal FrameR1 As Boolean = True, _
                                                          Optional ByVal FrameR2 As Boolean = True, _
                                                          Optional ByVal FrameR3 As Boolean = True)
        Dim Seq As New List(Of String)

        If StartPos > TranslatedSequence(0).Length Then
            StartPos -= TranslatedSequence(0).Length
        End If

        If EndPos > TranslatedSequence(0).Length Then
            EndPos -= TranslatedSequence(0).Length
        End If

        If StartPos < 1 Then
            StartPos += TranslatedSequence(0).Length
        End If

        If EndPos < 1 Then
            EndPos += TranslatedSequence(0).Length
        End If


        Try

            If EndPos >= StartPos Then

                For i = 0 To TranslatedSequence.Count - 1

                    If i = 0 And Not FrameF1 Then
                        Continue For
                    ElseIf i = 1 And Not FrameF2 Then
                        Continue For
                    ElseIf i = 2 And Not FrameF3 Then
                        Continue For
                    ElseIf i = 3 And Not FrameR3 Then
                        Continue For
                    ElseIf i = 4 And Not FrameR2 Then
                        Continue For
                    ElseIf i = 5 And Not FrameR1 Then
                        Continue For
                    End If

                    Seq.Add(TranslatedSequence(i).Substring(StartPos - 1, EndPos - StartPos + 1))
                Next i

            Else

                For i = 0 To TranslatedSequence.Count - 1

                    If i = 0 And Not FrameF1 Then
                        Continue For
                    ElseIf i = 1 And Not FrameF2 Then
                        Continue For
                    ElseIf i = 2 And Not FrameF3 Then
                        Continue For
                    ElseIf i = 3 And Not FrameR3 Then
                        Continue For
                    ElseIf i = 4 And Not FrameR2 Then
                        Continue For
                    ElseIf i = 5 And Not FrameR1 Then
                        Continue For
                    End If

                    Seq.Add(String.Concat(TranslatedSequence(i).Substring(StartPos - 1), TranslatedSequence(i).Substring(0, EndPos)))
                Next i

            End If

        Catch ex As Exception
            MsgBox("Seq Error")
        End Try

        Return Seq
    End Function

    Public Shared Sub SaveDataTable(ByVal DataToSave As DataTable, ByVal SaveAPI As SaveFileDialog, Optional ByVal WriteHeaders As Boolean = True)

        SaveAPI.DefaultExt = "txt"

        If SaveAPI.ShowDialog = DialogResult.OK Then
            Dim FS As New IO.FileStream(SaveAPI.FileName, IO.FileMode.Create)
            Dim Writer As New IO.StreamWriter(FS)
            Dim Line As String = ""

            If WriteHeaders Then
                For Each Col As DataColumn In DataToSave.Columns
                    Line &= Col.ColumnName & Chr(9)
                Next
                Writer.WriteLine(Line)
            End If

            For Each Row As DataRow In DataToSave.Rows
                Line = ""
                For i = 0 To DataToSave.Columns.Count - 1
                    Line &= Row.Item(i) & Chr(9)
                Next i
                Writer.WriteLine(Line)

            Next Row


            Writer.Close()
            FS.Close()
            Writer.Dispose()
            FS.Dispose()

        End If

        SaveAPI.DefaultExt = ""

    End Sub

    Public Shared Sub SavePileup(ByVal Pileup As List(Of Integer), ByVal SaveAPI As SaveFileDialog)
        If SaveAPI.ShowDialog = DialogResult.OK Then
            Dim FS As New IO.FileStream(SaveAPI.FileName, IO.FileMode.Create)
            Dim Writer As New IO.StreamWriter(FS)

            For Each Val As Integer In Pileup
                Writer.WriteLine(Val)
            Next

            Writer.Close()
            FS.Close()
            Writer.Dispose()
            FS.Dispose()

        End If

    End Sub

#Region "Browser functions"

    Public Shared Sub LaunchBrowser(ByVal URL As String)

        Dim p As New System.Diagnostics.Process
        Try
            p = New Diagnostics.Process
            p.StartInfo.FileName() = URL
            p.StartInfo.UseShellExecute = True
            p.StartInfo.CreateNoWindow = False
            p.StartInfo.RedirectStandardInput = False
            p.StartInfo.RedirectStandardOutput = False
            p.StartInfo.RedirectStandardError = False
            p.Start()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try


    End Sub

#End Region

End Class
