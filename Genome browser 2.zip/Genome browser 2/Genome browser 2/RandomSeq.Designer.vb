﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RandomSeq
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RandomSeq))
        Me.SeqTextBox = New System.Windows.Forms.TextBox
        Me.LengthTextBox = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.GCTextBox = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.ATextBox = New System.Windows.Forms.TextBox
        Me.GTextBox = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.CTextBox = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.TTextBox = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.OKButton = New System.Windows.Forms.Button
        Me.Label7 = New System.Windows.Forms.Label
        Me.ActualGCTextBox = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'SeqTextBox
        '
        Me.SeqTextBox.Location = New System.Drawing.Point(12, 12)
        Me.SeqTextBox.Multiline = True
        Me.SeqTextBox.Name = "SeqTextBox"
        Me.SeqTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.SeqTextBox.Size = New System.Drawing.Size(378, 82)
        Me.SeqTextBox.TabIndex = 0
        '
        'LengthTextBox
        '
        Me.LengthTextBox.Location = New System.Drawing.Point(61, 100)
        Me.LengthTextBox.Name = "LengthTextBox"
        Me.LengthTextBox.Size = New System.Drawing.Size(50, 20)
        Me.LengthTextBox.TabIndex = 1
        Me.LengthTextBox.Text = "25"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 103)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Length:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(126, 103)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(33, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "%GC:"
        '
        'GCTextBox
        '
        Me.GCTextBox.Location = New System.Drawing.Point(165, 100)
        Me.GCTextBox.Name = "GCTextBox"
        Me.GCTextBox.Size = New System.Drawing.Size(50, 20)
        Me.GCTextBox.TabIndex = 5
        Me.GCTextBox.Text = "50"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(38, 140)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(17, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "A:"
        '
        'ATextBox
        '
        Me.ATextBox.Location = New System.Drawing.Point(61, 137)
        Me.ATextBox.Name = "ATextBox"
        Me.ATextBox.ReadOnly = True
        Me.ATextBox.Size = New System.Drawing.Size(50, 20)
        Me.ATextBox.TabIndex = 7
        '
        'GTextBox
        '
        Me.GTextBox.Location = New System.Drawing.Point(61, 163)
        Me.GTextBox.Name = "GTextBox"
        Me.GTextBox.ReadOnly = True
        Me.GTextBox.Size = New System.Drawing.Size(50, 20)
        Me.GTextBox.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(37, 166)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(18, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "G:"
        '
        'CTextBox
        '
        Me.CTextBox.Location = New System.Drawing.Point(165, 163)
        Me.CTextBox.Name = "CTextBox"
        Me.CTextBox.ReadOnly = True
        Me.CTextBox.Size = New System.Drawing.Size(50, 20)
        Me.CTextBox.TabIndex = 13
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(142, 166)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(17, 13)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "C:"
        '
        'TTextBox
        '
        Me.TTextBox.Location = New System.Drawing.Point(165, 137)
        Me.TTextBox.Name = "TTextBox"
        Me.TTextBox.ReadOnly = True
        Me.TTextBox.Size = New System.Drawing.Size(50, 20)
        Me.TTextBox.TabIndex = 11
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(142, 140)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(17, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "T:"
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(315, 160)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.Size = New System.Drawing.Size(75, 23)
        Me.OKButton.TabIndex = 14
        Me.OKButton.Text = "Generate"
        Me.OKButton.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(221, 103)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(66, 13)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Actual %GC:"
        '
        'ActualGCTextBox
        '
        Me.ActualGCTextBox.Location = New System.Drawing.Point(293, 100)
        Me.ActualGCTextBox.Name = "ActualGCTextBox"
        Me.ActualGCTextBox.ReadOnly = True
        Me.ActualGCTextBox.Size = New System.Drawing.Size(50, 20)
        Me.ActualGCTextBox.TabIndex = 17
        '
        'RandomSeq
        '
        Me.AcceptButton = Me.OKButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(403, 199)
        Me.Controls.Add(Me.ActualGCTextBox)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.OKButton)
        Me.Controls.Add(Me.CTextBox)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TTextBox)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.GTextBox)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.ATextBox)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.GCTextBox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.LengthTextBox)
        Me.Controls.Add(Me.SeqTextBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "RandomSeq"
        Me.Text = "Random sequence"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SeqTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LengthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ATextBox As System.Windows.Forms.TextBox
    Friend WithEvents GTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents CTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents OKButton As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents ActualGCTextBox As System.Windows.Forms.TextBox
End Class
