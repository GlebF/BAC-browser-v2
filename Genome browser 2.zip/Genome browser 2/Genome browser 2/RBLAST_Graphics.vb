﻿Public Class RBLAST_Graphics
    Private MyResult As RBLAST_Result = Nothing
    Private MyQuery As String = ""
    Private AlignedIdentity As Single
    Private TotalIdentity As Single
    Private ReverseDirection As Boolean
    Private intCounter As Integer
    Private TargetViewer As Genome_Viewer

    Public Property Result_Data() As RBLAST_Result
        Get
            Result_Data = MyResult
        End Get
        Set(ByVal value As RBLAST_Result)
            MyResult = value
        End Set
    End Property

    Public Property Query_String() As String
        Get
            Query_String = MyQuery
        End Get
        Set(ByVal value As String)
            MyQuery = value
        End Set
    End Property

    Public Property Reverse_Direction() As Boolean
        Get
            Reverse_Direction = ReverseDirection
        End Get
        Set(ByVal value As Boolean)
            ReverseDirection = value
        End Set
    End Property

    Public ReadOnly Property Aligned_Identity() As Single
        Get
            Aligned_Identity = AlignedIdentity
        End Get
    End Property

    Public ReadOnly Property Total_Identity() As Single
        Get
            Total_Identity = TotalIdentity
        End Get
    End Property

    Public Sub New(ByVal Result_Data As RBLAST_Result, ByVal Query_String As String, ByVal Reverse_Direction As Boolean, ByVal Counter As Integer, ByVal Target_Viewer As Genome_Viewer)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        MyResult = Result_Data
        MyQuery = Query_String
        ReverseDirection = Reverse_Direction
        intCounter = Counter
        TargetViewer = Target_Viewer

        MyResult.Direction = Reverse_Direction
        AlignedIdentity = Math.Round((MyResult.IdentityNumber / MyResult.MatchString.Length) * 100, 2)
        TotalIdentity = Math.Round((MyResult.IdentityNumber / MyQuery.Length) * 100, 2)


    End Sub

    Public Sub CreateText()
        Dim DirStr As String = ""
        Dim FormattedAlignment As String = ""

        If ReverseDirection Then
            DirStr = "minus"
        Else
            DirStr = "plus"
        End If


        Dim DelCounter As Integer = 0
        For i = 0 To MyResult.QuerySequence.Count - 1
            If MyResult.QuerySequence(i) = "-" Then
                DelCounter += 1
            End If
        Next i
        Dim InsCounter As Integer = 0
        For i = 0 To MyResult.SubjectSequence.Count - 1
            If MyResult.SubjectSequence(i) = "-" Then
                InsCounter += 1
            End If
        Next i



        ResultTextBox.Text &= "Alingment_" & intCounter
        ResultTextBox.Text &= Environment.NewLine
        ResultTextBox.Text &= "Total hits: " & MyResult.IdentityNumber & "/" & MyQuery.Length & "; Total coverage=" & TotalIdentity & "%"
        ResultTextBox.Text &= Environment.NewLine
        ResultTextBox.Text &= "Aligned hits: " & MyResult.IdentityNumber & "/" & MyResult.MatchString.Length & "; Identity=" & AlignedIdentity & "%; Deletions=" & DelCounter & "; Insertions=" & InsCounter & "; Mismatches=" & MyResult.MatchString.Length - MyResult.IdentityNumber - InsCounter - DelCounter
        ResultTextBox.Text &= Environment.NewLine
        ResultTextBox.Text &= "Direction=" & DirStr
        ResultTextBox.Text &= Environment.NewLine
        ResultTextBox.Text &= "Reference position: Start=" & MyResult.SubjectStartPos & ", End=" & MyResult.SubjectEndPos
        ResultTextBox.Text &= Environment.NewLine
        ResultTextBox.Text &= "Query position: Start=" & MyResult.QueryStartPos & ", End=" & MyResult.QueryEndPos
        ResultTextBox.Text &= Environment.NewLine
        ResultTextBox.Text &= Environment.NewLine

        If ReverseDirection Then
            FormattedAlignment = Bioinformatics.FormatAlignment(MyResult, ReverseDirection)
            ResultTextBox.Text &= FormattedAlignment
        Else
            FormattedAlignment = Bioinformatics.FormatAlignment(MyResult, ReverseDirection)
            ResultTextBox.Text &= FormattedAlignment
        End If


    End Sub

    Private Sub ViewButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewButton.Click
        Dim F_tag As String = "RBLAST_" & intCounter
        Dim F_name As String = "RBLAST_" & intCounter
        Dim F_Start As Integer = MyResult.SubjectStartPos + 1
        Dim F_End As Integer = MyResult.SubjectEndPos
        Dim F_Dir As Short = 0
        Dim F_identity As Single = 0
        Dim F_type As Short = 11
        Dim DirStr As String = ""

        If ReverseDirection Then
            F_Dir = 2
        Else
            F_Dir = 1
        End If



        If ReverseDirection Then
            DirStr = "Minus"
        Else
            DirStr = "Plus"
        End If

        Dim Found As Boolean = False
        For Each Feature As Genome_Feature In TargetViewer.Features_Groups_List(1).FeaturesList
            If Feature.AbsoluteStart = F_Start And Feature.AbsoluteEnd = F_End And Feature.Direction = F_Dir Then
                Found = True
            End If
        Next

        If Not Found Then
            TargetViewer.AddUserFeature(F_tag, F_name, "RBLAST result", F_Start, F_End, F_Dir, "none", F_type, "", F_identity)
        End If

        TargetViewer.RangeStart = F_Start
        TargetViewer.RangeEnd = F_End
        TargetViewer.DisplayFeatures()

    End Sub

End Class
