﻿Public Class VirtualGenome
    Private cMyParent As Genome_Viewer = Nothing
    Private GridOn As Boolean = True
    Private Features_Table As New List(Of FeatureInfo)
    Private intGenomeLength As Integer
    Private bFullView As Boolean = False
    Private StartAngleParam As Integer = -90 'Set zero coordinate point to the upper point of the circle
    Private FeatureSimpleWidth As Integer = 6
    Private FeatureFullWidth As Integer = 16
    Private FeatureFullArrangeOffset As Integer = 5

    Private bShowRestrictases As Boolean = False
    Private SearchSeqList As New DataTable
    Private RestrictionList As New List(Of CoordHit)

    Public Property MyParent() As Genome_Viewer
        Get
            MyParent = cMyParent
        End Get
        Set(ByVal value As Genome_Viewer)
            cMyParent = value
        End Set
    End Property

    Public Property Genome_Length() As Integer
        Get
            Genome_Length = intGenomeLength
        End Get
        Set(ByVal value As Integer)
            intGenomeLength = value
        End Set
    End Property

    Public Sub New(ByVal GenomeLength As Integer)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        intGenomeLength = GenomeLength

    End Sub

#Region "Graphics"

    Private Sub ViewPanel_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles ViewPanel.Paint
        'Deg to Rad:  Rad=Deg*Pi/180

        Try
            DrawImage(e.Graphics)

        Catch ex As Exception
            MsgBox("Error drawing genome view!")
        End Try


    End Sub

    Private Sub DrawImage(ByVal g As Graphics, Optional ByVal ExportK As Single = 1)

        'Try

        Dim R As Integer = (ViewPanel.Width / 5) * ExportK
        Dim R_Default As Integer = (ViewPanel.Width / 5 + 6) * ExportK
        MinOverlapAngleTextBox.Text = 0.1
        Dim Angle_Div_Lim As Single = MinOverlapAngleTextBox.Text '0.1

        Dim Circle_Pen As New Pen(Color.Black, 6 * ExportK)
        Dim Feature_Pen As New Pen(Color.Black, FeatureSimpleWidth * ExportK)
        Dim Feature_Brush As New SolidBrush(Color.Red)
        Dim PointerPen As New Pen(Color.Black, ExportK)

        Dim MyFont As New Font(Me.Font.Name, CType(TextSizeComboBox.Text, Integer) * ExportK, FontStyle.Regular)
        Dim AxisFont As New Font(Me.Font.Name, CType(AxisComboBox.Text, Integer) * ExportK, FontStyle.Regular)

        Dim FullViewArrangeIterator As Integer = 3


        Dim MidPoint As New Point((ViewPanel.Width / 2) * ExportK, (ViewPanel.Height / 2) * ExportK)

        'Load information about features from the data grid view
        LoadFeaturesFromDataTable(R_Default)



        'Draw scaffold
        g.DrawEllipse(Circle_Pen, MidPoint.X - R, MidPoint.Y - R, R * 2, R * 2)


        If GridOn Then
            'Draw Grid
            DrawGrid(g, MidPoint, R, StartAngleParam, AxisFont)
        End If



        If bFullView Then

            DrawFullView(g, MidPoint, StartAngleParam, FeatureFullWidth * ExportK, FeatureFullArrangeOffset * ExportK, Feature_Brush, PointerPen, MyFont, Angle_Div_Lim, FullViewArrangeIterator, 20 * ExportK, , , ExportK)

            If bShowRestrictases Then

                Dim PrevHitAngle As Single = -10
                Dim PointerR As Integer = R * 1.5

                Dim PointerShiftDefault_X As Integer = ExportK
                Dim PointerShiftDefault_Y As Integer = ExportK
                Dim PointerShift_X As Integer = PointerShiftDefault_X
                Dim PointerShift_Y As Integer = PointerShiftDefault_Y

                For Each Hit As CoordHit In RestrictionList

                    Dim StringSize As SizeF = g.MeasureString(Hit.Label, MyFont)


                    Dim RefAngle As Single = Hit.Position / intGenomeLength * 360
                    Dim PointerAngle As Single = RefAngle + StartAngleParam


                    If RefAngle - PrevHitAngle < 5 Then
                        PointerShift_X += StringSize.Width
                        PointerShift_Y += StringSize.Height
                    Else
                        PointerShift_X = PointerShiftDefault_X
                        PointerShift_Y = PointerShiftDefault_Y
                    End If



                    Dim HitPointerStart As New Point(MidPoint.X + R * Math.Cos((PointerAngle) / 180 * Math.PI), _
                                                     MidPoint.Y + R * Math.Sin((PointerAngle) / 180 * Math.PI))

                    Dim HitPointerEnd As New Point(MidPoint.X + PointerR * Math.Cos((PointerAngle) / 180 * Math.PI), _
                                                     MidPoint.Y + PointerR * Math.Sin((PointerAngle) / 180 * Math.PI))

                    g.DrawLine(PointerPen, HitPointerStart, HitPointerEnd)


                    If RefAngle >= 270 Or RefAngle <= 90 Then
                        'Top side

                        If RefAngle >= 0 And RefAngle <= 180 Then
                            'Right side
                            Dim LabelPoint As New Point(HitPointerEnd.X + PointerShift_X, HitPointerEnd.Y)
                            g.DrawLine(PointerPen, HitPointerEnd, LabelPoint)
                            g.DrawString(Hit.Label, MyFont, Brushes.Black, LabelPoint.X, LabelPoint.Y - StringSize.Height)
                        Else
                            'Top Left side
                            Dim LabelPoint As New Point(HitPointerEnd.X, HitPointerEnd.Y - PointerShift_Y)
                            g.DrawLine(PointerPen, HitPointerEnd, LabelPoint)
                            g.DrawString(Hit.Label, MyFont, Brushes.Black, LabelPoint.X - StringSize.Width, LabelPoint.Y - StringSize.Height)
                        End If

                    Else
                        'Bottom side

                        If RefAngle >= 0 And RefAngle <= 180 Then
                            'Bottom Right side
                            Dim LabelPoint As New Point(HitPointerEnd.X, HitPointerEnd.Y + PointerShift_Y)
                            g.DrawLine(PointerPen, HitPointerEnd, LabelPoint)
                            g.DrawString(Hit.Label, MyFont, Brushes.Black, LabelPoint.X, LabelPoint.Y)
                        Else
                            'Left side
                            Dim LabelPoint As New Point(HitPointerEnd.X - PointerShift_X, HitPointerEnd.Y)
                            g.DrawLine(PointerPen, HitPointerEnd, LabelPoint)
                            g.DrawString(Hit.Label, MyFont, Brushes.Black, LabelPoint.X - StringSize.Width, LabelPoint.Y)
                        End If

                    End If

                    PrevHitAngle = RefAngle
                Next Hit
            End If

        Else 'Simple view

            DrawSimpleView(g, MidPoint, StartAngleParam, Feature_Pen, PointerPen, MyFont, Angle_Div_Lim, )

        End If 'bFullView


        'Catch ex As Exception
        'MsgBox("Error at map drawing!" & vbNewLine & ex.Message)
        'End Try
    End Sub

    Private Sub DrawGrid(ByVal g As Graphics, ByVal MidPoint As Point, ByVal R As Integer, ByVal StartAngleParam As Integer, ByVal MyFont As Font)
        Dim MarkPen As New Pen(Color.Black, 2)
        Dim MarkAngle As Integer = 0
        Dim MarkString As String = ""
        Dim Mark_Curr As String = ""
        Dim Mark_Base As Single = 0
        Dim Mark_Val As Single = 0
        Dim Mark_X As Integer = 0
        Dim Mark_Y As Integer = 0

        If intGenomeLength < 100000 Then
            Mark_Base = intGenomeLength / 1000
            Mark_Curr = "Kb"
        Else
            Mark_Base = intGenomeLength / 1000000
            Mark_Curr = "Mb"
        End If


        For i = 0 To 9
            MarkAngle += 36

            Dim TargetMarkPoint As New Point(MidPoint.X + (R + 10) * Math.Cos((MarkAngle + StartAngleParam) * Math.PI / 180), MidPoint.Y + (R + 10) * Math.Sin((MarkAngle + StartAngleParam) * Math.PI / 180))
            Dim InitMarkPoint As New Point(MidPoint.X + (R - 10) * Math.Cos((MarkAngle + StartAngleParam) * Math.PI / 180), MidPoint.Y + (R - 10) * Math.Sin((MarkAngle + StartAngleParam) * Math.PI / 180))
            g.DrawLine(MarkPen, TargetMarkPoint, InitMarkPoint)

            Mark_Val = Math.Round((i + 1) * Mark_Base / 10, 2)


            MarkString = String.Concat(Mark_Val, Mark_Curr)
            If MarkAngle >= 0 And MarkAngle <= 180 Then
                Mark_X = InitMarkPoint.X - g.MeasureString(MarkString, MyFont).Width

            Else
                Mark_X = InitMarkPoint.X

            End If

            If MarkAngle >= 90 And MarkAngle <= 270 Then
                Mark_Y = InitMarkPoint.Y - g.MeasureString(MarkString, MyFont).Height
            Else
                Mark_Y = InitMarkPoint.Y
            End If

            g.DrawString(MarkString, MyFont, Brushes.Black, Mark_X, Mark_Y)

        Next i

    End Sub

    Private Sub DrawLocusPlus(ByVal g As Graphics, _
                              ByVal MidPoint As Point, _
                              ByVal UpRadius As Integer, _
                              ByVal MidRadius As Integer, _
                              ByVal DnRadius As Integer, _
                              ByVal DrawStartAngle As Single, _
                              ByVal Rot_Angle As Single, _
                              ByVal DirRotParam As Integer, _
                              ByVal ArcUpX As Integer, _
                              ByVal ArcUpY As Integer, _
                              ByVal ArcUpWidth As Integer, _
                              ByVal ArcUpHeight As Integer, _
                              ByVal ArcDnX As Integer, _
                              ByVal ArcDnY As Integer, _
                              ByVal ArcDnWidth As Integer, _
                              ByVal ArcDnHeight As Integer, _
                              ByVal Feature_Brush As SolidBrush, _
                              ByVal PointerPen As Pen)

        Dim DrawPath As New Drawing2D.GraphicsPath
        Dim DirRotAngle As Single = Rot_Angle - DirRotParam
        If DirRotAngle < 0.1 Then
            DirRotAngle = 0.1
        End If

        Dim EndPoint As New Point(MidPoint.X + MidRadius * Math.Cos((DrawStartAngle + Rot_Angle) / 180 * Math.PI), _
                                  MidPoint.Y + MidRadius * Math.Sin((DrawStartAngle + Rot_Angle) / 180 * Math.PI))

        Dim PlusUpPoint As New Point(MidPoint.X + UpRadius * Math.Cos((DrawStartAngle + Rot_Angle - DirRotParam) / 180 * Math.PI), _
                                     MidPoint.Y + UpRadius * Math.Sin((DrawStartAngle + Rot_Angle - DirRotParam) / 180 * Math.PI))

        Dim PlusDnPoint As New Point(MidPoint.X + DnRadius * Math.Cos((DrawStartAngle + Rot_Angle - DirRotParam) / 180 * Math.PI), _
                                     MidPoint.Y + DnRadius * Math.Sin((DrawStartAngle + Rot_Angle - DirRotParam) / 180 * Math.PI))

        Dim StartUpPoint As New Point(MidPoint.X + UpRadius * Math.Cos(DrawStartAngle / 180 * Math.PI), _
                                      MidPoint.Y + UpRadius * Math.Sin(DrawStartAngle / 180 * Math.PI))

        Dim StartDnPoint As New Point(MidPoint.X + DnRadius * Math.Cos(DrawStartAngle / 180 * Math.PI), _
                                      MidPoint.Y + DnRadius * Math.Sin(DrawStartAngle / 180 * Math.PI))


        DrawPath.AddArc(ArcUpX, ArcUpY, ArcUpWidth, ArcUpHeight, DrawStartAngle, DirRotAngle)
        DrawPath.AddLine(PlusUpPoint, EndPoint)
        DrawPath.AddLine(EndPoint, PlusDnPoint)
        DrawPath.AddArc(ArcDnX, ArcDnY, ArcDnWidth, ArcDnHeight, DrawStartAngle + DirRotAngle, -DirRotAngle)
        DrawPath.AddLine(StartDnPoint, StartUpPoint)

        g.FillPath(Feature_Brush, DrawPath)
        g.DrawPath(PointerPen, DrawPath)
    End Sub

    Private Sub DrawLocusMinus(ByVal g As Graphics, _
                          ByVal MidPoint As Point, _
                          ByVal UpRadius As Integer, _
                          ByVal MidRadius As Integer, _
                          ByVal DnRadius As Integer, _
                          ByVal DrawStartAngle As Single, _
                          ByVal Rot_Angle As Single, _
                          ByVal DirRotParam As Integer, _
                          ByVal ArcUpX As Integer, _
                          ByVal ArcUpY As Integer, _
                          ByVal ArcUpWidth As Integer, _
                          ByVal ArcUpHeight As Integer, _
                          ByVal ArcDnX As Integer, _
                          ByVal ArcDnY As Integer, _
                          ByVal ArcDnWidth As Integer, _
                          ByVal ArcDnHeight As Integer, _
                          ByVal Feature_Brush As SolidBrush, _
                          ByVal PointerPen As Pen)

        Dim DrawPath As New Drawing2D.GraphicsPath
        Dim DirArcStartAngle As Single = DrawStartAngle + DirRotParam
        Dim DirRotAngle As Single = Rot_Angle - DirRotParam
        If DirRotAngle < 0.1 Then
            DirRotAngle = 0.1
        End If

        Dim StartPoint As New Point(MidPoint.X + MidRadius * Math.Cos(DrawStartAngle / 180 * Math.PI), _
                                    MidPoint.Y + MidRadius * Math.Sin(DrawStartAngle / 180 * Math.PI))

        Dim MinusUpPoint As New Point(MidPoint.X + UpRadius * Math.Cos((DrawStartAngle + DirRotParam) / 180 * Math.PI), _
                                      MidPoint.Y + UpRadius * Math.Sin((DrawStartAngle + DirRotParam) / 180 * Math.PI))

        Dim MinusDnPoint As New Point(MidPoint.X + DnRadius * Math.Cos((DrawStartAngle + DirRotParam) / 180 * Math.PI), _
                                      MidPoint.Y + DnRadius * Math.Sin((DrawStartAngle + DirRotParam) / 180 * Math.PI))

        Dim EndUpPoint As New Point(MidPoint.X + UpRadius * Math.Cos((DrawStartAngle + Rot_Angle) / 180 * Math.PI), _
                                    MidPoint.Y + UpRadius * Math.Sin((DrawStartAngle + Rot_Angle) / 180 * Math.PI))

        Dim EndDnPoint As New Point(MidPoint.X + DnRadius * Math.Cos((DrawStartAngle + Rot_Angle) / 180 * Math.PI), _
                                    MidPoint.Y + DnRadius * Math.Sin((DrawStartAngle + Rot_Angle) / 180 * Math.PI))

        DrawPath.AddArc(ArcUpX, ArcUpY, ArcUpWidth, ArcUpHeight, DirArcStartAngle, DirRotAngle)
        DrawPath.AddLine(EndUpPoint, EndDnPoint)
        DrawPath.AddArc(ArcDnX, ArcDnY, ArcDnWidth, ArcDnHeight, DirArcStartAngle + DirRotAngle, -DirRotAngle)
        DrawPath.AddLine(MinusDnPoint, StartPoint)
        DrawPath.AddLine(StartPoint, MinusUpPoint)

        g.FillPath(Feature_Brush, DrawPath)
        g.DrawPath(PointerPen, DrawPath)

    End Sub

    Private Sub DrawLocusUndefined(ByVal g As Graphics, ByVal MidPoint As Point, ByVal UpRadius As Integer, _
                              ByVal MidRadius As Integer, _
                              ByVal DnRadius As Integer, _
                              ByVal DrawStartAngle As Single, _
                              ByVal Rot_Angle As Single, _
                              ByVal ArcUpX As Integer, _
                              ByVal ArcUpY As Integer, _
                              ByVal ArcUpWidth As Integer, _
                              ByVal ArcUpHeight As Integer, _
                              ByVal ArcDnX As Integer, _
                              ByVal ArcDnY As Integer, _
                              ByVal ArcDnWidth As Integer, _
                              ByVal ArcDnHeight As Integer, _
                              ByVal Feature_Brush As SolidBrush, _
                              ByVal PointerPen As Pen)

        Dim DrawPath As New Drawing2D.GraphicsPath

        Dim StartUpPoint As New Point(MidPoint.X + UpRadius * Math.Cos(DrawStartAngle / 180 * Math.PI), _
                                              MidPoint.Y + UpRadius * Math.Sin(DrawStartAngle / 180 * Math.PI))

        Dim StartDnPoint As New Point(MidPoint.X + DnRadius * Math.Cos(DrawStartAngle / 180 * Math.PI), _
                                      MidPoint.Y + DnRadius * Math.Sin(DrawStartAngle / 180 * Math.PI))

        Dim EndUpPoint As New Point(MidPoint.X + UpRadius * Math.Cos((DrawStartAngle + Rot_Angle) / 180 * Math.PI), _
                                    MidPoint.Y + UpRadius * Math.Sin((DrawStartAngle + Rot_Angle) / 180 * Math.PI))

        Dim EndDnPoint As New Point(MidPoint.X + DnRadius * Math.Cos((DrawStartAngle + Rot_Angle) / 180 * Math.PI), _
                                    MidPoint.Y + DnRadius * Math.Sin((DrawStartAngle + Rot_Angle) / 180 * Math.PI))

        DrawPath.AddArc(ArcUpX, ArcUpY, ArcUpWidth, ArcUpHeight, DrawStartAngle, Rot_Angle)
        DrawPath.AddLine(EndUpPoint, EndDnPoint)
        DrawPath.AddArc(ArcDnX, ArcDnY, ArcDnWidth, ArcDnHeight, DrawStartAngle + Rot_Angle, -Rot_Angle)
        DrawPath.AddLine(StartDnPoint, StartUpPoint)

        g.FillPath(Feature_Brush, DrawPath)
        g.DrawPath(PointerPen, DrawPath)

    End Sub

    Private Sub DrawTSS(ByVal g As Graphics, _
                        ByVal TSS_Dir As Short, _
                        ByVal MidPoint As Point, _
                        ByVal UpRadius As Integer, _
                        ByVal DnRadius As Integer, _
                        ByVal DrawStartAngle As Single, _
                        ByVal DrawEndAngle As Single, _
                        ByVal FeatureArrangeOffset As Integer, _
                        ByVal PointerPen As Pen, _
                        ByVal TSS_Arrow_Length As Integer, _
                        ByVal TSS_Arrow_Width As Integer)

        Dim TSS_Radius As Integer = UpRadius + FeatureArrangeOffset

        Dim TSS_Pen As New Pen(PointerPen.Color)
        TSS_Pen.Width = PointerPen.Width * TSS_Arrow_Width

        Dim ArrowPen As New Pen(PointerPen.Color)
        ArrowPen.Width = PointerPen.Width * TSS_Arrow_Width


        Dim TSSArrowPath As New Drawing2D.GraphicsPath
        TSSArrowPath.AddLine(0, 0, 1, -3)
        TSSArrowPath.AddLine(0, 0, -1, -3)
        Dim TSSArrow As New Drawing2D.CustomLineCap(Nothing, TSSArrowPath)
        ArrowPen.CustomEndCap = TSSArrow


        If TSS_Dir = 1 Then
            Dim DnPoint As New Point(MidPoint.X + DnRadius * Math.Cos((DrawStartAngle) / 180 * Math.PI), _
                                     MidPoint.Y + DnRadius * Math.Sin((DrawStartAngle) / 180 * Math.PI))

            Dim UpPoint As New Point(MidPoint.X + TSS_Radius * Math.Cos((DrawStartAngle) / 180 * Math.PI), _
                                     MidPoint.Y + TSS_Radius * Math.Sin((DrawStartAngle) / 180 * Math.PI))

            Dim ArrowPoint As New Point(MidPoint.X + TSS_Radius * Math.Cos((DrawStartAngle + TSS_Arrow_Length) / 180 * Math.PI), _
                                        MidPoint.Y + TSS_Radius * Math.Sin((DrawStartAngle + TSS_Arrow_Length) / 180 * Math.PI))

            g.DrawLine(TSS_Pen, DnPoint, UpPoint)
            g.DrawLine(ArrowPen, UpPoint, ArrowPoint)

        ElseIf TSS_Dir = 2 Then

            Dim DnPoint As New Point(MidPoint.X + DnRadius * Math.Cos((DrawEndAngle) / 180 * Math.PI), _
                                     MidPoint.Y + DnRadius * Math.Sin((DrawEndAngle) / 180 * Math.PI))

            Dim UpPoint As New Point(MidPoint.X + UpRadius * Math.Cos((DrawEndAngle) / 180 * Math.PI), _
                                     MidPoint.Y + UpRadius * Math.Sin((DrawEndAngle) / 180 * Math.PI))

            Dim ArrowPoint As New Point(MidPoint.X + UpRadius * Math.Cos((DrawEndAngle - TSS_Arrow_Length) / 180 * Math.PI), _
                                        MidPoint.Y + UpRadius * Math.Sin((DrawEndAngle - TSS_Arrow_Length) / 180 * Math.PI))

            g.DrawLine(TSS_Pen, DnPoint, UpPoint)
            g.DrawLine(ArrowPen, UpPoint, ArrowPoint)


        End If
    End Sub

    Private Sub DrawTT(ByVal g As Graphics, _
                        ByVal TT_Dir As Short, _
                        ByVal MidPoint As Point, _
                        ByVal UpRadius As Integer, _
                        ByVal DnRadius As Integer, _
                        ByVal DrawStartAngle As Single, _
                        ByVal DrawEndAngle As Single, _
                        ByVal FeatureWidth As Integer, _
                        ByVal PointerPen As Pen, _
                        ByVal TSS_Arrow_Width As Integer)

        Dim TT_Width As Integer = FeatureWidth / 4
        Dim CircRadius As Single = UpRadius + TT_Width

        Dim TT_Pen As New Pen(PointerPen.Color)
        TT_Pen.Width = PointerPen.Width * TSS_Arrow_Width

        If TT_Dir = 1 Then

            Dim DnPoint As New Point(MidPoint.X + DnRadius * Math.Cos((DrawStartAngle) / 180 * Math.PI), _
                                     MidPoint.Y + DnRadius * Math.Sin((DrawStartAngle) / 180 * Math.PI))

            Dim UpPoint As New Point(MidPoint.X + UpRadius * Math.Cos((DrawStartAngle) / 180 * Math.PI), _
                                     MidPoint.Y + UpRadius * Math.Sin((DrawStartAngle) / 180 * Math.PI))

            Dim CircPoint As New Point(MidPoint.X + CircRadius * Math.Cos((DrawStartAngle) / 180 * Math.PI), _
                                    MidPoint.Y + CircRadius * Math.Sin((DrawStartAngle) / 180 * Math.PI))

            g.DrawLine(TT_Pen, DnPoint, UpPoint)
            g.DrawEllipse(TT_Pen, CircPoint.X - TT_Width, CircPoint.Y - TT_Width, TT_Width * 2, TT_Width * 2)


        ElseIf TT_Dir = 2 Then

            Dim DnPoint As New Point(MidPoint.X + DnRadius * Math.Cos((DrawEndAngle) / 180 * Math.PI), _
                                     MidPoint.Y + DnRadius * Math.Sin((DrawEndAngle) / 180 * Math.PI))

            Dim UpPoint As New Point(MidPoint.X + UpRadius * Math.Cos((DrawEndAngle) / 180 * Math.PI), _
                                     MidPoint.Y + UpRadius * Math.Sin((DrawEndAngle) / 180 * Math.PI))

            Dim CircPoint As New Point(MidPoint.X + CircRadius * Math.Cos((DrawEndAngle) / 180 * Math.PI), _
                                     MidPoint.Y + CircRadius * Math.Sin((DrawEndAngle) / 180 * Math.PI))

            g.DrawLine(TT_Pen, DnPoint, UpPoint)
            g.DrawEllipse(TT_Pen, CircPoint.X - TT_Width, CircPoint.Y - TT_Width, TT_Width * 2, TT_Width * 2)

        End If

    End Sub

    Private Sub DrawFullView(ByVal g As Graphics, ByVal MidPoint As Point, _
                             ByVal StartAngleParam As Integer, _
                             ByVal FeatureWidth As Integer, _
                             ByVal FeatureArrangeOffset As Integer, _
                             ByVal Feature_Brush As SolidBrush, _
                             ByVal PointerPen As Pen, _
                             ByVal MyFont As Font, _
                             Optional ByVal Angle_Div_Lim As Integer = 5, _
                             Optional ByVal Y_ArrangeSteps As Integer = 6, _
                             Optional ByVal LabelPointerOffset As Integer = 20, _
                             Optional ByVal TSS_Arrow_Length As Integer = 5, _
                             Optional ByVal TSS_Arrow_Width As Integer = 3, Optional ByVal PointerShift As Integer = 1)


        Dim Rot_Angle As Single = 0

        Dim EndAnglePrev As Single = 0
        Dim Pointer_Iteration_Counter As Integer = 0

        Dim LabelText As String = ""
        Dim StringSize As SizeF = Nothing

        Dim PointerShift_X As Integer = PointerShift
        Dim PointerShift_Y As Integer = PointerShift
        Dim PrevMidAngle As Single = -10
        Dim PrevTextSize As SizeF = New Size(0, 0)

        For Each DataFeature As FeatureInfo In Features_Table

            Rot_Angle = DataFeature.EndAngle - DataFeature.StartAngle


            'Arrange layout for feature not to overlap with the previous
            If DataFeature.StartAngle - EndAnglePrev < Angle_Div_Lim Then
                If Pointer_Iteration_Counter < Y_ArrangeSteps Then
                    Pointer_Iteration_Counter += 1
                    DataFeature.Radius += (FeatureWidth + FeatureArrangeOffset) * Pointer_Iteration_Counter
                Else
                    Pointer_Iteration_Counter = 0
                End If
            Else
                Pointer_Iteration_Counter = 0
            End If

            Feature_Brush.Color = DataFeature.FillColor

            Dim DrawPath As New Drawing2D.GraphicsPath

            Dim DirRotParam As Integer = 5 'Defines arrow sharpness
            Dim UpRadius As Integer = DataFeature.Radius + FeatureWidth
            Dim MidRadius As Integer = DataFeature.Radius + FeatureWidth / 2 'Defines arrow tip
            Dim DnRadius As Integer = DataFeature.Radius
            Dim DrawStartAngle As Single = DataFeature.StartAngle + StartAngleParam
            Dim DrawEndAngle As Single = DataFeature.EndAngle + StartAngleParam


            If Rot_Angle < 0.1 Then
                Rot_Angle = 0.1
            End If

            If Rot_Angle < DirRotParam Then
                DirRotParam = Rot_Angle
            End If

            'Max radius
            Dim ArcUpX As Integer = MidPoint.X - UpRadius
            Dim ArcUpY As Integer = MidPoint.Y - UpRadius
            Dim ArcUpWidth As Integer = UpRadius * 2
            Dim ArcUpHeight As Integer = UpRadius * 2
            'Min radius
            Dim ArcDnX As Integer = MidPoint.X - DnRadius
            Dim ArcDnY As Integer = MidPoint.Y - DnRadius
            Dim ArcDnWidth As Integer = DnRadius * 2
            Dim ArcDnHeight As Integer = DnRadius * 2



            Select Case DataFeature.FeatureDrawStyle
                Case 0 'Locus

                    If DataFeature.FeatureOrientation = 1 Then 'Plus

                        DrawLocusPlus(g, MidPoint, UpRadius, MidRadius, DnRadius, DrawStartAngle, Rot_Angle, DirRotParam, ArcUpX, ArcUpY, ArcUpWidth, ArcUpHeight, ArcDnX, ArcDnY, ArcDnWidth, ArcDnHeight, Feature_Brush, PointerPen)

                    ElseIf DataFeature.FeatureOrientation = 2 Then 'Minus

                        DrawLocusMinus(g, MidPoint, UpRadius, MidRadius, DnRadius, DrawStartAngle, Rot_Angle, DirRotParam, ArcUpX, ArcUpY, ArcUpWidth, ArcUpHeight, ArcDnX, ArcDnY, ArcDnWidth, ArcDnHeight, Feature_Brush, PointerPen)

                    Else 'Direction not specified

                        DrawLocusUndefined(g, MidPoint, UpRadius, MidRadius, DnRadius, DrawStartAngle, Rot_Angle, ArcUpX, ArcUpY, ArcUpWidth, ArcUpHeight, ArcDnX, ArcDnY, ArcDnWidth, ArcDnHeight, Feature_Brush, PointerPen)

                    End If 'DataFeature.FeatureOrientation

                Case 1 'TSS

                    DrawTSS(g, DataFeature.FeatureOrientation, MidPoint, UpRadius, DnRadius, DrawStartAngle, DrawEndAngle, FeatureArrangeOffset, PointerPen, TSS_Arrow_Length, TSS_Arrow_Width)

                Case 2 'Terminator

                    DrawTT(g, DataFeature.FeatureOrientation, MidPoint, UpRadius, DnRadius, DrawStartAngle, DrawEndAngle, FeatureWidth, PointerPen, TSS_Arrow_Width)

            End Select



            'Draw feature label
            If DataFeature.ShowLabel Then



                LabelText = DataFeature.FeatureName
                StringSize = g.MeasureString(LabelText, MyFont)



                Dim PointerRadius As Integer = DataFeature.Radius + FeatureWidth * 2
                Dim FeatureMidRadius As Integer = DataFeature.Radius + FeatureWidth / 2
                Dim FeatureMidAngle As Single = DrawStartAngle + Rot_Angle / 2


                If FeatureMidAngle - PrevMidAngle < 5 Then
                    PointerShift_X += PrevTextSize.Width
                    PointerShift_Y += PrevTextSize.Height
                Else
                    PointerShift_X = PointerShift
                    PointerShift_Y = PointerShift
                End If




                Dim PointerStartX As Integer = MidPoint.X + PointerRadius * Math.Cos(FeatureMidAngle / 180 * Math.PI)
                Dim PointerStartY As Integer = MidPoint.Y + PointerRadius * Math.Sin(FeatureMidAngle / 180 * Math.PI)
                Dim PointerStart As New Point(PointerStartX, PointerStartY)

                Dim PointerEnd As New Point(MidPoint.X + FeatureMidRadius * Math.Cos(FeatureMidAngle / 180 * Math.PI), _
                                            MidPoint.Y + FeatureMidRadius * Math.Sin(FeatureMidAngle / 180 * Math.PI))

                g.DrawLine(PointerPen, PointerStart, PointerEnd)

                Dim RefAngle As Single = DataFeature.StartAngle + Rot_Angle / 2


                If RefAngle >= 270 Or RefAngle <= 90 Then
                    'Top side
                    If RefAngle >= 0 And RefAngle <= 180 Then
                        'Right side
                        Dim LabelPoint As New Point(PointerStartX + LabelPointerOffset + PointerShift_X, PointerStartY)
                        g.DrawLine(PointerPen, PointerStart, LabelPoint)
                        g.DrawString(LabelText, MyFont, Brushes.Black, LabelPoint.X, LabelPoint.Y - StringSize.Height)
                    Else
                        'Top Left side
                        Dim LabelPoint As New Point(PointerStartX, PointerStartY - LabelPointerOffset - PointerShift_Y)
                        g.DrawLine(PointerPen, PointerStart, LabelPoint)
                        g.DrawString(LabelText, MyFont, Brushes.Black, LabelPoint.X - StringSize.Width, LabelPoint.Y - StringSize.Height)
                    End If
                Else
                    'Bottom side
                    If RefAngle >= 0 And RefAngle <= 180 Then
                        'Right side
                        Dim LabelPoint As New Point(PointerStartX, PointerStartY + LabelPointerOffset + PointerShift_Y)
                        g.DrawLine(PointerPen, PointerStart, LabelPoint)
                        g.DrawString(LabelText, MyFont, Brushes.Black, LabelPoint.X, LabelPoint.Y)
                    Else
                        'Top Left side
                        Dim LabelPoint As New Point(PointerStartX - LabelPointerOffset - PointerShift_X, PointerStartY)
                        g.DrawLine(PointerPen, PointerStart, LabelPoint)
                        g.DrawString(LabelText, MyFont, Brushes.Black, LabelPoint.X - StringSize.Width, LabelPoint.Y)
                    End If
                End If

                PrevMidAngle = FeatureMidAngle
                PrevTextSize = StringSize
            End If 'DataFeature.ShowLabel

            EndAnglePrev = DataFeature.EndAngle

        Next DataFeature

    End Sub

    Private Sub DrawSimpleView(ByVal g As Graphics, _
                               ByVal MidPoint As Point, _
                               ByVal StartAngleParam As Integer, _
                               ByVal Feature_Pen As Pen, _
                               ByVal PointerPen As Pen, _
                               ByVal MyFont As Font, _
                               Optional ByVal Angle_Div_Lim As Integer = 5, _
                               Optional ByVal Y_ArrangeSteps As Integer = 6, _
                               Optional ByVal BasePointerL As Integer = 20)

        Dim Start_Angle As Single = 0
        Dim Rot_Angle As Single = 0

        Dim EndAnglePrev As Single = 0

        Dim PrevTextWidth As Integer = 0

        Dim PointerL As Integer = BasePointerL
        Dim Pointer_Iteration_Counter As Integer = 0

        Dim FeatureX As Single = 0
        Dim FeatureY As Single = 0
        Dim FeatureWidth As Single = 0
        Dim FeatureHeight As Single = 0
        Dim FeatureStartAngle As Single = 0
        Dim LabelText As String = ""
        Dim DirText As String = ""
        Dim StringSize As SizeF = Nothing
        Dim LabelOffsetY As Integer = 0
        Dim FeatureMidAngle As Single = 0
        Dim X_ProjK As Single = 0
        Dim Y_ProjK As Single = 0


        For Each DataFeature As FeatureInfo In Features_Table

            Start_Angle = DataFeature.StartAngle
            Rot_Angle = DataFeature.EndAngle - DataFeature.StartAngle


            'Arrange layout for feature not to overlap with the previous
            If Start_Angle - EndAnglePrev < Angle_Div_Lim Then
                If Pointer_Iteration_Counter < Y_ArrangeSteps Then
                    PointerL += PrevTextWidth + 5
                    Pointer_Iteration_Counter += 1
                    DataFeature.Radius += Feature_Pen.Width * Pointer_Iteration_Counter
                Else
                    PointerL = BasePointerL
                    Pointer_Iteration_Counter = 0
                End If
            Else
                PointerL = BasePointerL
                Pointer_Iteration_Counter = 0
            End If


            Feature_Pen.Color = DataFeature.FillColor

            FeatureX = MidPoint.X - DataFeature.Radius
            FeatureY = MidPoint.Y - DataFeature.Radius
            FeatureWidth = DataFeature.Radius * 2
            FeatureHeight = DataFeature.Radius * 2
            FeatureStartAngle = Start_Angle + StartAngleParam

            If Rot_Angle < 0.1 Then
                Rot_Angle = 0.1
            End If

            g.DrawArc(Feature_Pen, FeatureX, FeatureY, FeatureWidth, FeatureHeight, FeatureStartAngle, Rot_Angle)


            If DataFeature.ShowLabel Then

                FeatureMidAngle = Start_Angle + StartAngleParam + Rot_Angle / 2
                X_ProjK = Math.Cos((FeatureMidAngle) * Math.PI / 180)
                Y_ProjK = Math.Sin((FeatureMidAngle) * Math.PI / 180)

                If DataFeature.FeatureOrientation = 1 Then
                    DirText = "(+)"
                ElseIf DataFeature.FeatureOrientation = 2 Then
                    DirText = "(-)"
                Else
                    DirText = "(:)"
                End If

                LabelText = String.Concat(DataFeature.FeatureName, " ", DirText)
                StringSize = g.MeasureString(LabelText, MyFont)
                LabelOffsetY = -StringSize.Height / 2



                Dim TargetPoint As New Point(MidPoint.X + (DataFeature.Radius + PointerL) * X_ProjK, _
                                             MidPoint.Y + (DataFeature.Radius + PointerL) * Y_ProjK)
                Dim InitPoint As New Point(MidPoint.X + (DataFeature.Radius) * X_ProjK, _
                                           MidPoint.Y + (DataFeature.Radius) * Y_ProjK)

                g.DrawLine(PointerPen, InitPoint, TargetPoint)

                Dim LayoutRect As New RectangleF
                LayoutRect.Width = StringSize.Width
                LayoutRect.Height = StringSize.Height
                LayoutRect.Location = New Point(MidPoint.X, MidPoint.Y)
                Dim LayoutVectorMatrix As New Drawing.Drawing2D.Matrix()
                If Start_Angle >= 0 And Start_Angle <= 180 Then
                    LayoutVectorMatrix.RotateAt((2 * Start_Angle + Rot_Angle) / 2 - 90, MidPoint)
                    LayoutVectorMatrix.Translate(DataFeature.Radius + PointerL + 5, LabelOffsetY)
                Else
                    LayoutVectorMatrix.RotateAt((2 * Start_Angle + Rot_Angle) / 2 - 270, MidPoint)
                    LayoutVectorMatrix.Translate(-(DataFeature.Radius + PointerL + StringSize.Width), LabelOffsetY)
                End If

                g.Transform = LayoutVectorMatrix
                g.DrawString(LabelText, MyFont, Brushes.Black, LayoutRect)
                g.ResetTransform()
            End If 'DataFeature.ShowLabel

            EndAnglePrev = DataFeature.EndAngle
            PrevTextWidth = StringSize.Width

        Next DataFeature

    End Sub

    Public Sub SaveImage()

        If Master.SaveImageDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim FileName As String = Master.SaveImageDialog.FileName

            Dim ExportK As Single = 2
            Dim ExportWidth As Integer = ViewPanel.Width * ExportK
            Dim ExportHeight As Integer = ViewPanel.Height * ExportK


            Dim ExportImage As Image = New Bitmap(ExportWidth, ExportHeight, System.Drawing.Imaging.PixelFormat.Format24bppRgb)

            Using outputG As Graphics = Graphics.FromImage(ExportImage)
                outputG.Clear(Color.White)
                DrawImage(outputG, ExportK)
            End Using

            Select Case Master.SaveImageDialog.FilterIndex
                Case 1
                    If Not FileName.EndsWith(".bmp") Then
                        FileName = String.Concat(FileName, ".bmp")
                    End If
                    ExportImage.Save(FileName, Imaging.ImageFormat.Bmp)
                Case 2
                    If Not FileName.EndsWith(".jpg") Then
                        FileName = String.Concat(FileName, ".jpg")
                    End If
                    ExportImage.Save(FileName, Imaging.ImageFormat.Jpeg)
                Case 3
                    If Not FileName.EndsWith(".png") Then
                        FileName = String.Concat(FileName, ".png")
                    End If
                    ExportImage.Save(FileName, Imaging.ImageFormat.Png)
                Case 4
                    If Not FileName.EndsWith(".tif") Then
                        FileName = String.Concat(FileName, ".tif")
                    End If
                    ExportImage.Save(FileName, Imaging.ImageFormat.Tiff)
            End Select

        End If
    End Sub


#End Region

#Region "Mouse - clickable view panel"

    Private Sub ViewPanel_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ViewPanel.MouseDown

        Dim MidPoint As New Point(ViewPanel.Width / 2, ViewPanel.Height / 2)
        Dim Mouse_Angle As Single = Bioinformatics.Get_Angle_Deg(MidPoint, e.Location)
        Dim Mouse_Radius As Single = Bioinformatics.Get_Radius_Int(MidPoint, e.Location)
        Dim found As Boolean = False
        Dim Found_ID As String = ""

        If bFullView Then


            For Each DataFeature As FeatureInfo In Features_Table

                If Mouse_Angle <= DataFeature.EndAngle And Mouse_Angle >= DataFeature.StartAngle _
                And Mouse_Radius < DataFeature.Radius + FeatureFullWidth And Mouse_Radius > DataFeature.Radius Then

                    Found_ID = DataFeature.FeatureID
                    found = True
                    Exit For
                End If

            Next DataFeature

            If found Then
                For i = 0 To FeaturesDataGridView.Rows.Count - 2
                    If FeaturesDataGridView.Rows(i).Cells(3).Value = Found_ID Then
                        FeaturesDataGridView.ClearSelection()
                        FeaturesDataGridView.Rows(i).Selected = True
                        FeaturesDataGridView.FirstDisplayedScrollingRowIndex = i
                        Exit For
                    End If
                Next i
            End If 'found


        Else

            For Each DataFeature As FeatureInfo In Features_Table

                If Mouse_Angle <= DataFeature.EndAngle And Mouse_Angle >= DataFeature.StartAngle And Mouse_Radius < DataFeature.Radius + 3 And Mouse_Radius > DataFeature.Radius - 3 Then
                    Found_ID = DataFeature.FeatureID
                    found = True
                    Exit For
                End If

            Next DataFeature

            If found Then
                For i = 0 To FeaturesDataGridView.Rows.Count - 2
                    If FeaturesDataGridView.Rows(i).Cells(3).Value = Found_ID Then
                        FeaturesDataGridView.ClearSelection()
                        FeaturesDataGridView.Rows(i).Selected = True
                        FeaturesDataGridView.FirstDisplayedScrollingRowIndex = i
                        Exit For
                    End If
                Next i
            End If 'found

        End If 'bFullView


    End Sub

#End Region

#Region "Data"

    Private Sub LoadFeaturesFromDataTable(ByVal R_Default As Integer)

        Features_Table.Clear()
        For i = 0 To FeaturesDataGridView.Rows.Count - 2

            If FeaturesDataGridView.Rows(i).Cells(0).Value = True Then

                Dim FeatureStyle As Short = 0
                Select Case FeaturesDataGridView.Rows(i).Cells(9).Value
                    Case "Locus"
                        FeatureStyle = 0
                    Case "TSS"
                        FeatureStyle = 1
                    Case "Terminator"
                        FeatureStyle = 2
                End Select

                Dim FeatureDir As Short = 0
                Select Case FeaturesDataGridView.Rows(i).Cells(6).Value
                    Case "Plus"
                        FeatureDir = 1
                    Case "Minus"
                        FeatureDir = 2
                    Case "plus"
                        FeatureDir = 1
                    Case "minus"
                        FeatureDir = 2
                    Case "+"
                        FeatureDir = 1
                    Case "-"
                        FeatureDir = 2
                    Case Else
                        FeatureDir = 0
                End Select

                Dim NewFeature As New FeatureInfo(FeaturesDataGridView.Rows(i).Cells(0).Value, _
                                                   FeaturesDataGridView.Rows(i).Cells(1).Value, _
                                                   FeaturesDataGridView.Rows(i).Cells(2).Value, _
                                        FeaturesDataGridView.Rows(i).Cells(3).Value, _
                                        FeaturesDataGridView.Rows(i).Cells(4).Value, _
                                        FeaturesDataGridView.Rows(i).Cells(5).Value, _
                                        FeatureDir, _
                                        FeaturesDataGridView.Rows(i).Cells(7).Value, _
                                        FeaturesDataGridView.Rows(i).Cells(8).Style.BackColor, _
                                        FeatureStyle)



                NewFeature.StartAngle = (FeaturesDataGridView.Rows(i).Cells(4).Value / intGenomeLength) * 360
                NewFeature.EndAngle = (FeaturesDataGridView.Rows(i).Cells(5).Value / intGenomeLength) * 360
                NewFeature.Radius = R_Default

                Features_Table.Add(NewFeature)

            End If

        Next i

        SortFeatures(Features_Table)

    End Sub

#End Region


    Public Sub SortFeatures(ByRef DataList As List(Of FeatureInfo))
        Dim Tmp As FeatureInfo = Nothing
        For i = 1 To DataList.Count - 1
            For j = 0 To DataList.Count - 1 - i
                If DataList(j).FeatureStart > DataList(j + 1).FeatureStart Then
                    Tmp = DataList(j)
                    DataList(j) = DataList(j + 1)
                    DataList(j + 1) = Tmp
                End If
            Next
        Next
    End Sub

    Private Sub RefreshButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshButton.Click
        ViewPanel.Refresh()

    End Sub

    Private Sub ZoomInButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ZoomInButton.Click
        If Not ViewPanel.Width > 16000 Then
            ViewPanel.Size = New Size(ViewPanel.Width * 2, ViewPanel.Height * 2)
            ViewPanel.Invalidate()
        End If

    End Sub

    Private Sub ZoomOutButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ZoomOutButton.Click
        ViewPanel.Size = New Size(ViewPanel.Width / 2, ViewPanel.Height / 2)
        ViewPanel.Invalidate()
    End Sub

    Private Sub GridButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GridButton.Click
        GridOn = Not GridOn
        ViewPanel.Refresh()
    End Sub

    Private Sub CheckButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckButton.Click
        Static Chk As Boolean = False

        For i = 0 To FeaturesDataGridView.Rows.Count - 2
            FeaturesDataGridView.Rows(i).Cells(0).Value = Chk
        Next

        Chk = Not Chk

        ViewPanel.Refresh()
    End Sub

    Private Sub DrawImageButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawImageButton.Click
        SaveImage()
    End Sub

    Private Sub SimplifiedToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SimplifiedToolStripMenuItem.Click
        FullToolStripMenuItem.Checked = False
        bFullView = False
        ViewPanel.Invalidate()

    End Sub

    Private Sub FullToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FullToolStripMenuItem.Click
        SimplifiedToolStripMenuItem.Checked = False
        bFullView = True
        ViewPanel.Invalidate()

    End Sub

    Private Sub FeaturesDataGridView_CellMouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles FeaturesDataGridView.CellMouseUp
        If e.ColumnIndex = 0 Or e.ColumnIndex = 1 Then
            FeaturesDataGridView.EndEdit()
            ViewPanel.Invalidate()
        End If
    End Sub

    Private Sub FeaturesDataGridView_CellBeginEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellCancelEventArgs) Handles FeaturesDataGridView.CellBeginEdit
        If e.ColumnIndex = 8 Then

            If Master.ColorSelectDialog.ShowDialog = DialogResult.OK Then

                FeaturesDataGridView.CurrentRow.Cells(8).Style.BackColor = Master.ColorSelectDialog.Color

                FeaturesDataGridView.EndEdit()
                ViewPanel.Invalidate()
            End If


        End If
    End Sub

    Private Sub FeaturesDataGridView_CellEndEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles FeaturesDataGridView.CellEndEdit
        ViewPanel.Invalidate()

    End Sub

    Private Sub TextSizeComboBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextSizeComboBox.TextChanged

        Dim TSize As Integer = CType(TextSizeComboBox.Text, Integer)
        If TSize > 0 Then
            ViewPanel.Invalidate()
        End If

    End Sub

    Private Sub AxisComboBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AxisComboBox.TextChanged

        Dim TSize As Integer = CType(AxisComboBox.Text, Integer)
        If TSize > 0 Then
            ViewPanel.Invalidate()
        End If

    End Sub

    Private Sub DetectRestrictionSites()
        If Not IsNothing(cMyParent) Then
            SearchSeqList.Rows.Clear()

            For Each Row As DataRow In Master.SiteSeqList.Rows
                For i = 0 To DetectorListBox.CheckedItems.Count - 1
                    If Row.Item(0) = DetectorListBox.CheckedItems(i) Then
                        SearchSeqList.Rows.Add(Row.Item(0), Row.Item(1))
                    End If
                Next
            Next

            RestrictionList.Clear()

            Dim ForCoordList As List(Of CoordHit)
            Dim RevCoordList As List(Of CoordHit)
            Dim ClearedSequence As String = ""

            For Each Site As DataRow In SearchSeqList.Rows
                ClearedSequence = Site.Item(1)
                ClearedSequence = ClearedSequence.Replace(Chr(94), vbNullString)
                ClearedSequence = ClearedSequence.Replace(Chr(42), vbNullString)

                If ClearedSequence = Bioinformatics.GetReverseComplement(ClearedSequence) Then
                    'Sequence is a palindrome
                    ForCoordList = Bioinformatics.UngappedSequenceSearch(cMyParent.Genome_Sequence, ClearedSequence, 1)

                    For Each Hit As CoordHit In ForCoordList
                        Hit.Label = Site.Item(0)
                        RestrictionList.Add(Hit)
                    Next

                Else
                    ForCoordList = Bioinformatics.UngappedSequenceSearch(cMyParent.Genome_Sequence, ClearedSequence, 1)
                    RevCoordList = Bioinformatics.UngappedSequenceSearch(cMyParent.Genome_Sequence, Bioinformatics.GetReverseComplement(ClearedSequence), 1)

                    For Each Hit As CoordHit In ForCoordList
                        Hit.Label = Site.Item(0)
                        RestrictionList.Add(Hit)
                    Next

                    For Each Hit As CoordHit In RevCoordList
                        Hit.Label = Site.Item(0)
                        RestrictionList.Add(Hit)
                    Next

                End If
            Next Site


            'Sort Restriction List by start position
            Dim Tmp As CoordHit = Nothing
            For i = 1 To RestrictionList.Count - 1
                For j = 0 To RestrictionList.Count - 1 - i
                    If RestrictionList(j).Position > RestrictionList(j + 1).Position Then
                        Tmp = RestrictionList(j)
                        RestrictionList(j) = RestrictionList(j + 1)
                        RestrictionList(j + 1) = Tmp
                    End If
                Next
            Next


        End If

    End Sub

    Public Sub LoadDetectorItems()
        DetectorListBox.Items.Clear()
        For Each Row As DataRow In Master.SiteSeqList.Rows
            DetectorListBox.Items.Add(Row.Item(0))
        Next
    End Sub

    Private Sub VirtualGenome_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        SearchSeqList.Columns.Add("Name")
        SearchSeqList.Columns.Add("Seq")
        LoadDetectorItems()

    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        SearchSeqList.Rows.Clear()
        LoadDetectorItems()
        RestrictionList.Clear()
        ViewPanel.Invalidate()

    End Sub

    Private Sub DetectButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DetectButton.Click
        If DetectorListBox.CheckedItems.Count > 0 Then
            bShowRestrictases = True
            DetectRestrictionSites()
        Else
            bShowRestrictases = False
        End If
        ViewPanel.Invalidate()

    End Sub

    Private Sub DeleteSelectedRowsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteSelectedRowsButton.Click
        For i = FeaturesDataGridView.SelectedRows.Count - 1 To 0 Step -1
            FeaturesDataGridView.Rows.RemoveAt(FeaturesDataGridView.SelectedRows(i).Index)
        Next i
    End Sub

    Private Sub FeaturesDataGridView_SelectionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FeaturesDataGridView.SelectionChanged
        If FeaturesDataGridView.SelectedRows.Count > 0 Then
            DeleteSelectedRowsButton.Enabled = True
        Else
            DeleteSelectedRowsButton.Enabled = False
        End If
    End Sub
End Class
