﻿Public Class ConsensusSequence

    Private lA_list As New List(Of Single)
    Private lG_list As New List(Of Single)
    Private lC_list As New List(Of Single)
    Private lT_list As New List(Of Single)

    Public Property A_list() As List(Of Single)
        Get
            A_list = lA_list
        End Get
        Set(ByVal value As List(Of Single))
            lA_list = value
        End Set
    End Property

    Public Property G_list() As List(Of Single)
        Get
            G_list = lG_list
        End Get
        Set(ByVal value As List(Of Single))
            lG_list = value
        End Set
    End Property

    Public Property C_list() As List(Of Single)
        Get
            C_list = lC_list
        End Get
        Set(ByVal value As List(Of Single))
            lC_list = value
        End Set
    End Property

    Public Property T_list() As List(Of Single)
        Get
            T_list = lT_list
        End Get
        Set(ByVal value As List(Of Single))
            lT_list = value
        End Set
    End Property

End Class
