﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SystemStrandSelectionBox
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PlusButton = New System.Windows.Forms.Button
        Me.MinusButton = New System.Windows.Forms.Button
        Me.AbortButton = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'PlusButton
        '
        Me.PlusButton.Location = New System.Drawing.Point(12, 12)
        Me.PlusButton.Name = "PlusButton"
        Me.PlusButton.Size = New System.Drawing.Size(75, 23)
        Me.PlusButton.TabIndex = 0
        Me.PlusButton.Text = "Plus"
        Me.PlusButton.UseVisualStyleBackColor = True
        '
        'MinusButton
        '
        Me.MinusButton.Location = New System.Drawing.Point(93, 12)
        Me.MinusButton.Name = "MinusButton"
        Me.MinusButton.Size = New System.Drawing.Size(75, 23)
        Me.MinusButton.TabIndex = 1
        Me.MinusButton.Text = "Minus"
        Me.MinusButton.UseVisualStyleBackColor = True
        '
        'AbortButton
        '
        Me.AbortButton.Location = New System.Drawing.Point(174, 12)
        Me.AbortButton.Name = "AbortButton"
        Me.AbortButton.Size = New System.Drawing.Size(75, 23)
        Me.AbortButton.TabIndex = 2
        Me.AbortButton.Text = "Abort"
        Me.AbortButton.UseVisualStyleBackColor = True
        '
        'SystemStrandSelectionBox
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(260, 46)
        Me.Controls.Add(Me.AbortButton)
        Me.Controls.Add(Me.MinusButton)
        Me.Controls.Add(Me.PlusButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "SystemStrandSelectionBox"
        Me.Text = "Set default strand"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PlusButton As System.Windows.Forms.Button
    Friend WithEvents MinusButton As System.Windows.Forms.Button
    Friend WithEvents AbortButton As System.Windows.Forms.Button
End Class
