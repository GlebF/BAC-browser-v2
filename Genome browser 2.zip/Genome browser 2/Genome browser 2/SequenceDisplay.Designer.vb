﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SequenceDisplay
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SequenceDisplay))
        Me.EF2DButton = New System.Windows.Forms.Button
        Me.ClearButton = New System.Windows.Forms.Button
        Me.SeqTextBox = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.SeqLengthTextBox = New System.Windows.Forms.TextBox
        Me.TranslationTextBox = New System.Windows.Forms.TextBox
        Me.CopyGeneButton = New System.Windows.Forms.Button
        Me.CopyProtButton = New System.Windows.Forms.Button
        Me.ReverseButton = New System.Windows.Forms.Button
        Me.ContainerPanel = New System.Windows.Forms.Panel
        Me.ReverseTranslationButton = New System.Windows.Forms.Button
        Me.ClearSeqCheckBox = New System.Windows.Forms.CheckBox
        Me.ReadListCheckBox = New System.Windows.Forms.CheckBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.AATextBox = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.StopTextBox = New System.Windows.Forms.TextBox
        Me.Code3CheckBox = New System.Windows.Forms.CheckBox
        Me.TranslateComboBox = New System.Windows.Forms.ComboBox
        Me.TranslateButton = New System.Windows.Forms.Button
        Me.ComplementButton = New System.Windows.Forms.Button
        Me.ReverseComplementButton = New System.Windows.Forms.Button
        Me.SeqPanel = New System.Windows.Forms.Panel
        Me.MRNATextBox = New System.Windows.Forms.TextBox
        Me.ContainerPanel.SuspendLayout()
        Me.SeqPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'EF2DButton
        '
        Me.EF2DButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.EF2DButton.Location = New System.Drawing.Point(264, 35)
        Me.EF2DButton.Name = "EF2DButton"
        Me.EF2DButton.Size = New System.Drawing.Size(120, 23)
        Me.EF2DButton.TabIndex = 11
        Me.EF2DButton.Text = "View on 2D map"
        Me.EF2DButton.UseVisualStyleBackColor = True
        '
        'ClearButton
        '
        Me.ClearButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ClearButton.Location = New System.Drawing.Point(138, 35)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(120, 23)
        Me.ClearButton.TabIndex = 10
        Me.ClearButton.Text = "Clear all"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'SeqTextBox
        '
        Me.SeqTextBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.SeqTextBox.Location = New System.Drawing.Point(0, 0)
        Me.SeqTextBox.Multiline = True
        Me.SeqTextBox.Name = "SeqTextBox"
        Me.SeqTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.SeqTextBox.Size = New System.Drawing.Size(720, 85)
        Me.SeqTextBox.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 67)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Nucleotides:"
        '
        'SeqLengthTextBox
        '
        Me.SeqLengthTextBox.Location = New System.Drawing.Point(82, 64)
        Me.SeqLengthTextBox.Name = "SeqLengthTextBox"
        Me.SeqLengthTextBox.ReadOnly = True
        Me.SeqLengthTextBox.Size = New System.Drawing.Size(50, 20)
        Me.SeqLengthTextBox.TabIndex = 8
        '
        'TranslationTextBox
        '
        Me.TranslationTextBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.TranslationTextBox.Location = New System.Drawing.Point(0, 170)
        Me.TranslationTextBox.Multiline = True
        Me.TranslationTextBox.Name = "TranslationTextBox"
        Me.TranslationTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TranslationTextBox.Size = New System.Drawing.Size(720, 85)
        Me.TranslationTextBox.TabIndex = 4
        '
        'CopyGeneButton
        '
        Me.CopyGeneButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.CopyGeneButton.Location = New System.Drawing.Point(588, 6)
        Me.CopyGeneButton.Name = "CopyGeneButton"
        Me.CopyGeneButton.Size = New System.Drawing.Size(120, 23)
        Me.CopyGeneButton.TabIndex = 6
        Me.CopyGeneButton.Text = "Copy gene"
        Me.CopyGeneButton.UseVisualStyleBackColor = True
        '
        'CopyProtButton
        '
        Me.CopyProtButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.CopyProtButton.Location = New System.Drawing.Point(588, 35)
        Me.CopyProtButton.Name = "CopyProtButton"
        Me.CopyProtButton.Size = New System.Drawing.Size(120, 23)
        Me.CopyProtButton.TabIndex = 5
        Me.CopyProtButton.Text = "Copy protein"
        Me.CopyProtButton.UseVisualStyleBackColor = True
        '
        'ReverseButton
        '
        Me.ReverseButton.Location = New System.Drawing.Point(12, 35)
        Me.ReverseButton.Name = "ReverseButton"
        Me.ReverseButton.Size = New System.Drawing.Size(120, 23)
        Me.ReverseButton.TabIndex = 4
        Me.ReverseButton.Text = "Reverse"
        Me.ReverseButton.UseVisualStyleBackColor = True
        '
        'ContainerPanel
        '
        Me.ContainerPanel.Controls.Add(Me.ReverseTranslationButton)
        Me.ContainerPanel.Controls.Add(Me.ClearSeqCheckBox)
        Me.ContainerPanel.Controls.Add(Me.ReadListCheckBox)
        Me.ContainerPanel.Controls.Add(Me.Label3)
        Me.ContainerPanel.Controls.Add(Me.AATextBox)
        Me.ContainerPanel.Controls.Add(Me.Label2)
        Me.ContainerPanel.Controls.Add(Me.StopTextBox)
        Me.ContainerPanel.Controls.Add(Me.Code3CheckBox)
        Me.ContainerPanel.Controls.Add(Me.EF2DButton)
        Me.ContainerPanel.Controls.Add(Me.ClearButton)
        Me.ContainerPanel.Controls.Add(Me.Label1)
        Me.ContainerPanel.Controls.Add(Me.SeqLengthTextBox)
        Me.ContainerPanel.Controls.Add(Me.CopyGeneButton)
        Me.ContainerPanel.Controls.Add(Me.CopyProtButton)
        Me.ContainerPanel.Controls.Add(Me.ReverseButton)
        Me.ContainerPanel.Controls.Add(Me.TranslateComboBox)
        Me.ContainerPanel.Controls.Add(Me.TranslateButton)
        Me.ContainerPanel.Controls.Add(Me.ComplementButton)
        Me.ContainerPanel.Controls.Add(Me.ReverseComplementButton)
        Me.ContainerPanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ContainerPanel.Location = New System.Drawing.Point(0, 349)
        Me.ContainerPanel.Name = "ContainerPanel"
        Me.ContainerPanel.Size = New System.Drawing.Size(720, 129)
        Me.ContainerPanel.TabIndex = 6
        '
        'ReverseTranslationButton
        '
        Me.ReverseTranslationButton.Location = New System.Drawing.Point(390, 6)
        Me.ReverseTranslationButton.Name = "ReverseTranslationButton"
        Me.ReverseTranslationButton.Size = New System.Drawing.Size(120, 23)
        Me.ReverseTranslationButton.TabIndex = 19
        Me.ReverseTranslationButton.Text = "Reverse translate"
        Me.ReverseTranslationButton.UseVisualStyleBackColor = True
        '
        'ClearSeqCheckBox
        '
        Me.ClearSeqCheckBox.AutoSize = True
        Me.ClearSeqCheckBox.Location = New System.Drawing.Point(377, 91)
        Me.ClearSeqCheckBox.Name = "ClearSeqCheckBox"
        Me.ClearSeqCheckBox.Size = New System.Drawing.Size(108, 17)
        Me.ClearSeqCheckBox.TabIndex = 18
        Me.ClearSeqCheckBox.Text = "Format sequence"
        Me.ClearSeqCheckBox.UseVisualStyleBackColor = True
        '
        'ReadListCheckBox
        '
        Me.ReadListCheckBox.AutoSize = True
        Me.ReadListCheckBox.Location = New System.Drawing.Point(155, 91)
        Me.ReadListCheckBox.Name = "ReadListCheckBox"
        Me.ReadListCheckBox.Size = New System.Drawing.Size(67, 17)
        Me.ReadListCheckBox.TabIndex = 17
        Me.ReadListCheckBox.Text = "Read list"
        Me.ReadListCheckBox.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 92)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 13)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Aminoacids:"
        '
        'AATextBox
        '
        Me.AATextBox.Location = New System.Drawing.Point(82, 90)
        Me.AATextBox.Name = "AATextBox"
        Me.AATextBox.ReadOnly = True
        Me.AATextBox.Size = New System.Drawing.Size(50, 20)
        Me.AATextBox.TabIndex = 15
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(152, 67)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 13)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Stop codons:"
        '
        'StopTextBox
        '
        Me.StopTextBox.Location = New System.Drawing.Point(228, 64)
        Me.StopTextBox.Name = "StopTextBox"
        Me.StopTextBox.ReadOnly = True
        Me.StopTextBox.Size = New System.Drawing.Size(30, 20)
        Me.StopTextBox.TabIndex = 13
        '
        'Code3CheckBox
        '
        Me.Code3CheckBox.AutoSize = True
        Me.Code3CheckBox.Location = New System.Drawing.Point(264, 91)
        Me.Code3CheckBox.Name = "Code3CheckBox"
        Me.Code3CheckBox.Size = New System.Drawing.Size(107, 17)
        Me.Code3CheckBox.TabIndex = 12
        Me.Code3CheckBox.Text = "Three-letter code"
        Me.Code3CheckBox.UseVisualStyleBackColor = True
        '
        'TranslateComboBox
        '
        Me.TranslateComboBox.FormattingEnabled = True
        Me.TranslateComboBox.Location = New System.Drawing.Point(264, 64)
        Me.TranslateComboBox.Name = "TranslateComboBox"
        Me.TranslateComboBox.Size = New System.Drawing.Size(120, 21)
        Me.TranslateComboBox.TabIndex = 3
        '
        'TranslateButton
        '
        Me.TranslateButton.Location = New System.Drawing.Point(264, 6)
        Me.TranslateButton.Name = "TranslateButton"
        Me.TranslateButton.Size = New System.Drawing.Size(120, 23)
        Me.TranslateButton.TabIndex = 2
        Me.TranslateButton.Text = "Translate"
        Me.TranslateButton.UseVisualStyleBackColor = True
        '
        'ComplementButton
        '
        Me.ComplementButton.Location = New System.Drawing.Point(12, 6)
        Me.ComplementButton.Name = "ComplementButton"
        Me.ComplementButton.Size = New System.Drawing.Size(120, 23)
        Me.ComplementButton.TabIndex = 1
        Me.ComplementButton.Text = "Complement"
        Me.ComplementButton.UseVisualStyleBackColor = True
        '
        'ReverseComplementButton
        '
        Me.ReverseComplementButton.Location = New System.Drawing.Point(138, 6)
        Me.ReverseComplementButton.Name = "ReverseComplementButton"
        Me.ReverseComplementButton.Size = New System.Drawing.Size(120, 23)
        Me.ReverseComplementButton.TabIndex = 0
        Me.ReverseComplementButton.Text = "Reverse complement"
        Me.ReverseComplementButton.UseVisualStyleBackColor = True
        '
        'SeqPanel
        '
        Me.SeqPanel.Controls.Add(Me.TranslationTextBox)
        Me.SeqPanel.Controls.Add(Me.MRNATextBox)
        Me.SeqPanel.Controls.Add(Me.SeqTextBox)
        Me.SeqPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SeqPanel.Location = New System.Drawing.Point(0, 0)
        Me.SeqPanel.Name = "SeqPanel"
        Me.SeqPanel.Size = New System.Drawing.Size(720, 349)
        Me.SeqPanel.TabIndex = 7
        '
        'MRNATextBox
        '
        Me.MRNATextBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.MRNATextBox.Location = New System.Drawing.Point(0, 85)
        Me.MRNATextBox.Multiline = True
        Me.MRNATextBox.Name = "MRNATextBox"
        Me.MRNATextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.MRNATextBox.Size = New System.Drawing.Size(720, 85)
        Me.MRNATextBox.TabIndex = 5
        '
        'SequenceDisplay
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(720, 478)
        Me.Controls.Add(Me.SeqPanel)
        Me.Controls.Add(Me.ContainerPanel)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "SequenceDisplay"
        Me.Text = "Sequence"
        Me.ContainerPanel.ResumeLayout(False)
        Me.ContainerPanel.PerformLayout()
        Me.SeqPanel.ResumeLayout(False)
        Me.SeqPanel.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents EF2DButton As System.Windows.Forms.Button
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents SeqTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents SeqLengthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TranslationTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CopyGeneButton As System.Windows.Forms.Button
    Friend WithEvents CopyProtButton As System.Windows.Forms.Button
    Friend WithEvents ReverseButton As System.Windows.Forms.Button
    Friend WithEvents ContainerPanel As System.Windows.Forms.Panel
    Friend WithEvents TranslateComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents TranslateButton As System.Windows.Forms.Button
    Friend WithEvents ComplementButton As System.Windows.Forms.Button
    Friend WithEvents ReverseComplementButton As System.Windows.Forms.Button
    Friend WithEvents SeqPanel As System.Windows.Forms.Panel
    Friend WithEvents Code3CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents StopTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents AATextBox As System.Windows.Forms.TextBox
    Friend WithEvents ReadListCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents MRNATextBox As System.Windows.Forms.TextBox
    Friend WithEvents ClearSeqCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ReverseTranslationButton As System.Windows.Forms.Button
End Class
