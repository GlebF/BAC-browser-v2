﻿Public Class Virtual2D_EF
    Private Grid As Boolean = True
    Private HydroColoring As Boolean = False

    Private Sub SetDefaultProperties()
        RunTextBox.Text = CType(16.6, String)
        ResTextBox.Text = CType(1.26, String)

    End Sub

    Private Sub EFPanel_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles EFPanel.Paint

        Dim pH_mark As Integer = 0
        Dim L_pH_mark As Single = 0
        Dim H_pH_mark As Single = 0

        Dim Offset_Left As Integer = 50
        Dim Offset_Down As Integer = 20

        Dim GridCoordPen As New Pen(Color.Black)
        GridCoordPen.DashStyle = Drawing2D.DashStyle.Dot


        Dim MultK As Single = EFPanel.Height * RunTextBox.Text
        Dim SubtrK As Single = EFPanel.Height * ResTextBox.Text

        Dim MW_Mark As Integer = 0
        Dim LowesMW As Integer = CType(LowestMassTextBox.Text, Integer) * 1000

        'EF borders

        MW_Mark = Offset_Down + MultK / Math.Log(LowesMW) - SubtrK
        L_pH_mark = LpHTextBox.Text * (EFPanel.Width - Offset_Left) / 14
        H_pH_mark = HpHTextBox.Text * (EFPanel.Width - Offset_Left) / 14

        e.Graphics.DrawLine(Pens.Black, L_pH_mark + Offset_Left, Offset_Down, L_pH_mark + Offset_Left, MW_Mark)
        e.Graphics.DrawLine(Pens.Black, H_pH_mark + Offset_Left, Offset_Down, H_pH_mark + Offset_Left, MW_Mark)
        e.Graphics.DrawLine(Pens.Black, L_pH_mark + Offset_Left, Offset_Down, H_pH_mark + Offset_Left, Offset_Down)
        e.Graphics.DrawLine(Pens.Black, L_pH_mark + Offset_Left, MW_Mark, H_pH_mark + Offset_Left, MW_Mark)


        For i = 1 To 13
            pH_mark = i * (EFPanel.Width - Offset_Left) / 14
            e.Graphics.DrawLine(Pens.Black, pH_mark + Offset_Left, 0, pH_mark + Offset_Left, 10)

            If Grid Then
                e.Graphics.DrawLine(GridCoordPen, pH_mark + Offset_Left, Offset_Down, pH_mark + Offset_Left, MW_Mark)
            End If

            e.Graphics.DrawString(i, Me.Font, Brushes.Black, pH_mark + Offset_Left, 8)
        Next

        Dim MW_increment As Integer = LowesMW
        For i = 1 To 10
            MW_Mark = Offset_Down + MultK / Math.Log(MW_increment) - SubtrK
            e.Graphics.DrawLine(Pens.Black, 0, MW_Mark, 10, MW_Mark)

            If Grid Then
                e.Graphics.DrawLine(GridCoordPen, Offset_Left, MW_Mark, EFPanel.Width, MW_Mark)
            End If

            e.Graphics.DrawString(String.Concat(MW_increment / 1000, " kDa"), Me.Font, Brushes.Black, 10, MW_Mark)
            MW_increment *= 2
        Next

        Dim CurrentX As Integer = 0
        Dim CurrentY As Integer = 40
        Dim R As Integer = RTextBox.Text

        Dim Prot_Color As New Color
        Dim Prot_Brush As Brush = Brushes.Black



        For i = 0 To ProtDataGridView.Rows.Count - 2
            If ProtDataGridView.Rows(i).Cells(0).Value = True Then
                CurrentX = Offset_Left + ProtDataGridView.Rows(i).Cells(4).Value * (EFPanel.Width - Offset_Left) / 14
                CurrentY = Offset_Down + MultK / Math.Log(ProtDataGridView.Rows(i).Cells(5).Value) - SubtrK

                If CurrentY < 20 Then
                    CurrentY = 20
                End If

                ProtDataGridView.Rows(i).Cells(8).Value = CurrentX
                ProtDataGridView.Rows(i).Cells(9).Value = CurrentY

                If HydroColoring Then

                    Dim Red As Integer = 0
                    Dim Green As Integer = 0
                    If ProtDataGridView.Rows(i).Cells(6).Value <= -10 Then
                        Red = 255
                        Green = 0

                    ElseIf ProtDataGridView.Rows(i).Cells(6).Value > -10 And ProtDataGridView.Rows(i).Cells(6).Value <= 10 Then
                        Red = 205
                        Green = 55

                    ElseIf ProtDataGridView.Rows(i).Cells(6).Value > 10 And ProtDataGridView.Rows(i).Cells(6).Value <= 100 Then
                        Red = 105
                        Green = 155

                    Else
                        Red = 0
                        Green = 255

                    End If

                    Prot_Color = Color.FromArgb(255, Red, Green, 0)
                    Dim HydroBrush As New SolidBrush(Prot_Color)
                    Prot_Brush = HydroBrush
                Else
                    Select Case ProtDataGridView.Rows(i).Cells(7).Value
                        Case "Red"
                            Prot_Brush = Brushes.Red
                        Case "Green"
                            Prot_Brush = Brushes.LimeGreen
                        Case "Blue"
                            Prot_Brush = Brushes.Blue
                        Case "Yellow"
                            Prot_Brush = Brushes.Gold
                        Case Else
                            Prot_Brush = Brushes.Black
                    End Select
                End If

                ' e.Graphics.DrawEllipse(Pens.Black, CurrentX - R, CurrentY - R, R * 2, R * 2)

                e.Graphics.FillEllipse(Prot_Brush, CurrentX - R, CurrentY - R, R * 2, R * 2)
                If ProtDataGridView.Rows(i).Cells(1).Value = True Then
                    e.Graphics.DrawString(ProtDataGridView.Rows(i).Cells(2).Value, Me.Font, Brushes.Black, CurrentX, CurrentY)
                End If

            End If
        Next



    End Sub

    Private Sub ProtDataGridView_CellMouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles ProtDataGridView.CellMouseUp
        If e.ColumnIndex = 0 Or e.ColumnIndex = 1 Then
            ProtDataGridView.EndEdit()
            EFPanel.Refresh()
        End If
    End Sub

    Private Sub RefreshButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshButton.Click
        EFPanel.Width = WTextBox.Text
        EFPanel.Height = HTextBox.Text
        EFPanel.Refresh()
    End Sub

    Private Sub ZoomInButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ZoomInButton.Click
        WTextBox.Text *= 2
        HTextBox.Text *= 2
        EFPanel.Width = WTextBox.Text
        EFPanel.Height = HTextBox.Text
        EFPanel.Refresh()
    End Sub

    Private Sub ZoomOutButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ZoomOutButton.Click
        WTextBox.Text /= 2
        HTextBox.Text /= 2
        EFPanel.Width = WTextBox.Text
        EFPanel.Height = HTextBox.Text
        EFPanel.Refresh()
    End Sub

    Private Sub GridToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GridToolStripMenuItem.Click
        Grid = Not Grid
        EFPanel.Refresh()
    End Sub

    Private Sub DeleteButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteButton.Click
        ProtDataGridView.Rows.RemoveAt(ProtDataGridView.CurrentRow.Index)
        EFPanel.Refresh()
    End Sub

    Private Sub RunTextBox_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles RunTextBox.KeyDown
        If e.KeyCode = Keys.Enter Then
            EFPanel.Refresh()
        End If
    End Sub

    Private Sub ResTextBox_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ResTextBox.KeyDown
        If e.KeyCode = Keys.Enter Then
            EFPanel.Refresh()
        End If
    End Sub

    Private Sub LowestMassTextBox_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles LowestMassTextBox.KeyDown
        If e.KeyCode = Keys.Enter Then
            EFPanel.Refresh()
        End If
    End Sub

    Private Sub HpHTextBox_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles HpHTextBox.KeyDown
        If e.KeyCode = Keys.Enter Then
            EFPanel.Refresh()
        End If
    End Sub

    Private Sub LpHTextBox_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles LpHTextBox.KeyDown
        If e.KeyCode = Keys.Enter Then
            EFPanel.Refresh()
        End If
    End Sub

    Private Sub WTextBox_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles WTextBox.KeyDown
        EFPanel.Width = WTextBox.Text
        EFPanel.Height = HTextBox.Text
        EFPanel.Refresh()
    End Sub

    Private Sub HTextBox_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles HTextBox.KeyDown
        EFPanel.Width = WTextBox.Text
        EFPanel.Height = HTextBox.Text
        EFPanel.Refresh()
    End Sub

    Private Sub EFPanel_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles EFPanel.MouseDown

        Dim DetectionRadius As Integer = RTextBox.Text
        Dim found As Boolean = False

        For i = 0 To ProtDataGridView.Rows.Count - 2
            If e.X < ProtDataGridView.Rows(i).Cells(8).Value + DetectionRadius And e.X > ProtDataGridView.Rows(i).Cells(8).Value - DetectionRadius _
            And e.Y < ProtDataGridView.Rows(i).Cells(9).Value + DetectionRadius And e.Y > ProtDataGridView.Rows(i).Cells(9).Value - DetectionRadius Then
                NameTextBox.Text = ProtDataGridView.Rows(i).Cells(2).Value
                IDTextBox.Text = ProtDataGridView.Rows(i).Cells(3).Value
                ProtDataGridView.ClearSelection()
                ProtDataGridView.Rows(i).Selected = True
                ProtDataGridView.FirstDisplayedScrollingRowIndex = i
                found = True
                Exit For
            End If
        Next

        If Not found Then
            NameTextBox.Text = ""
            IDTextBox.Text = ""
        End If

    End Sub

    Private Sub HydrophobicityToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HydrophobicityToolStripMenuItem.Click
        HydroColoring = HydrophobicityToolStripMenuItem.Checked
        EFPanel.Refresh()
    End Sub

    Private Sub ShowButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShowButton.Click
        For i = 0 To ProtDataGridView.Rows.Count - 2
            ProtDataGridView.Rows(i).Cells(0).Value = True
        Next
        EFPanel.Refresh()
    End Sub

    Private Sub HideButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HideButton.Click
        For i = 0 To ProtDataGridView.Rows.Count - 2
            If Not i = ProtDataGridView.CurrentRow.Index Then
                ProtDataGridView.Rows(i).Cells(0).Value = False
            End If
        Next
        EFPanel.Refresh()
    End Sub

    Private Sub RTextBox_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles RTextBox.KeyDown
        If e.KeyCode = Keys.Enter Then
            EFPanel.Refresh()
        End If
    End Sub

    Private Sub Virtual2D_EF_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SetDefaultProperties()
    End Sub
End Class
