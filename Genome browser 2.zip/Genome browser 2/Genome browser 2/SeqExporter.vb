﻿Public Class SeqExporter

    Public MyGenomeViewer As Genome_Viewer

    Private Sub ExportButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportButton.Click

        If Not UpstreamCheckBox.Checked _
                   And Not FeatureCheckBox.Checked _
                   And Not DownstreamCheckBox.Checked _
                   And Not HeadCheckBox.Checked _
                   And Not TailCheckBox.Checked Then
            MsgBox("Select region type for export (Topology box): feature, upstream, downstream, etc...")
            Exit Sub
        End If

        If Not CodingCheckBox.Checked _
        And Not OperonsCheckBox.Checked _
        And Not StructRNAsCheckBox.Checked _
        And Not SiteCheckBox.Checked _
        And Not TSSCheckBox.Checked _
        And Not UserCheckBox.Checked Then
            MsgBox("Select feature type for export (Features box): CDS, RNA, TSS, etc...")
            Exit Sub
        End If


        ' Master.SaveFileDialog.Filter = "Text file|*.txt"



        If Master.SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then




            Dim SeqList As New List(Of String)
            Dim UpstreamLength As Integer = UpstreamTextBox.Text
            Dim DownstreamLength As Integer = DownstreamTextBox.Text
            Dim HeadLength As Integer = HeadTextBox.Text
            Dim TailLength As Integer = TailTextBox.Text

            Dim ExportFileName As String = ""


            If FormatComboBox.Text = "FASTA" Then
                ExportFileName = Master.SaveFileDialog.FileName & ".fasta"
            ElseIf FormatComboBox.Text = "Table" Then
                ExportFileName = Master.SaveFileDialog.FileName & ".txt"
            ElseIf FormatComboBox.Text = "ID/Seq" Then
                ExportFileName = Master.SaveFileDialog.FileName & ".txt"
            ElseIf FormatComboBox.Text = "DrOligo" Then
                ExportFileName = Master.SaveFileDialog.FileName & ".csv"
            End If

            Dim WriteStream As New IO.FileStream(ExportFileName, IO.FileMode.Create)
            Dim Writer As New IO.StreamWriter(WriteStream)

            Dim ExportSeq As String = ""

            Dim FeatureSeq As String = ""
            Dim UpstreamSeq As String = ""
            Dim DownstreamSeq As String = ""
            Dim HeadSeq As String = "" 'Beginning of the feature
            Dim TailSeq As String = "" 'Ending of the feature

            Dim BannedNames As String() = BannedTextBox.Text.Split(";")

            
            Dim AllowedNames As String() = SelectTextBox.Text.Split(";")

            Dim Skip As Boolean = False
            Dim Bann As Boolean = False

            Dim FeaturesList As List(Of Genome_Feature) = Nothing

            For Each Group As FeaturesAssembly In MyGenomeViewer.Features_Groups_List
                If Group.AssemblyName = SourceComboBox.Text Then
                    FeaturesList = Group.FeaturesList
                End If
            Next Group

            For Each Feature As Genome_Feature In FeaturesList
                UpstreamSeq = ""
                FeatureSeq = ""
                DownstreamSeq = ""
                HeadSeq = ""
                TailSeq = ""

                Bann = False

                If Not BannedTextBox.Text = "" Then
                    Skip = False
                    For Each BannedName As String In BannedNames
                        If Feature.Name.Contains(BannedName) Or Feature.Description.Contains(BannedName) Then
                            Skip = True
                            Bann = True
                            Exit For
                        End If
                    Next
                End If


                If SelectTextBox.Text.Length > 0 Then

                    If Not Bann Then
                        Skip = True
                        For Each AllowedName As String In AllowedNames
                            If Feature.Name.Contains(AllowedName) Or Feature.Description.Contains(AllowedName) Then

                                Skip = False
                                Exit For
                            End If
                        Next AllowedName
                    End If

                End If



                If Not Skip Then


                    If (Feature.Type = 1 And CodingCheckBox.Checked = True) Or _
                    (Feature.Type = 10 And UserCheckBox.Checked = True) Or _
                    (Feature.Type = 12 And OperonsCheckBox.Checked = True) Or _
                    (Feature.Type = 2 And StructRNAsCheckBox.Checked = True) Or _
                    (Feature.Type = 3 And SiteCheckBox.Checked = True) Or _
                    (Feature.Type = 5 And TSSCheckBox.Checked = True) Or _
                    (Feature.Type = 7 And UserCheckBox.Checked = True) Or _
                    (Feature.Type = 8 And UserCheckBox.Checked = True) Or _
                    (Feature.Type = 11 And UserCheckBox.Checked = True) Then

                        ExportSeq = ""

                        If FeatureCheckBox.Checked Then
                            FeatureSeq = MyGenomeViewer.GetFeatureSequence(Feature)
                            ExportSeq = FeatureSeq

                            If Feature.Type = 8 And Not Feature.Sequence = "" Then
                                ExportSeq = Feature.Sequence & ExportSeq
                            End If

                        ElseIf UpstreamCheckBox.Checked And DownstreamCheckBox.Checked Then
                            ExportSeq = "---"
                        End If

                        If UpstreamCheckBox.Checked Then
                            If Feature.Direction = 1 Then
                                UpstreamSeq = DataIO.RetrieveSeqFromCache(MyGenomeViewer.Genome_Sequence, Feature.AbsoluteStart - UpstreamLength, Feature.AbsoluteStart - 1)
                            ElseIf Feature.Direction = 2 Then
                                UpstreamSeq = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(MyGenomeViewer.Genome_Sequence, Feature.AbsoluteEnd + 1, Feature.AbsoluteEnd + UpstreamLength))
                            Else
                                UpstreamSeq = DataIO.RetrieveSeqFromCache(MyGenomeViewer.Genome_Sequence, Feature.AbsoluteStart - UpstreamLength, Feature.AbsoluteStart - 1)
                            End If

                            ExportSeq = UpstreamSeq & ExportSeq

                        End If

                        If DownstreamCheckBox.Checked Then
                            If Feature.Direction = 1 Then
                                DownstreamSeq = DataIO.RetrieveSeqFromCache(MyGenomeViewer.Genome_Sequence, Feature.AbsoluteEnd + 1, Feature.AbsoluteEnd + DownstreamLength)
                            ElseIf Feature.Direction = 2 Then
                                DownstreamSeq = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(MyGenomeViewer.Genome_Sequence, Feature.AbsoluteStart - DownstreamLength, Feature.AbsoluteStart - 1))
                            Else
                                DownstreamSeq = DataIO.RetrieveSeqFromCache(MyGenomeViewer.Genome_Sequence, Feature.AbsoluteEnd + 1, Feature.AbsoluteEnd + DownstreamLength)
                            End If

                            ExportSeq &= DownstreamSeq

                        End If

                        If HeadCheckBox.Checked Then
                            If Feature.Direction = 1 Then
                                HeadSeq = DataIO.RetrieveSeqFromCache(MyGenomeViewer.Genome_Sequence, Feature.AbsoluteStart, Feature.AbsoluteStart + HeadLength - 1)
                            ElseIf Feature.Direction = 2 Then
                                HeadSeq = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(MyGenomeViewer.Genome_Sequence, Feature.AbsoluteEnd - HeadLength + 1, Feature.AbsoluteEnd))
                            Else
                                HeadSeq = DataIO.RetrieveSeqFromCache(MyGenomeViewer.Genome_Sequence, Feature.AbsoluteStart, Feature.AbsoluteStart + HeadLength - 1)
                            End If

                            ExportSeq = HeadSeq
                        End If

                        If TailCheckBox.Checked Then
                            If Feature.Direction = 1 Then
                                TailSeq = DataIO.RetrieveSeqFromCache(MyGenomeViewer.Genome_Sequence, Feature.AbsoluteEnd - TailLength, Feature.AbsoluteEnd - 1)
                            ElseIf Feature.Direction = 2 Then
                                TailSeq = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(MyGenomeViewer.Genome_Sequence, Feature.AbsoluteStart, Feature.AbsoluteStart + TailLength - 1))
                            Else
                                TailSeq = DataIO.RetrieveSeqFromCache(MyGenomeViewer.Genome_Sequence, Feature.AbsoluteEnd - TailLength, Feature.AbsoluteEnd - 1)
                            End If

                            ExportSeq = TailSeq
                        End If


                        If FormatComboBox.Text = "FASTA" Then
                            Writer.WriteLine(">" & Feature.TAG & "_" & Feature.Name)
                            Writer.WriteLine(ExportSeq)
                        ElseIf FormatComboBox.Text = "Table" Then
                            Writer.WriteLine(Feature.TAG & Chr(9) & Feature.Name & Chr(9) & Feature.Description & Chr(9) & ExportSeq)
                        ElseIf FormatComboBox.Text = "ID/Seq" Then
                            Writer.WriteLine(Feature.TAG & Chr(9) & ExportSeq)
                        ElseIf FormatComboBox.Text = "DrOligo" Then
                            Writer.WriteLine(ExportSeq & ",DMT ON," & Feature.TAG & ",CUSTOMER")
                        End If

                    End If





                End If

            Next



            Writer.Close()
            WriteStream.Close()
            Writer.Dispose()
            WriteStream.Dispose()

            MsgBox("Export completed!")

        End If

        Master.SaveFileDialog.Filter = ""

    End Sub

    Private Sub SeqExporter_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SourceComboBox.Items.Clear()
        For Each Group As FeaturesAssembly In MyGenomeViewer.Features_Groups_List
            SourceComboBox.Items.Add(Group.AssemblyName)
        Next Group
    End Sub

End Class