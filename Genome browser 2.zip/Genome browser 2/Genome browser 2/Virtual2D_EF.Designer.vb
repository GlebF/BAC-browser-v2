﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Virtual2D_EF
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Virtual2D_EF))
        Me.IDCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ControlToolStrip = New System.Windows.Forms.ToolStrip
        Me.RefreshButton = New System.Windows.Forms.ToolStripButton
        Me.ZoomInButton = New System.Windows.Forms.ToolStripButton
        Me.ZoomOutButton = New System.Windows.Forms.ToolStripButton
        Me.GridOnOffButton = New System.Windows.Forms.ToolStripDropDownButton
        Me.GridToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HydrophobicityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.DeleteButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel
        Me.LowestMassTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripLabel4 = New System.Windows.Forms.ToolStripLabel
        Me.LpHTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripLabel5 = New System.Windows.Forms.ToolStripLabel
        Me.HpHTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel
        Me.WTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripLabel3 = New System.Windows.Forms.ToolStripLabel
        Me.HTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripLabel6 = New System.Windows.Forms.ToolStripLabel
        Me.RunTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripLabel7 = New System.Windows.Forms.ToolStripLabel
        Me.ResTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripLabel10 = New System.Windows.Forms.ToolStripLabel
        Me.RTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.pI_Col = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ProtNameCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.MW_Col = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ShowProtLabelCol = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.ShowProtCol = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.ProtDataGridView = New System.Windows.Forms.DataGridView
        Me.HCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ColorCol = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.XCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.YCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.EFPanel = New System.Windows.Forms.Panel
        Me.ToolStripLabel8 = New System.Windows.Forms.ToolStripLabel
        Me.NameTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripLabel9 = New System.Windows.Forms.ToolStripLabel
        Me.HideButton = New System.Windows.Forms.ToolStripButton
        Me.ShowButton = New System.Windows.Forms.ToolStripButton
        Me.FinderToolStrip = New System.Windows.Forms.ToolStrip
        Me.IDTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ControlToolStrip.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.ProtDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FinderToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'IDCol
        '
        Me.IDCol.HeaderText = "ID"
        Me.IDCol.Name = "IDCol"
        Me.IDCol.Width = 50
        '
        'ControlToolStrip
        '
        Me.ControlToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RefreshButton, Me.ZoomInButton, Me.ZoomOutButton, Me.GridOnOffButton, Me.ToolStripSeparator2, Me.DeleteButton, Me.ToolStripSeparator1, Me.ToolStripLabel1, Me.LowestMassTextBox, Me.ToolStripLabel4, Me.LpHTextBox, Me.ToolStripLabel5, Me.HpHTextBox, Me.ToolStripLabel2, Me.WTextBox, Me.ToolStripLabel3, Me.HTextBox, Me.ToolStripLabel6, Me.RunTextBox, Me.ToolStripLabel7, Me.ResTextBox, Me.ToolStripLabel10, Me.RTextBox})
        Me.ControlToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.ControlToolStrip.Name = "ControlToolStrip"
        Me.ControlToolStrip.Size = New System.Drawing.Size(911, 25)
        Me.ControlToolStrip.TabIndex = 3
        Me.ControlToolStrip.Text = "ToolStrip1"
        '
        'RefreshButton
        '
        Me.RefreshButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.RefreshButton.Image = CType(resources.GetObject("RefreshButton.Image"), System.Drawing.Image)
        Me.RefreshButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.RefreshButton.Name = "RefreshButton"
        Me.RefreshButton.Size = New System.Drawing.Size(23, 22)
        Me.RefreshButton.Text = "Refresh"
        '
        'ZoomInButton
        '
        Me.ZoomInButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ZoomInButton.Image = CType(resources.GetObject("ZoomInButton.Image"), System.Drawing.Image)
        Me.ZoomInButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ZoomInButton.Name = "ZoomInButton"
        Me.ZoomInButton.Size = New System.Drawing.Size(23, 22)
        Me.ZoomInButton.Text = "Zoom in"
        '
        'ZoomOutButton
        '
        Me.ZoomOutButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ZoomOutButton.Image = CType(resources.GetObject("ZoomOutButton.Image"), System.Drawing.Image)
        Me.ZoomOutButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ZoomOutButton.Name = "ZoomOutButton"
        Me.ZoomOutButton.Size = New System.Drawing.Size(23, 22)
        Me.ZoomOutButton.Text = "Zoom out"
        '
        'GridOnOffButton
        '
        Me.GridOnOffButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.GridOnOffButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GridToolStripMenuItem, Me.HydrophobicityToolStripMenuItem})
        Me.GridOnOffButton.Image = CType(resources.GetObject("GridOnOffButton.Image"), System.Drawing.Image)
        Me.GridOnOffButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.GridOnOffButton.Name = "GridOnOffButton"
        Me.GridOnOffButton.Size = New System.Drawing.Size(29, 22)
        Me.GridOnOffButton.Text = "Grid"
        '
        'GridToolStripMenuItem
        '
        Me.GridToolStripMenuItem.Checked = True
        Me.GridToolStripMenuItem.CheckOnClick = True
        Me.GridToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.GridToolStripMenuItem.Name = "GridToolStripMenuItem"
        Me.GridToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.GridToolStripMenuItem.Text = "Grid"
        '
        'HydrophobicityToolStripMenuItem
        '
        Me.HydrophobicityToolStripMenuItem.CheckOnClick = True
        Me.HydrophobicityToolStripMenuItem.Name = "HydrophobicityToolStripMenuItem"
        Me.HydrophobicityToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.HydrophobicityToolStripMenuItem.Text = "Hydrophobicity"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'DeleteButton
        '
        Me.DeleteButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DeleteButton.Image = CType(resources.GetObject("DeleteButton.Image"), System.Drawing.Image)
        Me.DeleteButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DeleteButton.Name = "DeleteButton"
        Me.DeleteButton.Size = New System.Drawing.Size(23, 22)
        Me.DeleteButton.Text = "Delete current"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(108, 22)
        Me.ToolStripLabel1.Text = "Lowest mass (kDa):"
        '
        'LowestMassTextBox
        '
        Me.LowestMassTextBox.Name = "LowestMassTextBox"
        Me.LowestMassTextBox.Size = New System.Drawing.Size(30, 25)
        Me.LowestMassTextBox.Text = "5"
        '
        'ToolStripLabel4
        '
        Me.ToolStripLabel4.Name = "ToolStripLabel4"
        Me.ToolStripLabel4.Size = New System.Drawing.Size(66, 22)
        Me.ToolStripLabel4.Text = "Lowest pH:"
        '
        'LpHTextBox
        '
        Me.LpHTextBox.Name = "LpHTextBox"
        Me.LpHTextBox.Size = New System.Drawing.Size(30, 25)
        Me.LpHTextBox.Text = "3"
        '
        'ToolStripLabel5
        '
        Me.ToolStripLabel5.Name = "ToolStripLabel5"
        Me.ToolStripLabel5.Size = New System.Drawing.Size(70, 22)
        Me.ToolStripLabel5.Text = "Highest pH:"
        '
        'HpHTextBox
        '
        Me.HpHTextBox.Name = "HpHTextBox"
        Me.HpHTextBox.Size = New System.Drawing.Size(30, 25)
        Me.HpHTextBox.Text = "10"
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(42, 22)
        Me.ToolStripLabel2.Text = "Width:"
        '
        'WTextBox
        '
        Me.WTextBox.Name = "WTextBox"
        Me.WTextBox.Size = New System.Drawing.Size(30, 25)
        Me.WTextBox.Text = "500"
        '
        'ToolStripLabel3
        '
        Me.ToolStripLabel3.Name = "ToolStripLabel3"
        Me.ToolStripLabel3.Size = New System.Drawing.Size(46, 22)
        Me.ToolStripLabel3.Text = "Height:"
        '
        'HTextBox
        '
        Me.HTextBox.Name = "HTextBox"
        Me.HTextBox.Size = New System.Drawing.Size(30, 25)
        Me.HTextBox.Text = "400"
        '
        'ToolStripLabel6
        '
        Me.ToolStripLabel6.Name = "ToolStripLabel6"
        Me.ToolStripLabel6.Size = New System.Drawing.Size(85, 22)
        Me.ToolStripLabel6.Text = "Run efficiency:"
        '
        'RunTextBox
        '
        Me.RunTextBox.Name = "RunTextBox"
        Me.RunTextBox.Size = New System.Drawing.Size(30, 25)
        Me.RunTextBox.Text = "16,6"
        '
        'ToolStripLabel7
        '
        Me.ToolStripLabel7.Name = "ToolStripLabel7"
        Me.ToolStripLabel7.Size = New System.Drawing.Size(62, 22)
        Me.ToolStripLabel7.Text = "Resistance"
        '
        'ResTextBox
        '
        Me.ResTextBox.Name = "ResTextBox"
        Me.ResTextBox.Size = New System.Drawing.Size(30, 25)
        Me.ResTextBox.Text = "1,26"
        '
        'ToolStripLabel10
        '
        Me.ToolStripLabel10.Name = "ToolStripLabel10"
        Me.ToolStripLabel10.Size = New System.Drawing.Size(17, 22)
        Me.ToolStripLabel10.Text = "R:"
        '
        'RTextBox
        '
        Me.RTextBox.Name = "RTextBox"
        Me.RTextBox.Size = New System.Drawing.Size(30, 25)
        Me.RTextBox.Text = "2"
        '
        'pI_Col
        '
        Me.pI_Col.HeaderText = "pI"
        Me.pI_Col.Name = "pI_Col"
        Me.pI_Col.Width = 40
        '
        'ProtNameCol
        '
        Me.ProtNameCol.HeaderText = "Name"
        Me.ProtNameCol.Name = "ProtNameCol"
        Me.ProtNameCol.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ProtNameCol.Width = 50
        '
        'MW_Col
        '
        Me.MW_Col.HeaderText = "MW"
        Me.MW_Col.Name = "MW_Col"
        Me.MW_Col.Width = 40
        '
        'ShowProtLabelCol
        '
        Me.ShowProtLabelCol.HeaderText = ""
        Me.ShowProtLabelCol.Name = "ShowProtLabelCol"
        Me.ShowProtLabelCol.Width = 30
        '
        'ShowProtCol
        '
        Me.ShowProtCol.HeaderText = ""
        Me.ShowProtCol.Name = "ShowProtCol"
        Me.ShowProtCol.Width = 30
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 50)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.ProtDataGridView)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.AutoScroll = True
        Me.SplitContainer1.Panel2.Controls.Add(Me.EFPanel)
        Me.SplitContainer1.Size = New System.Drawing.Size(911, 386)
        Me.SplitContainer1.SplitterDistance = 399
        Me.SplitContainer1.TabIndex = 4
        '
        'ProtDataGridView
        '
        Me.ProtDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ProtDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ShowProtCol, Me.ShowProtLabelCol, Me.ProtNameCol, Me.IDCol, Me.pI_Col, Me.MW_Col, Me.HCol, Me.ColorCol, Me.XCol, Me.YCol})
        Me.ProtDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ProtDataGridView.Location = New System.Drawing.Point(0, 0)
        Me.ProtDataGridView.Name = "ProtDataGridView"
        Me.ProtDataGridView.Size = New System.Drawing.Size(399, 386)
        Me.ProtDataGridView.TabIndex = 0
        '
        'HCol
        '
        Me.HCol.HeaderText = "H"
        Me.HCol.Name = "HCol"
        Me.HCol.Width = 40
        '
        'ColorCol
        '
        Me.ColorCol.HeaderText = "Color"
        Me.ColorCol.Items.AddRange(New Object() {"Red", "Green", "Blue", "Yellow"})
        Me.ColorCol.Name = "ColorCol"
        Me.ColorCol.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ColorCol.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.ColorCol.Width = 60
        '
        'XCol
        '
        Me.XCol.HeaderText = "X"
        Me.XCol.Name = "XCol"
        Me.XCol.Visible = False
        Me.XCol.Width = 80
        '
        'YCol
        '
        Me.YCol.HeaderText = "Y"
        Me.YCol.Name = "YCol"
        Me.YCol.Visible = False
        Me.YCol.Width = 80
        '
        'EFPanel
        '
        Me.EFPanel.BackColor = System.Drawing.Color.White
        Me.EFPanel.Location = New System.Drawing.Point(0, 0)
        Me.EFPanel.Name = "EFPanel"
        Me.EFPanel.Size = New System.Drawing.Size(500, 400)
        Me.EFPanel.TabIndex = 0
        '
        'ToolStripLabel8
        '
        Me.ToolStripLabel8.Name = "ToolStripLabel8"
        Me.ToolStripLabel8.Size = New System.Drawing.Size(42, 22)
        Me.ToolStripLabel8.Text = "Name:"
        '
        'NameTextBox
        '
        Me.NameTextBox.Name = "NameTextBox"
        Me.NameTextBox.Size = New System.Drawing.Size(80, 25)
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel9
        '
        Me.ToolStripLabel9.Name = "ToolStripLabel9"
        Me.ToolStripLabel9.Size = New System.Drawing.Size(63, 22)
        Me.ToolStripLabel9.Text = "Locus Tag:"
        '
        'HideButton
        '
        Me.HideButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HideButton.Image = CType(resources.GetObject("HideButton.Image"), System.Drawing.Image)
        Me.HideButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HideButton.Name = "HideButton"
        Me.HideButton.Size = New System.Drawing.Size(23, 22)
        Me.HideButton.Text = "Hide all but this"
        '
        'ShowButton
        '
        Me.ShowButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ShowButton.Image = CType(resources.GetObject("ShowButton.Image"), System.Drawing.Image)
        Me.ShowButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ShowButton.Name = "ShowButton"
        Me.ShowButton.Size = New System.Drawing.Size(23, 22)
        Me.ShowButton.Text = "Show all"
        '
        'FinderToolStrip
        '
        Me.FinderToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShowButton, Me.HideButton, Me.ToolStripSeparator3, Me.ToolStripLabel8, Me.NameTextBox, Me.ToolStripLabel9, Me.IDTextBox})
        Me.FinderToolStrip.Location = New System.Drawing.Point(0, 25)
        Me.FinderToolStrip.Name = "FinderToolStrip"
        Me.FinderToolStrip.Size = New System.Drawing.Size(911, 25)
        Me.FinderToolStrip.TabIndex = 5
        Me.FinderToolStrip.Text = "ToolStrip1"
        '
        'IDTextBox
        '
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.Size = New System.Drawing.Size(80, 25)
        '
        'Virtual2D_EF
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.FinderToolStrip)
        Me.Controls.Add(Me.ControlToolStrip)
        Me.Name = "Virtual2D_EF"
        Me.Size = New System.Drawing.Size(911, 436)
        Me.ControlToolStrip.ResumeLayout(False)
        Me.ControlToolStrip.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.ProtDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FinderToolStrip.ResumeLayout(False)
        Me.FinderToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents IDCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ControlToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents RefreshButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ZoomInButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ZoomOutButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents GridOnOffButton As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents GridToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HydrophobicityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DeleteButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents LowestMassTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripLabel4 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents LpHTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripLabel5 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents HpHTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripLabel2 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents WTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripLabel3 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents HTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripLabel6 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents RunTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripLabel7 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ResTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripLabel10 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents RTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents pI_Col As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProtNameCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MW_Col As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ShowProtLabelCol As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents ShowProtCol As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents ProtDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents HCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ColorCol As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents XCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents YCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EFPanel As System.Windows.Forms.Panel
    Friend WithEvents ToolStripLabel8 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents NameTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel9 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents HideButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ShowButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents FinderToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents IDTextBox As System.Windows.Forms.ToolStripTextBox

End Class
