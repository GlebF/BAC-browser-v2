﻿Public Class PWM
    Private lPWM_Table As New List(Of PWM_cell)

    Public Property PWM_Table() As List(Of PWM_cell)
        Get
            PWM_Table = lPWM_Table
        End Get
        Set(ByVal value As List(Of PWM_cell))
            lPWM_Table = value
        End Set
    End Property

    Public Function GetMaxWeight()
        Dim Result As Single = 0

        Dim Weights As New List(Of Single)

        For Each Position As PWM_cell In lPWM_Table
            Weights.Clear()
            Weights.Add(Position.A_Weight)
            Weights.Add(Position.T_Weight)
            Weights.Add(Position.G_Weight)
            Weights.Add(Position.C_Weight)
            Result += Bioinformatics.Maximum(Weights)
        Next

        Return Result
    End Function

    Public Function GetMinWeight()
        Dim Result As Single = 0

        Dim Weights As New List(Of Single)

        For Each Position As PWM_cell In lPWM_Table
            Weights.Clear()
            Weights.Add(Position.A_Weight)
            Weights.Add(Position.T_Weight)
            Weights.Add(Position.G_Weight)
            Weights.Add(Position.C_Weight)
            Result += Bioinformatics.Minimum(Weights)
        Next

        Return Result
    End Function

    Public Function GetMaxWeightAt(ByVal index As Integer)

        Dim Weights As New List(Of Single)
        Weights.Add(lPWM_Table(index).A_Weight)
        Weights.Add(lPWM_Table(index).T_Weight)
        Weights.Add(lPWM_Table(index).G_Weight)
        Weights.Add(lPWM_Table(index).C_Weight)

        Dim Result As Single = Weights(0)

        For Each Weight As Single In Weights
            If Weight > Result Then
                Result = Weight
            End If
        Next

        Return Result
    End Function

    Public Function GetMinWeightAt(ByVal index As Integer)

        Dim Weights As New List(Of Single)
        Weights.Add(lPWM_Table(index).A_Weight)
        Weights.Add(lPWM_Table(index).T_Weight)
        Weights.Add(lPWM_Table(index).G_Weight)
        Weights.Add(lPWM_Table(index).C_Weight)

        Dim Result As Single = Weights(0)

        For Each Weight As Single In Weights
            If Weight < Result Then
                Result = Weight
            End If
        Next

        Return Result
    End Function

    Public Function GetMaxRange()
        Dim Result As Single = 0
        Dim LocalRange As Single = 0

        For i = 0 To lPWM_Table.Count - 1
            LocalRange = GetMaxWeightAt(i) - GetMinWeightAt(i)
            If LocalRange > Result Then
                Result = LocalRange
            End If
        Next

        Return Result
    End Function

    Public Function GetRangeAt(ByVal index As Integer)
        Return GetMaxWeightAt(index) - GetMinWeightAt(index)
    End Function

End Class
