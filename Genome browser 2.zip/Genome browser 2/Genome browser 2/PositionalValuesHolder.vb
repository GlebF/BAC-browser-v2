﻿Public Class PositionalValuesHolder

    Private strHolderName As String
    Private shStrand As Short ' Plus, minus or undefined
    Private intValues As New List(Of Integer)
    Private sglLogValues As New List(Of Single)
    Private bVisible As Boolean = True
    Private colDrawColor As Color
    Private shScale As Short 'Logarithm or linear
    Private strGroup As String = "default" 'Group of values like for plus and minus coverage
    Private bShowOnSeparateLane As Boolean = False

    'Direction list
    '0 - None
    '1 - Plus
    '2 - Minus
    '3 - Symmetrical
    '4 - Hairpin plus/minus
    '5 - Hairpin minus/plus

    Public Property Holder_Name() As String
        Get
            Holder_Name = strHolderName
        End Get
        Set(ByVal value As String)
            strHolderName = value
        End Set
    End Property

    Public Property Strand() As Short
        Get
            Strand = shStrand
        End Get
        Set(ByVal value As Short)
            shStrand = value
        End Set
    End Property

    Public Property Positional_Values() As List(Of Integer)
        Get
            Positional_Values = intValues
        End Get
        Set(ByVal value As List(Of Integer))
            intValues = value
        End Set
    End Property

    Public Property Draw_Color() As Color
        Get
            Draw_Color = colDrawColor
        End Get
        Set(ByVal value As Color)
            colDrawColor = value
        End Set
    End Property

    Public Property Scale() As Short
        Get
            Scale = shScale
        End Get
        Set(ByVal value As Short)
            shScale = value
        End Set
    End Property

    Public Property Log_Values() As List(Of Single)
        Get
            Log_Values = sglLogValues
        End Get
        Set(ByVal value As List(Of Single))
            sglLogValues = value
        End Set
    End Property

    Public Property Visible() As Boolean
        Get
            Visible = bVisible
        End Get
        Set(ByVal value As Boolean)
            bVisible = value
        End Set
    End Property

    Public Property Group() As String
        Get
            Group = strGroup
        End Get
        Set(ByVal value As String)
            strGroup = value
        End Set
    End Property

    Public Property ShowOnSeparateLane() As Boolean
        Get
            ShowOnSeparateLane = bShowOnSeparateLane
        End Get
        Set(ByVal value As Boolean)
            bShowOnSeparateLane = value
        End Set
    End Property

    'Scale list
    '0 - Linear
    '1 - Log

    Public Sub New(ByVal Holder_Name As String, ByVal Strand As Short, ByVal Positional_Values As List(Of Integer), ByVal Draw_Color As Color, ByVal Scale As Short)
        strHolderName = Holder_Name
        shStrand = Strand
        intValues = Positional_Values
        colDrawColor = Draw_Color
        shScale = Scale

        'If Scale = 1 Then
        CreateLogList()
        'End If

    End Sub

    Public Sub CreateLogList()
        sglLogValues.Clear()
        For Each Val As Integer In intValues
            If Val = 0 Then
                sglLogValues.Add(0)
            Else
                sglLogValues.Add(Math.Log(Val) / Math.Log(2))
            End If
        Next
    End Sub

End Class
