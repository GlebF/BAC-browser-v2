﻿Public Class SequenceMarker
    Private intAbsolutePosition As Integer = 0
    Private intProjectionPosition As Integer = 0
    Private bPaired As Boolean = False
    Private cntPartner As SequenceMarker
    Private bCount As Boolean = False 'To cross out partners
    Private bSelected As Boolean = False
    Private bRole As Boolean = False
    'False for start
    'True for end
    Private bInvertedView As Boolean
    Private bEndOfSeq As Boolean = False


    Public Property AbsolutePosition() As Integer
        Get
            AbsolutePosition = intAbsolutePosition
        End Get
        Set(ByVal value As Integer)
            intAbsolutePosition = value
        End Set
    End Property

    Public Property ProjectionPosition() As Integer
        Get
            ProjectionPosition = intProjectionPosition
        End Get
        Set(ByVal value As Integer)
            intProjectionPosition = value
        End Set
    End Property

    Public Property Paired() As Boolean
        Get
            Paired = bPaired
        End Get
        Set(ByVal value As Boolean)
            bPaired = value
        End Set
    End Property

    Public Property MyPartner() As SequenceMarker
        Get
            MyPartner = cntPartner
        End Get
        Set(ByVal value As SequenceMarker)
            cntPartner = value
        End Set
    End Property

    Public Property Selected() As Boolean
        Get
            Selected = bSelected
        End Get
        Set(ByVal value As Boolean)
            bSelected = value
        End Set
    End Property

    Public Property Counted() As Boolean
        Get
            Counted = bCount
        End Get
        Set(ByVal value As Boolean)
            bCount = value
        End Set
    End Property

    Public Property Role() As Boolean
        Get
            Role = bRole
        End Get
        Set(ByVal value As Boolean)
            bRole = value
        End Set
    End Property

    Public Property InvertedView() As Boolean
        Get
            InvertedView = bInvertedView
        End Get
        Set(ByVal value As Boolean)
            bInvertedView = value
        End Set
    End Property

    Public Property EndOfSeq() As Boolean
        Get
            EndOfSeq = bEndOfSeq
        End Get
        Set(ByVal value As Boolean)
            bEndOfSeq = value
        End Set
    End Property

    Public Function GetStartPos()
        If Not IsNothing(cntPartner) Then
            If bRole Then
                Return cntPartner.AbsolutePosition
            Else
                Return intAbsolutePosition
            End If
        Else
            Return Nothing
        End If
    End Function

    Public Function GetEndPos()
        If Not IsNothing(cntPartner) Then
            If bRole Then
                Return intAbsolutePosition
            Else
                Return cntPartner.AbsolutePosition
            End If
        Else
            Return Nothing
        End If
    End Function

    Public Function GetCoveredRange(ByVal SequenceLength As Integer)
        If Not IsNothing(cntPartner) Then
            Dim StartPos As Integer = GetStartPos()
            Dim EndPos As Integer = GetEndPos()

            If EndPos > StartPos Then
                Return EndPos - StartPos
            Else
                Return SequenceLength - StartPos + EndPos
            End If

        Else
            Return 0
        End If
    End Function

    Public Function GetStartMarker()
        If Not IsNothing(cntPartner) Then
            If bRole Then
                Return cntPartner
            Else
                Return Me
            End If
        Else
            Return Nothing
        End If
    End Function

    Public Function GetEndMarker()
        If Not IsNothing(cntPartner) Then
            If bRole Then
                Return Me
            Else
                Return cntPartner
            End If
        Else
            Return Nothing
        End If
    End Function

End Class
