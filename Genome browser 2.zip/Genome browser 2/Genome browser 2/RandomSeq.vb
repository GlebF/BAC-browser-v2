﻿Public Class RandomSeq

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        SeqTextBox.Text = ""

        Dim Lim As Integer = LengthTextBox.Text

        Dim A As Integer = 0
        Dim G As Integer = 0
        Dim T As Integer = 0
        Dim C As Integer = 0

        Dim CurrentChar As Char = ""


        For i = 0 To Lim - 1

            If Bioinformatics.Get_Random(1, 100) <= GCTextBox.Text Then 'char = G or C

                If Bioinformatics.Get_Random(0, 1) = 0 Then
                    G += 1
                    CurrentChar = "G"
                Else
                    C += 1
                    CurrentChar = "C"
                End If

            Else 'char = A or T

                If Bioinformatics.Get_Random(0, 1) = 0 Then
                    A += 1
                    CurrentChar = "A"
                Else
                    T += 1
                    CurrentChar = "T"
                End If

            End If

            SeqTextBox.Text &= CurrentChar

        Next


        ATextBox.Text = A
        GTextBox.Text = G
        TTextBox.Text = T
        CTextBox.Text = C
        ActualGCTextBox.Text = 100 * (G + C) / Lim

    End Sub


End Class