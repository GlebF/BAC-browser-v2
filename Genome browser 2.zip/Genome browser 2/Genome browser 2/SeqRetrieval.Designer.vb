﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SeqRetrieval
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.RevRadioButton = New System.Windows.Forms.RadioButton
        Me.DownLowerCheckBox = New System.Windows.Forms.CheckBox
        Me.ForRadioButton = New System.Windows.Forms.RadioButton
        Me.ORFLowerCheckBox = New System.Windows.Forms.CheckBox
        Me.UpLowerCheckBox = New System.Windows.Forms.CheckBox
        Me.DownTextBox = New System.Windows.Forms.TextBox
        Me.UpTextBox = New System.Windows.Forms.TextBox
        Me.DownstreamCheckBox = New System.Windows.Forms.CheckBox
        Me.UpstreamCheckBox = New System.Windows.Forms.CheckBox
        Me.ORFCheckBox = New System.Windows.Forms.CheckBox
        Me.EscButton = New System.Windows.Forms.Button
        Me.OKButton = New System.Windows.Forms.Button
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RevRadioButton)
        Me.GroupBox2.Controls.Add(Me.DownLowerCheckBox)
        Me.GroupBox2.Controls.Add(Me.ForRadioButton)
        Me.GroupBox2.Controls.Add(Me.ORFLowerCheckBox)
        Me.GroupBox2.Controls.Add(Me.UpLowerCheckBox)
        Me.GroupBox2.Controls.Add(Me.DownTextBox)
        Me.GroupBox2.Controls.Add(Me.UpTextBox)
        Me.GroupBox2.Controls.Add(Me.DownstreamCheckBox)
        Me.GroupBox2.Controls.Add(Me.UpstreamCheckBox)
        Me.GroupBox2.Controls.Add(Me.ORFCheckBox)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(580, 95)
        Me.GroupBox2.TabIndex = 19
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Sequence"
        '
        'RevRadioButton
        '
        Me.RevRadioButton.AutoSize = True
        Me.RevRadioButton.Location = New System.Drawing.Point(124, 65)
        Me.RevRadioButton.Name = "RevRadioButton"
        Me.RevRadioButton.Size = New System.Drawing.Size(112, 17)
        Me.RevRadioButton.TabIndex = 6
        Me.RevRadioButton.TabStop = True
        Me.RevRadioButton.Text = "Get reverse strand"
        Me.RevRadioButton.UseVisualStyleBackColor = True
        '
        'DownLowerCheckBox
        '
        Me.DownLowerCheckBox.AutoSize = True
        Me.DownLowerCheckBox.Location = New System.Drawing.Point(351, 42)
        Me.DownLowerCheckBox.Name = "DownLowerCheckBox"
        Me.DownLowerCheckBox.Size = New System.Drawing.Size(81, 17)
        Me.DownLowerCheckBox.TabIndex = 11
        Me.DownLowerCheckBox.Text = "Lower case"
        Me.DownLowerCheckBox.UseVisualStyleBackColor = True
        '
        'ForRadioButton
        '
        Me.ForRadioButton.AutoSize = True
        Me.ForRadioButton.Location = New System.Drawing.Point(6, 65)
        Me.ForRadioButton.Name = "ForRadioButton"
        Me.ForRadioButton.Size = New System.Drawing.Size(112, 17)
        Me.ForRadioButton.TabIndex = 5
        Me.ForRadioButton.TabStop = True
        Me.ForRadioButton.Text = "Get forward strand"
        Me.ForRadioButton.UseVisualStyleBackColor = True
        '
        'ORFLowerCheckBox
        '
        Me.ORFLowerCheckBox.AutoSize = True
        Me.ORFLowerCheckBox.Location = New System.Drawing.Point(216, 42)
        Me.ORFLowerCheckBox.Name = "ORFLowerCheckBox"
        Me.ORFLowerCheckBox.Size = New System.Drawing.Size(81, 17)
        Me.ORFLowerCheckBox.TabIndex = 10
        Me.ORFLowerCheckBox.Text = "Lower case"
        Me.ORFLowerCheckBox.UseVisualStyleBackColor = True
        '
        'UpLowerCheckBox
        '
        Me.UpLowerCheckBox.AutoSize = True
        Me.UpLowerCheckBox.Location = New System.Drawing.Point(6, 42)
        Me.UpLowerCheckBox.Name = "UpLowerCheckBox"
        Me.UpLowerCheckBox.Size = New System.Drawing.Size(81, 17)
        Me.UpLowerCheckBox.TabIndex = 9
        Me.UpLowerCheckBox.Text = "Lower case"
        Me.UpLowerCheckBox.UseVisualStyleBackColor = True
        '
        'DownTextBox
        '
        Me.DownTextBox.Location = New System.Drawing.Point(519, 17)
        Me.DownTextBox.Name = "DownTextBox"
        Me.DownTextBox.Size = New System.Drawing.Size(50, 20)
        Me.DownTextBox.TabIndex = 7
        Me.DownTextBox.Text = "0"
        '
        'UpTextBox
        '
        Me.UpTextBox.Location = New System.Drawing.Point(160, 17)
        Me.UpTextBox.Name = "UpTextBox"
        Me.UpTextBox.Size = New System.Drawing.Size(50, 20)
        Me.UpTextBox.TabIndex = 8
        Me.UpTextBox.Text = "0"
        '
        'DownstreamCheckBox
        '
        Me.DownstreamCheckBox.AutoSize = True
        Me.DownstreamCheckBox.Location = New System.Drawing.Point(351, 19)
        Me.DownstreamCheckBox.Name = "DownstreamCheckBox"
        Me.DownstreamCheckBox.Size = New System.Drawing.Size(162, 17)
        Me.DownstreamCheckBox.TabIndex = 2
        Me.DownstreamCheckBox.Text = "Add downstream nucleotides"
        Me.DownstreamCheckBox.UseVisualStyleBackColor = True
        '
        'UpstreamCheckBox
        '
        Me.UpstreamCheckBox.AutoSize = True
        Me.UpstreamCheckBox.Location = New System.Drawing.Point(6, 19)
        Me.UpstreamCheckBox.Name = "UpstreamCheckBox"
        Me.UpstreamCheckBox.Size = New System.Drawing.Size(148, 17)
        Me.UpstreamCheckBox.TabIndex = 4
        Me.UpstreamCheckBox.Text = "Add upstream nucleotides"
        Me.UpstreamCheckBox.UseVisualStyleBackColor = True
        '
        'ORFCheckBox
        '
        Me.ORFCheckBox.AutoSize = True
        Me.ORFCheckBox.Location = New System.Drawing.Point(216, 19)
        Me.ORFCheckBox.Name = "ORFCheckBox"
        Me.ORFCheckBox.Size = New System.Drawing.Size(129, 17)
        Me.ORFCheckBox.TabIndex = 3
        Me.ORFCheckBox.Text = "Get feature sequence"
        Me.ORFCheckBox.UseVisualStyleBackColor = True
        '
        'EscButton
        '
        Me.EscButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.EscButton.Location = New System.Drawing.Point(436, 113)
        Me.EscButton.Name = "EscButton"
        Me.EscButton.Size = New System.Drawing.Size(75, 23)
        Me.EscButton.TabIndex = 17
        Me.EscButton.Text = "Cancel"
        Me.EscButton.UseVisualStyleBackColor = True
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(517, 113)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.Size = New System.Drawing.Size(75, 23)
        Me.OKButton.TabIndex = 16
        Me.OKButton.Text = "OK"
        Me.OKButton.UseVisualStyleBackColor = True
        '
        'SeqRetrieval
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(598, 148)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.EscButton)
        Me.Controls.Add(Me.OKButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "SeqRetrieval"
        Me.Text = "Sequence retrieval master"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents DownLowerCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ORFLowerCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents UpLowerCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents DownTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UpTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DownstreamCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents UpstreamCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ORFCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ForRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents EscButton As System.Windows.Forms.Button
    Friend WithEvents RevRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents OKButton As System.Windows.Forms.Button
End Class
