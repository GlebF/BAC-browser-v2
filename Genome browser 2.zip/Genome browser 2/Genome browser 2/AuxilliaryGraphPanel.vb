﻿Public Class AuxilliaryGraphPanel
    Inherits Panel

    Private classMyViewer As Genome_Viewer

    Public Property MyGenomeViewer() As Genome_Viewer
        Get
            MyGenomeViewer = classMyViewer
        End Get
        Set(ByVal value As Genome_Viewer)
            classMyViewer = value
        End Set
    End Property


    Private Sub InitializeComponent()
        Me.SuspendLayout()
        '
        'AuxilliaryGraphPanel
        '
        Me.ResumeLayout(False)

    End Sub

    Private Sub AuxilliaryGraphPanel_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        If classMyViewer.DrawGrid Then
            classMyViewer.DrawFeaturesRuller(e, Me.Height)
        End If

        Try
            If classMyViewer.Positional_Values_Collection.Count > 0 And Not classMyViewer.ViewRange > 100000 Then
                Dim Current_X As Integer = 0
                Dim Previous_X As Integer = 0

                Dim Current_Length As Integer = 0
                Dim MarkBrush As New SolidBrush(Color.White)
                Dim HighlightRect As New Rectangle

                Dim CurrentRelativeValue As Integer = 0

                Dim CurrentIntList As List(Of Integer) = Nothing
                Dim CurrentLogList As List(Of Single) = Nothing

                Dim VisibleChart As Boolean = True
                Dim ChartStrand As Short = 0
                Dim ChartColor As Color = Color.Black
                Dim ChartScale As Short = 0
                Dim Baseline As Integer = Height / 2

                Dim CurrentHeight As Integer = 0
                Dim PrevHeight As Integer = 0

                Dim AllowDraw As Boolean = False

                Dim MaxValue As Integer = 1
                Dim MaxLogValue As Single = 1

                Dim MaxList As Integer = 0

                'Direction list
                '0 - None
                '1 - Plus
                '2 - Minus
                '3 - Symmetrical
                '4 - Hairpin plus/minus
                '5 - Hairpin minus/plus


                'Only one data should be displayed on the lane
                For Each PosValHolder As PositionalValuesHolder In classMyViewer.Positional_Values_Collection
                    If PosValHolder.Holder_Name = Tag Then

                        Me.Visible = PosValHolder.Visible

                        If Me.Visible Then
                            Current_X = 0
                            Previous_X = 0
                            AllowDraw = False
                            CurrentHeight = Baseline
                            PrevHeight = Baseline


                            Select Case PosValHolder.Scale
                                Case 0
                                    CurrentIntList = DataIO.RetrievePositionalValuesFromCache(PosValHolder, classMyViewer.RangeStart, classMyViewer.RangeEnd)

                                    MaxValue = Bioinformatics.Maximum(CurrentIntList)
                                    If MaxValue = 0 Then
                                        MaxValue = 1
                                    End If

                                    MaxList = CurrentIntList.Count - 1

                                Case 1
                                    CurrentLogList = DataIO.RetrievePositionalLogValuesFromCache(PosValHolder, classMyViewer.RangeStart, classMyViewer.RangeEnd)

                                    MaxLogValue = Bioinformatics.Maximum(CurrentLogList)
                                    If MaxLogValue = 0 Then
                                        MaxLogValue = 1
                                    End If
                                    MaxList = CurrentLogList.Count - 1

                            End Select

                            Dim ChartPen As New Pen(PosValHolder.Draw_Color)
                            ChartPen.Width = 2

                            MarkBrush.Color = Color.FromArgb(50, PosValHolder.Draw_Color.R, PosValHolder.Draw_Color.G, PosValHolder.Draw_Color.B)



                            For i = 0 To MaxList
                                Previous_X = Current_X
                                PrevHeight = CurrentHeight
                                Current_X = (i) * classMyViewer.ViewProjectionK
                                Current_Length = (i + 1) * classMyViewer.ViewProjectionK

                                If AllowDraw Then

                                    Select Case PosValHolder.Scale
                                        Case 0
                                            CurrentRelativeValue = Baseline * CurrentIntList(i) / MaxValue
                                        Case 1
                                            CurrentRelativeValue = Baseline * CurrentLogList(i) / MaxLogValue
                                    End Select

                                    Select Case PosValHolder.Strand
                                        Case 0
                                            CurrentHeight = Baseline - CurrentRelativeValue
                                        Case 1
                                            CurrentHeight = Baseline - CurrentRelativeValue

                                            HighlightRect.Location = New Point(Current_X, CurrentHeight)

                                        Case 2
                                            CurrentHeight = Baseline + CurrentRelativeValue

                                            HighlightRect.Location = New Point(Current_X, Baseline)

                                    End Select


                                    If classMyViewer.ViewChartStyle Then
                                        HighlightRect.Size = New Size(Current_Length - Current_X, CurrentRelativeValue)
                                        e.Graphics.FillRectangle(MarkBrush, HighlightRect)
                                    Else
                                        e.Graphics.DrawLine(ChartPen, Current_X, CurrentHeight, Previous_X, PrevHeight)
                                    End If


                                End If 'AllowDraw

                                AllowDraw = True

                            Next i

                            ChartPen.Dispose()

                        End If 'Me.Visible


                    End If
                Next PosValHolder



                'Draw baseline
                e.Graphics.DrawLine(Pens.Black, 0, Baseline, Width, Baseline)


                e.Graphics.DrawLine(Pens.Black, 2, 3, 2, Height - 3)
                e.Graphics.DrawLine(Pens.Black, 0, 3, 4, 3)
                e.Graphics.DrawLine(Pens.Black, 0, Height - 3, 4, Height - 3)

                e.Graphics.DrawString(MaxValue, classMyViewer.ViewFont, Brushes.Black, 5, 3)
                e.Graphics.DrawString(MaxValue, classMyViewer.ViewFont, Brushes.Black, 5, Height - 10)



            End If 'Data is present and visibility is OK




        Catch ex As Exception

        End Try


    End Sub

End Class
