﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ImportFeatures
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ImportFeatures))
        Me.NameComboBox = New System.Windows.Forms.ComboBox
        Me.StartComboBox = New System.Windows.Forms.ComboBox
        Me.EndComboBox = New System.Windows.Forms.ComboBox
        Me.DirectionComboBox = New System.Windows.Forms.ComboBox
        Me.TypeComboBox = New System.Windows.Forms.ComboBox
        Me.TAGComboBox = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.DescrComboBox = New System.Windows.Forms.ComboBox
        Me.OpenButton = New System.Windows.Forms.Button
        Me.ImportButton = New System.Windows.Forms.Button
        Me.FileTextBox = New System.Windows.Forms.TextBox
        Me.MainImport = New System.Windows.Forms.CheckBox
        Me.AutodetectCheckBox = New System.Windows.Forms.CheckBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.OldTagComboBox = New System.Windows.Forms.ComboBox
        Me.OrthoComboBox = New System.Windows.Forms.ComboBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.ReplacementCheckBox = New System.Windows.Forms.CheckBox
        Me.SuspendLayout()
        '
        'NameComboBox
        '
        Me.NameComboBox.FormattingEnabled = True
        Me.NameComboBox.Location = New System.Drawing.Point(94, 66)
        Me.NameComboBox.Name = "NameComboBox"
        Me.NameComboBox.Size = New System.Drawing.Size(121, 21)
        Me.NameComboBox.TabIndex = 0
        '
        'StartComboBox
        '
        Me.StartComboBox.FormattingEnabled = True
        Me.StartComboBox.Location = New System.Drawing.Point(94, 93)
        Me.StartComboBox.Name = "StartComboBox"
        Me.StartComboBox.Size = New System.Drawing.Size(121, 21)
        Me.StartComboBox.TabIndex = 1
        '
        'EndComboBox
        '
        Me.EndComboBox.FormattingEnabled = True
        Me.EndComboBox.Location = New System.Drawing.Point(94, 120)
        Me.EndComboBox.Name = "EndComboBox"
        Me.EndComboBox.Size = New System.Drawing.Size(121, 21)
        Me.EndComboBox.TabIndex = 2
        '
        'DirectionComboBox
        '
        Me.DirectionComboBox.FormattingEnabled = True
        Me.DirectionComboBox.Location = New System.Drawing.Point(94, 147)
        Me.DirectionComboBox.Name = "DirectionComboBox"
        Me.DirectionComboBox.Size = New System.Drawing.Size(121, 21)
        Me.DirectionComboBox.TabIndex = 3
        '
        'TypeComboBox
        '
        Me.TypeComboBox.FormattingEnabled = True
        Me.TypeComboBox.Location = New System.Drawing.Point(94, 174)
        Me.TypeComboBox.Name = "TypeComboBox"
        Me.TypeComboBox.Size = New System.Drawing.Size(121, 21)
        Me.TypeComboBox.TabIndex = 4
        '
        'TAGComboBox
        '
        Me.TAGComboBox.FormattingEnabled = True
        Me.TAGComboBox.Location = New System.Drawing.Point(94, 39)
        Me.TAGComboBox.Name = "TAGComboBox"
        Me.TAGComboBox.Size = New System.Drawing.Size(121, 21)
        Me.TAGComboBox.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(56, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "TAG:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(50, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Name:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(56, 96)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Start:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(59, 123)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "End:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(36, 150)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Direction:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(25, 204)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Description:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(54, 177)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(34, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Type:"
        '
        'DescrComboBox
        '
        Me.DescrComboBox.FormattingEnabled = True
        Me.DescrComboBox.Location = New System.Drawing.Point(94, 201)
        Me.DescrComboBox.Name = "DescrComboBox"
        Me.DescrComboBox.Size = New System.Drawing.Size(121, 21)
        Me.DescrComboBox.TabIndex = 13
        '
        'OpenButton
        '
        Me.OpenButton.Location = New System.Drawing.Point(19, 257)
        Me.OpenButton.Name = "OpenButton"
        Me.OpenButton.Size = New System.Drawing.Size(75, 23)
        Me.OpenButton.TabIndex = 14
        Me.OpenButton.Text = "Open file"
        Me.OpenButton.UseVisualStyleBackColor = True
        '
        'ImportButton
        '
        Me.ImportButton.Location = New System.Drawing.Point(19, 327)
        Me.ImportButton.Name = "ImportButton"
        Me.ImportButton.Size = New System.Drawing.Size(75, 23)
        Me.ImportButton.TabIndex = 15
        Me.ImportButton.Text = "Import"
        Me.ImportButton.UseVisualStyleBackColor = True
        '
        'FileTextBox
        '
        Me.FileTextBox.Location = New System.Drawing.Point(100, 259)
        Me.FileTextBox.Name = "FileTextBox"
        Me.FileTextBox.Size = New System.Drawing.Size(115, 20)
        Me.FileTextBox.TabIndex = 16
        '
        'MainImport
        '
        Me.MainImport.AutoSize = True
        Me.MainImport.Location = New System.Drawing.Point(100, 308)
        Me.MainImport.Name = "MainImport"
        Me.MainImport.Size = New System.Drawing.Size(115, 17)
        Me.MainImport.TabIndex = 17
        Me.MainImport.Text = "Import into main list"
        Me.MainImport.UseVisualStyleBackColor = True
        '
        'AutodetectCheckBox
        '
        Me.AutodetectCheckBox.AutoSize = True
        Me.AutodetectCheckBox.Checked = True
        Me.AutodetectCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.AutodetectCheckBox.Location = New System.Drawing.Point(100, 285)
        Me.AutodetectCheckBox.Name = "AutodetectCheckBox"
        Me.AutodetectCheckBox.Size = New System.Drawing.Size(92, 17)
        Me.AutodetectCheckBox.TabIndex = 18
        Me.AutodetectCheckBox.Text = "Autodetection"
        Me.AutodetectCheckBox.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(37, 15)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(51, 13)
        Me.Label8.TabIndex = 21
        Me.Label8.Text = "Old TAG:"
        '
        'OldTagComboBox
        '
        Me.OldTagComboBox.Enabled = False
        Me.OldTagComboBox.FormattingEnabled = True
        Me.OldTagComboBox.Location = New System.Drawing.Point(94, 12)
        Me.OldTagComboBox.Name = "OldTagComboBox"
        Me.OldTagComboBox.Size = New System.Drawing.Size(121, 21)
        Me.OldTagComboBox.TabIndex = 20
        '
        'OrthoComboBox
        '
        Me.OrthoComboBox.FormattingEnabled = True
        Me.OrthoComboBox.Location = New System.Drawing.Point(94, 228)
        Me.OrthoComboBox.Name = "OrthoComboBox"
        Me.OrthoComboBox.Size = New System.Drawing.Size(121, 21)
        Me.OrthoComboBox.TabIndex = 23
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(33, 231)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 13)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "Orthology:"
        '
        'ReplacementCheckBox
        '
        Me.ReplacementCheckBox.AutoSize = True
        Me.ReplacementCheckBox.Location = New System.Drawing.Point(100, 331)
        Me.ReplacementCheckBox.Name = "ReplacementCheckBox"
        Me.ReplacementCheckBox.Size = New System.Drawing.Size(89, 17)
        Me.ReplacementCheckBox.TabIndex = 24
        Me.ReplacementCheckBox.Text = "Replacement"
        Me.ReplacementCheckBox.UseVisualStyleBackColor = True
        '
        'ImportFeatures
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(227, 358)
        Me.Controls.Add(Me.ReplacementCheckBox)
        Me.Controls.Add(Me.OrthoComboBox)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.OldTagComboBox)
        Me.Controls.Add(Me.AutodetectCheckBox)
        Me.Controls.Add(Me.MainImport)
        Me.Controls.Add(Me.FileTextBox)
        Me.Controls.Add(Me.ImportButton)
        Me.Controls.Add(Me.OpenButton)
        Me.Controls.Add(Me.DescrComboBox)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TAGComboBox)
        Me.Controls.Add(Me.TypeComboBox)
        Me.Controls.Add(Me.DirectionComboBox)
        Me.Controls.Add(Me.EndComboBox)
        Me.Controls.Add(Me.StartComboBox)
        Me.Controls.Add(Me.NameComboBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "ImportFeatures"
        Me.Text = "Import features"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents NameComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents StartComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents EndComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents DirectionComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents TypeComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents TAGComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents DescrComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents OpenButton As System.Windows.Forms.Button
    Friend WithEvents ImportButton As System.Windows.Forms.Button
    Friend WithEvents FileTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MainImport As System.Windows.Forms.CheckBox
    Friend WithEvents AutodetectCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents OldTagComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents OrthoComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ReplacementCheckBox As System.Windows.Forms.CheckBox
End Class
