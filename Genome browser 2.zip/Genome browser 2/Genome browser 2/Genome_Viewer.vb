﻿Public Class Genome_Viewer

#Region "Variables"

    'Browser core
    Private strFileName As String = ""
    Private strGenomeSequence As String = ""
    Private strFastaHeader As String = ""
    Private cntFeaturesGroupsList As New List(Of FeaturesAssembly) 'List of groups of features to replace separate lists. Any additional lists of features are stored here.
    Private strMainFeaturesListName As String = "Main Features"
    Private strUserFeaturesListName As String = "User Features"
    Private listDisplayedGenomeFeatures As New List(Of Genome_Feature) 'List of currently displayed features
    Private listHighlightedSites As New List(Of Genome_Feature) 'List of features projected onto sequence lane rather then on features lane, like restriction sites
    Private listDisplayedHighlightedSites As New List(Of Genome_Feature) 'List of displayed features projected onto sequence lane rather then on features lane, like restriction sites
    Private listSequenceMarkers As New List(Of SequenceMarker) 'Total list of markers
    Private listDisplayedSequenceMarkers As New List(Of SequenceMarker) 'Displayed markers
    Private cntrlSelected_Feature As Genome_Feature = Nothing 'Currently selected feature
    Private cntrlSelected_Block As QuantitationBlock = Nothing 'Currently selected block(interval)
    Private cntrlSelected_Block_Alt As QuantitationBlock = Nothing 'To merge blocks
    Private cntSelectedRestrictionSite As Genome_Feature = Nothing 'Current restriction site
    Private cntSelectedRestrictionSiteA As Genome_Feature = Nothing 'First restriction site to cut and remove sequence
    Private cntSelectedRestrictionSiteB As Genome_Feature = Nothing 'Second restriction site to cut and remove sequence
    Private listUndo_Features As New List(Of Genome_Feature) 'List of changed or deleted features
    Private History As New List(Of String) 'List of changes made to features and sequence
    Private EditMode As Boolean = False
    Private bGenomeTopology As Boolean = True 'Circular
    Private intRangeStart As Integer = 0
    Private intRangeEnd As Integer = 0
    Private MaximalSeqDisplayRange As Integer = 500 'At this range or smaller sequence and translation are displayed
    Private strSequenceFilePath As String
    Private shGenetic_Code As Short = 0
    Private strComment As String = ""
    Private MouseLocation As Point 'Location of mouse within DrawPanel control
    Private MouseLocationGraph As Point
    Private listPositionalValues As New List(Of PositionalValuesHolder) 'For expression, etc...
    Private listIntegratedValues As New List(Of QuantBlockHolder)
    Private listDisplayedIntegratedValues As New List(Of QuantitationBlock)
    Private bIntegratedLog As Boolean = False 'Integrated values log or linear display mode
    Private bIntegratedFill As Boolean = False
    Private bGroupLock As Boolean = False
    Private bPositionalNormalization As Boolean = False 'If True Max is calculated for all charts
    Private list6FrameTranslation As New List(Of String) 'This is to replace prot list in peptide search



    'Graphics
    Private FeatureH As Integer = 18 'Height of features by def=18
    Private FeatureBorder As Integer = 3
    Private ZeroLayoutOffset As Integer = 10
    Private MaxLayoutOrder As Integer = 0 '12
    Private RullerOffset As Integer = 60
    Private Projection_K As Single = 0
    Private Range As Integer = 0
    Private MyFont As New Font("Tahoma", 7, FontStyle.Regular)
    Private SeqFont As New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
    Private MarkOrder As Integer = 1
    Private bGraphicsLock As Boolean = True 'Do not paint (on resize)
    Private bDrawGrid As Boolean = True
    Private bSiteMarckupMode As Boolean = False
    Private SeqLaneOffset As Integer = 0
    Private bSiteMarckupView As Boolean = False 'True for full site highlight
    Private SiteHighlitePen As New Pen(Color.Green, 2)
    Private SiteSmallPen As New Pen(Color.Green, 1)
    Private SiteBrush As Brush = Brushes.Green
    Private MarkerHeight As Integer = 15
    Private MarkerWidthHalf As Integer = 6
    Private MarkerHighlightPen As New Pen(Color.Red, 2)
    Private BindingBrush As SolidBrush = Nothing
    Private ActiveBindingBrush As New SolidBrush(Color.FromArgb(25, 200, 0, 100))
    Private InActiveBindingBrush As New SolidBrush(Color.FromArgb(25, 0, 200, 100))
    Private BlockSelectionBrush As New SolidBrush(Color.FromArgb(50, 200, 0, 100))
    Private BindingPenHeight As Integer = 15
    Private GraphicsLock As Boolean = True
    Private UltrastructureLim As Integer = 50000 'If range exeeds this value exons, frameshifts, etc... are not painted
    Private bPositionalRuller As Boolean = False
    Private bChartStyle As Boolean = False
    Private AuxGraphPanels As New List(Of AuxilliaryGraphPanel)

    'Hand scroll
    Private HandScrollStart As Boolean = False
    Private HandInitLocationX As Integer
    Private HandInitLocationY As Integer
    Private StepInitLocationX As Integer
    Private StepInitLocationY As Integer
    Private InitialRangeStart As Integer = 0
    Private InitialRangeEnd As Integer = 0
    Private FeatureMovementStart As Boolean = False
    Private MarkerMovementStart As Boolean = False
    Private cntSelectedMarker As SequenceMarker = Nothing

    'Scroll tool
    Private ScrollDirection As Boolean

    'Minimap
    Public Minimap As New Genome_Minimap
    Private MinimapOffsetH As Integer = 50
    Private MinimapOffsetY As Integer = 0

    'Design panel
    Private bSelectionMode As Boolean = False
    Private bInternalMarkers As Boolean = False
    Private RangeValues(3) As Integer

    'Oligos
    Private Oligo_Counter As Integer = 0

    'Peptide search
    Private ctrProteins As List(Of ProtPeptide)
    Private RefreshProteins As Boolean = True

    'Database
    Private CurrentTAG As String = ""
    Private CurrentGroup As String = ""
    Private bSaveRequired As Boolean = False
    Private UndoList As List(Of String)
    Private CurrentValuesHolder As String = ""

    Private CurrentBlockName As String = ""
    Private CurrentHolderName As String = ""

    'Controls
    Private MyReportBox As New FeatureReportBox
    Private MyControlBox As New BrowserControlBox

    'Analysis
    Private T_Skew As List(Of Single)
    Private A_Skew As List(Of Single)

    'Translation panel
    Private intTrippletStart As Integer 'Start of the edited tripplet
    Private intTrippletEnd As Integer 'End of the edited tripplet
    Private TrippletIdentified As Boolean = False 'If current tripplet was selected
    Private bReverseStrand As Boolean
    Private bFullColor As Boolean = False

    'Private AT_Skew As List(Of Single)
    'Private GC_Skew As List(Of Single)

#End Region

#Region "Properties"

    Public Property File_Name() As String
        Get
            File_Name = strFileName
        End Get
        Set(ByVal value As String)
            strFileName = value
        End Set
    End Property

    Public Property Fasta_Header() As String
        Get
            Fasta_Header = strFastaHeader
        End Get
        Set(ByVal value As String)
            strFastaHeader = value
        End Set
    End Property

    Public Property Features_Groups_List() As List(Of FeaturesAssembly)
        Get
            Features_Groups_List = cntFeaturesGroupsList
        End Get
        Set(ByVal value As List(Of FeaturesAssembly))
            cntFeaturesGroupsList = value
        End Set
    End Property

    Public Property RangeStart() As Integer
        Get
            RangeStart = intRangeStart
        End Get
        Set(ByVal value As Integer)
            intRangeStart = value
        End Set
    End Property

    Public Property RangeEnd() As Integer
        Get
            RangeEnd = intRangeEnd
        End Get
        Set(ByVal value As Integer)
            intRangeEnd = value
        End Set
    End Property

    Public Property GenomeTopology() As Boolean
        Get
            GenomeTopology = bGenomeTopology
        End Get
        Set(ByVal value As Boolean)
            bGenomeTopology = value
        End Set
    End Property

    Public Property Genetic_Code() As Short
        Get
            Genetic_Code = shGenetic_Code
        End Get
        Set(ByVal value As Short)
            shGenetic_Code = value
        End Set
    End Property

    Public Property Comment() As String
        Get
            Comment = strComment
        End Get
        Set(ByVal value As String)
            strComment = value
        End Set
    End Property

    Public Property Save_Required() As Boolean
        Get
            Save_Required = bSaveRequired
        End Get
        Set(ByVal value As Boolean)
            bSaveRequired = value
        End Set
    End Property

    Public Property DrawGrid() As Boolean
        Get
            DrawGrid = bDrawGrid
        End Get
        Set(ByVal value As Boolean)
            bDrawGrid = value
            DisplayFeatures()
        End Set
    End Property

    Public Property Features_History() As List(Of String)
        Get
            Features_History = History
        End Get
        Set(ByVal value As List(Of String))
            History = value
        End Set
    End Property

    Public Property Genome_Sequence() As String
        Get
            Genome_Sequence = strGenomeSequence
        End Get
        Set(ByVal value As String)
            strGenomeSequence = value
        End Set
    End Property

    Public Property SiteMarkupMode() As Boolean
        Get
            SiteMarkupMode = bSiteMarckupMode
        End Get
        Set(ByVal value As Boolean)
            bSiteMarckupMode = value

            If Not IsNothing(MyControlBox) Then
                MyControlBox.MarckupOnRadioButton.Checked = bSiteMarckupMode
                MyControlBox.MarckupOffRadioButton.Checked = Not bSiteMarckupMode
            End If

            If bSiteMarckupMode Then
                SeqLaneOffset = 20
                SequencePanel.Height = 65
            Else
                SeqLaneOffset = 0
                SequencePanel.Height = 25
                listSequenceMarkers.Clear()
            End If
            DisplayFeatures()
        End Set
    End Property

    Public Property Site_Detector() As List(Of Genome_Feature)
        Get
            Site_Detector = listHighlightedSites
        End Get
        Set(ByVal value As List(Of Genome_Feature))
            listHighlightedSites = value
        End Set
    End Property

    Public Property Sequence_Markers() As List(Of SequenceMarker)
        Get
            Sequence_Markers = listSequenceMarkers
        End Get
        Set(ByVal value As List(Of SequenceMarker))
            listSequenceMarkers = value
        End Set
    End Property

    Public ReadOnly Property Selected_Feature() As Genome_Feature
        Get
            Selected_Feature = cntrlSelected_Feature
        End Get
    End Property

    Public Property Positional_Values_Collection() As List(Of PositionalValuesHolder)
        Get
            Positional_Values_Collection = listPositionalValues
        End Get
        Set(ByVal value As List(Of PositionalValuesHolder))
            listPositionalValues = value
        End Set
    End Property

    Public Property Integrated_Values() As List(Of QuantBlockHolder)
        Get
            Integrated_Values = listIntegratedValues
        End Get
        Set(ByVal value As List(Of QuantBlockHolder))
            listIntegratedValues = value
        End Set
    End Property

    Public Property Control_Box() As BrowserControlBox
        Get
            Control_Box = MyControlBox
        End Get
        Set(ByVal value As BrowserControlBox)
            MyControlBox = value
        End Set
    End Property

    Public Property Report_Box() As FeatureReportBox
        Get
            Report_Box = MyReportBox
        End Get
        Set(ByVal value As FeatureReportBox)
            MyReportBox = value
        End Set
    End Property

    Public Property TranslationList6Frame()
        Get
            TranslationList6Frame = list6FrameTranslation
        End Get
        Set(ByVal value)
            list6FrameTranslation = value
        End Set
    End Property

    Public Property TranslationFullColor() As Boolean
        Get
            TranslationFullColor = bFullColor
        End Get
        Set(ByVal value As Boolean)
            bFullColor = value
        End Set
    End Property

    Public Property Protein_Refresh_Required() As Boolean
        Get
            Protein_Refresh_Required = RefreshProteins
        End Get
        Set(ByVal value As Boolean)
            RefreshProteins = value
        End Set
    End Property

    Public Property Protein_Translation_List() As List(Of ProtPeptide)
        Get
            Protein_Translation_List = ctrProteins
        End Get
        Set(ByVal value As List(Of ProtPeptide))
            ctrProteins = value
        End Set
    End Property

    Public ReadOnly Property MainFeaturesListName() As String
        Get
            MainFeaturesListName = strMainFeaturesListName
        End Get
    End Property

    Public ReadOnly Property UserFeaturesListName() As String
        Get
            UserFeaturesListName = strUserFeaturesListName
        End Get
    End Property

    Public ReadOnly Property ViewRange() As Integer
        Get
            ViewRange = Range
        End Get
    End Property

    Public ReadOnly Property ViewProjectionK() As Single
        Get
            ViewProjectionK = Projection_K
        End Get
    End Property

    Public ReadOnly Property ViewFont() As Font
        Get
            ViewFont = MyFont
        End Get
    End Property

    Public ReadOnly Property ViewChartStyle() As Boolean
        Get
            ViewChartStyle = bChartStyle
        End Get
    End Property



#End Region

#Region "Initialization"

    Public Sub New(ByVal Seq As String, ByVal SeqName As String, Optional ByVal Features As List(Of Genome_Feature) = Nothing, Optional ByVal InfoData As FeatureData = Nothing, Optional ByVal GeneticCode As Short = 1, Optional ByVal Circular As Boolean = False)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        Dim MainFeaturesList As New FeaturesAssembly

        If Not IsNothing(Features) Then

            For Each F As Genome_Feature In Features
                F.Group = strMainFeaturesListName
            Next F

            MainFeaturesList.FeaturesList = Features
        End If


        MainFeaturesList.AssemblyName = strMainFeaturesListName
        MainFeaturesList.Visible = True
        cntFeaturesGroupsList.Add(MainFeaturesList)

        Dim UserOligoList As New FeaturesAssembly
        UserOligoList.AssemblyName = strUserFeaturesListName
        UserOligoList.Visible = True
        cntFeaturesGroupsList.Add(UserOligoList)

        FeaturesGroupsListBox.Items.Add(MainFeaturesList.AssemblyName)
        FeaturesGroupsListBox.Items(0).Checked = True
        FeaturesGroupsListBox.Items.Add(UserOligoList.AssemblyName)
        FeaturesGroupsListBox.Items(1).Checked = True

        MyReportBox.Dock = DockStyle.Top
        MyControlBox.Dock = DockStyle.Top

        MyReportBox.MyParent = Me
        MyControlBox.MyParent = Me

        PrimarySplitContainer.Panel1.Controls.Add(MyControlBox)
        PrimarySplitContainer.Panel1.Controls.Add(MyReportBox)

        Minimap.MyParent = Me
        Minimap.Name = "Minimap"
        Minimap.Location = New Point(MinimapOffsetH, MinimapOffsetY)
        MinimapPanel.Controls.Add(Minimap)


        MyControlBox.TransComboBox.Items.Clear()

        For Each Row As DataRow In Master.CodeNamesList.Rows
            MyControlBox.TransComboBox.Items.Add(Row.Item(0) & "-" & Row.Item(1))
        Next


        MyControlBox.SeqNameTextBox.Text = SeqName

        If Circular Then
            GenomeTopology = True
            MyControlBox.TopologyComboBox.Text = "Circular"
        Else
            GenomeTopology = False
            MyControlBox.TopologyComboBox.Text = "Linear"
        End If


        shGenetic_Code = GeneticCode
        For Each Row As DataRow In Master.CodeNamesList.Rows
            If Row.Item(0) = shGenetic_Code Then
                MyControlBox.TransComboBox.Text = Row.Item(0) & "-" & Row.Item(1)
            End If
        Next


        strGenomeSequence = Seq
        strFastaHeader = SeqName
        UpdateSeqStat()

        intRangeStart = 1
        intRangeEnd = strGenomeSequence.Length / 100
        If intRangeEnd < 1 Then
            intRangeEnd = 2
        End If

        Minimap.UpdateRange()
        MaxLayoutOrder = Math.Truncate((DrawPanel.Height - ZeroLayoutOffset) / FeatureH)
        Minimap.Size = New Size(MinimapPanel.Width - MinimapOffsetH * 2, 50)

        GraphicsLock = False
        DisplayFeatures()

        'Initialize new control center for features
        Dim F_TypeColumn As DataGridViewComboBoxColumn = FeaturesGroupDataGridView.Columns(6)
        For i = 0 To 12
            F_TypeColumn.Items.Add(Genome_Feature.GetDescriptionOfType(i))
        Next

        Dim F_DirectionColumn As DataGridViewComboBoxColumn = FeaturesGroupDataGridView.Columns(5)
        For i = 0 To 3
            F_DirectionColumn.Items.Add(Genome_Feature.GetDescriptionOfDirection(i))
        Next



        'Initialize general data about sequence
        Try
            If Not IsNothing(InfoData) Then
                For i = 0 To InfoData.DataHeaders.Count - 1
                    MyControlBox.InfoDataGridView.Rows.Add(InfoData.DataHeaders(i), InfoData.DataValues(i))
                Next i
            End If
        Catch ex As Exception
            MsgBox("Error in additional sequence data!")
        End Try




        'Get rid of whole-sequence feature
        For i = 0 To MainFeaturesList.FeaturesList.Count - 1
            If MainFeaturesList.FeaturesList(i).Type = 99 Then

                If Not IsNothing(MainFeaturesList.FeaturesList(i).AdditionalProperties) Then
                    For j = 0 To MainFeaturesList.FeaturesList(i).AdditionalProperties.DataHeaders.Count - 1
                        MyControlBox.InfoDataGridView.Rows.Add("//" & MainFeaturesList.FeaturesList(i).AdditionalProperties.DataHeaders(j), MainFeaturesList.FeaturesList(i).AdditionalProperties.DataValues(j))
                    Next j
                End If


                MainFeaturesList.FeaturesList.RemoveAt(i)
                Exit For
            End If
        Next i


    End Sub

    Public Sub New(ByVal FileName As String, ByVal SeqFormat As String, ByVal AnnotationFormat As String)


        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.


        Dim MainFeaturesList As New FeaturesAssembly
        MainFeaturesList.AssemblyName = strMainFeaturesListName
        MainFeaturesList.Visible = True
        cntFeaturesGroupsList.Add(MainFeaturesList)

        Dim UserOligoList As New FeaturesAssembly
        UserOligoList.AssemblyName = strUserFeaturesListName
        UserOligoList.Visible = True
        cntFeaturesGroupsList.Add(UserOligoList)

        FeaturesGroupsListBox.Items.Add(MainFeaturesList.AssemblyName)
        FeaturesGroupsListBox.Items(0).Checked = True
        FeaturesGroupsListBox.Items.Add(UserOligoList.AssemblyName)
        FeaturesGroupsListBox.Items(1).Checked = True

        MyReportBox.Dock = DockStyle.Top
        MyControlBox.Dock = DockStyle.Top

        MyReportBox.MyParent = Me
        MyControlBox.MyParent = Me

        PrimarySplitContainer.Panel1.Controls.Add(MyControlBox)
        PrimarySplitContainer.Panel1.Controls.Add(MyReportBox)

        Minimap.MyParent = Me
        Minimap.Name = "Minimap"
        Minimap.Location = New Point(MinimapOffsetH, MinimapOffsetY)
        MinimapPanel.Controls.Add(Minimap)

        InitializeMe(FileName, SeqFormat, AnnotationFormat)


    End Sub

    Public Sub InitializeMe(ByVal FileName As String, ByVal SeqFormat As String, ByVal AnnotationFormat As String)


        If SeqFormat = ".fasta" And AnnotationFormat = ".annot" Then 'Own formats, standard case
            strFileName = FileName
        End If
        'For other formats conversion is needed



        MyControlBox.TransComboBox.Items.Clear()

        For Each Row As DataRow In Master.CodeNamesList.Rows
            MyControlBox.TransComboBox.Items.Add(Row.Item(0) & "-" & Row.Item(1))
        Next

        'Read annotation file

        If AnnotationFormat = ".annot" Then

            Dim AnnotationHeader As List(Of String) = DataIO.ReadAnnotationHeader(String.Concat(strFileName, AnnotationFormat))
            Dim DataPair As String()
            For Each Data As String In AnnotationHeader

                DataPair = Data.Split("=")

                If DataPair(0).StartsWith("/") Then

                    MyControlBox.InfoDataGridView.Rows.Add(DataPair(0).Substring(1), DataPair(1))

                Else

                    Select Case DataPair(0)
                        Case "GenomeTopology"
                            GenomeTopology = DataPair(1)
                            If GenomeTopology Then
                                MyControlBox.TopologyComboBox.Text = "Circular"
                            Else
                                MyControlBox.TopologyComboBox.Text = "Linear"
                            End If
                        Case "GeneticCode"
                            shGenetic_Code = DataPair(1)
                            For Each Row As DataRow In Master.CodeNamesList.Rows
                                If Row.Item(0) = shGenetic_Code Then
                                    MyControlBox.TransComboBox.Text = Row.Item(0) & "-" & Row.Item(1)
                                End If
                            Next
                        Case "Comment"
                            strComment = DataPair(1)
                            MyControlBox.CommentTextBox.Text = strComment
                    End Select

                End If 'DataPair(0).StartsWith("/")
            Next Data



            cntFeaturesGroupsList(0).FeaturesList = DataIO.ReadAnnotationData(String.Concat(strFileName, AnnotationFormat), strMainFeaturesListName)


            Dim Tmp As Genome_Feature = Nothing
            For i = 1 To cntFeaturesGroupsList(0).FeaturesList.Count - 1
                For j = 0 To cntFeaturesGroupsList(0).FeaturesList.Count - 1 - i
                    If cntFeaturesGroupsList(0).FeaturesList(j).AbsoluteStart > cntFeaturesGroupsList(0).FeaturesList(j + 1).AbsoluteStart Then
                        Tmp = cntFeaturesGroupsList(0).FeaturesList(j)
                        cntFeaturesGroupsList(0).FeaturesList(j) = cntFeaturesGroupsList(0).FeaturesList(j + 1)
                        cntFeaturesGroupsList(0).FeaturesList(j + 1) = Tmp
                    End If
                Next
            Next



        ElseIf AnnotationFormat = "" Then


            MsgBox("No annotation file found!")
        End If

        Dim SeqName As String() = FileName.Split("\")
        MyControlBox.SeqNameTextBox.Text = SeqName(SeqName.GetUpperBound(0))

        strFastaHeader = DataIO.LoadHeader(FileName)
        strGenomeSequence = DataIO.LoadSequence(FileName, SeqFormat)

        If strFastaHeader = ">" Or strFastaHeader = "" Then
            strFastaHeader = ">" & MyControlBox.SeqNameTextBox.Text
        End If

        UpdateSeqStat()

        intRangeStart = 1
        intRangeEnd = strGenomeSequence.Length / 100
        If intRangeEnd < 1 Then
            intRangeEnd = 2
        End If

        Minimap.UpdateRange()
        MaxLayoutOrder = Math.Truncate((DrawPanel.Height - ZeroLayoutOffset) / FeatureH)
        Minimap.Size = New Size(MinimapPanel.Width - MinimapOffsetH * 2, 50)

        GraphicsLock = False
        DisplayFeatures()


        'Initialize new control center for features
        Dim F_TypeColumn As DataGridViewComboBoxColumn = FeaturesGroupDataGridView.Columns(6)
        For i = 0 To 12
            F_TypeColumn.Items.Add(Genome_Feature.GetDescriptionOfType(i))
        Next

        Dim F_DirectionColumn As DataGridViewComboBoxColumn = FeaturesGroupDataGridView.Columns(5)
        For i = 0 To 3
            F_DirectionColumn.Items.Add(Genome_Feature.GetDescriptionOfDirection(i))
        Next



    End Sub

    Private Sub Genome_Viewer_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'DrawPanel.SendToBack()
        'SequencePanel.SendToBack()
        'TranslatePanel.SendToBack()
        'MinimapPanel.SendToBack()
        'EditorToolStrip.SendToBack()
        'ViewerToolStrip.SendToBack()


        TranslatePanel.Height = 76
        TranslatePanel.Visible = False

        SearchOptionsDropDownButton.DropDown.Items.Clear()
        For Each Row As DataRow In Master.SiteSeqList.Rows
            SearchOptionsDropDownButton.DropDown.Items.Add(Row.Item(0))
        Next

    End Sub

    Public Sub UpdateSeqStat()
        MyControlBox.LengthTextBox.Text = strGenomeSequence.Length
        MyControlBox.GenomeMWTextBox.Text = Bioinformatics.CalculateOligoMW(strGenomeSequence)
    End Sub

#End Region

#Region "Graphics"

    Public Sub DisplayFeatures()
        If GraphicsLock Then
            Exit Sub
        End If

        listDisplayedGenomeFeatures.Clear()
        listDisplayedHighlightedSites.Clear()
        listDisplayedSequenceMarkers.Clear()
        listDisplayedIntegratedValues.Clear()

        For Each Marker As SequenceMarker In listSequenceMarkers
            Marker.Counted = False
            Marker.InvertedView = False
        Next

        If intRangeStart > strGenomeSequence.Length Then
            If GenomeTopology Then
                intRangeStart -= strGenomeSequence.Length
            Else
                intRangeStart = 1
            End If
        End If

        If intRangeEnd > strGenomeSequence.Length Then
            If GenomeTopology Then
                intRangeEnd -= strGenomeSequence.Length
            Else
                intRangeEnd = strGenomeSequence.Length
            End If

        End If

        If intRangeStart < 1 Then
            If GenomeTopology Then
                intRangeStart += strGenomeSequence.Length
            Else
                intRangeStart = 1
            End If
        End If

        If intRangeEnd < 1 Then
            If GenomeTopology Then
                intRangeEnd += strGenomeSequence.Length
            Else
                intRangeEnd = strGenomeSequence.Length
            End If
        End If

        If Not GenomeTopology And intRangeStart > intRangeEnd Then
            intRangeStart = 1
            intRangeEnd = strGenomeSequence.Length / 100
        End If


        If intRangeStart < intRangeEnd Then 'Normal position of projection window

            Range = intRangeEnd - intRangeStart
            Projection_K = DrawPanel.Width / (Range + 1) 'Projection coefficient definition

            For Each Group As FeaturesAssembly In cntFeaturesGroupsList
                If Group.Visible Then
                    For Each Feature As Genome_Feature In Group.FeaturesList
                        Bioinformatics.CalculateFeatureProjectionNormal(Feature, listDisplayedGenomeFeatures, intRangeStart, intRangeEnd, strGenomeSequence.Length, Projection_K)
                    Next
                End If
            Next

            'Highlighted sites
            For Each Feature As Genome_Feature In listHighlightedSites
                If Feature.AbsoluteEnd > intRangeStart And Feature.AbsoluteStart < intRangeEnd Then
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd - intRangeStart + 1) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        For Each ReadElement As ReadItem In Feature.ReadList
                            ReadElement.ReadProjectionStart = (Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    listDisplayedHighlightedSites.Add(Feature)
                End If
            Next

            'Sequence markers
            For Each Marker As SequenceMarker In listSequenceMarkers
                If Marker.Counted Then
                    Continue For
                End If

                Bioinformatics.CalculateMarkerProjectionNormal(Marker, listDisplayedSequenceMarkers, _
                                                               intRangeStart, intRangeEnd, _
                                                               strGenomeSequence.Length, Projection_K)

            Next

            'Integrated values
            For Each QHolder As QuantBlockHolder In listIntegratedValues
                For Each CurrentQ As QuantitationBlock In QHolder.BlocksList
                    If CurrentQ.AbsoluteEnd > intRangeStart And CurrentQ.AbsoluteStart < intRangeEnd Then
                        CurrentQ.ProjectionStart = (CurrentQ.AbsoluteStart - intRangeStart) * Projection_K
                        CurrentQ.ProjectionEnd = (CurrentQ.AbsoluteEnd - intRangeStart + 1) * Projection_K
                        listDisplayedIntegratedValues.Add(CurrentQ)
                    End If
                Next
            Next

        Else 'Projection window overlaps with zero coordinate of circular genome

            Range = strGenomeSequence.Length - intRangeStart + intRangeEnd
            Projection_K = DrawPanel.Width / (Range + 1) 'Projection coefficient definition

            For Each Group As FeaturesAssembly In cntFeaturesGroupsList
                If Group.Visible Then
                    For Each Feature As Genome_Feature In Group.FeaturesList
                        Bioinformatics.CalculateFeatureProjectionOverlap(Feature, listDisplayedGenomeFeatures, intRangeStart, intRangeEnd, strGenomeSequence.Length, Projection_K)
                    Next
                End If
            Next

            'Highlighted sites
            For Each Feature As Genome_Feature In listHighlightedSites
                If Feature.AbsoluteEnd > intRangeStart Then 'Left side relative to zero
                    Feature.ProjectionStart = (Feature.AbsoluteStart - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd - intRangeStart + 1) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        For Each ReadElement As ReadItem In Feature.ReadList
                            ReadElement.ReadProjectionStart = (Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    listDisplayedHighlightedSites.Add(Feature)
                End If

                If Feature.AbsoluteStart < intRangeEnd Then 'Right side relative to zero
                    Feature.ProjectionStart = (Feature.AbsoluteStart + strGenomeSequence.Length - intRangeStart) * Projection_K
                    Feature.ProjectionEnd = (Feature.AbsoluteEnd + strGenomeSequence.Length - intRangeStart + 1) * Projection_K

                    If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                        For Each ReadElement As ReadItem In Feature.ReadList
                            ReadElement.ReadProjectionStart = (Feature.AbsoluteStart + ReadElement.ReadAbsoluteStart + strGenomeSequence.Length - intRangeStart) * Projection_K
                            ReadElement.ReadProjectionEnd = (Feature.AbsoluteStart + ReadElement.ReadAbsoluteEnd + strGenomeSequence.Length - intRangeStart + 1) * Projection_K
                        Next
                    End If

                    listDisplayedHighlightedSites.Add(Feature)
                End If
            Next


            'Sequence markers
            For Each Marker As SequenceMarker In listSequenceMarkers

                If Marker.Counted Then
                    Continue For
                End If

                Bioinformatics.CalculateMarkerProjectionOverlap(Marker, listDisplayedSequenceMarkers, _
                                                                  intRangeStart, intRangeEnd, _
                                                                  strGenomeSequence.Length, Projection_K)

            Next Marker


            'Integrated values
            For Each QHolder As QuantBlockHolder In listIntegratedValues
                For Each CurrentQ As QuantitationBlock In QHolder.BlocksList
                    If CurrentQ.AbsoluteEnd > intRangeStart Then 'Left side relative to zero
                        CurrentQ.ProjectionStart = (CurrentQ.AbsoluteStart - intRangeStart) * Projection_K
                        CurrentQ.ProjectionEnd = (CurrentQ.AbsoluteEnd - intRangeStart + 1) * Projection_K
                        listDisplayedIntegratedValues.Add(CurrentQ)
                    End If

                    If CurrentQ.AbsoluteStart < intRangeEnd Then 'Right side relative to zero
                        CurrentQ.ProjectionStart = (CurrentQ.AbsoluteStart + strGenomeSequence.Length - intRangeStart) * Projection_K
                        CurrentQ.ProjectionEnd = (CurrentQ.AbsoluteEnd + strGenomeSequence.Length - intRangeStart + 1) * Projection_K
                        listDisplayedIntegratedValues.Add(CurrentQ)
                    End If
                Next
            Next

        End If

        Sort_Displayed_Features() 'Sites and markers are not sorted as they are displayed on sequence lane and not arranged in Y direction

        ArrangeLayout()


        MarkOrder = 10 ^ Math.Truncate(Math.Log10(Range)) / 4
        If MarkOrder < 1 Then
            MarkOrder = 1
        End If

        Minimap.UpdateRange()

        DrawPanel.Invalidate()
        MinimapPanel.Invalidate()
        SequencePanel.Invalidate()
        TranslatePanel.Invalidate()
        GraphPanel.Invalidate()

        If AuxGraphPanels.Count > 0 Then
            For Each P As AuxilliaryGraphPanel In AuxGraphPanels
                P.Invalidate()
            Next P
        End If

        StartTextBox.Text = intRangeStart
        EndTextBox.Text = intRangeEnd
        RangeTextBox.Text = Range

    End Sub

    Private Sub Sort_Displayed_Features()
        Dim Tmp As Genome_Feature = Nothing
        For i = 1 To listDisplayedGenomeFeatures.Count - 1
            For j = 0 To listDisplayedGenomeFeatures.Count - 1 - i
                If listDisplayedGenomeFeatures(j).ProjectionStart > listDisplayedGenomeFeatures(j + 1).ProjectionStart Then
                    Tmp = listDisplayedGenomeFeatures(j)
                    listDisplayedGenomeFeatures(j) = listDisplayedGenomeFeatures(j + 1)
                    listDisplayedGenomeFeatures(j + 1) = Tmp
                End If
            Next
        Next
    End Sub

    Private Sub ArrangeLayout()

        Dim Master_Y As Integer = 0
        Dim Target_Y As Integer = 0

        For i = 0 To listDisplayedGenomeFeatures.Count - 1
            listDisplayedGenomeFeatures(i).LayoutOrder = 0
        Next

        For i = 0 To listDisplayedGenomeFeatures.Count - 1

            For j = i + 1 To listDisplayedGenomeFeatures.Count - 1
                If listDisplayedGenomeFeatures(j).ProjectionEnd >= listDisplayedGenomeFeatures(i).ProjectionStart And _
                listDisplayedGenomeFeatures(j).ProjectionStart <= listDisplayedGenomeFeatures(i).ProjectionEnd Then
                    listDisplayedGenomeFeatures(j).LayoutOrder = listDisplayedGenomeFeatures(i).LayoutOrder + 1
                    If listDisplayedGenomeFeatures(j).LayoutOrder >= MaxLayoutOrder Then
                        listDisplayedGenomeFeatures(j).LayoutOrder = 0
                    End If
                End If

            Next

        Next

    End Sub

    Private Sub Draw_Feature_Sequence(ByVal e As System.Windows.Forms.PaintEventArgs, ByVal Feature As Genome_Feature, ByVal CurrentY As Integer, ByVal Feature_Width As Integer)

        Dim Y_Seq_Offset As Integer = CurrentY + FeatureBorder

        Dim Seq As Char()

        If Feature.Direction = 2 Then
            Seq = Bioinformatics.ReverseStrand(Feature.Sequence).ToCharArray
        Else
            Seq = Feature.Sequence.ToCharArray
        End If

        Dim CurrentX As Integer = 0
        Dim GenomeSeq As String = DataIO.RetrieveSeqFromCache(strGenomeSequence, Feature.AbsoluteStart, Feature.AbsoluteEnd)
        If Feature.Direction = 2 Then
            GenomeSeq = Bioinformatics.GetComplement(GenomeSeq)
        End If
        Dim GenomeArray As Char() = GenomeSeq.ToCharArray
        Dim MyBrush As Brush = Brushes.Black
        Dim NegativeImpact As Integer = 0
        Dim buff As Char = ""

        Try

            For i = 0 To Seq.GetUpperBound(0)

                If Not Seq(i) = "#" Then
                    If Seq(i) = GenomeSeq(i - NegativeImpact) Then
                        MyBrush = Brushes.Black
                    Else
                        MyBrush = Brushes.LightSkyBlue
                    End If

                End If


                If Feature.AbsoluteEnd > intRangeStart Then
                    CurrentX = (Feature.AbsoluteStart - intRangeStart + i - NegativeImpact) * Projection_K
                Else
                    If Feature.AbsoluteEnd > intRangeStart Then
                        CurrentX = (Feature.AbsoluteStart - intRangeStart + i - NegativeImpact) * Projection_K
                    End If
                    If Feature.AbsoluteStart < intRangeEnd Then
                        CurrentX = (Feature.AbsoluteStart + strGenomeSequence.Length - intRangeStart + i - NegativeImpact) * Projection_K
                    End If
                End If


                If Not Seq(i) = "#" Then
                    e.Graphics.DrawString(Seq(i), SeqFont, MyBrush, CurrentX, Y_Seq_Offset)
                Else
                    e.Graphics.DrawLine(Pens.Red, CurrentX - 1, CurrentY, CurrentX - 1, CurrentY + FeatureH)
                    e.Graphics.DrawLine(Pens.Red, CurrentX - 3, CurrentY, CurrentX - 3, CurrentY + FeatureH)
                    NegativeImpact += 1
                End If

            Next i

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Draw_Feature_Translation(ByVal e As System.Windows.Forms.PaintEventArgs, ByVal Feature As Genome_Feature, ByVal CurrentY As Integer, ByVal Feature_Width As Integer)

        Dim Y_Seq_Offset As Integer = CurrentY + FeatureBorder
        Dim MyBrush As Brush = Brushes.Black
        Dim Seq As Char()

        If Feature.Direction = 2 Then
            Seq = Bioinformatics.ReverseStrand(Feature.Translation).ToCharArray
        Else
            Seq = Feature.Translation.ToCharArray
        End If

        Dim CurrentX As Integer = 0


        For i = 0 To Seq.GetUpperBound(0)

            If Feature.AbsoluteEnd > intRangeStart Then
                CurrentX = (Feature.AbsoluteStart - intRangeStart + i * 3) * Projection_K
            Else
                If Feature.AbsoluteEnd > intRangeStart Then
                    CurrentX = (Feature.AbsoluteStart - intRangeStart + i * 3) * Projection_K
                End If
                If Feature.AbsoluteStart < intRangeEnd Then
                    CurrentX = (Feature.AbsoluteStart + strGenomeSequence.Length - intRangeStart + i * 3) * Projection_K
                End If
            End If

            e.Graphics.DrawString(Seq(i), SeqFont, MyBrush, CurrentX, Y_Seq_Offset)

        Next i



    End Sub

    Private Sub Draw_Feature_Label(ByVal e As System.Windows.Forms.PaintEventArgs, ByVal Feature As Genome_Feature, ByVal CurrentY As Integer, ByVal Feature_Width As Integer)
        Dim StringSize As SizeF
        Dim VisibleRegionStart As Integer = 0
        Dim VisibleRegionEnd As Integer = 0
        Dim LabelLocation As Integer = 0

        StringSize = e.Graphics.MeasureString(Feature.Name, MyFont)

        If StringSize.Width <= Feature_Width Then

            If Feature.ProjectionStart > 0 Then
                VisibleRegionStart = Feature.ProjectionStart
            Else
                VisibleRegionStart = 0
            End If

            If Feature.ProjectionEnd < DrawPanel.Width Then
                VisibleRegionEnd = Feature.ProjectionEnd
            Else
                VisibleRegionEnd = DrawPanel.Width
            End If

            If VisibleRegionEnd >= VisibleRegionStart Then
                LabelLocation = (VisibleRegionEnd + VisibleRegionStart) / 2 - StringSize.Width / 2
                e.Graphics.DrawString(Feature.Name, MyFont, Brushes.Black, LabelLocation, CurrentY + FeatureBorder)
            Else
                LabelLocation = (VisibleRegionStart + DrawPanel.Width) / 2 - StringSize.Width / 2
                e.Graphics.DrawString(Feature.Name, MyFont, Brushes.Black, LabelLocation, CurrentY + FeatureBorder)
                LabelLocation = (VisibleRegionEnd) / 2 - StringSize.Width / 2
                e.Graphics.DrawString(Feature.Name, MyFont, Brushes.Black, LabelLocation, CurrentY + FeatureBorder)
            End If



        End If
    End Sub

    Private Function Get_Feature_Poly(ByVal Feature As Genome_Feature, ByVal Feature_Width As Integer, ByVal CurrentY As Integer)
        Dim pt(0) As Point
        Dim Arrow_K As Integer = 0
        Dim Mid_H As Integer = FeatureH / 2

        Dim TopY As Integer = CurrentY + FeatureBorder
        Dim BottomY As Integer = CurrentY + FeatureH - FeatureBorder
        Dim MidY As Integer = CurrentY + Mid_H

        If Feature_Width < 10 Then
            Arrow_K = Math.Abs(Feature.ProjectionEnd - Feature.ProjectionStart) / 4
        Else
            Arrow_K = 10
        End If

        Select Case Feature.Type

            Case 5   'TSS

                Select Case Feature.Direction
                    Case 0
                        ReDim pt(1)

                        pt(0) = New Point(Feature.ProjectionStart, CurrentY)
                        pt(1) = New Point(Feature.ProjectionEnd, CurrentY)

                    Case 1
                        ReDim pt(2)

                        pt(0) = New Point(Feature.ProjectionStart, CurrentY + FeatureH)
                        pt(1) = New Point(Feature.ProjectionStart, CurrentY)
                        pt(2) = New Point(Feature.ProjectionStart + DrawPanel.Width / 50, CurrentY)

                    Case 2
                        ReDim pt(2)

                        pt(0) = New Point(Feature.ProjectionEnd, CurrentY)
                        pt(1) = New Point(Feature.ProjectionEnd, CurrentY + FeatureH)
                        pt(2) = New Point(Feature.ProjectionEnd - DrawPanel.Width / 50, CurrentY + FeatureH)


                    Case 3
                        ReDim pt(1)

                        pt(0) = New Point(Feature.ProjectionStart, CurrentY)
                        pt(1) = New Point(Feature.ProjectionEnd, CurrentY)

                End Select

            Case 6 'Terminators

                Select Case Feature.Direction
                    Case 0
                        ReDim pt(1)

                        pt(0) = New Point(Feature.ProjectionStart, CurrentY)
                        pt(1) = New Point(Feature.ProjectionEnd, CurrentY)

                    Case 1
                        ReDim pt(2)

                        pt(0) = New Point(Feature.ProjectionStart + DrawPanel.Width / 100, CurrentY + FeatureH)
                        pt(1) = New Point(Feature.ProjectionStart, CurrentY + FeatureH)
                        pt(2) = New Point(Feature.ProjectionStart, CurrentY + Mid_H)

                    Case 2
                        ReDim pt(2)

                        pt(0) = New Point(Feature.ProjectionEnd - DrawPanel.Width / 100, CurrentY)
                        pt(1) = New Point(Feature.ProjectionEnd, CurrentY)
                        pt(2) = New Point(Feature.ProjectionEnd, CurrentY + Mid_H)

                    Case 3
                        ReDim pt(1)

                        pt(0) = New Point(Feature.ProjectionStart, CurrentY)
                        pt(1) = New Point(Feature.ProjectionEnd, CurrentY)

                End Select


            Case Else
                Select Case Feature.Direction
                    Case 0
                        ReDim pt(3)

                        pt(0) = New Point(Feature.ProjectionStart, TopY)
                        pt(1) = New Point(Feature.ProjectionEnd, TopY)
                        pt(2) = New Point(Feature.ProjectionEnd, BottomY)
                        pt(3) = New Point(Feature.ProjectionStart, BottomY)

                    Case 1
                        ReDim pt(4)

                        pt(0) = New Point(Feature.ProjectionStart, TopY)
                        pt(1) = New Point(Feature.ProjectionEnd - Arrow_K, TopY)
                        pt(2) = New Point(Feature.ProjectionEnd, MidY)
                        pt(3) = New Point(Feature.ProjectionEnd - Arrow_K, BottomY)
                        pt(4) = New Point(Feature.ProjectionStart, BottomY)

                    Case 2
                        ReDim pt(4)

                        pt(0) = New Point(Feature.ProjectionStart, MidY)
                        pt(1) = New Point(Feature.ProjectionStart + Arrow_K, TopY)
                        pt(2) = New Point(Feature.ProjectionEnd, TopY)
                        pt(3) = New Point(Feature.ProjectionEnd, BottomY)
                        pt(4) = New Point(Feature.ProjectionStart + Arrow_K, BottomY)

                    Case 3
                        ReDim pt(5)

                        pt(0) = New Point(Feature.ProjectionStart + Arrow_K, TopY)
                        pt(1) = New Point(Feature.ProjectionEnd - Arrow_K, TopY)
                        pt(2) = New Point(Feature.ProjectionEnd, MidY)
                        pt(3) = New Point(Feature.ProjectionEnd - Arrow_K, BottomY)
                        pt(4) = New Point(Feature.ProjectionStart + Arrow_K, BottomY)
                        pt(5) = New Point(Feature.ProjectionStart, MidY)

                End Select

        End Select


        Return pt
    End Function

    Private Function Get_Feature_Brush(ByVal Feature As Genome_Feature)
        Dim FillBrush As New SolidBrush(Color.Silver)
        Select Case Feature.Type
            Case 1 'ORF
                If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                    FillBrush = New SolidBrush(Color.FromArgb(100, 255, 0, 0))
                Else
                    FillBrush = Brushes.Red
                End If
            Case 2 'structural RNA
                If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                    FillBrush = New SolidBrush(Color.FromArgb(100, 0, 255, 0))
                Else
                    FillBrush = Brushes.Lime
                End If
            Case 3 'Binding site, regulatory sequence
                FillBrush = Brushes.Gold
            Case 4 'Non-coding RNA
                FillBrush = Brushes.GreenYellow
            Case 5 'TSS
                FillBrush = Brushes.MediumOrchid
            Case 6 'Transcription termination site
                FillBrush = Brushes.Gold
            Case 7 'Highlidhted
                FillBrush = Brushes.LightGray
            Case 8 'User
                FillBrush = Brushes.Pink
            Case 9 'Repeat
                FillBrush = Brushes.PowderBlue
            Case 10
                FillBrush = Brushes.Goldenrod
            Case 11
                FillBrush = Brushes.LightGray
            Case 12 'mRNAs, intron-exon structure and operons
                If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                    FillBrush = New SolidBrush(Color.FromArgb(100, 50, 205, 50))
                Else
                    FillBrush = Brushes.LimeGreen
                End If

            Case Else
                FillBrush = Brushes.Gray
        End Select


        'If Feature.Selected Then

        'FillBrush = New SolidBrush(Color.FromArgb(FillBrush.Color.A, 255 - FillBrush.Color.R, 255 - FillBrush.Color.G, 255 - FillBrush.Color.B))

        'End If

        Return FillBrush
    End Function

    Private Function Get_Feature_Segment_Brush(ByVal Feature As Genome_Feature)
        Dim FillBrush As New SolidBrush(Color.Silver)

        If Feature.Selected Then

            FillBrush = Brushes.Cyan

        Else
            Select Case Feature.Type
                Case 1 'ORF
                    FillBrush = Brushes.Red
                Case 2 'RNA
                    FillBrush = Brushes.Lime
                Case 3 'Binding site, regulatory sequence
                    FillBrush = Brushes.Gold
                Case 4 'Non-coding RNA
                    FillBrush = Brushes.PaleGreen
                Case 5 'TSS
                    FillBrush = Brushes.MediumOrchid
                Case 6 'Transcription termination site
                    FillBrush = Brushes.Gold
                Case 7 'Highlidhted
                    FillBrush = Brushes.LightGray
                Case 8 'User
                    FillBrush = Brushes.Pink
                Case 9 'Repeat
                    FillBrush = Brushes.PowderBlue
                Case 10
                    FillBrush = Brushes.Goldenrod
                Case 12
                    FillBrush = Brushes.LimeGreen
                Case Else
                    FillBrush = Brushes.Gray
            End Select
        End If

        Return FillBrush
    End Function

    Private Function Get_Feature_Segment_Poly(ByVal ProjectionStart As Integer, ByVal ProjectionEnd As Integer, ByVal CurrentY As Integer, ByVal Dir As Short, Optional ByVal Feature As Genome_Feature = Nothing, Optional ByVal Feature_Width As Integer = 0)

        Dim pt As Point()
        Dim TopY As Integer = CurrentY + FeatureBorder
        Dim BottomY As Integer = CurrentY + FeatureH - FeatureBorder


        Select Case Dir
            Case 0
                ReDim pt(3)
                pt(0) = New Point(ProjectionStart, TopY)
                pt(1) = New Point(ProjectionEnd, TopY)
                pt(2) = New Point(ProjectionEnd, BottomY)
                pt(3) = New Point(ProjectionStart, BottomY)

            Case 1 'Plus
                Dim Arrow_K As Integer = 0
                Dim Mid_H As Integer = FeatureH / 2
                Dim MidY As Integer = CurrentY + Mid_H

                If Feature_Width < 10 Then
                    Arrow_K = Math.Abs(Feature.ProjectionEnd - Feature.ProjectionStart) / 4
                Else
                    Arrow_K = 10
                End If

                ReDim pt(4)

                pt(0) = New Point(ProjectionStart, TopY)
                pt(1) = New Point(ProjectionEnd - Arrow_K, TopY)
                pt(2) = New Point(ProjectionEnd, MidY)
                pt(3) = New Point(ProjectionEnd - Arrow_K, BottomY)
                pt(4) = New Point(ProjectionStart, BottomY)

            Case 2 'Minus
                Dim Arrow_K As Integer = 0
                Dim Mid_H As Integer = FeatureH / 2
                Dim MidY As Integer = CurrentY + Mid_H

                If Feature_Width < 10 Then
                    Arrow_K = Math.Abs(Feature.ProjectionEnd - Feature.ProjectionStart) / 4
                Else
                    Arrow_K = 10
                End If

                ReDim pt(4)

                pt(0) = New Point(ProjectionStart, TopY)
                pt(1) = New Point(ProjectionEnd + Arrow_K, TopY)
                pt(2) = New Point(ProjectionEnd, MidY)
                pt(3) = New Point(ProjectionEnd + Arrow_K, BottomY)
                pt(4) = New Point(ProjectionStart, BottomY)

            Case Else
                ReDim pt(3)
                pt(0) = New Point(ProjectionStart, TopY)
                pt(1) = New Point(ProjectionEnd, TopY)
                pt(2) = New Point(ProjectionEnd, BottomY)
                pt(3) = New Point(ProjectionStart, BottomY)
        End Select


        Return pt
    End Function

    Private Function Get_Inverted_Feature_Poly_Left(ByVal Feature As Genome_Feature, ByVal Feature_Width As Integer, ByVal CurrentY As Integer)
        Dim pt(0) As Point
        Dim Arrow_K As Integer = 0
        Dim Mid_H As Integer = FeatureH / 2

        Dim TopY As Integer = CurrentY + FeatureBorder
        Dim BottomY As Integer = CurrentY + FeatureH - FeatureBorder
        Dim MidY As Integer = CurrentY + Mid_H

        If Feature_Width < 10 Then
            Arrow_K = Feature_Width / 4
        Else
            Arrow_K = 10
        End If

        Select Case Feature.Type

            Case 5   'TSS

                Select Case Feature.Direction
                    Case 0
                        ReDim pt(1)

                        pt(0) = New Point(Feature.ProjectionStart, CurrentY)
                        pt(1) = New Point(Feature.ProjectionEnd, CurrentY)

                    Case 1
                        ReDim pt(2)

                        pt(0) = New Point(Feature.ProjectionStart, CurrentY + FeatureH)
                        pt(1) = New Point(Feature.ProjectionStart, CurrentY)
                        pt(2) = New Point(Feature.ProjectionStart + DrawPanel.Width / 50, CurrentY)

                    Case 2
                        ReDim pt(2)

                        pt(0) = New Point(Feature.ProjectionEnd, CurrentY + FeatureH)
                        pt(1) = New Point(Feature.ProjectionEnd, CurrentY)
                        pt(2) = New Point(Feature.ProjectionEnd - DrawPanel.Width / 50, CurrentY)

                    Case 3
                        ReDim pt(1)

                        pt(0) = New Point(Feature.ProjectionStart, CurrentY)
                        pt(1) = New Point(Feature.ProjectionEnd, CurrentY)

                End Select

            Case Else
                Select Case Feature.Direction
                    Case 0
                        ReDim pt(3)

                        pt(0) = New Point(0, TopY)
                        pt(1) = New Point(Feature.ProjectionEnd, TopY)
                        pt(2) = New Point(Feature.ProjectionEnd, BottomY)
                        pt(3) = New Point(0, BottomY)

                    Case 1
                        ReDim pt(4)

                        pt(0) = New Point(0, TopY)
                        pt(1) = New Point(Feature.ProjectionEnd - Arrow_K, TopY)
                        pt(2) = New Point(Feature.ProjectionEnd, MidY)
                        pt(3) = New Point(Feature.ProjectionEnd - Arrow_K, BottomY)
                        pt(4) = New Point(0, BottomY)

                    Case 2
                        ReDim pt(4)

                        pt(0) = New Point(0, MidY)
                        pt(1) = New Point(0, TopY)
                        pt(2) = New Point(Feature.ProjectionEnd, TopY)
                        pt(3) = New Point(Feature.ProjectionEnd, BottomY)
                        pt(4) = New Point(0, BottomY)

                    Case 3
                        ReDim pt(5)

                        pt(0) = New Point(0, TopY)
                        pt(1) = New Point(Feature.ProjectionEnd - Arrow_K, TopY)
                        pt(2) = New Point(Feature.ProjectionEnd, MidY)
                        pt(3) = New Point(Feature.ProjectionEnd - Arrow_K, BottomY)
                        pt(4) = New Point(0, BottomY)
                        pt(5) = New Point(0, MidY)

                End Select

        End Select


        Return pt
    End Function

    Private Function Get_Inverted_Feature_Poly_Right(ByVal Feature As Genome_Feature, ByVal Feature_Width As Integer, ByVal CurrentY As Integer)
        Dim pt(0) As Point
        Dim Arrow_K As Integer = 0
        Dim Mid_H As Integer = FeatureH / 2

        Dim TopY As Integer = CurrentY + FeatureBorder
        Dim BottomY As Integer = CurrentY + FeatureH - FeatureBorder
        Dim MidY As Integer = CurrentY + Mid_H

        If Feature_Width < 10 Then
            Arrow_K = Feature_Width / 4
        Else
            Arrow_K = 10
        End If

        Select Case Feature.Type

            Case 5   'TSS

                Select Case Feature.Direction
                    Case 0
                        ReDim pt(1)

                        pt(0) = New Point(Feature.ProjectionStart, CurrentY)
                        pt(1) = New Point(Feature.ProjectionEnd, CurrentY)

                    Case 1
                        ReDim pt(2)

                        pt(0) = New Point(Feature.ProjectionStart, CurrentY + FeatureH)
                        pt(1) = New Point(Feature.ProjectionStart, CurrentY)
                        pt(2) = New Point(Feature.ProjectionStart + DrawPanel.Width / 50, CurrentY)

                    Case 2
                        ReDim pt(2)

                        pt(0) = New Point(Feature.ProjectionEnd, CurrentY + FeatureH)
                        pt(1) = New Point(Feature.ProjectionEnd, CurrentY)
                        pt(2) = New Point(Feature.ProjectionEnd - DrawPanel.Width / 50, CurrentY)

                    Case 3
                        ReDim pt(1)

                        pt(0) = New Point(Feature.ProjectionStart, CurrentY)
                        pt(1) = New Point(Feature.ProjectionEnd, CurrentY)

                End Select

            Case Else
                Select Case Feature.Direction
                    Case 0
                        ReDim pt(3)

                        pt(0) = New Point(Feature.ProjectionStart, TopY)
                        pt(1) = New Point(DrawPanel.Width, TopY)
                        pt(2) = New Point(DrawPanel.Width, BottomY)
                        pt(3) = New Point(Feature.ProjectionStart, BottomY)

                    Case 1
                        ReDim pt(4)

                        pt(0) = New Point(Feature.ProjectionStart, TopY)
                        pt(1) = New Point(DrawPanel.Width, TopY)
                        pt(2) = New Point(DrawPanel.Width, MidY)
                        pt(3) = New Point(DrawPanel.Width, BottomY)
                        pt(4) = New Point(Feature.ProjectionStart, BottomY)

                    Case 2
                        ReDim pt(4)

                        pt(0) = New Point(Feature.ProjectionStart, MidY)
                        pt(1) = New Point(Feature.ProjectionStart + Arrow_K, TopY)
                        pt(2) = New Point(DrawPanel.Width, TopY)
                        pt(3) = New Point(DrawPanel.Width, BottomY)
                        pt(4) = New Point(Feature.ProjectionStart + Arrow_K, BottomY)

                    Case 3
                        ReDim pt(5)

                        pt(0) = New Point(Feature.ProjectionStart + Arrow_K, TopY)
                        pt(1) = New Point(DrawPanel.Width, TopY)
                        pt(2) = New Point(DrawPanel.Width, MidY)
                        pt(3) = New Point(DrawPanel.Width, BottomY)
                        pt(4) = New Point(Feature.ProjectionStart + Arrow_K, BottomY)
                        pt(5) = New Point(Feature.ProjectionStart, MidY)

                End Select

        End Select


        Return pt
    End Function

    Private Function Get_Marker_Poly(ByVal CurrentMarker As SequenceMarker, ByVal PrimaryPoly As Boolean)
        Dim pt(2) As Point

        pt(0) = New Point(CurrentMarker.ProjectionPosition, MarkerHeight)
        pt(1) = New Point(CurrentMarker.ProjectionPosition - MarkerWidthHalf, 0)
        pt(2) = New Point(CurrentMarker.ProjectionPosition + MarkerWidthHalf, 0)

        Return pt
    End Function

    Private Function Get_Marker_Brush(ByVal CurrentMarker As SequenceMarker)
        If CurrentMarker.Selected Then
            Return Brushes.Red
        ElseIf Not IsNothing(CurrentMarker.MyPartner) Then
            Return Brushes.Lime
        Else
            Return Brushes.DodgerBlue
        End If
    End Function

    Private Sub DrawGeneRuller(ByVal e As System.Windows.Forms.PaintEventArgs)
        Dim MarkNumber As Integer = Math.Truncate(Range / MarkOrder)
        Dim CurrentMark As Integer = Math.Round((intRangeStart / MarkOrder), 0) * MarkOrder
        Dim MarkProjection As Integer = 0
        Dim Offset_B As Boolean = False
        Dim Offset As Integer = 0

        For i = 0 To MarkNumber

            If CurrentMark > strGenomeSequence.Length Then
                CurrentMark -= strGenomeSequence.Length
            End If

            If intRangeStart < intRangeEnd Then
                MarkProjection = (CurrentMark - intRangeStart) * Projection_K

                If Offset_B Then
                    Offset = 20
                Else
                    Offset = 10
                End If

                Offset_B = Not Offset_B

                e.Graphics.DrawLine(Pens.Black, MarkProjection, RullerOffset, MarkProjection, RullerOffset + 10)
                e.Graphics.DrawLine(Pens.Black, MarkProjection, RullerOffset + 35, MarkProjection, RullerOffset + 50)
                e.Graphics.DrawString(CurrentMark, MyFont, Brushes.Black, MarkProjection, RullerOffset + Offset)
            Else

                If CurrentMark >= intRangeStart Then
                    MarkProjection = (CurrentMark - intRangeStart) * Projection_K

                    If Offset_B Then
                        Offset = 20
                    Else
                        Offset = 10
                    End If

                    Offset_B = Not Offset_B

                    e.Graphics.DrawLine(Pens.Black, MarkProjection, RullerOffset, MarkProjection, RullerOffset + 10)
                    e.Graphics.DrawLine(Pens.Black, MarkProjection, RullerOffset + 35, MarkProjection, RullerOffset + 50)
                    e.Graphics.DrawString(CurrentMark, MyFont, Brushes.Black, MarkProjection, RullerOffset + Offset)
                End If

                If CurrentMark <= intRangeEnd Then
                    MarkProjection = (CurrentMark + strGenomeSequence.Length - intRangeStart) * Projection_K

                    If Offset_B Then
                        Offset = 20
                    Else
                        Offset = 10
                    End If

                    Offset_B = Not Offset_B

                    e.Graphics.DrawLine(Pens.Black, MarkProjection, RullerOffset, MarkProjection, RullerOffset + 10)
                    e.Graphics.DrawLine(Pens.Black, MarkProjection, RullerOffset + 35, MarkProjection, RullerOffset + 50)
                    e.Graphics.DrawString(CurrentMark, MyFont, Brushes.Black, MarkProjection, RullerOffset + Offset)
                End If

            End If


            CurrentMark += MarkOrder
        Next

    End Sub

    Public Sub DrawFeaturesRuller(ByVal e As System.Windows.Forms.PaintEventArgs, ByVal Height As Integer)
        Dim MarkNumber As Integer = Math.Truncate(Range / MarkOrder)
        Dim CurrentMark As Integer = Math.Round((intRangeStart / MarkOrder), 0) * MarkOrder
        Dim MarkProjection As Integer = 0
        Dim LinePen As New Pen(Color.Black, 1)
        LinePen.DashStyle = Drawing2D.DashStyle.Dot

        For i = 0 To MarkNumber
            If CurrentMark > strGenomeSequence.Length Then
                CurrentMark -= strGenomeSequence.Length
            End If

            If intRangeStart < intRangeEnd Then
                MarkProjection = (CurrentMark - intRangeStart) * Projection_K
                e.Graphics.DrawLine(LinePen, MarkProjection, 0, MarkProjection, Height)
            Else

                If CurrentMark > intRangeStart Then
                    MarkProjection = (CurrentMark - intRangeStart) * Projection_K
                    e.Graphics.DrawLine(LinePen, MarkProjection, 0, MarkProjection, Height)
                End If

                If CurrentMark < intRangeEnd Then
                    MarkProjection = (CurrentMark + strGenomeSequence.Length - intRangeStart) * Projection_K
                    e.Graphics.DrawLine(LinePen, MarkProjection, 0, MarkProjection, Height)
                End If

            End If


            CurrentMark += MarkOrder
        Next
    End Sub

    Private Sub DrawSequence(ByVal e As System.Windows.Forms.PaintEventArgs)

        If Range <= 500 Then

            Dim GenomeBarLength As Integer = DrawPanel.Width
            Dim TextBrushPlus As Brush = Brushes.Black
            Dim TextBrushMinus As Brush = Brushes.Black
            Dim MarkBrushPlus As New SolidBrush(Color.White)
            Dim MarkBrushMinus As New SolidBrush(Color.White)
            Dim HighlightRectPlus As New Rectangle
            Dim HighlightRectMinus As New Rectangle

            Dim Seq_String As String = DataIO.RetrieveSeqFromCache(strGenomeSequence, intRangeStart, intRangeEnd)

            Dim Seq As Char() = Seq_String.ToCharArray
            Dim SeqComplement As Char() = Bioinformatics.GetComplement(Seq_String).ToCharArray


            Dim Current_X As Integer = 0
            Dim Current_Length As Integer = 0

            For i = 0 To Seq.GetUpperBound(0)
                Current_X = (i) * Projection_K
                Current_Length = (i + 1) * Projection_K

                If bSelectionMode And (i + 1) + RangeStart >= RangeValues(0) And (i + 1) + RangeStart <= RangeValues(1) Then

                    Select Case Seq(i)
                        Case "A"
                            TextBrushPlus = Brushes.Salmon
                            TextBrushMinus = Brushes.Gold
                        Case "T"
                            TextBrushPlus = Brushes.Gold
                            TextBrushMinus = Brushes.Salmon
                        Case "G"
                            TextBrushPlus = Brushes.DeepSkyBlue
                            TextBrushMinus = Brushes.Lime
                        Case "C"
                            TextBrushPlus = Brushes.Lime
                            TextBrushMinus = Brushes.DeepSkyBlue
                        Case Else
                            TextBrushPlus = Brushes.White
                            TextBrushMinus = Brushes.White
                    End Select

                    MarkBrushPlus.Color = Color.DarkBlue
                    MarkBrushMinus.Color = Color.DarkBlue

                Else

                    TextBrushPlus = Brushes.Black
                    TextBrushMinus = Brushes.Black

                    Select Case Seq(i)
                        Case "A"
                            MarkBrushPlus.Color = Color.Salmon
                            MarkBrushMinus.Color = Color.Gold
                        Case "T"
                            MarkBrushPlus.Color = Color.Gold
                            MarkBrushMinus.Color = Color.Salmon
                        Case "G"
                            MarkBrushPlus.Color = Color.DeepSkyBlue
                            MarkBrushMinus.Color = Color.Lime
                        Case "C"
                            MarkBrushPlus.Color = Color.Lime
                            MarkBrushMinus.Color = Color.DeepSkyBlue
                        Case Else
                            MarkBrushPlus.Color = Color.White
                            MarkBrushMinus.Color = Color.White
                    End Select

                End If

                HighlightRectPlus.Location = New Point(Current_X, SeqLaneOffset)
                HighlightRectPlus.Size = New Size(Current_Length - Current_X, 12)

                HighlightRectMinus.Location = New Point(Current_X, 12 + SeqLaneOffset)
                HighlightRectMinus.Size = New Size(Current_Length - Current_X, 12)

                e.Graphics.FillRectangle(MarkBrushPlus, HighlightRectPlus)
                e.Graphics.FillRectangle(MarkBrushMinus, HighlightRectMinus)

                If Range <= 100 Then
                    e.Graphics.DrawString(Seq(i), SeqFont, TextBrushPlus, Current_X, SeqLaneOffset)
                    e.Graphics.DrawString(SeqComplement(i), SeqFont, TextBrushMinus, Current_X, 12 + SeqLaneOffset)
                End If

            Next i

        Else
            If bDrawGrid Then
                DrawFeaturesRuller(e, SequencePanel.Height)
            End If

        End If

    End Sub

    Private Sub DrawTranslation6Frames(ByVal e As System.Windows.Forms.PaintEventArgs)

        If Range <= 500 Then

            Dim GenomeBarLength As Integer = DrawPanel.Width
            Dim TextBrush As Brush = Brushes.Black

            Dim HighlightRect As New Rectangle

            Dim CurrentAA As List(Of String) = DataIO.RetrieveTranslatedSeqFromCache(list6FrameTranslation, intRangeStart, intRangeEnd, MyControlBox.F1CheckBox.Checked, MyControlBox.F2CheckBox.Checked, MyControlBox.F3CheckBox.Checked, MyControlBox.R1CheckBox.Checked, MyControlBox.R2CheckBox.Checked, MyControlBox.R3CheckBox.Checked)


            Dim Current_X As Integer = 0
            Dim Prev_X As Integer = 0
            Dim Current_Length As Integer = 0
            Dim FrameVerticalOfset As Integer = 2

            If TranslationFullColor Then
                For i = 0 To CurrentAA(0).Length - 1
                    Current_X = (i) * Projection_K
                    Prev_X = (i - 1) * Projection_K
                    Current_Length = (i + 2) * Projection_K

                    FrameVerticalOfset = 2


                    For j = 0 To CurrentAA.Count - 1


                        Select Case CurrentAA(j)(i)
                            Case "*"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.Red, HighlightRect)
                            Case "M"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.LimeGreen, HighlightRect)
                            Case "K"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.DeepSkyBlue, HighlightRect)
                            Case "R"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.DeepSkyBlue, HighlightRect)
                            Case "H"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.Aqua, HighlightRect)
                            Case "D"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.Orchid, HighlightRect)
                            Case "E"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.Orchid, HighlightRect)
                            Case "N"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.Pink, HighlightRect)
                            Case "Q"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.Pink, HighlightRect)
                            Case "S"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.LightBlue, HighlightRect)
                            Case "T"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.LightBlue, HighlightRect)
                            Case "P"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.DarkKhaki, HighlightRect)
                            Case "C"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.Yellow, HighlightRect)
                            Case "U"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.Yellow, HighlightRect)
                            Case "F"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.Orange, HighlightRect)
                            Case "Y"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.Orange, HighlightRect)
                            Case "W"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.Orange, HighlightRect)
                            Case Else
                                If Not CurrentAA(j)(i) = "-" Then
                                    HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                    HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                    e.Graphics.DrawRectangle(Pens.Gray, HighlightRect)
                                End If
                        End Select


                        If Range <= 150 Then
                            If Not CurrentAA(j)(i) = "-" Then

                                e.Graphics.DrawString(CurrentAA(j)(i), SeqFont, TextBrush, Current_X, FrameVerticalOfset)
                            End If
                        End If

                        FrameVerticalOfset += 12


                    Next j

                Next i

            Else

                For i = 0 To CurrentAA(0).Length - 1
                    Current_X = (i) * Projection_K
                    Prev_X = (i - 1) * Projection_K
                    Current_Length = (i + 2) * Projection_K

                    FrameVerticalOfset = 2


                    For j = 0 To CurrentAA.Count - 1


                        Select Case CurrentAA(j)(i)
                            Case "*"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.Red, HighlightRect)
                            Case "M"
                                HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                e.Graphics.FillRectangle(Brushes.LimeGreen, HighlightRect)
                            Case Else
                                If Not CurrentAA(j)(i) = "-" Then
                                    HighlightRect.Location = New Point(Prev_X, FrameVerticalOfset)
                                    HighlightRect.Size = New Size(Current_Length - Prev_X, 12)
                                    e.Graphics.DrawRectangle(Pens.Gray, HighlightRect)
                                End If
                        End Select


                        If Range <= 150 Then
                            If Not CurrentAA(j)(i) = "-" Then

                                e.Graphics.DrawString(CurrentAA(j)(i), SeqFont, TextBrush, Current_X, FrameVerticalOfset)
                            End If
                        End If

                        FrameVerticalOfset += 12


                    Next j

                Next i

            End If


            'Draw selection for current AA
            'e.Graphics.DrawLine(Pens.Red, (intRangeStart + intTrippletStart) * Projection_K, 0, (intRangeStart + intTrippletStart) * Projection_K, 500)
            'e.Graphics.DrawLine(Pens.Red, (intRangeStart + intTrippletEnd) * Projection_K, 0, (intRangeStart + intTrippletEnd) * Projection_K, 500)

        Else
            If bDrawGrid Then
                DrawFeaturesRuller(e, TranslatePanel.Height)
            End If

        End If




    End Sub

    Private Sub DrawPositionalValues(ByVal e As System.Windows.Forms.PaintEventArgs)

        Try

            If listPositionalValues.Count > 0 And Not Range > 100000 Then

                Dim Current_X As Integer = 0
                Dim Previous_X As Integer = 0

                Dim Current_Length As Integer = 0
                Dim MarkBrush As New SolidBrush(Color.White)
                Dim HighlightRect As New Rectangle

                Dim CurrentRelativeValue As Integer = 0

                Dim CurrentIntList As List(Of Integer) = Nothing
                Dim CurrentLogList As List(Of Single) = Nothing

                Dim VisibleChart As Boolean = True
                Dim ChartStrand As Short = 0
                Dim ChartColor As Color = Color.Black
                Dim ChartScale As Short = 0
                Dim Baseline As Integer = GraphPanel.Height / 2

                Dim CurrentHeight As Integer = 0
                Dim PrevHeight As Integer = 0

                Dim AllowDraw As Boolean = False

                Dim MaxValue As Integer = 1
                Dim MaxLogValue As Single = 1

                Dim MaxList As Integer = 0

                'Direction list
                '0 - None
                '1 - Plus
                '2 - Minus
                '3 - Symmetrical
                '4 - Hairpin plus/minus
                '5 - Hairpin minus/plus


                If bPositionalNormalization Then 'Find global maximum

                    Dim GlobalMax As Integer = 0
                    Dim GlobalMaxLog As Integer = 0

                    For Each PosValHolder As PositionalValuesHolder In listPositionalValues
                        If Not PosValHolder.ShowOnSeparateLane Then
                            If PosValHolder.Visible Then
                                Select Case PosValHolder.Scale
                                    Case 0
                                        CurrentIntList = DataIO.RetrievePositionalValuesFromCache(PosValHolder, intRangeStart, intRangeEnd)
                                        MaxValue = Bioinformatics.Maximum(CurrentIntList)
                                        If MaxValue = 0 Then
                                            MaxValue = 1
                                        End If
                                        If MaxValue > GlobalMax Then
                                            GlobalMax = MaxValue
                                        End If
                                    Case 1
                                        CurrentLogList = DataIO.RetrievePositionalLogValuesFromCache(PosValHolder, intRangeStart, intRangeEnd)
                                        MaxLogValue = Bioinformatics.Maximum(CurrentLogList)
                                        If MaxLogValue = 0 Then
                                            MaxLogValue = 1
                                        End If
                                        If MaxLogValue > GlobalMaxLog Then
                                            GlobalMaxLog = MaxLogValue
                                        End If
                                End Select
                            End If
                        End If
                    Next PosValHolder

                    MaxValue = GlobalMax + 0.1 * GlobalMax
                    MaxLogValue = GlobalMaxLog + 0.1 * GlobalMaxLog

                End If 'bPositionalNormalization



                For Each PosValHolder As PositionalValuesHolder In listPositionalValues
                    If Not PosValHolder.ShowOnSeparateLane Then
                        If PosValHolder.Visible Then

                            Current_X = 0
                            Previous_X = 0
                            AllowDraw = False
                            CurrentHeight = Baseline
                            PrevHeight = Baseline


                            Select Case PosValHolder.Scale
                                Case 0
                                    CurrentIntList = DataIO.RetrievePositionalValuesFromCache(PosValHolder, intRangeStart, intRangeEnd)

                                    If Not bPositionalNormalization Then
                                        MaxValue = Bioinformatics.Maximum(CurrentIntList)
                                        If MaxValue = 0 Then
                                            MaxValue = 1
                                        End If
                                    End If

                                    MaxList = CurrentIntList.Count - 1

                                Case 1
                                    CurrentLogList = DataIO.RetrievePositionalLogValuesFromCache(PosValHolder, intRangeStart, intRangeEnd)

                                    If Not bPositionalNormalization Then
                                        MaxLogValue = Bioinformatics.Maximum(CurrentLogList)
                                        If MaxLogValue = 0 Then
                                            MaxLogValue = 1
                                        End If
                                    End If

                                    MaxList = CurrentLogList.Count - 1

                            End Select





                            Dim ChartPen As New Pen(PosValHolder.Draw_Color)
                            ChartPen.Width = 2

                            MarkBrush.Color = Color.FromArgb(50, PosValHolder.Draw_Color.R, PosValHolder.Draw_Color.G, PosValHolder.Draw_Color.B)


                            For i = 0 To MaxList
                                Previous_X = Current_X
                                PrevHeight = CurrentHeight
                                Current_X = (i) * Projection_K
                                Current_Length = (i + 1) * Projection_K

                                If AllowDraw Then

                                    Select Case PosValHolder.Scale
                                        Case 0
                                            CurrentRelativeValue = Baseline * CurrentIntList(i) / MaxValue
                                        Case 1
                                            CurrentRelativeValue = Baseline * CurrentLogList(i) / MaxLogValue
                                    End Select

                                    Select Case PosValHolder.Strand
                                        Case 0
                                            CurrentHeight = Baseline - CurrentRelativeValue
                                        Case 1
                                            CurrentHeight = Baseline - CurrentRelativeValue

                                            HighlightRect.Location = New Point(Current_X, CurrentHeight)

                                        Case 2
                                            CurrentHeight = Baseline + CurrentRelativeValue

                                            HighlightRect.Location = New Point(Current_X, Baseline)

                                    End Select


                                    If bChartStyle Then
                                        HighlightRect.Size = New Size(Current_Length - Current_X, CurrentRelativeValue)
                                        e.Graphics.FillRectangle(MarkBrush, HighlightRect)
                                    Else
                                        e.Graphics.DrawLine(ChartPen, Current_X, CurrentHeight, Previous_X, PrevHeight)
                                    End If


                                End If 'AllowDraw

                                AllowDraw = True

                            Next i

                            ChartPen.Dispose()

                        End If 'PosValHolder.Visible
                    End If 'Not PosValHolder.ShowOnSeparateLane
                Next PosValHolder

                'Draw baseline
                e.Graphics.DrawLine(Pens.Black, 0, Baseline, GraphPanel.Width, Baseline)

                If bPositionalNormalization And bPositionalRuller Then
                    e.Graphics.DrawLine(Pens.Black, 2, 3, 2, GraphPanel.Height - 3)
                    e.Graphics.DrawLine(Pens.Black, 0, 3, 4, 3)
                    e.Graphics.DrawLine(Pens.Black, 0, GraphPanel.Height - 3, 4, GraphPanel.Height - 3)

                    e.Graphics.DrawString(MaxValue, MyFont, Brushes.Black, 5, 3)
                    e.Graphics.DrawString(MaxValue, MyFont, Brushes.Black, 5, GraphPanel.Height - 10)
                End If

            End If


        Catch ex As Exception
            MsgBox("Error while drawing positional values chart")
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub DrawIntegratedValues(ByVal e As System.Windows.Forms.PaintEventArgs)
        Try
            If listIntegratedValues.Count > 0 Then

                Dim Baseline As Integer = GraphPanel.Height / 2
                Dim MaxTotal As Single = 0
                Dim AdjustedHeight As Single = 0
                Dim CurrentHeight As Single = 0
                Dim CurrentPen As New Pen(Color.Black)
                Dim CurrentBrush As New SolidBrush(Color.Black)

                For Each IntegratedValue As QuantitationBlock In listDisplayedIntegratedValues
                    If IntegratedValue.Visible Then
                        If IntegratedValue.Value > MaxTotal Then
                            MaxTotal = IntegratedValue.Value
                        End If
                    End If
                Next

                If bIntegratedLog Then
                    MaxTotal = Math.Log(MaxTotal)

                End If

                MaxTotal += MaxTotal * 0.1


                For Each IntegratedValue As QuantitationBlock In listDisplayedIntegratedValues
                    If IntegratedValue.Visible Then

                        If bIntegratedLog Then
                            If IntegratedValue.Value > 1 Then
                                AdjustedHeight = Baseline * Math.Log(IntegratedValue.Value) / MaxTotal
                            Else
                                AdjustedHeight = 0
                            End If

                        Else
                            AdjustedHeight = Baseline * IntegratedValue.Value / MaxTotal
                        End If


                        Select Case IntegratedValue.Direction
                            Case 1
                                CurrentHeight = Baseline - AdjustedHeight
                            Case 2
                                CurrentHeight = Baseline + AdjustedHeight
                        End Select


                        If bIntegratedFill Then
                            CurrentBrush.Color = Color.FromArgb(100, IntegratedValue.Draw_Color.R, IntegratedValue.Draw_Color.G, IntegratedValue.Draw_Color.B)

                            Dim pt(3) As Point
                            pt(0) = New Point(IntegratedValue.ProjectionStart, Baseline)
                            pt(1) = New Point(IntegratedValue.ProjectionStart, CurrentHeight)
                            pt(2) = New Point(IntegratedValue.ProjectionEnd, CurrentHeight)
                            pt(3) = New Point(IntegratedValue.ProjectionEnd, Baseline)

                            e.Graphics.FillPolygon(CurrentBrush, pt)

                        Else
                            CurrentPen.Color = IntegratedValue.Draw_Color

                            'Draw interval
                            e.Graphics.DrawLine(CurrentPen, IntegratedValue.ProjectionStart, CurrentHeight, IntegratedValue.ProjectionEnd, CurrentHeight)
                            'Draw vertical borders
                            e.Graphics.DrawLine(CurrentPen, IntegratedValue.ProjectionStart, CurrentHeight, IntegratedValue.ProjectionStart, Baseline)
                            e.Graphics.DrawLine(CurrentPen, IntegratedValue.ProjectionEnd, CurrentHeight, IntegratedValue.ProjectionEnd, Baseline)
                        End If


                    End If
                Next

                If Not IsNothing(cntrlSelected_Block) Then
                    Dim pt(3) As Point

                    Select Case cntrlSelected_Block.Direction
                        Case 1
                            pt(0) = New Point(cntrlSelected_Block.ProjectionStart, Baseline)
                            pt(1) = New Point(cntrlSelected_Block.ProjectionStart, 0)
                            pt(2) = New Point(cntrlSelected_Block.ProjectionEnd, 0)
                            pt(3) = New Point(cntrlSelected_Block.ProjectionEnd, Baseline)
                        Case 2
                            pt(0) = New Point(cntrlSelected_Block.ProjectionStart, GraphPanel.Height)
                            pt(1) = New Point(cntrlSelected_Block.ProjectionStart, Baseline)
                            pt(2) = New Point(cntrlSelected_Block.ProjectionEnd, Baseline)
                            pt(3) = New Point(cntrlSelected_Block.ProjectionEnd, GraphPanel.Height)
                    End Select

                    e.Graphics.FillPolygon(BlockSelectionBrush, pt)

                End If

                'Draw baseline
                e.Graphics.DrawLine(Pens.Black, 0, Baseline, GraphPanel.Width, Baseline)

            End If
        Catch ex As Exception
            MsgBox("Error while drawing positional values chart")
            MsgBox(ex.Message)
        End Try
    End Sub

    Public Sub AssignFeaturesVisibility()

        For Each Group As FeaturesAssembly In cntFeaturesGroupsList
            For Each Feature As Genome_Feature In Group.FeaturesList
                Select Case Feature.Type
                    Case 1
                        Feature.Visible = MyControlBox.CodingCheckBox.Checked
                    Case 2
                        Feature.Visible = MyControlBox.CodingCheckBox.Checked
                    Case 3
                        Feature.Visible = MyControlBox.SiteCheckBox.Checked
                    Case 4
                        Feature.Visible = MyControlBox.NCCheckBox.Checked
                    Case 5
                        Feature.Visible = MyControlBox.TranscriptionCheckBox.Checked
                    Case 6
                        Feature.Visible = MyControlBox.TranscriptionCheckBox.Checked
                    Case 7
                        Feature.Visible = MyControlBox.UserCheckBox.Checked
                    Case 8
                        Feature.Visible = MyControlBox.UserCheckBox.Checked
                    Case 9
                        Feature.Visible = MyControlBox.RepCheckBox.Checked
                    Case 10
                        Feature.Visible = MyControlBox.UserCheckBox.Checked
                    Case 11
                        Feature.Visible = MyControlBox.UserCheckBox.Checked
                    Case 12
                        Feature.Visible = MyControlBox.OperonsCheckBox.Checked

                End Select
            Next

        Next

    End Sub

    Private Sub Genome_Viewer_Resize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Resize

        MaxLayoutOrder = Math.Truncate((DrawPanel.Height - ZeroLayoutOffset) / FeatureH)
        Minimap.Size = New Size(MinimapPanel.Width - MinimapOffsetH * 2, 50)
        DisplayFeatures()

    End Sub

    Private Sub DrawPanel_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles DrawPanel.Paint

        'Graphics
        Dim CurrentY As Integer = 0
        Dim Feature_Width As Integer = 0
        Dim FillBrush As Brush = Brushes.Magenta
        Dim SelectionPen As New Pen(Color.DarkBlue, 6)
        Dim RegularTSSPen As New Pen(Color.Black, 2)
        Dim SelectionTSSPen As New Pen(Color.BlueViolet, 2)
        Dim TSSArrowPath As New Drawing2D.GraphicsPath
        TSSArrowPath.AddLine(0, 0, 1, -3)
        TSSArrowPath.AddLine(0, 0, -1, -3)
        Dim TSSArrow As New Drawing2D.CustomLineCap(Nothing, TSSArrowPath)
        RegularTSSPen.CustomEndCap = TSSArrow
        SelectionTSSPen.CustomEndCap = TSSArrow

        Dim RegularTermPen As New Pen(Color.Black, 2)
        Dim SelectionTermPen As New Pen(Color.BlueViolet, 2)
        Dim TermSymbolPath As New Drawing2D.GraphicsPath
        TermSymbolPath.AddEllipse(-2, 0, 4, 4)
        Dim TermArrow As New Drawing2D.CustomLineCap(Nothing, TermSymbolPath)
        RegularTermPen.CustomEndCap = TermArrow
        SelectionTermPen.CustomEndCap = TermArrow

        If bDrawGrid Then
            DrawFeaturesRuller(e, DrawPanel.Height)
        End If

        For Each Feature As Genome_Feature In listDisplayedGenomeFeatures

            CurrentY = FeatureH * Feature.LayoutOrder + ZeroLayoutOffset
            Feature_Width = Math.Abs(Feature.ProjectionEnd - Feature.ProjectionStart)

            Select Case Feature.Type

                Case 5 'Special graphics for transcription start sites

                    If Feature.Selected Then
                        e.Graphics.DrawLines(SelectionTSSPen, Get_Feature_Poly(Feature, Feature_Width, CurrentY))
                    Else
                        e.Graphics.DrawLines(RegularTSSPen, Get_Feature_Poly(Feature, Feature_Width, CurrentY))
                    End If

                Case 6 'Special graphics for transcription termination sites

                    If Feature.Selected Then
                        e.Graphics.DrawLines(SelectionTermPen, Get_Feature_Poly(Feature, Feature_Width, CurrentY))
                    Else
                        e.Graphics.DrawLines(RegularTermPen, Get_Feature_Poly(Feature, Feature_Width, CurrentY))
                    End If

                Case Else

                    If Feature.InvertedView Then

                        If Feature.Selected Then
                            e.Graphics.DrawPolygon(SelectionPen, Get_Inverted_Feature_Poly_Left(Feature, Feature_Width, CurrentY))
                            e.Graphics.DrawPolygon(SelectionPen, Get_Inverted_Feature_Poly_Right(Feature, Feature_Width, CurrentY))

                        End If

                        e.Graphics.FillPolygon(Get_Feature_Brush(Feature), Get_Inverted_Feature_Poly_Left(Feature, Feature_Width, CurrentY))
                        e.Graphics.FillPolygon(Get_Feature_Brush(Feature), Get_Inverted_Feature_Poly_Right(Feature, Feature_Width, CurrentY))

                    Else

                        If Feature.Selected Then
                            e.Graphics.DrawPolygon(SelectionPen, Get_Feature_Poly(Feature, Feature_Width, CurrentY))

                        End If

                        e.Graphics.FillPolygon(Get_Feature_Brush(Feature), Get_Feature_Poly(Feature, Feature_Width, CurrentY))

                        If Feature.UseReadList And Feature.ReadList.Count > 0 And Range <= UltrastructureLim Then
                            Dim FL As Integer = Feature.AbsoluteEnd - Feature.AbsoluteStart
                            For Each ReadElement As ReadItem In Feature.ReadList

                                e.Graphics.FillPolygon(Get_Feature_Segment_Brush(Feature), Get_Feature_Segment_Poly(ReadElement.ReadProjectionStart, ReadElement.ReadProjectionEnd, CurrentY, Feature.Direction, Feature, Feature_Width))

                            Next ReadElement
                        End If

                    End If


            End Select

            If Feature.Type = 7 And Range < 100 Then
                Draw_Feature_Sequence(e, Feature, CurrentY, Feature_Width)
            ElseIf Feature.DisplayTranslation = True And Range < 300 Then
                Draw_Feature_Translation(e, Feature, CurrentY, Feature_Width)
            Else
                Draw_Feature_Label(e, Feature, CurrentY, Feature_Width)
            End If

        Next Feature

    End Sub

    Private Sub MinimapPanel_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MinimapPanel.Paint
        DrawGeneRuller(e)
    End Sub

    Private Sub SequencePanel_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles SequencePanel.Paint

        DrawSequence(e)

        Try
            For Each Marker As SequenceMarker In listDisplayedSequenceMarkers
                If Not IsNothing(Marker.MyPartner) Then

                    If Marker.Selected Then
                        BindingBrush = ActiveBindingBrush
                    Else
                        BindingBrush = InActiveBindingBrush
                    End If

                    If Marker.InvertedView Then
                        e.Graphics.FillRectangle(BindingBrush, Marker.GetStartMarker.ProjectionPosition, 0, SequencePanel.Width, SequencePanel.Height)
                        e.Graphics.FillRectangle(BindingBrush, 0, 0, Marker.GetEndMarker.ProjectionPosition, SequencePanel.Height)
                    Else
                        e.Graphics.FillRectangle(BindingBrush, Marker.GetStartMarker.ProjectionPosition, 0, Math.Abs(Marker.ProjectionPosition - Marker.MyPartner.ProjectionPosition), SequencePanel.Height)
                    End If

                    If Marker.Role Then
                        e.Graphics.DrawString("E", MyFont, Brushes.Black, Marker.ProjectionPosition - MarkerWidthHalf * 2 - 3, 1)
                        e.Graphics.DrawString(Marker.GetCoveredRange(strGenomeSequence.Length), MyFont, Brushes.Black, Marker.ProjectionPosition + MarkerWidthHalf, 1)
                    Else
                        e.Graphics.DrawString("S", MyFont, Brushes.Black, Marker.ProjectionPosition - MarkerWidthHalf * 2 - 3, 1)
                        e.Graphics.DrawString(Marker.GetCoveredRange(strGenomeSequence.Length), MyFont, Brushes.Black, Marker.ProjectionPosition + MarkerWidthHalf, 1)
                    End If
                End If

                e.Graphics.FillPolygon(Get_Marker_Brush(Marker), Get_Marker_Poly(Marker, False)) 'Body

            Next

        Catch ex As Exception
            MsgBox("error in markers")
        End Try

        Try


            For Each Feature As Genome_Feature In listDisplayedHighlightedSites

                If Feature.Selected Then
                    SiteHighlitePen.Color = Color.Red
                    SiteSmallPen.Color = Color.Red
                    SiteBrush = Brushes.Red
                Else
                    SiteHighlitePen.Color = Color.Green
                    SiteSmallPen.Color = Color.Green
                    SiteBrush = Brushes.Green
                End If

                Select Case Feature.Direction
                    Case 1
                        e.Graphics.DrawString(Feature.Name & " " & Feature.Description, MyFont, SiteBrush, Feature.ProjectionStart, 0) 'Name
                        e.Graphics.DrawLine(SiteHighlitePen, Feature.ProjectionStart, 12, Feature.ProjectionEnd, 12) 'Horizontal line
                        e.Graphics.DrawLine(SiteSmallPen, Feature.ProjectionStart, 12, Feature.ProjectionStart, 0) 'Vertical marker

                        If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                            For Each ReadElement As ReadItem In Feature.ReadList
                                e.Graphics.DrawLine(SiteHighlitePen, ReadElement.ReadProjectionStart, 12, ReadElement.ReadProjectionStart, 30)
                            Next
                        End If

                    Case 2
                        e.Graphics.DrawString(Feature.Name & " " & Feature.Description, MyFont, SiteBrush, Feature.ProjectionStart, 50) 'Name
                        e.Graphics.DrawLine(SiteHighlitePen, Feature.ProjectionStart, 50, Feature.ProjectionEnd, 50) 'Horizontal line
                        e.Graphics.DrawLine(SiteSmallPen, Feature.ProjectionStart, 50, Feature.ProjectionStart, 65) 'Vertical marker

                        If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                            For Each ReadElement As ReadItem In Feature.ReadList
                                e.Graphics.DrawLine(SiteHighlitePen, ReadElement.ReadProjectionStart, 50, ReadElement.ReadProjectionStart, 35)
                            Next
                        End If
                End Select
            Next

        Catch ex As Exception
            MsgBox("error in features")
        End Try


    End Sub

    Private Sub GraphPanel_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles GraphPanel.Paint

        If bDrawGrid Then
            DrawFeaturesRuller(e, GraphPanel.Height)
        End If

        DrawPositionalValues(e)
        DrawIntegratedValues(e)

    End Sub

    Private Sub TranslatePanel_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles TranslatePanel.Paint
        If list6FrameTranslation.Count = 6 Then
            Try
                DrawTranslation6Frames(e)
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try


        End If


    End Sub

#End Region

#Region "Hand tool"

    Private Function MousePositionToSeqCoord(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim GenomeCoord As Integer = intRangeStart + e.X * Range / TranslatePanel.Width
        If GenomeCoord > strGenomeSequence.Length Then
            GenomeCoord -= strGenomeSequence.Length
        End If
        Return GenomeCoord
    End Function

    Private Sub Initialize_Movement()
        HandScrollStart = True
        FeatureMovementStart = False
        HandInitLocationX = Windows.Forms.Cursor.Position.X
        HandInitLocationY = Windows.Forms.Cursor.Position.Y
        StepInitLocationX = Windows.Forms.Cursor.Position.X
        StepInitLocationY = Windows.Forms.Cursor.Position.Y
        InitialRangeStart = intRangeStart
        InitialRangeEnd = intRangeEnd
        DrawPanel.Cursor = Cursors.Hand
    End Sub

    Private Sub Initialize_Feature_Movement()
        If Not IsNothing(cntrlSelected_Feature) Then
            FeatureMovementStart = True
            HandScrollStart = False
            HandInitLocationX = Windows.Forms.Cursor.Position.X
            HandInitLocationY = Windows.Forms.Cursor.Position.Y
            StepInitLocationX = Windows.Forms.Cursor.Position.X
            StepInitLocationY = Windows.Forms.Cursor.Position.Y
            InitialRangeStart = cntrlSelected_Feature.AbsoluteStart
            InitialRangeEnd = cntrlSelected_Feature.AbsoluteEnd
            DrawPanel.Cursor = Cursors.Hand
        End If
    End Sub

    Private Sub Initialize_Marker_Movement()
        MarkerMovementStart = True
        HandScrollStart = False
        HandInitLocationX = Windows.Forms.Cursor.Position.X
        HandInitLocationY = Windows.Forms.Cursor.Position.Y
        StepInitLocationX = Windows.Forms.Cursor.Position.X
        StepInitLocationY = Windows.Forms.Cursor.Position.Y

        InitialRangeStart = cntSelectedMarker.AbsolutePosition

        SequencePanel.Cursor = Cursors.Hand

    End Sub

    Private Sub Do_Movement()

        Dim deltaX As Integer = -(Windows.Forms.Cursor.Position.X - HandInitLocationX)
        Dim deltaY As Integer = -(Windows.Forms.Cursor.Position.Y - HandInitLocationY)

        Dim step_deltaX As Integer = -(Windows.Forms.Cursor.Position.X - StepInitLocationX)
        Dim step_deltaY As Integer = -(Windows.Forms.Cursor.Position.Y - StepInitLocationY)

        Dim Range As Integer = 0
        If intRangeStart < intRangeEnd Then
            Range = intRangeEnd - intRangeStart
        Else
            Range = strGenomeSequence.Length - intRangeStart + intRangeEnd
        End If

        If Math.Abs(step_deltaX) > 10 Or Math.Abs(step_deltaY) > 10 Then

            Dim GenomeCoordChange_X As Integer = deltaX * Range / DrawPanel.Width
            Dim GenomeCoordChange_Y As Integer = 4 * deltaY * Range / DrawPanel.Width

            intRangeStart = InitialRangeStart + GenomeCoordChange_X - GenomeCoordChange_Y
            intRangeEnd = InitialRangeEnd + GenomeCoordChange_X + GenomeCoordChange_Y

            DisplayFeatures()

            StepInitLocationX = Windows.Forms.Cursor.Position.X
            StepInitLocationY = Windows.Forms.Cursor.Position.Y

        End If

    End Sub

    Private Sub Do_Feature_Movement()
        If Not IsNothing(cntrlSelected_Feature) Then
            Dim deltaX As Integer = (Windows.Forms.Cursor.Position.X - HandInitLocationX)
            Dim deltaY As Integer = -(Windows.Forms.Cursor.Position.Y - HandInitLocationY)

            Dim step_deltaX As Integer = -(Windows.Forms.Cursor.Position.X - StepInitLocationX)
            Dim step_deltaY As Integer = -(Windows.Forms.Cursor.Position.Y - StepInitLocationY)

            Dim Range As Integer = 0
            If intRangeStart < intRangeEnd Then
                Range = intRangeEnd - intRangeStart
            Else
                Range = strGenomeSequence.Length - intRangeStart + intRangeEnd
            End If

            If Math.Abs(step_deltaX) > 10 Or Math.Abs(step_deltaY) > 10 Then

                Dim GenomeCoordChange_X As Integer = deltaX * Range / DrawPanel.Width
                Dim GenomeCoordChange_Y As Integer = deltaY * Range / DrawPanel.Width


                If cntrlSelected_Feature.Type = 7 Then 'Highlighted sequence
                    cntrlSelected_Feature.AbsoluteStart = InitialRangeStart + GenomeCoordChange_X
                    cntrlSelected_Feature.AbsoluteEnd = InitialRangeEnd + GenomeCoordChange_X
                Else
                    cntrlSelected_Feature.AbsoluteStart = InitialRangeStart + GenomeCoordChange_X '- GenomeCoordChange_Y
                    cntrlSelected_Feature.AbsoluteEnd = InitialRangeEnd + GenomeCoordChange_X + GenomeCoordChange_Y
                End If

                If cntrlSelected_Feature.AbsoluteStart < 1 Then
                    cntrlSelected_Feature.AbsoluteStart = strGenomeSequence.Length + cntrlSelected_Feature.AbsoluteStart
                End If

                If cntrlSelected_Feature.AbsoluteEnd < 1 Then
                    cntrlSelected_Feature.AbsoluteEnd = strGenomeSequence.Length + cntrlSelected_Feature.AbsoluteEnd
                End If

                If cntrlSelected_Feature.AbsoluteStart > strGenomeSequence.Length Then
                    cntrlSelected_Feature.AbsoluteStart = cntrlSelected_Feature.AbsoluteStart - strGenomeSequence.Length
                End If

                If cntrlSelected_Feature.AbsoluteEnd > strGenomeSequence.Length Then
                    cntrlSelected_Feature.AbsoluteEnd = cntrlSelected_Feature.AbsoluteEnd - strGenomeSequence.Length
                End If

                'Display code here
                If intRangeStart < intRangeEnd Then
                    Bioinformatics.CalculateFeatureProjectionNormal(cntrlSelected_Feature, Nothing, intRangeStart, intRangeEnd, strGenomeSequence.Length, Projection_K)
                Else
                    Bioinformatics.CalculateFeatureProjectionOverlap(cntrlSelected_Feature, Nothing, intRangeStart, intRangeEnd, strGenomeSequence.Length, Projection_K)
                End If

                StepInitLocationX = Windows.Forms.Cursor.Position.X
                StepInitLocationY = Windows.Forms.Cursor.Position.Y

                Sort_Displayed_Features()
                ArrangeLayout()

                DrawPanel.Invalidate()

                Dim OligoSeq As String = GetFeatureSequence(cntrlSelected_Feature)
                MyReportBox.DescriptionTextBox.Text = String.Concat(cntrlSelected_Feature.Description, Environment.NewLine, "Tm = ", Bioinformatics.CalculateOligoTm(OligoSeq), "; %GC = ", Bioinformatics.CalculateCGContent(OligoSeq))
                MyReportBox.LocationTextBox.Text = String.Concat(cntrlSelected_Feature.AbsoluteStart, "-", cntrlSelected_Feature.AbsoluteEnd)

                If cntrlSelected_Feature.AbsoluteEnd >= cntrlSelected_Feature.AbsoluteStart Then
                    MyReportBox.LengthTextBox.Text = cntrlSelected_Feature.AbsoluteEnd - cntrlSelected_Feature.AbsoluteStart + 1
                Else
                    MyReportBox.LengthTextBox.Text = strGenomeSequence.Length - cntrlSelected_Feature.AbsoluteStart + cntrlSelected_Feature.AbsoluteEnd + 1
                End If

                'If cntrlSelected_Feature.Type = 7 Then
                'MyReportBox.DescriptionTextBox.Text &= (Environment.NewLine & "Identity = ")
                'End If

            End If

        End If
    End Sub

    Private Sub Do_Marker_Movement()
        If Not IsNothing(cntSelectedMarker) Then
            Dim deltaX As Integer = (Windows.Forms.Cursor.Position.X - HandInitLocationX)
            Dim deltaY As Integer = -(Windows.Forms.Cursor.Position.Y - HandInitLocationY)

            Dim step_deltaX As Integer = -(Windows.Forms.Cursor.Position.X - StepInitLocationX)
            Dim step_deltaY As Integer = -(Windows.Forms.Cursor.Position.Y - StepInitLocationY)


            If Math.Abs(step_deltaX) > 10 Or Math.Abs(step_deltaY) > 10 Then
                Dim GenomeCoordChange_X As Integer = deltaX * Range / DrawPanel.Width
                Dim GenomeCoordChange_Y As Integer = deltaY * Range / DrawPanel.Width


                cntSelectedMarker.AbsolutePosition = InitialRangeStart + GenomeCoordChange_X

                If cntSelectedMarker.AbsolutePosition <= 0 Then
                    cntSelectedMarker.AbsolutePosition = cntSelectedMarker.AbsolutePosition + strGenomeSequence.Length
                End If


                'Display code here
                If intRangeStart < intRangeEnd Then

                    cntSelectedMarker.ProjectionPosition = (cntSelectedMarker.AbsolutePosition - intRangeStart) * Projection_K

                Else
                    If cntSelectedMarker.AbsolutePosition > intRangeStart Then
                        cntSelectedMarker.ProjectionPosition = (cntSelectedMarker.AbsolutePosition - intRangeStart) * Projection_K
                    End If

                    If cntSelectedMarker.AbsolutePosition < intRangeEnd Then
                        cntSelectedMarker.ProjectionPosition = (cntSelectedMarker.AbsolutePosition + strGenomeSequence.Length - intRangeStart) * Projection_K
                    End If

                End If


                If Not (Not bGenomeTopology And cntSelectedMarker.AbsolutePosition = 1 And cntSelectedMarker.EndOfSeq) Then
                    cntSelectedMarker.EndOfSeq = False
                End If

                If cntSelectedMarker.AbsolutePosition > strGenomeSequence.Length Then
                    If Not bGenomeTopology And cntSelectedMarker.AbsolutePosition = strGenomeSequence.Length + 1 Then
                        cntSelectedMarker.EndOfSeq = True
                    End If

                    cntSelectedMarker.AbsolutePosition = cntSelectedMarker.AbsolutePosition - strGenomeSequence.Length

                End If



                StepInitLocationX = Windows.Forms.Cursor.Position.X
                StepInitLocationY = Windows.Forms.Cursor.Position.Y
                SequencePanel.Invalidate()

            End If


        End If

    End Sub

    Private Sub Terminate_Movement()
        HandScrollStart = False
        FeatureMovementStart = False
        DrawPanel.Cursor = Cursors.Default
        DisplayFeatures()
    End Sub

    Private Sub Terminate_Marker_Movement()


        If Not IsNothing(cntSelectedMarker) Then
            If Not IsNothing(cntSelectedMarker.MyPartner) Then

            End If
        End If



        MarkerMovementStart = False
        HandScrollStart = False
        SequencePanel.Cursor = Cursors.Default

        DisplayFeatures()

    End Sub

    Private Sub DrawPanel_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DrawPanel.MouseDown

        cntrlSelected_Block = Nothing
        cntrlSelected_Block_Alt = Nothing

        cntrlSelected_Feature = Nothing
        For Each Feature As Genome_Feature In listDisplayedGenomeFeatures

            Feature.Selected = False
            If (e.X > Feature.ProjectionStart And _
            e.X < Feature.ProjectionEnd And _
            e.Y > FeatureH * Feature.LayoutOrder + ZeroLayoutOffset And _
            e.Y < FeatureH * Feature.LayoutOrder + ZeroLayoutOffset + FeatureH And _
            Feature.InvertedView = False) _
            Or _
            (e.X < Feature.ProjectionEnd And _
             e.Y > FeatureH * Feature.LayoutOrder + ZeroLayoutOffset And _
             e.Y < FeatureH * Feature.LayoutOrder + ZeroLayoutOffset + FeatureH And _
             Feature.InvertedView = True) _
             Or _
             (e.X > Feature.ProjectionStart And _
             e.Y > FeatureH * Feature.LayoutOrder + ZeroLayoutOffset And _
             e.Y < FeatureH * Feature.LayoutOrder + ZeroLayoutOffset + FeatureH And _
             Feature.InvertedView = True) Then

                Feature.Selected = True
                cntrlSelected_Feature = Feature
                MyReportBox.FeatureTextBox.Text = Feature.TAG
                MyReportBox.NameTextBox.Text = Feature.Name
                MyReportBox.LocationTextBox.Text = String.Concat(Feature.AbsoluteStart, "-", Feature.AbsoluteEnd)
                MyReportBox.LengthTextBox.Text = Feature.AbsoluteEnd - Feature.AbsoluteStart + 1
                MyReportBox.GroupTextBox.Text = Feature.Group

                Select Case Feature.Direction
                    Case 0
                        MyReportBox.StrandTextBox.Text = "unknown"
                    Case 1
                        MyReportBox.StrandTextBox.Text = "plus"
                    Case 2
                        MyReportBox.StrandTextBox.Text = "minus"
                    Case 3
                        MyReportBox.StrandTextBox.Text = "palindrome"
                End Select



                If Feature.Type = 8 Then
                    Dim OligoSeq As String = GetFeatureSequence(Feature)
                    MyReportBox.DescriptionTextBox.Text = String.Concat(Feature.Description, Environment.NewLine, "Tm = ", Bioinformatics.CalculateOligoTm(OligoSeq), "; %GC = ", Bioinformatics.CalculateCGContent(OligoSeq))
                ElseIf Feature.Type = 7 Then
                    MyReportBox.DescriptionTextBox.Text = String.Concat(Feature.Description, Environment.NewLine, "Identity = ", Feature.Identity, "%")
                Else
                    MyReportBox.DescriptionTextBox.Text = Feature.Description
                End If



                MyReportBox.OrthologyTextBox.Text = Feature.Orthology

                'Fill table with additional properties
                MyReportBox.AuxDataGridView.Rows.Clear()
                If Not IsNothing(cntrlSelected_Feature.AdditionalProperties) Then
                    For i = 0 To cntrlSelected_Feature.AdditionalProperties.DataHeaders.Count - 1
                        MyReportBox.AuxDataGridView.Rows.Add(cntrlSelected_Feature.AdditionalProperties.DataHeaders(i), _
                                                             cntrlSelected_Feature.AdditionalProperties.DataValues(i))
                    Next i
                End If


            End If
        Next Feature

        ' DisplayFeatures()

        If e.Button = Windows.Forms.MouseButtons.Left Then
            If Not IsNothing(cntrlSelected_Feature) Then
                If cntrlSelected_Feature.Type = 7 Or cntrlSelected_Feature.Type = 8 Then
                    Initialize_Feature_Movement()
                Else
                    Initialize_Movement()
                End If
            Else
                Initialize_Movement()
            End If

        End If

        If e.Button = Windows.Forms.MouseButtons.Right Then
            If Not IsNothing(cntrlSelected_Feature) Then
                FeatureSequenceToolStripMenuItem.Visible = True
                SequenceRetrievalMasterToolStripMenuItem.Visible = False 'Disabled
                PCRToolStripMenuItem.Visible = True
                ViewToolStripMenuItem.Visible = True
                FindPrimersForVisibleRangeToolStripMenuItem.Visible = False

                If cntrlSelected_Feature.Type = 7 Or cntrlSelected_Feature.Type = 8 Or cntrlSelected_Feature.Type = 11 Then
                    AddToAnnotationToolStripMenuItem.Visible = True
                    DeleteOligoToolStripMenuItem.Visible = True
                Else
                    AddToAnnotationToolStripMenuItem.Visible = False
                    DeleteOligoToolStripMenuItem.Visible = False
                End If

                SelectedRegionToolStripMenuItem.Visible = False
                AddOligoToolStripMenuItem.Visible = False
            Else
                FeatureSequenceToolStripMenuItem.Visible = False
                SequenceRetrievalMasterToolStripMenuItem.Visible = False
                PCRToolStripMenuItem.Visible = False
                ViewToolStripMenuItem.Visible = False
                AddToAnnotationToolStripMenuItem.Visible = False

                If bSelectionMode Then
                    SelectedRegionToolStripMenuItem.Visible = True
                Else
                    SelectedRegionToolStripMenuItem.Visible = False
                End If

                FindPrimersForVisibleRangeToolStripMenuItem.Visible = True
                AddOligoToolStripMenuItem.Visible = True
                MouseLocation = e.Location
                DeleteOligoToolStripMenuItem.Visible = False
            End If

        End If

        If IsNothing(cntrlSelected_Feature) Then
            MyReportBox.FeatureTextBox.Text = ""
            MyReportBox.NameTextBox.Text = ""
            MyReportBox.LocationTextBox.Text = ""
            MyReportBox.LengthTextBox.Text = ""
            MyReportBox.DescriptionTextBox.Text = ""
            MyReportBox.OrthologyTextBox.Text = ""
            MyReportBox.StrandTextBox.Text = ""
            MyReportBox.GroupTextBox.Text = ""
        End If


    End Sub

    Private Sub DrawPanel_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DrawPanel.MouseMove
        If HandScrollStart Then
            Do_Movement()
        End If

        If FeatureMovementStart Then
            Do_Feature_Movement()
        End If

    End Sub

    Private Sub DrawPanel_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DrawPanel.MouseUp
        Terminate_Movement()
    End Sub

    Private Sub SequencePanel_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles SequencePanel.MouseDown
        cntSelectedMarker = Nothing
        cntSelectedRestrictionSite = Nothing

        For Each Marker As SequenceMarker In listDisplayedSequenceMarkers
            Marker.Selected = False
        Next

        For Each Marker As SequenceMarker In listDisplayedSequenceMarkers
            If _
            e.X > Marker.ProjectionPosition - MarkerWidthHalf And _
            e.X < Marker.ProjectionPosition + MarkerWidthHalf And _
            e.Y < MarkerHeight Then

                cntSelectedMarker = Marker
                Exit For
            End If
        Next

        If e.Button = Windows.Forms.MouseButtons.Left And Not IsNothing(cntSelectedMarker) Then
            Initialize_Marker_Movement()
        Else
            Initialize_Movement()
        End If

        If IsNothing(cntSelectedMarker) Then 'Search for restriction sites

            For Each RestrictionSite As Genome_Feature In listDisplayedHighlightedSites
                If _
                  e.X > RestrictionSite.ProjectionStart And _
                  e.X < RestrictionSite.ProjectionEnd And RestrictionSite.Direction = 1 And e.Y < 32 Then

                    cntSelectedRestrictionSite = RestrictionSite
                    Exit For

                ElseIf _
                  e.X > RestrictionSite.ProjectionStart And _
                  e.X < RestrictionSite.ProjectionEnd And RestrictionSite.Direction = 2 And e.Y > 32 Then

                    cntSelectedRestrictionSite = RestrictionSite
                    Exit For

                End If
            Next

        End If



        ' If e.Button = Windows.Forms.MouseButtons.Right Then

        MouseLocation = e.Location

        If Not IsNothing(cntSelectedMarker) Then

            NewMarkerToolStripMenuItem.Visible = False
            DeleteToolStripMenuItem.Visible = True
            SelectForRestrictionPositionAToolStripMenuItem.Visible = False
            SelectForRestrictionPositionBToolStripMenuItem.Visible = False
            CutRemoveSequenceToolStripMenuItem.Visible = False
            CutPasteToolStripMenuItem.Visible = False
            LigateSequenceToolStripMenuItem.Visible = False
            DesselectRestrictionSitesToolStripMenuItem.Visible = False
            SendSeqMenuItem.Visible = False

            If Not IsNothing(cntSelectedMarker.MyPartner) Then 'Paired
                GetMarkedSequenceToolStripMenuItem.Visible = True
                IdentifySiteToolStripMenuItem.Visible = True
                InsertSequenceToolStripMenuItem.Visible = False
                InsertPromoterToolStripMenuItem.Visible = False
                EditSequenceToolStripMenuItem.Visible = True
                DeleteSequenceToolStripMenuItem.Visible = True

                SendSeqMenuItem.Visible = True

                CopySequenceToolStripMenuItem.Visible = True
                CutSequenceToolStripMenuItem.Visible = True
                If Not Clipboard.GetText = "" Then
                    PasteSequenceToolStripMenuItem.Visible = True
                Else
                    PasteSequenceToolStripMenuItem.Visible = False
                End If

                CopyRegionToolStripMenuItem.Visible = True
                PasteRegionToolStripMenuItem.Visible = False
                CutRegionToolStripMenuItem.Visible = True
                FlipRegionToolStripMenuItem.Visible = True


                'Tool strip
                GetSequenceButton.Visible = True
                InsertSequenceButton.Visible = False
                InsertPromoterButton.Visible = False
                ReplaceSequenceButton.Visible = True
                DeleteSequenceButton.Visible = True
                InsertLigationButton.Visible = False
                ReplaceLigationButton.Visible = False
                DeleteRestrictionButton.Visible = False
                CopyDataButton.Visible = True
                PasteDataButton.Visible = False
                CutToolStripButton.Visible = True
                FlipToolStripButton.Visible = True

            Else 'Single
                GetMarkedSequenceToolStripMenuItem.Visible = False
                IdentifySiteToolStripMenuItem.Visible = False
                InsertSequenceToolStripMenuItem.Visible = True
                InsertPromoterToolStripMenuItem.Visible = True
                EditSequenceToolStripMenuItem.Visible = False
                DeleteSequenceToolStripMenuItem.Visible = False

                SendSeqMenuItem.Visible = False

                CopySequenceToolStripMenuItem.Visible = False
                CutSequenceToolStripMenuItem.Visible = False
                If Not Clipboard.GetText = "" Then
                    PasteSequenceToolStripMenuItem.Visible = True
                Else
                    PasteSequenceToolStripMenuItem.Visible = False
                End If

                CopyRegionToolStripMenuItem.Visible = False
                PasteRegionToolStripMenuItem.Visible = True
                PasteRegionToolStripMenuItem.Enabled = Master.ClipboardStarted
                CutRegionToolStripMenuItem.Visible = False
                FlipRegionToolStripMenuItem.Visible = False

                'Tool strip
                GetSequenceButton.Visible = False
                InsertSequenceButton.Visible = True
                InsertPromoterButton.Visible = True
                ReplaceSequenceButton.Visible = False
                DeleteSequenceButton.Visible = False
                InsertLigationButton.Visible = False
                ReplaceLigationButton.Visible = False
                DeleteRestrictionButton.Visible = False
                CopyDataButton.Visible = False
                PasteDataButton.Visible = True
                PasteDataButton.Enabled = Master.ClipboardStarted
                CutToolStripButton.Visible = False
                FlipToolStripButton.Visible = False

            End If

        ElseIf Not IsNothing(cntSelectedRestrictionSite) Then 'Restriction site
            NewMarkerToolStripMenuItem.Visible = True
            DeleteToolStripMenuItem.Visible = False

            SendSeqMenuItem.Visible = False

            GetMarkedSequenceToolStripMenuItem.Visible = False
            IdentifySiteToolStripMenuItem.Visible = False
            InsertSequenceToolStripMenuItem.Visible = False
            InsertPromoterToolStripMenuItem.Visible = False
            EditSequenceToolStripMenuItem.Visible = False
            DeleteSequenceToolStripMenuItem.Visible = False
            LigateSequenceToolStripMenuItem.Visible = True

            If Not IsNothing(cntSelectedRestrictionSiteA) And Not IsNothing(cntSelectedRestrictionSiteB) Then
                CutRemoveSequenceToolStripMenuItem.Visible = True
                CutPasteToolStripMenuItem.Visible = True
                ReplaceLigationButton.Visible = True
                DeleteRestrictionButton.Visible = True
            Else
                CutRemoveSequenceToolStripMenuItem.Visible = False
                CutPasteToolStripMenuItem.Visible = False
                ReplaceLigationButton.Visible = False
                DeleteRestrictionButton.Visible = False
            End If

            CopySequenceToolStripMenuItem.Visible = False
            CutSequenceToolStripMenuItem.Visible = False
            PasteSequenceToolStripMenuItem.Visible = False

            SelectForRestrictionPositionAToolStripMenuItem.Visible = True
            SelectForRestrictionPositionBToolStripMenuItem.Visible = True

            If Not IsNothing(cntSelectedRestrictionSiteA) Or Not IsNothing(cntSelectedRestrictionSiteB) Then
                DesselectRestrictionSitesToolStripMenuItem.Visible = True
            Else
                DesselectRestrictionSitesToolStripMenuItem.Visible = False
            End If

            CopyRegionToolStripMenuItem.Visible = False
            PasteRegionToolStripMenuItem.Visible = False
            CutRegionToolStripMenuItem.Visible = False
            FlipRegionToolStripMenuItem.Visible = False

            'Tool strip
            GetSequenceButton.Visible = False
            InsertSequenceButton.Visible = False
            InsertPromoterButton.Visible = False
            ReplaceSequenceButton.Visible = False
            DeleteSequenceButton.Visible = False
            InsertLigationButton.Visible = True
            CopyDataButton.Visible = False
            PasteDataButton.Visible = False
            CutToolStripButton.Visible = False
            FlipToolStripButton.Visible = False

        Else
            NewMarkerToolStripMenuItem.Visible = True
            DeleteToolStripMenuItem.Visible = False

            SendSeqMenuItem.Visible = False

            GetMarkedSequenceToolStripMenuItem.Visible = False
            IdentifySiteToolStripMenuItem.Visible = False
            InsertSequenceToolStripMenuItem.Visible = False
            InsertPromoterToolStripMenuItem.Visible = False
            EditSequenceToolStripMenuItem.Visible = False
            DeleteSequenceToolStripMenuItem.Visible = False
            LigateSequenceToolStripMenuItem.Visible = False
            CutRemoveSequenceToolStripMenuItem.Visible = False
            CutPasteToolStripMenuItem.Visible = False

            CopySequenceToolStripMenuItem.Visible = False
            CutSequenceToolStripMenuItem.Visible = False
            PasteSequenceToolStripMenuItem.Visible = False

            SelectForRestrictionPositionAToolStripMenuItem.Visible = False
            SelectForRestrictionPositionBToolStripMenuItem.Visible = False

            If Not IsNothing(cntSelectedRestrictionSiteA) Or Not IsNothing(cntSelectedRestrictionSiteB) Then
                DesselectRestrictionSitesToolStripMenuItem.Visible = True
            Else
                DesselectRestrictionSitesToolStripMenuItem.Visible = False
            End If

            CopyRegionToolStripMenuItem.Visible = False
            PasteRegionToolStripMenuItem.Visible = False
            CutRegionToolStripMenuItem.Visible = False
            FlipRegionToolStripMenuItem.Visible = False

            'Tool strip
            GetSequenceButton.Visible = False
            InsertSequenceButton.Visible = False
            InsertPromoterButton.Visible = False
            ReplaceSequenceButton.Visible = False
            DeleteSequenceButton.Visible = False
            InsertLigationButton.Visible = False
            ReplaceLigationButton.Visible = False
            DeleteRestrictionButton.Visible = False
            CopyDataButton.Visible = False
            PasteDataButton.Visible = False
            CutToolStripButton.Visible = False
            FlipToolStripButton.Visible = False

        End If

        '  End If

        If Not IsNothing(cntSelectedMarker) Then 'Make visually selected selected marker
            cntSelectedMarker.Selected = True
            If Not IsNothing(cntSelectedMarker.MyPartner) Then
                cntSelectedMarker.MyPartner.Selected = True
            End If
        End If

        CurrentMarkerLabel.Text = GetSelectedMarkerInfoText()
    End Sub

    Private Sub SequencePanel_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles SequencePanel.MouseMove
        If MarkerMovementStart Then
            Do_Marker_Movement()
        End If

        If HandScrollStart Then
            Do_Movement()
        End If

    End Sub

    Private Sub SequencePanel_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles SequencePanel.MouseUp
        Terminate_Movement()
        Terminate_Marker_Movement()
        SequencePanel.Invalidate()
    End Sub

    Private Sub GraphPanel_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles GraphPanel.MouseDown

        If Not Master.Ctrl_Pressed Then
            cntrlSelected_Block = Nothing
        End If

        cntrlSelected_Block_Alt = Nothing

        For Each Block As QuantitationBlock In listDisplayedIntegratedValues

            If e.X > Block.ProjectionStart And _
            e.X < Block.ProjectionEnd And _
            ((Block.Direction = 1 And e.Y < GraphPanel.Height / 2) Or _
             (Block.Direction = 2 And e.Y > GraphPanel.Height / 2)) Then

                If Master.Ctrl_Pressed Then
                    cntrlSelected_Block_Alt = Block
                Else
                    cntrlSelected_Block = Block
                End If

                Exit For

            End If


        Next



        If e.Button = Windows.Forms.MouseButtons.Right Then
            MouseLocationGraph = e.Location
        End If

    End Sub

    Private Sub GraphPanel_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles GraphPanel.MouseMove

    End Sub

    Private Sub GraphPanel_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles GraphPanel.MouseUp

        DisplayFeatures()

    End Sub

    Private Function IdentifyFramePanelClickPosition(ByVal e As System.Windows.Forms.MouseEventArgs)

        Dim FramePos As Short = 0

        If e.Y > 2 And e.Y < 14 Then 'Frame +1
            FramePos = 1
        ElseIf e.Y > 14 And e.Y < 26 Then 'Frame +2
            FramePos = 2
        ElseIf e.Y > 26 And e.Y < 38 Then 'Frame +3
            FramePos = 3
        ElseIf e.Y > 38 And e.Y < 50 Then 'Frame -1
            FramePos = 4
        ElseIf e.Y > 50 And e.Y < 62 Then 'Frame -2
            FramePos = 5
        ElseIf e.Y > 62 And e.Y < 72 Then 'Frame -3
            FramePos = 6
        End If

        Return FramePos

    End Function

    Private Function GetCurrentFrameFromFramePosition(ByVal e As System.Windows.Forms.MouseEventArgs)

        Dim VisibleFrames As New List(Of Short)

        If MyControlBox.F1CheckBox.Checked Then
            VisibleFrames.Add(1)
        End If

        If MyControlBox.F2CheckBox.Checked Then
            VisibleFrames.Add(2)
        End If

        If MyControlBox.F3CheckBox.Checked Then
            VisibleFrames.Add(3)
        End If

        If MyControlBox.R3CheckBox.Checked Then
            VisibleFrames.Add(-3)
        End If

        If MyControlBox.R2CheckBox.Checked Then
            VisibleFrames.Add(-2)
        End If

        If MyControlBox.R1CheckBox.Checked Then
            VisibleFrames.Add(-1)
        End If

        Dim ClickedPanel As Short = IdentifyFramePanelClickPosition(e)


        Dim Frame As Short = 0


        If ClickedPanel <= VisibleFrames.Count Then
            Try
                Frame = VisibleFrames(ClickedPanel - 1)
            Catch ex As Exception

            End Try
        End If

        'MsgBox("Clicked Panel: " & ClickedPanel & vbNewLine & "Frames count: " & VisibleFrames.Count & vbNewLine & "Frame: " & Frame)


        Return Frame
    End Function


    Private Sub TranslatePanel_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TranslatePanel.MouseDown

        If e.Button = Windows.Forms.MouseButtons.Left Then
            Initialize_Movement()
        End If

        If e.Button = Windows.Forms.MouseButtons.Right Then

            Dim Frame As Short = GetCurrentFrameFromFramePosition(e)

            Dim AA As String = ""
            Dim Synonyms As List(Of String)


            TrippletIdentified = False

            Dim TranslationTable As DataTable = Bioinformatics.GetTranslationTable(MyControlBox.TransComboBox.Text.Split("-")(0))

            SynonymousTripletToolStripMenuItem.DropDownItems.Clear()
            ChangeAminoacidToolStripMenuItem.DropDownItems.Clear()


            Select Case Frame
                Case 1
                    bReverseStrand = False
                    intTrippletEnd = Math.Ceiling(MousePositionToSeqCoord(e) / 3) * 3
                    intTrippletStart = intTrippletEnd - 2
                    TrippletIdentified = True
                Case 2
                    bReverseStrand = False
                    intTrippletEnd = Math.Ceiling(MousePositionToSeqCoord(e) / 3 - 0.334) * 3 + 1
                    intTrippletStart = intTrippletEnd - 2
                    TrippletIdentified = True
                Case 3
                    bReverseStrand = False
                    intTrippletEnd = Math.Ceiling(MousePositionToSeqCoord(e) / 3 - 0.667) * 3 + 2
                    intTrippletStart = intTrippletEnd - 2
                    TrippletIdentified = True
                Case -1
                    bReverseStrand = True
                    intTrippletEnd = Math.Ceiling(MousePositionToSeqCoord(e) / 3) * 3
                    intTrippletStart = intTrippletEnd - 3
                    TrippletIdentified = True
                Case -2
                    bReverseStrand = True
                    intTrippletEnd = Math.Ceiling(MousePositionToSeqCoord(e) / 3 - 0.334) * 3 + 1
                    intTrippletStart = intTrippletEnd - 3
                    TrippletIdentified = True
                Case -3
                    bReverseStrand = True
                    intTrippletEnd = Math.Ceiling(MousePositionToSeqCoord(e) / 3 - 0.667) * 3 + 2
                    intTrippletStart = intTrippletEnd - 3
                    TrippletIdentified = True
                Case Else
                    SynonymousTripletToolStripMenuItem.Text = "Synonymous triplets"
            End Select



            If TrippletIdentified Then
                If bReverseStrand Then 'For reverse strand
                    AA = Bioinformatics.Translate( _
                    Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(strGenomeSequence, intTrippletStart, intTrippletEnd)) _
                    , TranslationTable)

                Else 'For forward strand
                    AA = Bioinformatics.Translate(DataIO.RetrieveSeqFromCache(strGenomeSequence, intTrippletStart, intTrippletEnd), TranslationTable)

                End If

                Synonyms = Bioinformatics.GetSynonimousTripplets(AA, TranslationTable)

                SynonymousTripletToolStripMenuItem.Text = "Synonymous triplets for " & AA

                For Each Synonym As String In Synonyms
                    SynonymousTripletToolStripMenuItem.DropDownItems.Add(Synonym)
                Next

                For i = 0 To TranslationTable.Rows.Count - 1
                    ChangeAminoacidToolStripMenuItem.DropDownItems.Add(TranslationTable.Rows(i).Item(0) & "-" & TranslationTable.Rows(i).Item(1))
                Next i

            End If


        End If
    End Sub

    Private Sub TranslatePanel_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TranslatePanel.MouseMove
        If HandScrollStart Then
            Do_Movement()
        End If
    End Sub

    Private Sub TranslatePanel_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TranslatePanel.MouseUp
        Terminate_Movement()
    End Sub

    Private Sub SynonymousTripletToolStripMenuItem_DropDownItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles SynonymousTripletToolStripMenuItem.DropDownItemClicked
        If e.ClickedItem.OwnerItem.Text.StartsWith("Synonymous") Then
            If TrippletIdentified Then
                Bioinformatics.DeleteSequence(strGenomeSequence, intTrippletStart, intTrippletEnd + 1, cntFeaturesGroupsList, History, listUndo_Features)

                If bReverseStrand Then 'For reverse strand
                    Bioinformatics.InsertSequence(strGenomeSequence, Bioinformatics.GetReverseComplement(e.ClickedItem.Text), intTrippletStart, cntFeaturesGroupsList, History)
                Else 'For forward strand
                    Bioinformatics.InsertSequence(strGenomeSequence, e.ClickedItem.Text, intTrippletStart, cntFeaturesGroupsList, History)
                End If

                'Refresh data
                list6FrameTranslation = Bioinformatics.Make6FrameTranslation(strGenomeSequence, Bioinformatics.GetTranslationTable(MyControlBox.TransComboBox.Text.Split("-")(0)), bGenomeTopology, True, True)

                DisplayFeatures()
                bSaveRequired = True
                RefreshRestrictionSites()

            End If
        End If

        TrippletIdentified = False
    End Sub

    Private Sub ChangeAminoacidToolStripMenuItem_DropDownItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ChangeAminoacidToolStripMenuItem.DropDownItemClicked
        If TrippletIdentified Then
            Bioinformatics.DeleteSequence(strGenomeSequence, intTrippletStart, intTrippletEnd + 1, cntFeaturesGroupsList, History, listUndo_Features)

            Dim CurrentTripplet As String = e.ClickedItem.Text.Split("-")(0)

            If bReverseStrand Then 'For reverse strand
                Bioinformatics.InsertSequence(strGenomeSequence, Bioinformatics.GetReverseComplement(CurrentTripplet), intTrippletStart, cntFeaturesGroupsList, History)
            Else 'For forward strand
                Bioinformatics.InsertSequence(strGenomeSequence, CurrentTripplet, intTrippletStart, cntFeaturesGroupsList, History)
            End If

            'Refresh data
            list6FrameTranslation = Bioinformatics.Make6FrameTranslation(strGenomeSequence, Bioinformatics.GetTranslationTable(MyControlBox.TransComboBox.Text.Split("-")(0)), bGenomeTopology, True, True)

            DisplayFeatures()
            bSaveRequired = True
            RefreshRestrictionSites()

        End If

        TrippletIdentified = False

    End Sub

#End Region

#Region "Sequence edit bar"

    Private Sub SimpleMarkerButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SimpleMarkerButton.Click

        If intRangeEnd >= intRangeStart Then
            CreateSingleMarker((intRangeStart + intRangeEnd) / 2)

        Else
            Dim MidPoint As Integer = (intRangeStart - (strGenomeSequence.Length - intRangeEnd + 1)) / 2

            If MidPoint < 0 Then
                MidPoint = strGenomeSequence.Length - MidPoint
            End If

            CreateSingleMarker(MidPoint)

        End If



    End Sub

    Private Sub ClearMarkersButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearMarkersButton.Click
        RemoveAllMarkers()

        If listHighlightedSites.Count = 0 Then
            MyControlBox.MarckupOffRadioButton.Checked = True
        End If

    End Sub

    Private Sub SinglePairedButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SinglePairedButton.Click

        If intRangeEnd >= intRangeStart Then
            CreateSinglePairedMarker((intRangeStart + intRangeEnd) / 2 - 20, (intRangeStart + intRangeEnd) / 2 + 20)
        Else

            Dim MidPoint As Integer = (intRangeStart - (strGenomeSequence.Length - intRangeEnd + 1)) / 2


            If MidPoint > 0 Then
                Dim LeftPoint As Integer = 0
                LeftPoint = MidPoint - 20
                If LeftPoint < 0 Then
                    LeftPoint = strGenomeSequence.Length - LeftPoint
                End If
                CreateSinglePairedMarker(LeftPoint, MidPoint + 20)
            ElseIf MidPoint < 0 Then
                Dim RightPoint As Integer = 0
                MidPoint = strGenomeSequence.Length - MidPoint
                RightPoint = MidPoint + 20
                If RightPoint > strGenomeSequence.Length Then
                    RightPoint -= strGenomeSequence.Length
                End If
                CreateSinglePairedMarker(MidPoint - 20, RightPoint)
            Else 'MidPoint = 0
                CreateSinglePairedMarker(strGenomeSequence.Length - 20, 20)
            End If
        End If


    End Sub

    Private Sub InsertLigationButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InsertLigationButton.Click
        LigateSequence()
        UpdateSeqStat()
    End Sub

    Private Sub ReplaceLigationButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReplaceLigationButton.Click
        SwapByLigation()
        UpdateSeqStat()
    End Sub

    Private Sub DeleteRestrictionButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteRestrictionButton.Click
        RemoveByLigation()
        UpdateSeqStat()
    End Sub

    Private Sub InsertSequenceButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InsertSequenceButton.Click
        InsertSequence()
        UpdateSeqStat()
    End Sub

    Private Sub ReplaceSequenceButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReplaceSequenceButton.Click
        EditSequenceInRange()
        UpdateSeqStat()
    End Sub

    Private Sub DeleteSequenceButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteSequenceButton.Click
        If MsgBox("Are you sure to DELETE this region?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            DeleteSequenceInRange()
            UpdateSeqStat()
        End If
    End Sub


    Private Sub GeneratePromotersList(ByVal ItemListBox As ListBox)
        ItemListBox.Items.Clear()
        ItemListBox.Items.Add("Standard E.coli promoter (-10/-35)")
        ItemListBox.Items.Add("Mycoplasma strong promoter")
        ItemListBox.Items.Add("Consensus Shine-Dalgarno sequence")

    End Sub


    Private Function InterpretPromoterList(ByVal Name As String)
        Dim Result As String = ""

        Select Case Name
            Case "Standard E.coli promoter (-10/-35)"
                Result = "TTGACA" & Bioinformatics.GetRandomSequence(17, 30) & "TATAAT" & Bioinformatics.GetRandomSequence(5, 30)
            Case "Mycoplasma strong promoter"
                Result = "TATGTTATAATTATCATGT"
            Case "Consensus Shine-Dalgarno sequence"
                Result = "AGGAGG"
        End Select

        Return Result

    End Function

    Private Function InterpretPromoterStructure(ByVal Name As String, ByVal Pos As Integer, ByVal Dir As Short)
        Dim Result As New List(Of Genome_Feature)
        Static Counter As Integer = 0

        Select Case Name
            Case "Standard E.coli promoter (-10/-35)"
                Select Case Dir
                    Case 1
                        Dim New_10 As New Genome_Feature
                        New_10.AbsoluteStart = Pos + 23
                        New_10.AbsoluteEnd = Pos + 28
                        New_10.Direction = Dir
                        New_10.TAG = "Promoter_Part-" & Counter
                        New_10.Name = "-10-box"
                        New_10.Type = 3
                        New_10.Group = strMainFeaturesListName
                        Counter += 1
                        Result.Add(New_10)

                        Dim New_35 As New Genome_Feature
                        New_35.AbsoluteStart = Pos
                        New_35.AbsoluteEnd = Pos + 5
                        New_35.Direction = Dir
                        New_35.TAG = "Promoter_Part-" & Counter
                        New_35.Name = "-35-box"
                        New_35.Type = 3
                        New_35.Group = strMainFeaturesListName
                        Counter += 1
                        Result.Add(New_35)

                        Dim New_TSS As New Genome_Feature
                        New_TSS.AbsoluteStart = Pos + 33
                        New_TSS.AbsoluteEnd = Pos + 33
                        New_TSS.Direction = Dir
                        New_TSS.TAG = "Promoter_Part-" & Counter
                        New_TSS.Name = "TSS"
                        New_TSS.Type = 5
                        New_TSS.Group = strMainFeaturesListName
                        Counter += 1
                        Result.Add(New_TSS)

                    Case 2
                        Dim New_10 As New Genome_Feature
                        New_10.AbsoluteStart = Pos + 5
                        New_10.AbsoluteEnd = Pos + 10
                        New_10.Direction = Dir
                        New_10.TAG = "Promoter_Part-" & Counter
                        New_10.Name = "-10-box"
                        New_10.Type = 3
                        New_10.Group = strMainFeaturesListName
                        Counter += 1
                        Result.Add(New_10)

                        Dim New_35 As New Genome_Feature
                        New_35.AbsoluteStart = Pos + 28
                        New_35.AbsoluteEnd = Pos + 33
                        New_35.Direction = Dir
                        New_35.TAG = "Promoter_Part-" & Counter
                        New_35.Name = "-35-box"
                        New_35.Type = 3
                        New_35.Group = strMainFeaturesListName
                        Counter += 1
                        Result.Add(New_35)

                        Dim New_TSS As New Genome_Feature
                        New_TSS.AbsoluteStart = Pos
                        New_TSS.AbsoluteEnd = Pos
                        New_TSS.Direction = Dir
                        New_TSS.TAG = "Promoter_Part-" & Counter
                        New_TSS.Name = "TSS"
                        New_TSS.Type = 5
                        New_TSS.Group = strMainFeaturesListName
                        Counter += 1
                        Result.Add(New_TSS)

                End Select
            Case "Mycoplasma strong promoter"
                Select Case Dir
                    Case 1
                        Dim New_P As New Genome_Feature
                        New_P.AbsoluteStart = Pos
                        New_P.AbsoluteEnd = Pos + 18
                        New_P.Direction = Dir
                        New_P.TAG = "Promoter_Part-" & Counter
                        New_P.Name = "Promoter"
                        New_P.Type = 3
                        New_P.Group = strMainFeaturesListName
                        Counter += 1
                        Result.Add(New_P)

                        Dim New_TSS As New Genome_Feature
                        New_TSS.AbsoluteStart = Pos + 17
                        New_TSS.AbsoluteEnd = Pos + 17
                        New_TSS.Direction = Dir
                        New_TSS.TAG = "Promoter_Part-" & Counter
                        New_TSS.Name = "TSS"
                        New_TSS.Type = 5
                        New_TSS.Group = strMainFeaturesListName
                        Counter += 1
                        Result.Add(New_TSS)

                    Case 2
                        Dim New_P As New Genome_Feature
                        New_P.AbsoluteStart = Pos
                        New_P.AbsoluteEnd = Pos + 18
                        New_P.Direction = Dir
                        New_P.TAG = "Promoter_Part-" & Counter
                        New_P.Name = "Promoter"
                        New_P.Type = 3
                        New_P.Group = strMainFeaturesListName
                        Counter += 1
                        Result.Add(New_P)

                        Dim New_TSS As New Genome_Feature
                        New_TSS.AbsoluteStart = Pos + 1
                        New_TSS.AbsoluteEnd = Pos + 1
                        New_TSS.Direction = Dir
                        New_TSS.TAG = "Promoter_Part-" & Counter
                        New_TSS.Name = "TSS"
                        New_TSS.Type = 5
                        New_TSS.Group = strMainFeaturesListName
                        Counter += 1
                        Result.Add(New_TSS)

                End Select
            Case "Consensus Shine-Dalgarno sequence"

                Select Case Dir
                    Case 1
                        Dim New_P As New Genome_Feature
                        New_P.AbsoluteStart = Pos
                        New_P.AbsoluteEnd = Pos + 5
                        New_P.Direction = Dir
                        New_P.TAG = "SD-" & Counter
                        New_P.Name = "SD sequence"
                        New_P.Type = 3
                        New_P.Group = strMainFeaturesListName
                        Counter += 1
                        Result.Add(New_P)

                    Case 2
                        Dim New_P As New Genome_Feature
                        New_P.AbsoluteStart = Pos
                        New_P.AbsoluteEnd = Pos + 5
                        New_P.Direction = Dir
                        New_P.TAG = "SD-" & Counter
                        New_P.Name = "SD sequence"
                        New_P.Type = 3
                        New_P.Group = strMainFeaturesListName
                        Counter += 1
                        Result.Add(New_P)

                End Select


        End Select

        Return Result
    End Function


    Private Sub PromoterForwardToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PromoterForwardToolStripMenuItem.Click

        If Not IsNothing(cntSelectedMarker) Then

            GeneratePromotersList(ListInputBox.ItemsListBox)

            If ListInputBox.ShowDialog = DialogResult.OK Then

                Dim InsertPos As Integer = cntSelectedMarker.AbsolutePosition

                Bioinformatics.InsertSequence(strGenomeSequence, InterpretPromoterList(ListInputBox.ItemsListBox.SelectedItem), InsertPos, cntFeaturesGroupsList, History)

                Dim PromoterParts As List(Of Genome_Feature) = InterpretPromoterStructure(ListInputBox.ItemsListBox.SelectedItem, InsertPos, 1)

                For Each Feature As Genome_Feature In PromoterParts
                    cntFeaturesGroupsList(0).FeaturesList.Add(Feature)
                    Dim HistoryRecord As String = "Add:" & Feature.TAG & "|Asm=" & strMainFeaturesListName
                    History.Add(HistoryRecord)
                Next Feature

                DisplayFeatures()
                bSaveRequired = True
                'UndoButton.Enabled = True

                RefreshRestrictionSites()

            End If



        End If


    End Sub

    Private Sub PromoterReverseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PromoterReverseToolStripMenuItem.Click
        If Not IsNothing(cntSelectedMarker) Then

            GeneratePromotersList(ListInputBox.ItemsListBox)

            If ListInputBox.ShowDialog = DialogResult.OK Then

                Dim InsertPos As Integer = cntSelectedMarker.AbsolutePosition

                Bioinformatics.InsertSequence(strGenomeSequence, Bioinformatics.GetReverseComplement(InterpretPromoterList(ListInputBox.ItemsListBox.SelectedItem)), InsertPos, cntFeaturesGroupsList, History)

                Dim PromoterParts As List(Of Genome_Feature) = InterpretPromoterStructure(ListInputBox.ItemsListBox.SelectedItem, InsertPos, 2)

                For Each Feature As Genome_Feature In PromoterParts
                    cntFeaturesGroupsList(0).FeaturesList.Add(Feature)
                    Dim HistoryRecord As String = "Add:" & Feature.TAG & "|Asm=" & strMainFeaturesListName
                    History.Add(HistoryRecord)
                Next Feature

                DisplayFeatures()
                bSaveRequired = True
                'UndoButton.Enabled = True

                RefreshRestrictionSites()

            End If



        End If
    End Sub

    Private Sub CopyDataButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyDataButton.Click
        CopySeqAndAnnot()
    End Sub

    Private Sub PasteDataButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteDataButton.Click
        PasteSeqAndAnnot()
    End Sub

    Private Sub CutToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CutToolStripButton.Click
        CutSeqAndAnnot()
    End Sub

    Private Sub FlipToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlipToolStripButton.Click
        FlipSeqAndAnnot()
    End Sub

#End Region

#Region "Sequence lane context menu"

    Private Sub SingleToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SingleToolStripMenuItem.Click
        CreateSingleMarker(MouseLocation.X / Projection_K + intRangeStart)
    End Sub

    Private Sub PairedToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PairedToolStripMenuItem.Click
        CreateSinglePairedMarker(MouseLocation.X / Projection_K + intRangeStart - 20, MouseLocation.X / Projection_K + intRangeStart + 20)
    End Sub

    Private Sub GetMarkedSequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetMarkedSequenceToolStripMenuItem.Click
        SequenceDisplay.ReadListCheckBox.Checked = False
        SequenceDisplay.ReadList.Clear()
        SequenceDisplay.SeqTextBox.Text = GetMarkedSequence()
        SequenceDisplay.Locus_ID = ""
        SequenceDisplay.Locus_Name = ""
        SequenceDisplay.Show()
        SequenceDisplay.Focus()

    End Sub

    Private Sub DeleteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteToolStripMenuItem.Click
        DeleteSelectedMarker()
    End Sub

    Private Sub InsertSequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InsertSequenceToolStripMenuItem.Click
        InsertSequence()
        UpdateSeqStat()
    End Sub

    Private Sub DeleteSequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteSequenceToolStripMenuItem.Click
        If MsgBox("Are you sure to DELETE this region?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            DeleteSequenceInRange()
            UpdateSeqStat()
        End If
    End Sub

    Private Sub EditSequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditSequenceToolStripMenuItem.Click
        EditSequenceInRange()
        UpdateSeqStat()

    End Sub

    Private Sub CopySequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopySequenceToolStripMenuItem.Click
        Clipboard.SetText(GetMarkedSequence())
    End Sub

    Private Sub CutSequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CutSequenceToolStripMenuItem.Click
        Clipboard.SetText(GetMarkedSequence())
        DeleteSequenceInRange()
    End Sub

    Private Sub PasteSequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteSequenceToolStripMenuItem.Click

        If Not IsNothing(cntSelectedMarker.MyPartner) Then 'single-paired
            EditSequenceInRange(True)
        Else 'single
            InsertSequence(True)
        End If

    End Sub

    Private Sub LigateSequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LigateSequenceToolStripMenuItem.Click
        LigateSequence()
        UpdateSeqStat()
    End Sub

    Private Sub SelectForRestrictionPositionAToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectForRestrictionPositionAToolStripMenuItem.Click
        SelectASite()
    End Sub

    Private Sub SelectForRestrictionPositionBToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectForRestrictionPositionBToolStripMenuItem.Click
        SelectBSite()
    End Sub

    Private Sub DesselectRestrictionSitesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DesselectRestrictionSitesToolStripMenuItem.Click
        ClearSites()
    End Sub

    Private Sub CutRemoveSequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CutRemoveSequenceToolStripMenuItem.Click
        RemoveByLigation()
        UpdateSeqStat()
    End Sub

    Private Sub CutPasteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CutPasteToolStripMenuItem.Click
        SwapByLigation()
        UpdateSeqStat()
    End Sub

    Private Sub PrimerFinderMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrimerFinderMenuItem.Click
        If Not IsNothing(cntSelectedMarker) Then

            If Not IsNothing(cntSelectedMarker.MyPartner) Then

                Dim StartMarker As SequenceMarker = Nothing
                Dim EndMarker As SequenceMarker = Nothing

                If cntSelectedMarker.Role = False Then
                    StartMarker = cntSelectedMarker
                    EndMarker = cntSelectedMarker.MyPartner
                Else
                    StartMarker = cntSelectedMarker.MyPartner
                    EndMarker = cntSelectedMarker
                End If


                PrimerFinder.SeqTextBox.Text = DataIO.RetrieveSeqFromCache(strGenomeSequence, StartMarker.AbsolutePosition, EndMarker.AbsolutePosition - 1)

                PrimerFinder.LimCheckBox.Checked = True

                PrimerFinder.RangeStart = StartMarker.AbsolutePosition
                PrimerFinder.RangeEnd = EndMarker.AbsolutePosition

                PrimerFinder.ForLimTextBox.Text = EndMarker.AbsolutePosition - StartMarker.AbsolutePosition
                PrimerFinder.RevLimTextBox.Text = 0

                PrimerFinder.DrawBorderButtons()

                PrimerFinder.Show()
                PrimerFinder.Focus()

            End If

        End If
    End Sub

    Private Sub SecondaryStructureFinderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SecondaryStructureFinderToolStripMenuItem.Click

        If Not IsNothing(cntSelectedMarker) Then

            If Not IsNothing(cntSelectedMarker.MyPartner) Then

                Dim StartMarker As SequenceMarker = Nothing
                Dim EndMarker As SequenceMarker = Nothing

                If cntSelectedMarker.Role = False Then
                    StartMarker = cntSelectedMarker
                    EndMarker = cntSelectedMarker.MyPartner
                Else
                    StartMarker = cntSelectedMarker.MyPartner
                    EndMarker = cntSelectedMarker
                End If

                HairpinFinder.MyViewer = Me
                HairpinFinder.Show()
                HairpinFinder.Focus()
                HairpinFinder.StartComboBox.Text = StartMarker.AbsolutePosition
                HairpinFinder.EndComboBox.Text = EndMarker.AbsolutePosition


            End If

        End If






    End Sub



    Private Sub IdentifySiteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IdentifySiteToolStripMenuItem.Click
        Dim SelectedSeq As String = GetMarkedSequence()
        Dim ClearedSequence As String = ""

        Dim Found As Boolean = False

        For Each Row As DataRow In Master.SiteSeqList.Rows
            ClearedSequence = Row.Item(1)
            ClearedSequence = ClearedSequence.Replace(Chr(94), vbNullString)
            ClearedSequence = ClearedSequence.Replace(Chr(42), vbNullString)

            If ClearedSequence = SelectedSeq Then
                MsgBox("Found site for " & Row.Item(0))
                Found = True
            End If

        Next Row

        If Not Found Then
            MsgBox("No sites were found!")
        End If

    End Sub

    Private Sub AssemblyDesignerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AssemblyDesignerToolStripMenuItem.Click
        If Not IsNothing(cntSelectedMarker) Then

            If Not IsNothing(cntSelectedMarker.MyPartner) Then

                Dim StartMarker As SequenceMarker = Nothing
                Dim EndMarker As SequenceMarker = Nothing

                If cntSelectedMarker.Role = False Then
                    StartMarker = cntSelectedMarker
                    EndMarker = cntSelectedMarker.MyPartner
                Else
                    StartMarker = cntSelectedMarker.MyPartner
                    EndMarker = cntSelectedMarker
                End If

                Disassembler.MyGenomeViewer = Me
                Disassembler.SeqMode = True
                Disassembler.StartPos = StartMarker.AbsolutePosition
                Disassembler.EndPos = EndMarker.AbsolutePosition - 1
                Disassembler.Show()
                Disassembler.Focus()

            End If

        End If
    End Sub

    Private Sub ForwardToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ForwardToolStripMenuItem.Click
        If Not IsNothing(cntSelectedMarker) Then

            GeneratePromotersList(ListInputBox.ItemsListBox)

            If ListInputBox.ShowDialog = DialogResult.OK Then

                Dim InsertPos As Integer = cntSelectedMarker.AbsolutePosition

                Bioinformatics.InsertSequence(strGenomeSequence, InterpretPromoterList(ListInputBox.ItemsListBox.SelectedItem), InsertPos, cntFeaturesGroupsList, History)

                Dim PromoterParts As List(Of Genome_Feature) = InterpretPromoterStructure(ListInputBox.ItemsListBox.SelectedItem, InsertPos, 1)

                For Each Feature As Genome_Feature In PromoterParts
                    cntFeaturesGroupsList(0).FeaturesList.Add(Feature)
                Next Feature

                DisplayFeatures()
                bSaveRequired = True
                'UndoButton.Enabled = True

                RefreshRestrictionSites()

            End If



        End If
    End Sub

    Private Sub ReverseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReverseToolStripMenuItem.Click
        If Not IsNothing(cntSelectedMarker) Then

            GeneratePromotersList(ListInputBox.ItemsListBox)

            If ListInputBox.ShowDialog = DialogResult.OK Then

                Dim InsertPos As Integer = cntSelectedMarker.AbsolutePosition

                Bioinformatics.InsertSequence(strGenomeSequence, Bioinformatics.GetReverseComplement(InterpretPromoterList(ListInputBox.ItemsListBox.SelectedItem)), InsertPos, cntFeaturesGroupsList, History)

                Dim PromoterParts As List(Of Genome_Feature) = InterpretPromoterStructure(ListInputBox.ItemsListBox.SelectedItem, InsertPos, 2)

                For Each Feature As Genome_Feature In PromoterParts
                    cntFeaturesGroupsList(0).FeaturesList.Add(Feature)
                Next Feature

                DisplayFeatures()
                bSaveRequired = True
                'UndoButton.Enabled = True

                RefreshRestrictionSites()

            End If



        End If
    End Sub


    Private Sub CopyRegionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyRegionToolStripMenuItem.Click
        CopySeqAndAnnot()
    End Sub

    Private Sub PasteRegionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteRegionToolStripMenuItem.Click
        PasteSeqAndAnnot()
    End Sub

    Private Sub CutRegionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CutRegionToolStripMenuItem.Click
        CutSeqAndAnnot()
    End Sub

    Private Sub FlipRegionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlipRegionToolStripMenuItem.Click
        FlipSeqAndAnnot()
    End Sub

    Private Sub RepeatPlotToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RepeatPlotToolStripMenuItem.Click
        If Not IsNothing(cntSelectedMarker) Then

            If Not IsNothing(cntSelectedMarker.MyPartner) Then

                Dim StartMarker As SequenceMarker = Nothing
                Dim EndMarker As SequenceMarker = Nothing

                If cntSelectedMarker.Role = False Then
                    StartMarker = cntSelectedMarker
                    EndMarker = cntSelectedMarker.MyPartner
                Else
                    StartMarker = cntSelectedMarker.MyPartner
                    EndMarker = cntSelectedMarker
                End If


                HitPlot.SeqTextBox.Text = DataIO.RetrieveSeqFromCache(strGenomeSequence, StartMarker.AbsolutePosition, EndMarker.AbsolutePosition - 1)

                HitPlot.Show()
                HitPlot.Focus()
                HitPlot.RefreshPlot()

            End If

        End If
    End Sub

#End Region

#Region "Sequence edit instrument"

    Private Function GetSelectedMarkerInfoText()
        If Not IsNothing(cntSelectedMarker) Then
            Return "Marker:"
        ElseIf Not IsNothing(cntSelectedRestrictionSite) Then
            Return "Site:"
        Else
            Return "-"
        End If
    End Function

    Private Sub CreateSingleMarker(ByVal AbsolutePosition As Integer)
        If AbsolutePosition > strGenomeSequence.Length Then
            AbsolutePosition = AbsolutePosition - strGenomeSequence.Length
        End If

        Dim NewMarker As New SequenceMarker
        NewMarker.AbsolutePosition = AbsolutePosition
        listSequenceMarkers.Add(NewMarker)
        SiteMarkupMode = True
    End Sub

    Private Sub CreateSinglePairedMarker(ByVal AbsolutePositionA As Integer, ByVal AbsolutePositionB As Integer)

        If AbsolutePositionA > strGenomeSequence.Length Then
            AbsolutePositionA = AbsolutePositionA - strGenomeSequence.Length
        End If

        If AbsolutePositionB > strGenomeSequence.Length Then
            AbsolutePositionB = AbsolutePositionB - strGenomeSequence.Length
        End If

        Dim NewMarkerA As New SequenceMarker
        NewMarkerA.AbsolutePosition = AbsolutePositionA

        Dim NewMarkerB As New SequenceMarker
        NewMarkerB.AbsolutePosition = AbsolutePositionB

        NewMarkerA.MyPartner = NewMarkerB
        NewMarkerB.MyPartner = NewMarkerA

        NewMarkerA.Role = False 'start pos
        NewMarkerB.Role = True 'end pos

        listSequenceMarkers.Add(NewMarkerA)
        listSequenceMarkers.Add(NewMarkerB)
        SiteMarkupMode = True
    End Sub

    Private Function GetMarkedSequence()

        If Not IsNothing(cntSelectedMarker) Then

            If Not IsNothing(cntSelectedMarker.MyPartner) Then

                Dim StartMarker As SequenceMarker = cntSelectedMarker.GetStartMarker
                Dim EndMarker As SequenceMarker = cntSelectedMarker.GetEndMarker

                'If cntSelectedMarker.Role = False Then
                'StartMarker = cntSelectedMarker
                'EndMarker = cntSelectedMarker.MyPartner
                'Else
                'StartMarker = cntSelectedMarker.MyPartner
                'EndMarker = cntSelectedMarker
                'End If

                Return DataIO.RetrieveSeqFromCache(strGenomeSequence, _
                                                                    StartMarker.AbsolutePosition, _
                                                                    EndMarker.AbsolutePosition - 1)

            End If

        End If

        Return ""

    End Function



    Private Sub InternalHomologyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InternalHomologyToolStripMenuItem.Click
        If Not IsNothing(cntSelectedMarker) Then

            If Not IsNothing(cntSelectedMarker.MyPartner) Then

                Dim StartMarker As SequenceMarker = cntSelectedMarker.GetStartMarker
                Dim EndMarker As SequenceMarker = cntSelectedMarker.GetEndMarker





                If Master.SaveFileDialog.ShowDialog = DialogResult.OK Then

                    Dim Seq As String = DataIO.RetrieveSeqFromCache(strGenomeSequence, _
                                                                                      StartMarker.AbsolutePosition, _
                                                                                      EndMarker.AbsolutePosition - 1)

                    Dim FS As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.Create)
                    Dim Writer As New IO.StreamWriter(FS)

                    Dim Results As List(Of RBLAST_Result) = Bioinformatics.FindInternalHomology(Seq)

                    Writer.WriteLine("Region-1" & Chr(9) & "Region-2" & Chr(9) & "Sequence")

                    For Each Alignment As RBLAST_Result In Results

                        Writer.WriteLine(Alignment.SubjectStartPos + StartMarker.AbsolutePosition & " - " & Alignment.SubjectEndPos + StartMarker.AbsolutePosition & Chr(9) & Alignment.QueryStartPos + StartMarker.AbsolutePosition & " - " & Alignment.QueryEndPos + StartMarker.AbsolutePosition & Chr(9) & Alignment.SubjectSequence)

                    Next Alignment

                    Writer.Close()
                    FS.Close()
                    Writer.Dispose()
                    FS.Dispose()

                End If





            End If

        End If
    End Sub


    Private Sub DeleteSelectedMarker()
        If Not IsNothing(cntSelectedMarker) Then

            If Not IsNothing(cntSelectedMarker.MyPartner) Then
                listDisplayedSequenceMarkers.Remove(cntSelectedMarker.MyPartner)
                listSequenceMarkers.Remove(cntSelectedMarker.MyPartner)
            End If

            listDisplayedSequenceMarkers.Remove(cntSelectedMarker)
            listSequenceMarkers.Remove(cntSelectedMarker)
            SequencePanel.Invalidate()

            GetSequenceButton.Visible = False
            InsertSequenceButton.Visible = False
            InsertPromoterButton.Visible = False
            ReplaceSequenceButton.Visible = False
            DeleteSequenceButton.Visible = False
            InsertLigationButton.Visible = False
            ReplaceLigationButton.Visible = False
            DeleteRestrictionButton.Visible = False
            CopyDataButton.Visible = False
            PasteDataButton.Visible = False
            CutToolStripButton.Visible = False
            FlipToolStripButton.Visible = False

        End If
    End Sub

    Private Sub RemoveAllMarkers()
        listSequenceMarkers.Clear()
        listDisplayedSequenceMarkers.Clear()
        SequencePanel.Invalidate()

        GetSequenceButton.Visible = False
        InsertSequenceButton.Visible = False
        InsertPromoterButton.Visible = False
        ReplaceSequenceButton.Visible = False
        DeleteSequenceButton.Visible = False
        InsertLigationButton.Visible = False
        ReplaceLigationButton.Visible = False
        DeleteRestrictionButton.Visible = False
        CopyDataButton.Visible = False
        PasteDataButton.Visible = False

    End Sub

    Private Sub RefreshRestrictionSites()
        If Not IsNothing(MyControlBox) Then
            If MyControlBox.DetectorListBox.CheckedItems.Count > 0 Then
                MyControlBox.ClearCache()
                listHighlightedSites.Clear()
                listDisplayedHighlightedSites.Clear()
                MyControlBox.DetectRestrictionSites()
            End If
        End If
    End Sub

    Private Sub InsertSequence(Optional ByVal UseClipboard As Boolean = False)
        If Not IsNothing(cntSelectedMarker) Then

            TextInputBox.Text = "Enter new sequence (just text)"

            If UseClipboard Then
                TextInputBox.SeqTextBox.Text = Clipboard.GetText
            Else
                TextInputBox.SeqTextBox.Text = ""
            End If

            Dim InsertPos As Integer = cntSelectedMarker.AbsolutePosition

            If TextInputBox.ShowDialog = Windows.Forms.DialogResult.OK Then

                If cntSelectedMarker.AbsolutePosition = 1 Then
                    Select Case MsgBox("Append new sequence to start? Yes - append to start, No - append to end, Cancel to terminate operation.", MsgBoxStyle.YesNoCancel)
                        Case MsgBoxResult.Yes

                        Case MsgBoxResult.No
                            InsertPos = strGenomeSequence.Length + 1
                        Case MsgBoxResult.Cancel
                            Exit Sub
                    End Select
                End If


                Dim ClearedSeq As String = Bioinformatics.ClearSeq(TextInputBox.SeqTextBox.Text)
                If TextInputBox.Dir = 2 Then
                    Bioinformatics.InsertSequence(strGenomeSequence, Bioinformatics.GetReverseComplement(ClearedSeq), InsertPos, cntFeaturesGroupsList, History)
                Else
                    Bioinformatics.InsertSequence(strGenomeSequence, ClearedSeq, InsertPos, cntFeaturesGroupsList, History)
                End If

                If Not TextInputBox.Dir = 0 Then
                    Static InsCounter As Integer = 0

                    Dim NewFeature As New Genome_Feature
                    NewFeature.AbsoluteStart = InsertPos
                    NewFeature.AbsoluteEnd = InsertPos + ClearedSeq.Length - 1
                    NewFeature.Direction = TextInputBox.Dir
                    NewFeature.TAG = "New_Feature-" & InsCounter
                    NewFeature.Name = NewFeature.TAG
                    NewFeature.Type = 10
                    NewFeature.Group = strMainFeaturesListName
                    cntFeaturesGroupsList(0).FeaturesList.Add(NewFeature)
                    InsCounter += 1

                    Dim HistoryRecord As String = "Add:" & NewFeature.TAG & "|Asm=" & strMainFeaturesListName
                    History.Add(HistoryRecord)

                End If


                DisplayFeatures()
                bSaveRequired = True
                'UndoButton.Enabled = True

                RefreshRestrictionSites()

            End If

        End If
    End Sub

    Private Sub DeleteSequenceInRange()
        If Not IsNothing(cntSelectedMarker) Then
            If Not IsNothing(cntSelectedMarker.MyPartner) Then 'Paired single

                Dim StartIndex As Integer = cntSelectedMarker.GetStartPos 'Math.Min(cntSelectedMarker.AbsolutePosition, cntSelectedMarker.MyPartner.AbsolutePosition)
                Dim EndIndex As Integer = cntSelectedMarker.GetEndPos 'Math.Max(cntSelectedMarker.AbsolutePosition, cntSelectedMarker.MyPartner.AbsolutePosition)

                If StartIndex < EndIndex Then 'Normal position
                    Bioinformatics.DeleteSequence(strGenomeSequence, StartIndex, EndIndex, cntFeaturesGroupsList, History, listUndo_Features)
                Else
                    Dim DeletedRangePos As Integer = EndIndex - 1
                    Bioinformatics.DeleteSequence(strGenomeSequence, 1, EndIndex, cntFeaturesGroupsList, History, listUndo_Features)
                    Bioinformatics.DeleteSequence(strGenomeSequence, StartIndex - DeletedRangePos, strGenomeSequence.Length + 1, cntFeaturesGroupsList, History, listUndo_Features)
                End If

                DeleteSelectedMarker()

                DisplayFeatures()
                bSaveRequired = True
                'UndoButton.Enabled = True
                RefreshRestrictionSites()

            End If
        End If
    End Sub

    Private Sub EditSequenceInRange(Optional ByVal UseClipboard As Boolean = False)
        If Not IsNothing(cntSelectedMarker) Then
            If Not IsNothing(cntSelectedMarker.MyPartner) Then 'single-paired

                TextInputBox.Text = "Enter new sequence (just text)"

                If UseClipboard Then
                    TextInputBox.SeqTextBox.Text = Clipboard.GetText
                Else
                    TextInputBox.SeqTextBox.Text = ""
                End If

                If TextInputBox.ShowDialog = Windows.Forms.DialogResult.OK Then

                    Dim StartIndex As Integer = cntSelectedMarker.GetStartPos
                    Dim EndIndex As Integer = cntSelectedMarker.GetEndPos
                    Dim ClearedSeq As String = Bioinformatics.ClearSeq(TextInputBox.SeqTextBox.Text)

                    If StartIndex < EndIndex Then 'Normal position
                        Bioinformatics.DeleteSequence(strGenomeSequence, StartIndex, EndIndex, cntFeaturesGroupsList, History, listUndo_Features)
                        Bioinformatics.InsertSequence(strGenomeSequence, ClearedSeq, StartIndex, cntFeaturesGroupsList, History)
                    Else
                        Dim DeletedRangePos As Integer = EndIndex - 1
                        Bioinformatics.DeleteSequence(strGenomeSequence, 1, EndIndex, cntFeaturesGroupsList, History, listUndo_Features)
                        Bioinformatics.DeleteSequence(strGenomeSequence, StartIndex - DeletedRangePos, strGenomeSequence.Length + 1, cntFeaturesGroupsList, History, listUndo_Features)
                        Bioinformatics.InsertSequence(strGenomeSequence, ClearedSeq, 1, cntFeaturesGroupsList, History)
                    End If

                    DeleteSelectedMarker()

                    DisplayFeatures()
                    bSaveRequired = True
                    'UndoButton.Enabled = True

                    RefreshRestrictionSites()

                End If

            End If
        End If
    End Sub

    Private Sub LigateSequence()
        If Not IsNothing(cntSelectedRestrictionSite) Then
            'TextInputBox.ShowDialog()
            TextInputBox.Text = "Enter new sequence (just text)"
            If TextInputBox.ShowDialog = DialogResult.OK Then
                Dim ClearedSeq As String = Bioinformatics.ClearSeq(TextInputBox.SeqTextBox.Text)

                Dim RestrictionSite As String = GetFeatureSequence(cntSelectedRestrictionSite)
                If ClearedSeq.StartsWith(RestrictionSite) And ClearedSeq.EndsWith(RestrictionSite) Then
                    ClearedSeq = ClearedSeq.Substring(RestrictionSite.Length, ClearedSeq.Length - RestrictionSite.Length * 2)
                End If

                'Dim LeftPart As String = RestrictionSite.Substring(0, cntSelectedRestrictionSite.ReadList(0).ReadAbsoluteStart)
                'Dim RightPart As String = RestrictionSite.Substring(cntSelectedRestrictionSite.ReadList(0).ReadAbsoluteStart)

                Bioinformatics.DeleteSequence(strGenomeSequence, cntSelectedRestrictionSite.AbsoluteStart, cntSelectedRestrictionSite.AbsoluteEnd + 1, cntFeaturesGroupsList, History, listUndo_Features)
                Bioinformatics.InsertSequence(strGenomeSequence, RestrictionSite & ClearedSeq & RestrictionSite, cntSelectedRestrictionSite.AbsoluteStart, cntFeaturesGroupsList, History)
                DisplayFeatures()
                bSaveRequired = True
                'UndoButton.Enabled = True
                RefreshRestrictionSites()
            End If

        End If
    End Sub

    Private Sub RemoveByLigation()
        If Not IsNothing(cntSelectedRestrictionSiteA) And Not IsNothing(cntSelectedRestrictionSiteB) Then
            Dim RestrictionSiteA As String = GetFeatureSequence(cntSelectedRestrictionSiteA)
            Dim RestrictionSiteB As String = GetFeatureSequence(cntSelectedRestrictionSiteB)

            If RestrictionSiteA = RestrictionSiteB Then
                Bioinformatics.DeleteSequence(strGenomeSequence, Math.Min(cntSelectedRestrictionSiteA.AbsoluteEnd + 1, cntSelectedRestrictionSiteB.AbsoluteEnd + 1), Math.Max(cntSelectedRestrictionSiteA.AbsoluteEnd + 1, cntSelectedRestrictionSiteB.AbsoluteEnd + 1), cntFeaturesGroupsList, History, listUndo_Features)
                bSaveRequired = True
                'UndoButton.Enabled = True
                RefreshRestrictionSites()
            Else
                MsgBox("Non-matching termini, operation canceled!")
                'Bioinformatics.DeleteSequence(strGenomeSequence, cntSelectedRestrictionSiteA.AbsoluteEnd + 1, cntSelectedRestrictionSiteB.AbsoluteStart, listGenome_Features, listUser_Features, History, listUndo_Features)
                'DisplayFeatures()
                'bSaveRequired = True
                'UndoButton.Enabled = True
                'RefreshRestrictionSites()
            End If


        End If
    End Sub

    Private Sub SwapByLigation()
        If Not IsNothing(cntSelectedRestrictionSiteA) And Not IsNothing(cntSelectedRestrictionSiteB) Then

            'TextInputBox.ShowDialog()
            TextInputBox.Text = "Enter new sequence (just text)"

            If TextInputBox.ShowDialog = Windows.Forms.DialogResult.OK Then
                Dim ClearedSeq As String = Bioinformatics.ClearSeq(TextInputBox.SeqTextBox.Text)
                Dim RestrictionSiteA As String = GetFeatureSequence(cntSelectedRestrictionSiteA)
                Dim RestrictionSiteB As String = GetFeatureSequence(cntSelectedRestrictionSiteB)

                Bioinformatics.DeleteSequence(strGenomeSequence, Math.Min(cntSelectedRestrictionSiteA.AbsoluteEnd + 1, cntSelectedRestrictionSiteB.AbsoluteEnd + 1), Math.Max(cntSelectedRestrictionSiteA.AbsoluteStart, cntSelectedRestrictionSiteB.AbsoluteStart), cntFeaturesGroupsList, History, listUndo_Features)

                If Math.Min(cntSelectedRestrictionSiteA.AbsoluteEnd + 1, cntSelectedRestrictionSiteB.AbsoluteEnd + 1) = cntSelectedRestrictionSiteA.AbsoluteEnd + 1 Then
                    If ClearedSeq.StartsWith(RestrictionSiteA) And ClearedSeq.EndsWith(RestrictionSiteB) Then
                        ClearedSeq = ClearedSeq.Substring(RestrictionSiteA.Length, ClearedSeq.Length - RestrictionSiteA.Length - RestrictionSiteB.Length)
                    End If
                Else
                    If ClearedSeq.StartsWith(RestrictionSiteB) And ClearedSeq.EndsWith(RestrictionSiteA) Then
                        ClearedSeq = ClearedSeq.Substring(RestrictionSiteB.Length, ClearedSeq.Length - RestrictionSiteA.Length - RestrictionSiteB.Length)
                    End If
                End If

                Bioinformatics.InsertSequence(strGenomeSequence, ClearedSeq, Math.Min(cntSelectedRestrictionSiteA.AbsoluteEnd + 1, cntSelectedRestrictionSiteB.AbsoluteEnd + 1), cntFeaturesGroupsList, History)

                DisplayFeatures()
                bSaveRequired = True
                'UndoButton.Enabled = True
                RefreshRestrictionSites()

            End If

        End If
    End Sub

    Private Sub SelectASite()

        If cntSelectedRestrictionSite.Description = "B site" Then
            cntSelectedRestrictionSite.Selected = False
            cntSelectedRestrictionSite.Description = ""
            cntSelectedRestrictionSiteB = Nothing
        End If

        If cntSelectedRestrictionSite.Description = "A site" Then
            cntSelectedRestrictionSite.Selected = False
            cntSelectedRestrictionSite.Description = ""
            cntSelectedRestrictionSiteA = Nothing
            SequencePanel.Invalidate()
            Exit Sub
        End If

        If Not IsNothing(cntSelectedRestrictionSiteA) Then
            cntSelectedRestrictionSiteA.Selected = False
            cntSelectedRestrictionSiteA.Description = ""
        End If

        cntSelectedRestrictionSiteA = cntSelectedRestrictionSite
        cntSelectedRestrictionSiteA.Selected = True
        cntSelectedRestrictionSiteA.Description = "A site"
        SequencePanel.Invalidate()
    End Sub

    Private Sub SelectBSite()

        If cntSelectedRestrictionSite.Description = "A site" Then
            cntSelectedRestrictionSite.Selected = False
            cntSelectedRestrictionSite.Description = ""
            cntSelectedRestrictionSiteA = Nothing
        End If

        If cntSelectedRestrictionSite.Description = "B site" Then
            cntSelectedRestrictionSite.Selected = False
            cntSelectedRestrictionSite.Description = ""
            cntSelectedRestrictionSiteB = Nothing
            SequencePanel.Invalidate()
            Exit Sub
        End If

        If Not IsNothing(cntSelectedRestrictionSiteB) Then
            cntSelectedRestrictionSiteB.Selected = False
            cntSelectedRestrictionSiteB.Description = ""
        End If

        cntSelectedRestrictionSiteB = cntSelectedRestrictionSite
        cntSelectedRestrictionSiteB.Selected = True
        cntSelectedRestrictionSiteB.Description = "B site"
        SequencePanel.Invalidate()

    End Sub

    Private Sub ClearSites()
        If Not IsNothing(cntSelectedRestrictionSiteA) Then
            cntSelectedRestrictionSiteA.Selected = False
            cntSelectedRestrictionSiteA.Description = ""
            cntSelectedRestrictionSiteA = Nothing
        End If
        If Not IsNothing(cntSelectedRestrictionSiteB) Then
            cntSelectedRestrictionSiteB.Selected = False
            cntSelectedRestrictionSiteB.Description = ""
            cntSelectedRestrictionSiteB = Nothing
        End If
        SequencePanel.Invalidate()
    End Sub

    Private Sub CopySeqAndAnnot()
        If Not IsNothing(cntSelectedMarker) Then

            If Not IsNothing(cntSelectedMarker.MyPartner) Then




                Dim StartMarker As SequenceMarker = cntSelectedMarker.GetStartMarker
                Dim EndMarker As SequenceMarker = cntSelectedMarker.GetEndMarker


                Master.SeqClipboard = DataIO.RetrieveSeqFromCache(strGenomeSequence, _
                                                                    StartMarker.AbsolutePosition, _
                                                                    EndMarker.AbsolutePosition - 1)




                Dim MainFeatures As FeaturesAssembly = Nothing
                For Each Asm As FeaturesAssembly In cntFeaturesGroupsList
                    If Asm.AssemblyName = strMainFeaturesListName Then
                        MainFeatures = Asm
                        Exit For
                    End If
                Next Asm


                Master.AnnotClipboard.Clear()
                For Each AnnotFeature As Genome_Feature In MainFeatures.FeaturesList
                    If AnnotFeature.AbsoluteStart >= StartMarker.AbsolutePosition And AnnotFeature.AbsoluteEnd <= EndMarker.AbsolutePosition - 1 Then
                        Dim NewFeature As New Genome_Feature
                        NewFeature.AbsoluteStart = AnnotFeature.AbsoluteStart
                        NewFeature.AbsoluteEnd = AnnotFeature.AbsoluteEnd
                        NewFeature.Direction = AnnotFeature.Direction
                        NewFeature.TAG = AnnotFeature.TAG
                        NewFeature.Name = AnnotFeature.Name
                        NewFeature.Description = AnnotFeature.Description
                        NewFeature.Type = AnnotFeature.Type
                        NewFeature.Orthology = AnnotFeature.Orthology
                        NewFeature.ReadList = AnnotFeature.ReadList
                        NewFeature.UseReadList = AnnotFeature.UseReadList
                        NewFeature.AdditionalProperties = AnnotFeature.AdditionalProperties
                        NewFeature.Group = AnnotFeature.Group

                        Master.AnnotClipboard.Add(NewFeature)
                    End If
                Next AnnotFeature

                'Transfrom coordinates
                For Each AnnotFeature As Genome_Feature In Master.AnnotClipboard
                    AnnotFeature.AbsoluteStart -= StartMarker.AbsolutePosition
                    AnnotFeature.AbsoluteEnd -= StartMarker.AbsolutePosition
                Next AnnotFeature

                Master.ClipboardStarted = True

            End If

        End If
    End Sub

    Private Sub CutSeqAndAnnot(Optional ByVal CreateMarker As Boolean = True)
        If Not IsNothing(cntSelectedMarker) Then

            If Not IsNothing(cntSelectedMarker.MyPartner) Then




                Dim StartMarker As SequenceMarker = cntSelectedMarker.GetStartMarker
                Dim EndMarker As SequenceMarker = cntSelectedMarker.GetEndMarker


                Master.SeqClipboard = DataIO.RetrieveSeqFromCache(strGenomeSequence, _
                                                                    StartMarker.AbsolutePosition, _
                                                                    EndMarker.AbsolutePosition - 1)




                Dim MainFeatures As FeaturesAssembly = Nothing
                For Each Asm As FeaturesAssembly In cntFeaturesGroupsList
                    If Asm.AssemblyName = strMainFeaturesListName Then
                        MainFeatures = Asm
                        Exit For
                    End If
                Next Asm


                Master.AnnotClipboard.Clear()
                For Each AnnotFeature As Genome_Feature In MainFeatures.FeaturesList
                    If AnnotFeature.AbsoluteStart >= StartMarker.AbsolutePosition And AnnotFeature.AbsoluteEnd <= EndMarker.AbsolutePosition - 1 Then
                        Dim NewFeature As New Genome_Feature
                        NewFeature.AbsoluteStart = AnnotFeature.AbsoluteStart
                        NewFeature.AbsoluteEnd = AnnotFeature.AbsoluteEnd
                        NewFeature.Direction = AnnotFeature.Direction
                        NewFeature.TAG = AnnotFeature.TAG
                        NewFeature.Name = AnnotFeature.Name
                        NewFeature.Description = AnnotFeature.Description
                        NewFeature.Type = AnnotFeature.Type
                        NewFeature.Orthology = AnnotFeature.Orthology
                        NewFeature.ReadList = AnnotFeature.ReadList
                        NewFeature.UseReadList = AnnotFeature.UseReadList
                        NewFeature.AdditionalProperties = AnnotFeature.AdditionalProperties
                        NewFeature.Group = AnnotFeature.Group

                        Master.AnnotClipboard.Add(NewFeature)
                    End If
                Next AnnotFeature

                'Transfrom coordinates
                For Each AnnotFeature As Genome_Feature In Master.AnnotClipboard
                    AnnotFeature.AbsoluteStart -= StartMarker.AbsolutePosition
                    AnnotFeature.AbsoluteEnd -= StartMarker.AbsolutePosition
                Next AnnotFeature

                Master.ClipboardStarted = True

                If CreateMarker Then
                    CreateSingleMarker(StartMarker.AbsolutePosition)
                End If

                DeleteSequenceInRange()
                UpdateSeqStat()


            End If

        End If
    End Sub

    Private Function SearchEmptyTag(ByVal CurrentTag As String, ByVal FeaturesList As List(Of Genome_Feature), ByRef CurrentCounter As Integer)
        Dim EmptyTag As String = ""

        Dim TagFound As Boolean = False
        For Each Feature As Genome_Feature In FeaturesList
            If Feature.TAG = CurrentTag Then
                TagFound = True
            End If
        Next Feature

        If Not TagFound Then
            Return CurrentTag
            Exit Function
        End If

        Dim VarTag As String = ""

        Do
            TagFound = False

            VarTag = "InsFeat-" & CurrentCounter

            For Each Feature As Genome_Feature In FeaturesList
                If Feature.TAG = VarTag Then
                    TagFound = True
                    Exit For
                End If
            Next Feature


            CurrentCounter += 1



            If TagFound = False Then
                EmptyTag = VarTag
                Exit Do
            End If

        Loop


        Return EmptyTag
    End Function


    Private Sub PasteSeqAndAnnot(Optional ByVal ReverseStrand As Boolean = False, Optional ByVal InsertPos As Integer = 0)
        Static Counter As Integer = 0

        If Not IsNothing(cntSelectedMarker) Then
            Dim Insertion_Pos As Integer = cntSelectedMarker.AbsolutePosition

            Dim Strand As Short = -1 '= SystemStrandSelectionBox.DialogReturn

            If ReverseStrand = False Then
                Strand = SystemStrandSelectionBox.DialogReturn
            Else
                Strand = 2
            End If


            If Strand = -1 Then
                Exit Sub
            End If

            Dim MainFeatures As FeaturesAssembly = Nothing
            For Each Asm As FeaturesAssembly In cntFeaturesGroupsList
                If Asm.AssemblyName = strMainFeaturesListName Then
                    MainFeatures = Asm
                    Exit For
                End If
            Next Asm


            If Strand = 1 Then 'Insert in plus orientation
                Bioinformatics.InsertSequence(strGenomeSequence, Master.SeqClipboard, cntSelectedMarker.AbsolutePosition, cntFeaturesGroupsList, History)

                For Each AnnotFeature As Genome_Feature In Master.AnnotClipboard
                    AnnotFeature.AbsoluteStart += cntSelectedMarker.AbsolutePosition
                    AnnotFeature.AbsoluteEnd += cntSelectedMarker.AbsolutePosition

                    AnnotFeature.TAG = SearchEmptyTag(AnnotFeature.TAG, MainFeatures.FeaturesList, Counter) '"InsFeat-" & Counter

                    Dim HistoryRecord As String = "Add:" & AnnotFeature.TAG & "|Asm=" & strMainFeaturesListName
                    History.Add(HistoryRecord)
                    MainFeatures.FeaturesList.Add(AnnotFeature)

                    Counter += 1

                Next AnnotFeature




            Else ' Insert in minus orientation


                If ReverseStrand Then
                    Insertion_Pos = InsertPos
                End If

                Bioinformatics.InsertSequence(strGenomeSequence, Bioinformatics.GetReverseComplement(Master.SeqClipboard), Insertion_Pos, cntFeaturesGroupsList, History)

                For Each AnnotFeature As Genome_Feature In Master.AnnotClipboard
                    AnnotFeature.AbsoluteStart = Master.SeqClipboard.Length - AnnotFeature.AbsoluteStart
                    AnnotFeature.AbsoluteEnd = Master.SeqClipboard.Length - AnnotFeature.AbsoluteEnd

                    Dim Tmp As Integer = AnnotFeature.AbsoluteStart
                    AnnotFeature.AbsoluteStart = AnnotFeature.AbsoluteEnd
                    AnnotFeature.AbsoluteEnd = Tmp

                    Select Case AnnotFeature.Direction
                        Case 1
                            AnnotFeature.Direction = 2
                        Case 2
                            AnnotFeature.Direction = 1
                    End Select

                    AnnotFeature.AbsoluteStart += Insertion_Pos - 1
                    AnnotFeature.AbsoluteEnd += Insertion_Pos - 1

                    AnnotFeature.TAG = SearchEmptyTag(AnnotFeature.TAG, MainFeatures.FeaturesList, Counter) '"InsFeat-" & Counter

                    Dim HistoryRecord As String = "Add:" & AnnotFeature.TAG & "|Asm=" & strMainFeaturesListName
                    History.Add(HistoryRecord)
                    MainFeatures.FeaturesList.Add(AnnotFeature)

                    Counter += 1

                Next AnnotFeature

            End If

           
            CreateSinglePairedMarker(Insertion_Pos, Insertion_Pos + Master.SeqClipboard.Length)



            DeleteSelectedMarker()

            Master.AnnotClipboard.Clear()
            Master.SeqClipboard = ""

            Master.ClipboardStarted = False
            PasteDataButton.Enabled = False

            bSaveRequired = True
            RefreshRestrictionSites()
            DisplayFeatures()
            UpdateSeqStat()


        End If 'Not IsNothing(cntSelectedMarker)


    End Sub

    Private Sub FlipSeqAndAnnot()
        If Not IsNothing(cntSelectedMarker) Then

            If Not IsNothing(cntSelectedMarker.MyPartner) Then

                Dim StartMarker As SequenceMarker = cntSelectedMarker.GetStartMarker
                Dim InsPos As Integer = StartMarker.AbsolutePosition

                CutSeqAndAnnot(False)
                PasteSeqAndAnnot(True, InsPos)

            End If

        End If

    End Sub

#End Region

#Region "Zoom instrument"

    Public Sub Zoom(ByVal RangeMult As Single)
        Dim TmpRange As Long = intRangeEnd - intRangeStart
        Dim Midpoint As Long = (intRangeEnd + intRangeStart) / 2
        Dim ZoomedRange As Single = (intRangeEnd - intRangeStart) * RangeMult

        Dim CalculatedStart As Integer = Midpoint - ZoomedRange / 2
        Dim CalculatedEnd As Integer = CalculatedStart + ZoomedRange

        If CalculatedStart = CalculatedEnd Then
            CalculatedStart = Midpoint - 10
            CalculatedEnd = Midpoint + 10
        End If

        StartTextBox.Text = CalculatedStart
        EndTextBox.Text = CalculatedEnd

        intRangeStart = CalculatedStart
        intRangeEnd = CalculatedEnd
        DisplayFeatures()

    End Sub

    Private Sub GoToSeqButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoToSeqButton.Click
        Dim RangeCenter As Integer = (CType(EndTextBox.Text, Integer) + CType(StartTextBox.Text, Integer)) / 2
        RangeStart = RangeCenter - 50
        RangeEnd = RangeCenter + 50
        DisplayFeatures()
    End Sub

    Private Sub ZoomInButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ZoomInButton.Click
        Zoom(0.5)
    End Sub

    Private Sub ZoomOutButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ZoomOutButton.Click
        Zoom(2)
    End Sub

    Private Sub MaxOutButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MaxOutButton.Click
        intRangeStart = 1
        intRangeEnd = strGenomeSequence.Length
        DisplayFeatures()

    End Sub

#End Region

#Region "Scroll instrument"

    Private Sub GoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoButton.Click
        RangeStart = StartTextBox.Text
        RangeEnd = EndTextBox.Text
        DisplayFeatures()
    End Sub

    Private Sub JumpEnd(ByVal Direction As Boolean)
        Dim Range As Integer = 0

        If intRangeStart < intRangeEnd Then
            Range = Math.Abs(intRangeEnd - intRangeStart)
        Else
            Range = strGenomeSequence.Length - intRangeStart + intRangeEnd
        End If

        If Direction Then
            intRangeStart = strGenomeSequence.Length - Range
            intRangeEnd = strGenomeSequence.Length
        Else
            intRangeStart = 1
            intRangeEnd = Range
        End If

        DisplayFeatures()

    End Sub

    Private Sub ScrollTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScrollTimer.Tick
        Dim RStart As Integer = StartTextBox.Text
        Dim REnd As Integer = EndTextBox.Text

        Dim Range As Integer = 0

        If RStart < REnd Then
            Range = Math.Abs(REnd - RStart)
        Else
            Range = strGenomeSequence.Length - RStart + REnd
        End If

        If ScrollDirection Then
            RangeStart = RStart + Range / 4
            RangeEnd = REnd + Range / 4
        Else
            RangeStart = RStart - Range / 4
            RangeEnd = REnd - Range / 4
        End If

        DisplayFeatures()

    End Sub

    Private Sub MoveRightButton_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MoveRightButton.MouseDown
        ScrollDirection = True
        ScrollTimer.Enabled = True
    End Sub

    Private Sub MoveRightButton_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MoveRightButton.MouseUp
        ScrollTimer.Enabled = False
    End Sub

    Private Sub MoveLeftButton_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MoveLeftButton.MouseDown
        ScrollDirection = False
        ScrollTimer.Enabled = True
    End Sub

    Private Sub MoveLeftButton_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MoveLeftButton.MouseUp
        ScrollTimer.Enabled = False
    End Sub

    Private Sub LeftBorderStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LeftBorderStripButton.Click
        JumpEnd(False)
    End Sub

    Private Sub RightBorderStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RightBorderStripButton.Click
        JumpEnd(True)
    End Sub


#End Region

#Region "Context menu"

    Private Sub FeatureSequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FeatureSequenceToolStripMenuItem.Click
        If Not IsNothing(cntrlSelected_Feature) Then

            If cntrlSelected_Feature.ReadList.Count > 0 Then
                SequenceDisplay.ReadList = cntrlSelected_Feature.ReadList
                SequenceDisplay.ReadListCheckBox.Checked = True
            Else
                SequenceDisplay.ReadList.Clear()
                SequenceDisplay.ReadListCheckBox.Checked = False
            End If

            SequenceDisplay.MRNATextBox.Text = ""
            SequenceDisplay.TranslationTextBox.Text = ""
            SequenceDisplay.MyTranslationViever.NucleotideSequence = ""
            SequenceDisplay.Show()
            SequenceDisplay.Locus_ID = cntrlSelected_Feature.TAG
            SequenceDisplay.Locus_Name = cntrlSelected_Feature.Name

            If cntrlSelected_Feature.Type = 7 And Not cntrlSelected_Feature.Sequence = "" Then
                SequenceDisplay.SeqTextBox.Text = cntrlSelected_Feature.Sequence
            Else
                SequenceDisplay.SeqTextBox.Text = GetFeatureSequence(cntrlSelected_Feature)
            End If

            SequenceDisplay.TranslateComboBox.Text = MyControlBox.TransComboBox.Text

            SequenceDisplay.Focus()
        End If
    End Sub

    Private Sub SequenceRetrievalMasterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SequenceRetrievalMasterToolStripMenuItem.Click
        If Not IsNothing(cntrlSelected_Feature) Then

            If cntrlSelected_Feature.Direction = 1 Then
                SeqRetrieval.ForRadioButton.Checked = True
            ElseIf cntrlSelected_Feature.Direction = 2 Then
                SeqRetrieval.RevRadioButton.Checked = True
            Else
                SeqRetrieval.ForRadioButton.Checked = True
            End If

            SeqRetrieval.ShowDialog()
            If SeqRetrieval.Dialog_Res = True Then

                Dim ORFSeq As String = ""
                Dim UpSeq As String = ""
                Dim DownSeq As String = ""

                If SeqRetrieval.GetORF Then
                    If SeqRetrieval.Strand = True Then
                        ORFSeq = DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteStart, cntrlSelected_Feature.AbsoluteEnd)
                    Else
                        ORFSeq = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteStart, cntrlSelected_Feature.AbsoluteEnd))
                    End If
                End If




                If SeqRetrieval.UpSeq > 0 Then


                    If cntrlSelected_Feature.Direction = 1 Then
                        If SeqRetrieval.Strand = True Then
                            UpSeq = DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteStart - SeqRetrieval.UpSeq, cntrlSelected_Feature.AbsoluteStart - 1)
                        Else
                            UpSeq = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteStart - SeqRetrieval.UpSeq, cntrlSelected_Feature.AbsoluteStart - 1))
                        End If

                    ElseIf cntrlSelected_Feature.Direction = 2 Then

                        If SeqRetrieval.Strand = True Then
                            UpSeq = DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteEnd + 1, cntrlSelected_Feature.AbsoluteEnd + SeqRetrieval.UpSeq)
                        Else
                            UpSeq = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteEnd + 1, cntrlSelected_Feature.AbsoluteEnd + SeqRetrieval.UpSeq))
                        End If

                    Else

                        If SeqRetrieval.Strand = True Then
                            UpSeq = DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteStart - SeqRetrieval.UpSeq, cntrlSelected_Feature.AbsoluteStart - 1)
                        Else
                            UpSeq = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteStart - SeqRetrieval.UpSeq, cntrlSelected_Feature.AbsoluteStart - 1))
                        End If

                    End If

                End If



                If SeqRetrieval.DownSeq > 0 Then

                    If cntrlSelected_Feature.Direction = 1 Then
                        If SeqRetrieval.Strand = True Then
                            DownSeq = DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteEnd + 1, cntrlSelected_Feature.AbsoluteEnd + SeqRetrieval.DownSeq)
                        Else
                            DownSeq = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteEnd + 1, cntrlSelected_Feature.AbsoluteEnd + SeqRetrieval.DownSeq))
                        End If
                    ElseIf cntrlSelected_Feature.Direction = 2 Then
                        If SeqRetrieval.Strand = True Then
                            DownSeq = DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteStart - SeqRetrieval.DownSeq, cntrlSelected_Feature.AbsoluteStart - 1)
                        Else
                            DownSeq = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteStart - SeqRetrieval.DownSeq, cntrlSelected_Feature.AbsoluteStart - 1))
                        End If

                    Else
                        If SeqRetrieval.Strand = True Then
                            DownSeq = DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteEnd + 1, cntrlSelected_Feature.AbsoluteEnd + SeqRetrieval.DownSeq)
                        Else
                            DownSeq = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(strGenomeSequence, cntrlSelected_Feature.AbsoluteEnd + 1, cntrlSelected_Feature.AbsoluteEnd + SeqRetrieval.DownSeq))
                        End If
                    End If


                End If

                If SeqRetrieval.ORFLower Then
                    ORFSeq.ToLower()
                End If

                If SeqRetrieval.UpLower Then
                    UpSeq.ToLower()
                End If

                If SeqRetrieval.DownLower Then
                    DownSeq.ToLower()
                End If

                Dim boolOrientation As Boolean = True
                If cntrlSelected_Feature.Direction = 1 Then
                    boolOrientation = True
                ElseIf cntrlSelected_Feature.Direction = 2 Then
                    boolOrientation = False
                End If


                If Not boolOrientation = SeqRetrieval.Strand Then
                    SequenceDisplay.SeqTextBox.Text = String.Concat(DownSeq, ORFSeq, UpSeq)

                Else
                    SequenceDisplay.SeqTextBox.Text = String.Concat(UpSeq, ORFSeq, DownSeq)

                End If

                SequenceDisplay.ReadList.Clear()
                SequenceDisplay.ReadListCheckBox.Checked = False

                SequenceDisplay.Show()
                SequenceDisplay.Focus()
            End If
        End If

    End Sub

    Private Sub PlusToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlusToolStripMenuItem.Click
        SequenceDisplay.SeqTextBox.Text = DataIO.RetrieveSeqFromCache(strGenomeSequence, RangeValues(0), RangeValues(1))
        SequenceDisplay.Locus_ID = ""
        SequenceDisplay.Locus_Name = ""
        SequenceDisplay.ReadList.Clear()
        SequenceDisplay.ReadListCheckBox.Checked = False
        SequenceDisplay.Show()
        SequenceDisplay.Focus()
    End Sub

    Private Sub MinusToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MinusToolStripMenuItem.Click
        SequenceDisplay.SeqTextBox.Text = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(strGenomeSequence, RangeValues(0), RangeValues(1)))
        SequenceDisplay.Locus_ID = ""
        SequenceDisplay.Locus_Name = ""
        SequenceDisplay.ReadList.Clear()
        SequenceDisplay.ReadListCheckBox.Checked = False
        SequenceDisplay.Show()
        SequenceDisplay.Focus()
    End Sub

    Private Sub FindPrimersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindPrimersToolStripMenuItem.Click
        If Not IsNothing(cntrlSelected_Feature) Then
            PrimerFinder.LimCheckBox.Checked = False
            PrimerFinder.ForLimTextBox.Text = "0"
            PrimerFinder.RevLimTextBox.Text = "0"

            PrimerFinder.RangeStart = cntrlSelected_Feature.AbsoluteStart
            PrimerFinder.RangeEnd = cntrlSelected_Feature.AbsoluteEnd

            PrimerFinder.SeqTextBox.Text = GetFeatureSequence(cntrlSelected_Feature)
            PrimerFinder.SeqName = cntrlSelected_Feature.Name
            PrimerFinder.FeatureID = cntrlSelected_Feature.TAG

            PrimerFinder.Show()
        End If

    End Sub



    Private Sub PlusStrandThermodynamicsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlusStrandThermodynamicsToolStripMenuItem.Click
        If Not IsNothing(cntrlSelected_Feature) Then
            Oligocalculator.ForTextBox.Text = GetFeatureSequence(cntrlSelected_Feature)
            Oligocalculator.Show()
            Oligocalculator.Focus()
        End If
    End Sub

    Private Sub MinusStrandThermodynamicsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MinusStrandThermodynamicsToolStripMenuItem.Click
        If Not IsNothing(cntrlSelected_Feature) Then
            Oligocalculator.RevTextBox.Text = Bioinformatics.GetReverseComplement(GetFeatureSequence(cntrlSelected_Feature))
            Oligocalculator.Show()
            Oligocalculator.Focus()
        End If
    End Sub

    Private Sub CenterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CenterToolStripMenuItem.Click
        If Not IsNothing(cntrlSelected_Feature) Then
            RangeStart = cntrlSelected_Feature.AbsoluteStart
            RangeEnd = cntrlSelected_Feature.AbsoluteEnd
            DisplayFeatures()
        End If
    End Sub

    Public Sub ShowTopology(ByVal Feature As Genome_Feature)
        If Not IsNothing(Feature) Then

            Dim ParentTabNameArray As String() = strFileName.Split("\")
            Dim ParentTabName As String = ParentTabNameArray(ParentTabNameArray.GetUpperBound(0))

            Dim Found As Boolean = False

            For Each Page As TabPage In Master.MasterTabControl.TabPages
                If Page.Text = ParentTabName & " [View*]" Then
                    For Each Component As Control In Page.Controls
                        If Component.GetType.Name = "VirtualGenome" Then
                            Found = True

                            Dim Direction As String = Genome_Feature.GetDescriptionOfDirection(Feature.Direction)
                            Dim FeatureType As String = ""
                            If Feature.Type = 5 Then
                                FeatureType = "TSS"
                            ElseIf Feature.Type = 6 Then
                                FeatureType = "Terminator"
                            Else
                                FeatureType = "Locus"
                            End If


                            Dim CurrentViewer As VirtualGenome = Component
                            CurrentViewer.FeaturesDataGridView.Rows.Add(True, True, _
                            Feature.Name, _
                            Feature.TAG, _
                            Feature.AbsoluteStart, _
                            Feature.AbsoluteEnd, _
                            Direction, _
                            Feature.Type, "", FeatureType)
                            CurrentViewer.FeaturesDataGridView.Rows(CurrentViewer.FeaturesDataGridView.Rows.Count - 2).Cells(8).Style.BackColor = Get_Feature_Brush(Feature).Color


                            Master.MasterTabControl.SelectedTab = Page
                            Exit For
                        End If
                    Next
                End If
            Next

            If Not Found Then
                Dim NewTab As New TabPage(ParentTabName & " [View*]")
                Dim NewGenomeViewer As New VirtualGenome(strGenomeSequence.Length)

                Dim Direction As String = Genome_Feature.GetDescriptionOfDirection(Feature.Direction)
                Dim FeatureType As String = ""
                If Feature.Type = 5 Then
                    FeatureType = "TSS"
                ElseIf Feature.Type = 6 Then
                    FeatureType = "Terminator"
                Else
                    FeatureType = "Locus"
                End If


                NewGenomeViewer.FeaturesDataGridView.Rows.Add(True, True, _
                            Feature.Name, _
                            Feature.TAG, _
                            Feature.AbsoluteStart, _
                            Feature.AbsoluteEnd, _
                            Direction, _
                            Feature.Type, "", FeatureType)
                NewGenomeViewer.FeaturesDataGridView.Rows(NewGenomeViewer.FeaturesDataGridView.Rows.Count - 2).Cells(8).Style.BackColor = Get_Feature_Brush(Feature).Color

                NewGenomeViewer.Dock = DockStyle.Fill
                NewTab.Controls.Add(NewGenomeViewer)
                Master.MasterTabControl.TabPages.Add(NewTab)
                Master.MasterTabControl.SelectedTab = NewTab
            End If

        End If
    End Sub

    Private Sub ShowProtein(ByVal Feature As Genome_Feature)

        If Not IsNothing(Feature) Then
            Dim NN_Seq As String = GetFeatureSequence(Feature)
            Dim CodeTable As DataTable = Bioinformatics.GetTranslationTable(shGenetic_Code)
            Dim AA_Seq As String = Bioinformatics.Translate(NN_Seq, CodeTable)

            Dim ParentTabNameArray As String() = strFileName.Split("\")
            Dim ParentTabName As String = ParentTabNameArray(ParentTabNameArray.GetUpperBound(0))

            Dim Found As Boolean = False

            For Each Page As TabPage In Master.MasterTabControl.TabPages
                If Page.Text = ParentTabName & " [2D*]" Then
                    For Each Component As Control In Page.Controls
                        If Component.GetType.Name = "Virtual2D_EF" Then
                            Found = True
                            Dim CurrentViewer As Virtual2D_EF = Component
                            CurrentViewer.ProtDataGridView.Rows.Add(True, True, _
                            Feature.Name, _
                            Feature.TAG, _
                            Bioinformatics.Calculate_Prot_pI(AA_Seq, Master.AminoacidPIList), _
                            Bioinformatics.Calculate_Prot_Mass(AA_Seq, Master.AminoacidMWList), _
                            Bioinformatics.Calculate_Prot_Hydrophobisity(AA_Seq, Master.AminoacidHIList), "Red")
                            Master.MasterTabControl.SelectedTab = Page
                        End If
                    Next
                End If
            Next

            If Not Found Then
                Dim NewTab As New TabPage(ParentTabName & " [2D*]")
                Dim New2DViewer As New Virtual2D_EF
                New2DViewer.ProtDataGridView.Rows.Add(True, True, _
                           Feature.Name, _
                           Feature.TAG, _
                           Bioinformatics.Calculate_Prot_pI(AA_Seq, Master.AminoacidPIList), _
                           Bioinformatics.Calculate_Prot_Mass(AA_Seq, Master.AminoacidMWList), _
                           Bioinformatics.Calculate_Prot_Hydrophobisity(AA_Seq, Master.AminoacidHIList), "Red")
                New2DViewer.Dock = DockStyle.Fill
                NewTab.Controls.Add(New2DViewer)
                Master.MasterTabControl.TabPages.Add(NewTab)
                Master.MasterTabControl.SelectedTab = NewTab
            End If

        End If
    End Sub

    Private Sub TopologyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TopologyToolStripMenuItem.Click
        ShowTopology(cntrlSelected_Feature)
    End Sub

    Private Sub ProtMapToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProtMapToolStripMenuItem.Click
        ShowProtein(cntrlSelected_Feature)
    End Sub

    Private Sub DatabaseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DatabaseToolStripMenuItem.Click
        If Not IsNothing(cntrlSelected_Feature) Then
            FeaturesGroupDataGridView.Rows.Clear()
            WriteFeatureRow(cntrlSelected_Feature, FeaturesGroupDataGridView)
        End If

    End Sub

    Private Sub AddToAnnotationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToAnnotationToolStripMenuItem.Click
        If Not IsNothing(cntrlSelected_Feature) Then
            AddFeature.MyParent = Me
            AddFeature.StartTextBox.Text = cntrlSelected_Feature.AbsoluteStart
            AddFeature.EndTextBox.Text = cntrlSelected_Feature.AbsoluteEnd
            AddFeature.NameTextBox.Text = cntrlSelected_Feature.Name
            AddFeature.TagTextBox.Text = cntrlSelected_Feature.TAG
            AddFeature.DescTextBox.Text = cntrlSelected_Feature.Description
            AddFeature.OrthTextBox.Text = cntrlSelected_Feature.Orthology

            Select Case cntrlSelected_Feature.Direction
                Case 0
                    AddFeature.DirComboBox.Text = "None"
                Case 1
                    AddFeature.DirComboBox.Text = "Plus"
                Case 2
                    AddFeature.DirComboBox.Text = "Minus"
                Case 3
                    AddFeature.DirComboBox.Text = "Symmetrical"
            End Select

            AddFeature.Show()
            AddFeature.Focus()

        End If

    End Sub

    Private Sub AddOligoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddOligoToolStripMenuItem.Click
        Dim CurrentX As Integer = MouseLocation.X / Projection_K + intRangeStart
        AddOligo(CurrentX - 10, CurrentX + 10)
        DisplayFeatures()

    End Sub

    Private Sub DeleteOligoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteOligoToolStripMenuItem.Click
        If Not IsNothing(cntrlSelected_Feature) Then

            If cntrlSelected_Feature.Type = 7 Or cntrlSelected_Feature.Type = 8 Then

                For i = 0 To FeaturesGroupDataGridView.Rows.Count - 2
                    If FeaturesGroupDataGridView.Rows(i).Cells(0).Value = cntrlSelected_Feature.TAG And FeaturesGroupDataGridView.Rows(i).Cells(9).Value = cntrlSelected_Feature.Group Then
                        FeaturesGroupDataGridView.Rows.RemoveAt(i)
                        Exit For
                    End If
                Next i

                Dim CurrentGroup As FeaturesAssembly = Nothing
                CurrentGroup = DataIO.GetCurrentGroup(cntFeaturesGroupsList, cntrlSelected_Feature.Group)

                Dim HistoryRecord As String = ""
                HistoryRecord = "Del:" & cntrlSelected_Feature.TAG & "|Asm=" & CurrentGroup.AssemblyName
                History.Add(HistoryRecord)
                listUndo_Features.Add(cntrlSelected_Feature)


                listDisplayedGenomeFeatures.Remove(cntrlSelected_Feature)
                CurrentGroup.FeaturesList.Remove(cntrlSelected_Feature)


                DisplayFeatures()


            ElseIf cntrlSelected_Feature.Type = 11 Then


                For i = 0 To FeaturesGroupDataGridView.Rows.Count - 2
                    If FeaturesGroupDataGridView.Rows(i).Cells(0).Value = cntrlSelected_Feature.TAG And FeaturesGroupDataGridView.Rows(i).Cells(9).Value = cntrlSelected_Feature.Group Then
                        FeaturesGroupDataGridView.Rows.RemoveAt(i)
                        Exit For
                    End If
                Next i

                listDisplayedGenomeFeatures.Remove(cntrlSelected_Feature)

                For i = 0 To cntFeaturesGroupsList.Count - 1
                    If cntFeaturesGroupsList(i).AssemblyName = cntrlSelected_Feature.Group Then
                        cntFeaturesGroupsList(i).FeaturesList.Remove(cntrlSelected_Feature)

                        If cntFeaturesGroupsList(i).FeaturesList.Count = 0 And Not i = 0 And Not i = 1 Then
                            cntFeaturesGroupsList.RemoveAt(i)
                            RefreshAssemblyList()
                        End If

                        Exit For
                    End If
                Next i

                DisplayFeatures()
            End If

        End If
    End Sub

    Private Sub VisibleRangeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VisibleRangeToolStripMenuItem.Click
        SequenceDisplay.Locus_ID = ""
        SequenceDisplay.Locus_Name = ""
        SequenceDisplay.SeqTextBox.Text = DataIO.RetrieveSeqFromCache(strGenomeSequence, intRangeStart, intRangeEnd)
        SequenceDisplay.ReadList.Clear()
        SequenceDisplay.ReadListCheckBox.Checked = False
        SequenceDisplay.Show()
        SequenceDisplay.Focus()
    End Sub

    Private Sub FindPrimersForVisibleRangeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindPrimersForVisibleRangeToolStripMenuItem.Click
        PrimerFinder.LimCheckBox.Checked = False
        PrimerFinder.ForLimTextBox.Text = "0"
        PrimerFinder.RevLimTextBox.Text = "0"

        PrimerFinder.RangeStart = intRangeStart
        PrimerFinder.RangeEnd = intRangeEnd

        PrimerFinder.SeqTextBox.Text = DataIO.RetrieveSeqFromCache(strGenomeSequence, intRangeStart, intRangeEnd)
        PrimerFinder.SeqName = "visible"
        PrimerFinder.FeatureID = "none"

        PrimerFinder.Show()
    End Sub

#End Region

#Region "Mapping instrument"

    Public Sub AddUserFeature(ByVal Feature_TAG As String, ByVal Feature_Name As String, ByVal Feature_Description As String, ByVal Feature_Start As Integer, ByVal Feature_End As Integer, ByVal Feature_Direction As Short, ByVal Feature_Orthology As String, ByVal Feature_Type As Short, ByVal Feature_Sequence As String, Optional ByVal Identity As Single = 1)
        Dim NewFeature As New Genome_Feature
        NewFeature.Group = strUserFeaturesListName
        NewFeature.TAG = Feature_TAG
        NewFeature.Name = Feature_Name
        NewFeature.Description = Feature_Description
        NewFeature.AbsoluteStart = Feature_Start
        NewFeature.AbsoluteEnd = Feature_End
        NewFeature.Direction = Feature_Direction
        NewFeature.Orthology = Feature_Orthology
        NewFeature.Type = Feature_Type
        NewFeature.Sequence = Feature_Sequence

        If Feature_Type = 7 Then
            NewFeature.Identity = Identity
        End If

        cntFeaturesGroupsList(1).FeaturesList.Add(NewFeature)

        WriteFeatureRow(NewFeature, FeaturesGroupDataGridView)

        DisplayFeatures()
    End Sub

    Public Sub AddOligo(ByVal Feature_Start As Integer, ByVal Feature_End As Integer, Optional ByVal Feature_Name As String = "", Optional ByVal Feature_Direction As Short = 0, Optional ByVal Feature_Type As Short = 8, Optional ByVal Feature_Seq As String = "", Optional ByVal Identity As Single = 1)
        Dim OligoID As String = String.Concat("Oligo ", Oligo_Counter)
        If Feature_Name = "" Then
            Feature_Name = OligoID
        End If

        AddUserFeature(OligoID, Feature_Name, "User oligo", Feature_Start, Feature_End, Feature_Direction, "none", Feature_Type, Feature_Seq, Identity)
        'Dim FType As String = ""
        'Select Case Feature_Type
        'Case 7
        'FType = "Feature"
        'Case 8
        'FType = "Genome"
        'End Select

        'Dim FDir As String = ""

        'Select Case Feature_Direction
        'Case 0
        'FDir = "None"
        'Case 1
        'FDir = "Plus"
        'Case 2
        'FDir = "Minus"
        'End Select

        'MyAccessoryBox.AccessoryGridView.Rows.Add(True, OligoID, Feature_Name, Feature_Start, Feature_End, FDir, FType, Feature_Seq)



        Oligo_Counter += 1
    End Sub

    Public Sub RemoveUserFeature(ByVal Feature_TAG As String)
        For i = cntFeaturesGroupsList(1).FeaturesList.Count - 1 To 0 Step -1
            If cntFeaturesGroupsList(1).FeaturesList(i).TAG = Feature_TAG Then
                cntFeaturesGroupsList(1).FeaturesList.RemoveAt(i)
            End If
        Next
    End Sub

    Public Sub ClearUserFeatures()
        cntFeaturesGroupsList(1).FeaturesList.Clear()
        Oligo_Counter = 0
    End Sub

    Public Sub SendToPCR()

        PrimerFinder.SeqTextBox.Text = DataIO.RetrieveSeqFromCache(strGenomeSequence, RangeValues(0), RangeValues(1))

        PrimerFinder.LimCheckBox.Checked = bInternalMarkers



        PrimerFinder.RangeStart = RangeValues(0)
        PrimerFinder.RangeEnd = RangeValues(1)

        If bInternalMarkers Then
            PrimerFinder.ForLimTextBox.Text = RangeValues(2) - RangeValues(0)
            PrimerFinder.RevLimTextBox.Text = RangeValues(3) - RangeValues(0)
        Else
            PrimerFinder.ForLimTextBox.Text = 0
            PrimerFinder.RevLimTextBox.Text = 0
        End If

        PrimerFinder.DrawBorderButtons()

        PrimerFinder.Show()
        PrimerFinder.Focus()
    End Sub

    Public Sub MapFeature(ByVal QuerySequence As String, Optional ByVal Identity As Integer = 100, Optional ByVal FeatureName As String = "", Optional ByVal UpdateView As Boolean = True, Optional ByVal Gapped As Boolean = False)

        Try

            ' If Not strFileName = "" Then

            If Gapped Then
                Dim K_Word_Length As Integer = 8
                Dim TerDist As Integer = QuerySequence.Length / 2

                Dim AssemblyList As New List(Of Subject_Based_Assembly)
                AssemblyList = Bioinformatics.Assemble_Hit_Map_Subject_Based(strGenomeSequence, QuerySequence, K_Word_Length, TerDist, 1, 10, 10)
                Dim TotalIdentity As Single = 0
                Dim GapCount As Integer = 0
                Dim OligoSeq As String = ""

                For i = 0 To AssemblyList.Count - 1

                    Dim NewRBLAST As New RBLAST_Result
                    NewRBLAST = Bioinformatics.AssembleAlignment(AssemblyList(i), strGenomeSequence, QuerySequence, K_Word_Length)
                    TotalIdentity = Math.Round((NewRBLAST.IdentityNumber / QuerySequence.Length) * 100, 2)

                    If TotalIdentity >= Identity Then
                        OligoSeq = Bioinformatics.FormatOligoSeq(NewRBLAST, False)
                        GapCount = Bioinformatics.CountCharacters(OligoSeq, "#")
                        AddOligo(NewRBLAST.SubjectStartPos + 1, NewRBLAST.SubjectEndPos, FeatureName, 1, 7, OligoSeq, TotalIdentity)
                    End If

                Next

                Dim ReverseComplementQuery As String = Bioinformatics.GetReverseComplement(QuerySequence)
                AssemblyList = Bioinformatics.Assemble_Hit_Map_Subject_Based(strGenomeSequence, ReverseComplementQuery, K_Word_Length, TerDist, 1, 10, 10)

                For i = 0 To AssemblyList.Count - 1

                    Dim NewRBLAST As New RBLAST_Result
                    NewRBLAST = Bioinformatics.AssembleAlignment(AssemblyList(i), strGenomeSequence, ReverseComplementQuery, K_Word_Length)
                    TotalIdentity = Math.Round((NewRBLAST.IdentityNumber / ReverseComplementQuery.Length) * 100, 2)

                    If TotalIdentity >= Identity Then
                        OligoSeq = Bioinformatics.FormatOligoSeq(NewRBLAST, True)
                        GapCount = Bioinformatics.CountCharacters(OligoSeq, "#")
                        AddOligo(NewRBLAST.SubjectStartPos + 1, NewRBLAST.SubjectEndPos, FeatureName, 2, 7, OligoSeq, TotalIdentity)
                    End If

                Next


            Else
                Dim ForCoordList As List(Of CoordHit) = Nothing
                Dim RevCoordList As List(Of CoordHit) = Nothing

                ForCoordList = Bioinformatics.UngappedSequenceSearch(strGenomeSequence, QuerySequence, Identity / 100)
                RevCoordList = Bioinformatics.UngappedSequenceSearch(strGenomeSequence, Bioinformatics.GetReverseComplement(QuerySequence), Identity / 100)

                For Each PrimerCoord As CoordHit In ForCoordList
                    AddOligo(PrimerCoord.Position, PrimerCoord.Position + QuerySequence.Length - 1, FeatureName, 1, 7, QuerySequence, PrimerCoord.Identity)
                Next

                For Each PrimerCoord As CoordHit In RevCoordList
                    ' Dim RevSeq As String = Bioinformatics.GetReverseComplement(QuerySequence)
                    AddOligo(PrimerCoord.Position, PrimerCoord.Position + QuerySequence.Length - 1, FeatureName, 2, 7, QuerySequence, PrimerCoord.Identity)
                Next
            End If


            '  End If

            If UpdateView Then
                DisplayFeatures()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub SearchButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchButton.Click
        If SearchSequenceTextBox.Text = "" Then
            MsgBox("Enter sequence!")
            Exit Sub
        End If

        SearchSequenceTextBox.Text = SearchSequenceTextBox.Text.ToUpper

        If QueryTypeBox.Text = "DNA" Then

            Try

                Dim Gapped As Boolean = False
                If AlignmentTypeComboBox.Text = "Gapped" Then
                    Gapped = True
                Else
                    Gapped = False
                End If

                MapFeature(SearchSequenceTextBox.Text, IdentityPercentTextBox.Text, OligoNameTextBox.Text, , Gapped)
            Catch ex As Exception
                MsgBox("Error in mapping function: " & ex.Message)
            End Try



        ElseIf QueryTypeBox.Text = "Protein" Then

            If RefreshProteins = True Then
                ctrProteins = Bioinformatics.MakeProteinList(cntFeaturesGroupsList(0).FeaturesList, strGenomeSequence, Bioinformatics.GetTranslationTable(MyControlBox.TransComboBox.Text.Split("-")(0)), Master.AminoacidMWList, SystemProgressBarBox)
                RefreshProteins = False
            End If



            For Each Prot As ProtPeptide In ctrProteins

                Dim TargetPept As Genome_Feature = Bioinformatics.LookProteinForPeptide(Prot, SearchSequenceTextBox.Text)

                If Not IsNothing(TargetPept) Then
                    AddOligo(TargetPept.AbsoluteStart, TargetPept.AbsoluteEnd, , TargetPept.Direction)
                End If

            Next



        End If


    End Sub

    Private Sub SearchOptionsDropDownButton_DropDownItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles SearchOptionsDropDownButton.DropDownItemClicked

        Dim ClearedSeq As String = ""
        For Each Row As DataRow In Master.SiteSeqList.Rows
            If Row.Item(0) = e.ClickedItem.Text Then
                ClearedSeq = Row.Item(1).ToString
                ClearedSeq = ClearedSeq.Replace(Chr(94), vbNullString)
                ClearedSeq = ClearedSeq.Replace(Chr(42), vbNullString)
                SearchSequenceTextBox.Text = ClearedSeq
                MapFeature(SearchSequenceTextBox.Text, IdentityPercentTextBox.Text, Row.Item(0))

                Exit For
            End If
        Next


    End Sub

#End Region

#Region "Genome-scale tools"

    Public Sub CreateGenomicView()
        Dim ParentTabNameArray As String() = strFileName.Split("\")
        Dim ParentTabName As String = ParentTabNameArray(ParentTabNameArray.GetUpperBound(0))
        Dim NewTab As New TabPage(ParentTabName & " [View]")
        Dim NewGenomeViewer As New VirtualGenome(strGenomeSequence.Length)
        NewGenomeViewer.MyParent = Me
        NewGenomeViewer.MinOverlapAngleTextBox.Text = (0.1).ToString



        Dim Counter As Integer = 0
        Dim FeatureType As String = "Locus"
        Dim FeatureDir As String = ""

        For Each Feature As Genome_Feature In cntFeaturesGroupsList(0).FeaturesList
            If Feature.Type = 1 Or Feature.Type = 2 Or Feature.Type = 3 Or Feature.Type = 4 Or Feature.Type = 5 Or Feature.Type = 6 Or Feature.Type = 9 Then

                If Feature.Type = 5 Then
                    FeatureType = "TSS"
                ElseIf Feature.Type = 6 Then
                    FeatureType = "Terminator"
                Else
                    FeatureType = "Locus"
                End If

                FeatureDir = Genome_Feature.GetDescriptionOfDirection(Feature.Direction)

                NewGenomeViewer.FeaturesDataGridView.Rows.Add(True, False, _
                                  Feature.Name, _
                                  Feature.TAG, _
                                  Feature.AbsoluteStart, _
                                  Feature.AbsoluteEnd, _
                                  FeatureDir, _
                                  Feature.Type, _
                                  "", _
                                  FeatureType)

                NewGenomeViewer.FeaturesDataGridView.Rows(Counter).Cells(8).Style.BackColor = Get_Feature_Brush(Feature).Color
                Counter += 1
            End If
        Next Feature

        NewGenomeViewer.Dock = DockStyle.Fill
        NewTab.Controls.Add(NewGenomeViewer)
        Master.MasterTabControl.TabPages.Add(NewTab)
        Master.MasterTabControl.SelectedTab = NewTab

    End Sub

    Public Sub CreateProteomicsView()
        Dim CurrentAAseq As String = ""
        Dim CodeTable As DataTable = Bioinformatics.GetTranslationTable(shGenetic_Code)
        Dim ParentTabNameArray As String() = strFileName.Split("\")
        Dim ParentTabName As String = ParentTabNameArray(ParentTabNameArray.GetUpperBound(0))
        Dim NewTab As New TabPage(ParentTabName & " [2D]")
        Dim New2DViewer As New Virtual2D_EF

        Dim MainList As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, strMainFeaturesListName)

        SystemProgressBarBox.Show()
        SystemProgressBarBox.Focus()
        SystemProgressBarBox.MasterProgressBar.Maximum = MainList.FeaturesList.Count
        SystemProgressBarBox.MasterProgressBar.Value = 0
        SystemProgressBarBox.StatusLabel.Text = "Calculating proteins' properties..."
        SystemProgressBarBox.StatusLabel.Refresh()


        For Each Feature As Genome_Feature In MainList.FeaturesList
            If Feature.Type = 1 Then

                Dim GenomicSeq As String = GetFeatureSequence(Feature)
                Dim mRNA As String = ""

                If Feature.UseReadList And Feature.ReadList.Count > 0 Then
                    For Each Read As ReadItem In Feature.ReadList
                        mRNA &= GenomicSeq.Substring(Read.ReadAbsoluteStart, Read.ReadAbsoluteEnd - Read.ReadAbsoluteStart + 1)
                    Next
                Else
                    mRNA = GenomicSeq
                End If

                CurrentAAseq = Bioinformatics.Translate(mRNA, CodeTable)

                New2DViewer.ProtDataGridView.Rows.Add(True, False, _
                           Feature.Name, _
                           Feature.TAG, _
                           Bioinformatics.Calculate_Prot_pI(CurrentAAseq, Master.AminoacidPIList), _
                           Bioinformatics.Calculate_Prot_Mass(CurrentAAseq, Master.AminoacidMWList), _
                           Bioinformatics.Calculate_Prot_Hydrophobisity(CurrentAAseq, Master.AminoacidHIList), "Red")

            End If

            SystemProgressBarBox.MasterProgressBar.PerformStep()
        Next

        New2DViewer.Dock = DockStyle.Fill
        NewTab.Controls.Add(New2DViewer)
        Master.MasterTabControl.TabPages.Add(NewTab)
        Master.MasterTabControl.SelectedTab = NewTab

        SystemProgressBarBox.Close()

    End Sub

    Private Sub RBLASTButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        AlignmentSearchTool.MyGenomeViewer = Me
        AlignmentSearchTool.Text = AlignmentSearchTool.MyName & " - " & Me.Parent.Text
        AlignmentSearchTool.Show()
        AlignmentSearchTool.Focus()

    End Sub

    Private Sub GenomicsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        CreateGenomicView()

    End Sub

    Private Sub ProteomicsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        CreateProteomicsView()

    End Sub

    Private Sub ORFFinderButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ORF_Finder.MyGenomeViewer = Me
        ORF_Finder.Show()
        ORF_Finder.Focus()

    End Sub

    Private Sub MotifFinderToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        MotifDetector.CurrentGenome = Me
        MotifDetector.Show()
        MotifDetector.Focus()

    End Sub

    Private Sub PosIntegrToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        PositionalIntegrator.MyGenomeViewer = Me
        PositionalIntegrator.Show()
    End Sub

#End Region

#Region "Data"

    Public Sub WriteFeatureRow(ByVal Feature As Genome_Feature, ByVal DataGrid As DataGridView)
        Try

            Dim ReadString As String = ""

            If Feature.UseReadList Then
                For Each RItem As ReadItem In Feature.ReadList
                    ReadString &= String.Concat(RItem.ReadAbsoluteStart, "-", RItem.ReadAbsoluteEnd, ",")
                Next
                ReadString = ReadString.Remove(ReadString.Length - 1, 1)
            Else
                ReadString = "Continous"
            End If

            DataGrid.Rows.Add(Feature.TAG, Feature.Name, Feature.Description, Feature.AbsoluteStart, Feature.AbsoluteEnd, Feature.GetDescriptionOfDirection, Feature.GetDescriptionOfType, Feature.Orthology, ReadString, Feature.Group)


        Catch ex As Exception
            MsgBox("Error in writing feature data!")

            Try
                MsgBox("Error writing feature data for " & Feature.TAG)
            Catch ex1 As Exception

            End Try
        End Try


    End Sub

    Public Sub WriteBlockRow(ByVal Block As QuantitationBlock, ByVal DataGrid As DataGridView)
        Try

            Dim ReadString As String = ""


            DataGrid.Rows.Add(Block.TAG, Block.AbsoluteStart, Block.AbsoluteEnd, Block.GetStrandDescription, Block.Value, Block.Holder_Name)


        Catch ex As Exception
            MsgBox("Error in writing feature data!")

            Try
                MsgBox("Error writing feature data for " & Block.TAG)
            Catch ex1 As Exception

            End Try
        End Try


    End Sub

#End Region

#Region "Service functions"

    Public Function GetFeatureSequence(ByVal Feature As Genome_Feature)
        Dim MySequence As String = ""

        If Feature.Direction = 1 Then
            MySequence = DataIO.RetrieveSeqFromCache(strGenomeSequence, Feature.AbsoluteStart, Feature.AbsoluteEnd)
        ElseIf Feature.Direction = 2 Then
            MySequence = Bioinformatics.GetReverseComplement(DataIO.RetrieveSeqFromCache(strGenomeSequence, Feature.AbsoluteStart, Feature.AbsoluteEnd))
        Else
            MySequence = DataIO.RetrieveSeqFromCache(strGenomeSequence, Feature.AbsoluteStart, Feature.AbsoluteEnd)
        End If

        Return MySequence
    End Function

    Public Sub Undo()
        If History.Count > 0 Then
            Dim UndoCommand As String() = History(History.Count - 1).Split(":")

            Select Case UndoCommand(0)
                Case "Add"
                    Dim FeatureID As String() = UndoCommand(1).Split("|")
                    Dim FeatureGroup As String = FeatureID(1).Split("=")(1)
                    Dim CurrentGroup As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, FeatureGroup)

                    If Not IsNothing(CurrentGroup) Then
                        For Each Feature As Genome_Feature In CurrentGroup.FeaturesList
                            If Feature.TAG = FeatureID(0) Then
                                CurrentGroup.FeaturesList.Remove(Feature)
                                Exit For
                            End If
                        Next Feature
                    End If

                    For i = 0 To FeaturesGroupDataGridView.Rows.Count - 2
                        If FeaturesGroupDataGridView.Rows(i).Cells(0).Value = FeatureID(0) And FeaturesGroupDataGridView.Rows(i).Cells(9).Value = FeatureGroup Then
                            FeaturesGroupDataGridView.Rows.RemoveAt(i)
                            Exit For
                        End If
                    Next

                    History.RemoveAt(History.Count - 1)
                    DisplayFeatures()

                Case "Edt"
                    Dim Details As String() = UndoCommand(1).Split("=")
                    Dim Values As String() = Details(1).Split("|")
                    Dim Current_Feature As Genome_Feature = Nothing
                    Dim FeatureGroup As String = Details(2)
                    Dim CurrentGroup As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, FeatureGroup)
                    Dim Current_Row As DataGridViewRow = Nothing

                    If Not IsNothing(CurrentGroup) Then
                        For Each Feature As Genome_Feature In CurrentGroup.FeaturesList
                            If Feature.TAG = Values(0) Then
                                Current_Feature = Feature
                                Exit For
                            End If
                        Next Feature
                    End If

                    For i = 0 To FeaturesGroupDataGridView.Rows.Count - 2
                        If FeaturesGroupDataGridView.Rows(i).Cells(0).Value = Values(0) And FeaturesGroupDataGridView.Rows(i).Cells(9).Value = FeatureGroup Then
                            Current_Row = FeaturesGroupDataGridView.Rows(i)
                            Exit For
                        End If
                    Next

                    Select Case Details(0)
                        Case "TG"
                            If Not IsNothing(Current_Feature) Then
                                Current_Feature.TAG = Values(1)
                            End If

                            If Not IsNothing(Current_Row) Then
                                Current_Row.Cells(0).Value = Values(1)
                            End If

                        Case "NM"
                            If Not IsNothing(Current_Feature) Then
                                Current_Feature.Name = Values(1)
                            End If

                            If Not IsNothing(Current_Row) Then
                                Current_Row.Cells(1).Value = Values(1)
                            End If

                        Case "DC"
                            If Not IsNothing(Current_Feature) Then
                                Current_Feature.Description = Values(1)
                            End If

                            If Not IsNothing(Current_Row) Then
                                Current_Row.Cells(2).Value = Values(1)
                            End If

                        Case "ST"
                            If Not IsNothing(Current_Feature) Then
                                Current_Feature.AbsoluteStart = Values(1)
                            End If

                            If Not IsNothing(Current_Row) Then
                                Current_Row.Cells(3).Value = Values(1)
                            End If

                        Case "ED"
                            If Not IsNothing(Current_Feature) Then
                                Current_Feature.AbsoluteEnd = Values(1)
                            End If

                            If Not IsNothing(Current_Row) Then
                                Current_Row.Cells(4).Value = Values(1)
                            End If
                        Case "DR"
                            If Not IsNothing(Current_Feature) Then
                                Current_Feature.Direction = Values(1)
                            End If

                            If Not IsNothing(Current_Row) Then
                                Current_Row.Cells(5).Value = Values(1)
                            End If
                        Case "TP"
                            If Not IsNothing(Current_Feature) Then
                                Current_Feature.Type = Values(1)
                            End If

                            If Not IsNothing(Current_Row) Then
                                Current_Row.Cells(6).Value = Values(1)
                            End If
                        Case "OT"
                            If Not IsNothing(Current_Feature) Then
                                Current_Feature.Orthology = Values(1)
                            End If

                            If Not IsNothing(Current_Row) Then
                                Current_Row.Cells(7).Value = Values(1)
                            End If

                        Case "RD"

                            If Values(1) = "none" Then
                                If Not IsNothing(Current_Feature) Then
                                    Current_Feature.UseReadList = False
                                    Current_Feature.ReadList.Clear()
                                End If

                                If Not IsNothing(Current_Row) Then
                                    Current_Row.Cells(8).Value = "Continous"
                                End If
                            Else

                                Current_Feature.UseReadList = True
                                Current_Feature.ReadList.Clear()
                                Dim RCItems As String() = Values(1).Split(",")
                                For Each RCItem As String In RCItems
                                    Current_Feature.ReadList.Add(New ReadItem(RCItem.Split("-")(0), RCItem.Split("-")(1)))
                                Next RCItem

                                If Not IsNothing(Current_Row) Then
                                    Current_Row.Cells(8).Value = Values(1)
                                End If

                            End If


                    End Select

                    History.RemoveAt(History.Count - 1)
                    DisplayFeatures()

                Case "Del"
                    Dim Current_Feature As Genome_Feature = Nothing
                    Dim FeatureID As String() = UndoCommand(1).Split("|")

                    For Each Feature As Genome_Feature In listUndo_Features
                        If Feature.TAG = FeatureID(0) Then
                            Current_Feature = Feature
                            Exit For
                        End If
                    Next Feature


                    If FeatureID(1).StartsWith("Asm") Then
                        Dim FeatureGroup As String = FeatureID(1).Split("=")(1)

                        Dim CurrentGroup As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, FeatureGroup)
                        If Not IsNothing(CurrentGroup) Then
                            CurrentGroup.FeaturesList.Add(Current_Feature)
                            WriteFeatureRow(Current_Feature, FeaturesGroupDataGridView)
                            listUndo_Features.Remove(Current_Feature)
                            History.RemoveAt(History.Count - 1)
                            DisplayFeatures()
                        Else
                            MsgBox("Group was deleted: " & FeatureGroup)
                        End If

                    Else
                        MsgBox("Feature restore failed! No group identifier.")
                    End If

                Case "Ins"
                    Dim Values As String() = UndoCommand(1).Split("|")
                    Dim StartPos As Integer = Values(0)
                    Dim Length As Integer = Values(1)

                    Bioinformatics.DeleteSequence(strGenomeSequence, StartPos, StartPos + Length, cntFeaturesGroupsList)

                    History.RemoveAt(History.Count - 1)
                    DisplayFeatures()

                Case "Cut"
                    Dim Values As String() = UndoCommand(1).Split("|")
                    Dim StartPos As Integer = Values(0)
                    Dim Length As Integer = Values(1).ToString.Length

                    Bioinformatics.InsertSequence(strGenomeSequence, Values(1), StartPos + 1, cntFeaturesGroupsList)

                    History.RemoveAt(History.Count - 1)
                    DisplayFeatures()
            End Select

            If History.Count = 0 Then
                bSaveRequired = False
            End If
        End If
    End Sub

#End Region

#Region "Data context menu"

    Private Sub CenterViewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CenterViewToolStripMenuItem.Click
        If Not IsNothing(FeaturesGroupDataGridView.CurrentRow) Then
            Dim StartColIndex As Integer = DataIO.GetColumnIndex("F_Start", FeaturesGroupDataGridView)
            Dim EndColIndex As Integer = DataIO.GetColumnIndex("F_End", FeaturesGroupDataGridView)
            RangeStart = FeaturesGroupDataGridView.CurrentRow.Cells(StartColIndex).Value
            RangeEnd = FeaturesGroupDataGridView.CurrentRow.Cells(EndColIndex).Value
            If Math.Abs(RangeStart - RangeEnd) < 10 Then
                RangeStart -= 5
                RangeEnd += 5
            End If

            DisplayFeatures()
        End If
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyToolStripMenuItem.Click
        Clipboard.SetText(FeaturesGroupDataGridView.CurrentCell.Value.ToString)
    End Sub

    Private Sub GetSequenceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetSequenceToolStripMenuItem.Click
        If Not FeaturesGroupDataGridView.CurrentRow.Cells(0).Value = "" Then
            Dim CurrentFeature As Genome_Feature = Nothing

            Dim CurrentGroup As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, FeaturesGroupDataGridView.CurrentRow.Cells(9).Value)

            If IsNothing(CurrentGroup) Then
                MsgBox("No group found!")
                Exit Sub
            End If

            For Each Feature As Genome_Feature In CurrentGroup.FeaturesList
                If Feature.TAG = FeaturesGroupDataGridView.CurrentRow.Cells(0).Value Then
                    CurrentFeature = Feature
                    Exit For
                End If
            Next

            If Not IsNothing(CurrentFeature) Then
                If CurrentFeature.ReadList.Count > 0 Then
                    SequenceDisplay.ReadList = CurrentFeature.ReadList
                    SequenceDisplay.ReadListCheckBox.Checked = True
                Else
                    SequenceDisplay.ReadList.Clear()
                    SequenceDisplay.ReadListCheckBox.Checked = False
                End If

                SequenceDisplay.MRNATextBox.Text = ""
                SequenceDisplay.TranslationTextBox.Text = ""
                SequenceDisplay.Show()
                SequenceDisplay.Locus_ID = CurrentFeature.TAG
                SequenceDisplay.Locus_Name = CurrentFeature.Name
                SequenceDisplay.SeqTextBox.Text = GetFeatureSequence(CurrentFeature)
                SequenceDisplay.TranslateComboBox.Text = MyControlBox.TransComboBox.Text

                SequenceDisplay.Focus()
            End If

        End If
    End Sub

    Private Sub AddToLargeScaleViewerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToLargeScaleViewerToolStripMenuItem.Click
        Dim CurrentGroup As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, FeaturesGroupDataGridView.CurrentRow.Cells(9).Value)

        If IsNothing(CurrentGroup) Then
            MsgBox("No group found!")
            Exit Sub
        End If

        If Not FeaturesGroupDataGridView.CurrentRow.Cells(0).Value = "" Then
            Dim CurrentFeature As Genome_Feature = Nothing
            For Each Feature As Genome_Feature In CurrentGroup.FeaturesList
                If Feature.TAG = FeaturesGroupDataGridView.CurrentRow.Cells(0).Value Then
                    CurrentFeature = Feature
                    Exit For
                End If
            Next

            ShowTopology(CurrentFeature)

        End If
    End Sub

    Private Sub AddToVirtual2DEFViewerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToVirtual2DEFViewerToolStripMenuItem.Click
        Dim CurrentGroup As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, FeaturesGroupDataGridView.CurrentRow.Cells(9).Value)

        If IsNothing(CurrentGroup) Then
            MsgBox("No group found!")
            Exit Sub
        End If

        If Not FeaturesGroupDataGridView.CurrentRow.Cells(0).Value = "" Then
            Dim CurrentFeature As Genome_Feature = Nothing
            For Each Feature As Genome_Feature In CurrentGroup.FeaturesList
                If Feature.TAG = FeaturesGroupDataGridView.CurrentRow.Cells(0).Value Then
                    CurrentFeature = Feature
                    Exit For
                End If
            Next

            ShowProtein(CurrentFeature)

        End If
    End Sub

#End Region

#Region "Positional values control"

    Private Sub PositionalButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PositionalButton.Click

        DataIO.RetrievePositionalValues(Me)
        MyControlBox.SkewOnRadioButton.Checked = True

    End Sub

    Private Sub DeleteAllPosValuesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteAllPosValuesButton.Click
        listPositionalValues.Clear()
        PositionalValuesDataGridView.Rows.Clear()

        If AuxGraphPanels.Count > 0 Then

            For Each AuxP As AuxilliaryGraphPanel In AuxGraphPanels
                SecondarySplitContainer.Panel1.Controls.Remove(AuxP)
            Next AuxP
            AuxGraphPanels.Clear()
        End If


        DisplayFeatures()

        If listIntegratedValues.Count = 0 Then
            MyControlBox.SkewOffRadioButton.Checked = True
        End If


    End Sub

    Private Sub JumpBackButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles JumpBackButton.Click
        Dim RStart As Integer = StartTextBox.Text
        Dim REnd As Integer = EndTextBox.Text

        Dim Range As Integer = 0

        If RStart < REnd Then
            Range = Math.Abs(REnd - RStart)
        Else
            Range = strGenomeSequence.Length - RStart + REnd
        End If

        RangeStart = RStart - Range / 4
        RangeEnd = REnd - Range / 4

        DisplayFeatures()
    End Sub

    Private Sub JumpForButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles JumpForButton.Click
        Dim RStart As Integer = StartTextBox.Text
        Dim REnd As Integer = EndTextBox.Text

        Dim Range As Integer = 0

        If RStart < REnd Then
            Range = Math.Abs(REnd - RStart)
        Else
            Range = strGenomeSequence.Length - RStart + REnd
        End If

        RangeStart = RStart + Range / 4
        RangeEnd = REnd + Range / 4

        DisplayFeatures()
    End Sub

    Private Sub RemovePositionalValuesHolder(ByVal HolderName As String)
        For Each PosHolder As PositionalValuesHolder In listPositionalValues
            If PosHolder.Holder_Name = HolderName Then
                listPositionalValues.Remove(PosHolder)
                Exit For
            End If
        Next

    End Sub

    Private Sub DeleteCurrentPosValButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteCurrentPosValButton.Click

        Dim SearchID As String = ""

        For i = PositionalValuesDataGridView.SelectedRows.Count - 1 To 0 Step -1
            SearchID = PositionalValuesDataGridView.SelectedRows(i).Cells(1).Value

            If PositionalValuesDataGridView.SelectedRows(i).Cells(6).Value = True Then
                For Each AuxP As AuxilliaryGraphPanel In AuxGraphPanels
                    If AuxP.Tag = SearchID Then
                        SecondarySplitContainer.Panel1.Controls.Remove(AuxP)
                        AuxGraphPanels.Remove(AuxP)
                        Exit For
                    End If
                Next AuxP
            End If

            PositionalValuesDataGridView.Rows.RemoveAt(PositionalValuesDataGridView.SelectedRows(i).Index)
            RemovePositionalValuesHolder(SearchID)

        Next

        DisplayFeatures()

    End Sub

    Private Sub PositionalValuesDataGridView_SelectionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PositionalValuesDataGridView.SelectionChanged
        If PositionalValuesDataGridView.SelectedRows.Count > 0 Then
            DeleteCurrentPosValButton.Enabled = True
            SavePileupButton.Enabled = True
            AssemblePileupButton.Enabled = True
            SmoothToolStripButton.Enabled = True
            ShiftCovLeftToolStripButton.Enabled = True
            ShiftCovRightToolStripButton.Enabled = True

        Else
            DeleteCurrentPosValButton.Enabled = False
            SavePileupButton.Enabled = False
            AssemblePileupButton.Enabled = False
            SmoothToolStripButton.Enabled = False
            ShiftCovLeftToolStripButton.Enabled = False
            ShiftCovRightToolStripButton.Enabled = False

        End If

    End Sub

    Private Sub PositionalValuesDataGridView_CellEndEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles PositionalValuesDataGridView.CellEndEdit

        Select Case e.ColumnIndex
            Case 0
                Dim SearchID As String = PositionalValuesDataGridView.CurrentRow.Cells(1).Value

                For Each PosHolder As PositionalValuesHolder In listPositionalValues
                    If PosHolder.Holder_Name = SearchID Then
                        PosHolder.Visible = PositionalValuesDataGridView.CurrentRow.Cells(0).Value

                        If PosHolder.ShowOnSeparateLane And PosHolder.Visible = True Then
                            For Each P As AuxilliaryGraphPanel In AuxGraphPanels
                                If P.Tag = PosHolder.Holder_Name Then
                                    P.Visible = True
                                End If
                            Next
                        End If

                    End If

                Next

                DisplayFeatures()
            Case 1

                If Not CurrentValuesHolder = "" Then

                    For Each PosHolder As PositionalValuesHolder In listPositionalValues
                        If PosHolder.Holder_Name = CurrentValuesHolder Then
                            PosHolder.Holder_Name = PositionalValuesDataGridView.CurrentRow.Cells(1).Value
                            Exit For
                        End If
                    Next PosHolder

                End If

            Case 2
                Dim SearchID As String = PositionalValuesDataGridView.CurrentRow.Cells(1).Value

                For Each PosHolder As PositionalValuesHolder In listPositionalValues
                    If PosHolder.Holder_Name = SearchID Then

                        Select Case PositionalValuesDataGridView.CurrentRow.Cells(2).Value
                            Case "Plus"
                                PosHolder.Strand = 1
                            Case "Minus"
                                PosHolder.Strand = 2
                            Case "Undefined"
                                PosHolder.Strand = 0
                        End Select
                    End If

                Next

                DisplayFeatures()

            Case 4
                Dim SearchID As String = PositionalValuesDataGridView.CurrentRow.Cells(1).Value

                For Each PosHolder As PositionalValuesHolder In listPositionalValues
                    If PosHolder.Holder_Name = SearchID Then

                        Select Case PositionalValuesDataGridView.CurrentRow.Cells(4).Value
                            Case "Linear"
                                PosHolder.Scale = 0
                            Case "Logarithm"
                                PosHolder.Scale = 1
                        End Select
                    End If

                Next

                DisplayFeatures()

            Case 5
                Dim SearchID As String = PositionalValuesDataGridView.CurrentRow.Cells(1).Value

                For Each PosHolder As PositionalValuesHolder In listPositionalValues
                    If PosHolder.Holder_Name = SearchID Then
                        PosHolder.Group = PositionalValuesDataGridView.CurrentRow.Cells(5).Value
                    End If

                Next
            Case 6
                'Show the data on separate lane
                If PositionalValuesDataGridView.CurrentRow.Cells(6).Value = True Then
                    'Move data to separate lane
                    'Create separate lane

                    Dim SearchID As String = PositionalValuesDataGridView.CurrentRow.Cells(1).Value

                    For Each PosHolder As PositionalValuesHolder In listPositionalValues
                        If PosHolder.Holder_Name = SearchID Then
                            PosHolder.ShowOnSeparateLane = True
                        End If
                    Next PosHolder

                    Dim NewPanel As New AuxilliaryGraphPanel
                    NewPanel.MyGenomeViewer = Me
                    NewPanel.Tag = SearchID
                    'NewPanel.Location = New Point(0, 0)
                    NewPanel.Size = New Size(100, 100)
                    NewPanel.Dock = DockStyle.Top
                    GraphicsSplitContainer.Panel2.Controls.Add(NewPanel)
                    AuxGraphPanels.Add(NewPanel)

                Else
                    'Get data back on regular lane
                    'Remove separate lane

                    Dim SearchID As String = PositionalValuesDataGridView.CurrentRow.Cells(1).Value

                    For Each PosHolder As PositionalValuesHolder In listPositionalValues
                        If PosHolder.Holder_Name = SearchID Then
                            PosHolder.ShowOnSeparateLane = False
                        End If
                    Next PosHolder

                    For Each P As Control In GraphicsSplitContainer.Panel2.Controls
                        If P.Tag = SearchID Then
                            GraphicsSplitContainer.Panel2.Controls.Remove(P)
                            Exit For
                        End If
                    Next P

                    For Each P As AuxilliaryGraphPanel In AuxGraphPanels
                        If P.Tag = SearchID Then
                            AuxGraphPanels.Remove(P)
                            Exit For
                        End If
                    Next P

                End If

                DisplayFeatures()

        End Select


    End Sub

    Private Sub PositionalValuesDataGridView_CellBeginEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellCancelEventArgs) Handles PositionalValuesDataGridView.CellBeginEdit
        If e.ColumnIndex = 3 Then

            If Master.ColorSelectDialog.ShowDialog = DialogResult.OK Then
                Dim SearchID As String = PositionalValuesDataGridView.CurrentRow.Cells(1).Value

                For Each PosHolder As PositionalValuesHolder In listPositionalValues
                    If PosHolder.Holder_Name = SearchID Then
                        PosHolder.Draw_Color = Master.ColorSelectDialog.Color
                        PositionalValuesDataGridView.CurrentRow.Cells(3).Style.BackColor = Master.ColorSelectDialog.Color
                    End If
                Next

                DisplayFeatures()
                PositionalValuesDataGridView.EndEdit()
            End If


        End If

    End Sub

    Private Sub PositionalValuesDataGridView_CellEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles PositionalValuesDataGridView.CellEnter
        CurrentValuesHolder = PositionalValuesDataGridView.CurrentRow.Cells(1).Value


    End Sub

    Private Sub SavePileupButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SavePileupButton.Click

        For i = 0 To PositionalValuesDataGridView.SelectedRows.Count - 1
            Dim SearchID As String = PositionalValuesDataGridView.SelectedRows(i).Cells(1).Value

            For Each PosHolder As PositionalValuesHolder In listPositionalValues
                If PosHolder.Holder_Name = SearchID Then
                    DataIO.SavePileup(PosHolder.Positional_Values, Master.SaveFileDialog)
                End If
            Next PosHolder

        Next i


    End Sub

    Private Sub AssemblePileupButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AssemblePileupButton.Click

        If Master.SaveFileDialog.ShowDialog = DialogResult.OK Then

            Dim DataString As String = ""
            Dim HeaderString As String = ""
            Dim StrandMarker As String = ""

            Dim SelectedIDs As New List(Of String)
            Dim SelectedHolders As New List(Of PositionalValuesHolder)


            Dim Max_i As Integer = PositionalValuesDataGridView.SelectedRows.Count - 1

            For i = 0 To Max_i

                SelectedIDs.Add(PositionalValuesDataGridView.SelectedRows(i).Cells(1).Value)


                If PositionalValuesDataGridView.SelectedRows(i).Cells(2).Value = "Plus" Then
                    StrandMarker = "#+"
                ElseIf PositionalValuesDataGridView.SelectedRows(i).Cells(2).Value = "Minus" Then
                    StrandMarker = "#-"
                Else
                    StrandMarker = "#0"
                End If

                HeaderString &= PositionalValuesDataGridView.SelectedRows(i).Cells(1).Value & StrandMarker & "#" & PositionalValuesDataGridView.SelectedRows(i).Cells(5).Value

                If i < Max_i Then
                    HeaderString &= Chr(9)
                End If

            Next i


            For Each SelectedID As String In SelectedIDs
                For Each PosHolder As PositionalValuesHolder In listPositionalValues
                    If PosHolder.Holder_Name = SelectedID Then
                        SelectedHolders.Add(PosHolder)
                    End If
                Next PosHolder
            Next SelectedID


            Dim FS As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.Create)
            Dim Writer As New IO.StreamWriter(FS)

            Writer.WriteLine(HeaderString)


            Dim MaxHolders As Integer = SelectedHolders.Count - 1

            For i = 0 To strGenomeSequence.Length - 1
                DataString = ""

                For j = 0 To MaxHolders

                    DataString &= SelectedHolders(j).Positional_Values(i)

                    If j < MaxHolders Then
                        DataString &= Chr(9)
                    End If

                Next j

                Writer.WriteLine(DataString)
            Next i

            Writer.Close()
            FS.Close()
            Writer.Dispose()
            FS.Dispose()

        End If



    End Sub

    Private Sub LineToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LineToolStripMenuItem.Click
        bChartStyle = False
        LineToolStripMenuItem.Checked = True
        BarToolStripMenuItem.Checked = False
        DisplayFeatures()
    End Sub

    Private Sub BarToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BarToolStripMenuItem.Click
        bChartStyle = True
        LineToolStripMenuItem.Checked = False
        BarToolStripMenuItem.Checked = True
        DisplayFeatures()
    End Sub

    Private Sub AllChatsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AllChartsToolStripMenuItem.Click
        bPositionalNormalization = True
        bPositionalRuller = True
        AllChartsToolStripMenuItem.Checked = bPositionalNormalization
        IndividualToolStripMenuItem.Checked = Not bPositionalNormalization
        GraphPanel.Invalidate()
    End Sub

    Private Sub IndividualToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IndividualToolStripMenuItem.Click
        bPositionalNormalization = False
        bPositionalRuller = False
        AllChartsToolStripMenuItem.Checked = bPositionalNormalization
        IndividualToolStripMenuItem.Checked = Not bPositionalNormalization
        GraphPanel.Invalidate()

    End Sub

    Private Sub LinearPileupToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinearPileupToolStripMenuItem.Click
        For Each PosHolder As PositionalValuesHolder In listPositionalValues
            PosHolder.Scale = 0
        Next PosHolder

        For i = 0 To PositionalValuesDataGridView.Rows.Count - 2
            PositionalValuesDataGridView.Rows(i).Cells(4).Value = "Linear"
        Next i

        DisplayFeatures()
    End Sub

    Private Sub LogarithmPileupToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogarithmPileupToolStripMenuItem.Click
        For Each PosHolder As PositionalValuesHolder In listPositionalValues
            PosHolder.Scale = 1
        Next PosHolder

        For i = 0 To PositionalValuesDataGridView.Rows.Count - 2
            PositionalValuesDataGridView.Rows(i).Cells(4).Value = "Logarithm"
        Next i

        DisplayFeatures()
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectAllToolStripMenuItem.Click
        For Each PosHolder As PositionalValuesHolder In listPositionalValues
            PosHolder.Visible = True
        Next PosHolder

        For i = 0 To PositionalValuesDataGridView.Rows.Count - 2
            PositionalValuesDataGridView.Rows(i).Cells(0).Value = True
        Next i

        DisplayFeatures()

    End Sub

    Private Sub UnselectAllToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UnselectAllToolStripMenuItem.Click
        For Each PosHolder As PositionalValuesHolder In listPositionalValues
            PosHolder.Visible = False
        Next PosHolder

        For i = 0 To PositionalValuesDataGridView.Rows.Count - 2
            PositionalValuesDataGridView.Rows(i).Cells(0).Value = False
        Next i

        DisplayFeatures()

    End Sub

    Private Sub SmoothToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SmoothToolStripButton.Click

        Static Counter As Integer = 0

        Dim TmpHolderList As New List(Of PositionalValuesHolder)

        Dim Smooting As Integer = 100
        SystemTextBox.Text = "Smoothing window"
        SystemTextBox.InputTextBox.Text = Smooting

        If SystemTextBox.DialogReturn = 1 Then
            Smooting = SystemTextBox.InputTextBox.Text
            SystemTextBox.Text = ""
        Else
            SystemTextBox.Text = ""
            Exit Sub
        End If

        SystemProgressBarBox.Show()
        SystemProgressBarBox.Focus()

        For HolderIndex = 0 To PositionalValuesDataGridView.SelectedRows.Count - 1
            Dim SearchID As String = PositionalValuesDataGridView.SelectedRows(HolderIndex).Cells(1).Value

            For Each PosHolder As PositionalValuesHolder In listPositionalValues
                If PosHolder.Holder_Name = SearchID Then



                    SystemProgressBarBox.MasterProgressBar.Value = 0
                    SystemProgressBarBox.MasterProgressBar.Maximum = PosHolder.Positional_Values.Count

                    SystemProgressBarBox.StatusLabel.Text = "Smoothing: " & PosHolder.Holder_Name
                    SystemProgressBarBox.Refresh()


                    Dim SmoothedValue As Integer = 0
                    Dim SmoothedList As New List(Of Integer)

                    Dim SubList As New List(Of Integer)

                    Dim StartPos As Integer = 0
                    Dim EndPos As Integer = 0

                    For i = 0 To PosHolder.Positional_Values.Count - 1

                        StartPos = i - Smooting
                        EndPos = i + Smooting

                        If StartPos > PosHolder.Positional_Values.Count Then
                            StartPos -= PosHolder.Positional_Values.Count
                        End If

                        If EndPos > PosHolder.Positional_Values.Count Then
                            EndPos -= PosHolder.Positional_Values.Count
                        End If

                        If StartPos < 1 Then
                            StartPos += PosHolder.Positional_Values.Count
                        End If

                        If EndPos < 1 Then
                            EndPos += PosHolder.Positional_Values.Count
                        End If

                        If EndPos >= StartPos Then
                            SubList = Bioinformatics.GetIntSubList(PosHolder.Positional_Values, StartPos - 1, EndPos - StartPos + 1)
                        Else
                            SubList = Bioinformatics.ConcatIntLists(Bioinformatics.GetIntSubList(PosHolder.Positional_Values, StartPos - 1), Bioinformatics.GetIntSubList(PosHolder.Positional_Values, 0, EndPos))
                        End If

                        For Each Val As Integer In SubList
                            SmoothedValue += Val
                        Next

                        SmoothedValue /= SubList.Count


                        SmoothedList.Add(SmoothedValue)

                        SystemProgressBarBox.MasterProgressBar.PerformStep()
                    Next i


                    Dim NewPositionalHolder As New PositionalValuesHolder(PosHolder.Holder_Name & "-smoothed_" & Counter, PosHolder.Strand, SmoothedList, PosHolder.Draw_Color, PosHolder.Scale)
                    NewPositionalHolder.Visible = True

                    TmpHolderList.Add(NewPositionalHolder)

                End If
            Next PosHolder

        Next HolderIndex



        For Each PosHolder As PositionalValuesHolder In TmpHolderList

            Positional_Values_Collection.Add(PosHolder)

            Dim NewHolderScale As String = ""
            Select Case PosHolder.Scale
                Case 0
                    NewHolderScale = "Linear"
                Case 1
                    NewHolderScale = "Logarithm"
            End Select

            Dim StrandText As String = ""
            Select Case PosHolder.Strand
                Case 1
                    StrandText = "Plus"
                Case 2
                    StrandText = "Minus"
            End Select

            PositionalValuesDataGridView.Rows.Add(True, PosHolder.Holder_Name, StrandText, "", NewHolderScale, PosHolder.Group)
            PositionalValuesDataGridView.Rows(PositionalValuesDataGridView.Rows.Count - 2).Cells(3).Style.BackColor = PosHolder.Draw_Color


        Next PosHolder


        SystemTextBox.Text = ""
        DrawPanel.Invalidate()

        SystemProgressBarBox.Close()
        GraphPanel.Invalidate()

        Counter += 1
    End Sub

    Private Sub ShiftCovLeftToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShiftCovLeftToolStripButton.Click

        For HolderIndex = 0 To PositionalValuesDataGridView.SelectedRows.Count - 1
            Dim SearchID As String = PositionalValuesDataGridView.SelectedRows(HolderIndex).Cells(1).Value
            Dim TmpVal As New List(Of Integer)
            Dim TmpLog As New List(Of Single)

            For Each PosHolder As PositionalValuesHolder In listPositionalValues
                If PosHolder.Holder_Name = SearchID Then
                    SystemTextBox.InputTextBox.Text = "1"



                    If SystemTextBox.DialogReturn = 1 Then
                        Dim Shift As Integer = CType(SystemTextBox.InputTextBox.Text, Integer)

                        For i = 0 To Shift - 1
                            TmpVal.Add(PosHolder.Positional_Values(i))
                            TmpLog.Add(PosHolder.Log_Values(i))
                        Next i


                        PosHolder.Positional_Values.RemoveRange(0, Shift)
                        PosHolder.Log_Values.RemoveRange(0, Shift)

                        PosHolder.Positional_Values.AddRange(TmpVal)
                        PosHolder.Log_Values.AddRange(TmpLog)

                    End If

                    GraphPanel.Invalidate()
                    Exit Sub
                End If
            Next PosHolder

        Next HolderIndex
    End Sub

    Private Sub ShiftCovRightToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShiftCovRightToolStripButton.Click
        For HolderIndex = 0 To PositionalValuesDataGridView.SelectedRows.Count - 1
            Dim SearchID As String = PositionalValuesDataGridView.SelectedRows(HolderIndex).Cells(1).Value
            Dim TmpVal As New List(Of Integer)
            Dim TmpLog As New List(Of Single)

            For Each PosHolder As PositionalValuesHolder In listPositionalValues
                If PosHolder.Holder_Name = SearchID Then
                    SystemTextBox.InputTextBox.Text = "1"



                    If SystemTextBox.DialogReturn = 1 Then
                        Dim Shift As Integer = CType(SystemTextBox.InputTextBox.Text, Integer)

                        For i = PosHolder.Positional_Values.Count - Shift To PosHolder.Positional_Values.Count - 1
                            TmpVal.Add(PosHolder.Positional_Values(i))
                            TmpLog.Add(PosHolder.Log_Values(i))
                        Next i


                        PosHolder.Positional_Values.RemoveRange(PosHolder.Positional_Values.Count - Shift, Shift)
                        PosHolder.Log_Values.RemoveRange(PosHolder.Positional_Values.Count - Shift, Shift)

                        PosHolder.Positional_Values.InsertRange(0, TmpVal)
                        PosHolder.Log_Values.InsertRange(0, TmpLog)

                    End If

                    GraphPanel.Invalidate()
                    Exit Sub
                End If
            Next PosHolder

        Next HolderIndex
    End Sub

#End Region

#Region "Import of external data"
    Private Sub ImportToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ImportFeatures.MyGenomeViewer = Me
        ImportFeatures.Show()
        ImportFeatures.Focus()

    End Sub



#End Region

#Region "Data export"
    Private Sub ExportSeqToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        SeqExporter.MyGenomeViewer = Me
        SeqExporter.Show()
        SeqExporter.Focus()

    End Sub

#End Region

#Region "Features control center"

    Public Sub RefreshAssemblyList()

        bGroupLock = True

        FeaturesGroupsListBox.Items.Clear()
        For Each Asm As FeaturesAssembly In cntFeaturesGroupsList
            FeaturesGroupsListBox.Items.Add(Asm.AssemblyName)
            FeaturesGroupsListBox.Items(FeaturesGroupsListBox.Items.Count - 1).Checked = Asm.Visible

        Next

        bGroupLock = False

    End Sub

    Public Sub ShowFeaturesFromGroup(ByVal GroupName As String)
        For Each FeaturesList As FeaturesAssembly In cntFeaturesGroupsList
            If FeaturesList.AssemblyName = GroupName Then   'FeaturesGroupsListBox.SelectedItem

                FeaturesGroupDataGridView.Rows.Clear()

                For Each Feature As Genome_Feature In FeaturesList.FeaturesList
                    WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                Next

                Exit For
            End If
        Next

        CountButton.Text = FeaturesGroupDataGridView.Rows.Count - 1

    End Sub

    Private Sub SearchFeature()
        Select Case FieldComboBox.Text
            Case "Any"
                FeaturesGroupDataGridView.Rows.Clear()
                Dim Query As String = QueryTextBox.Text.ToLower

                For Each FeaturesList As FeaturesAssembly In cntFeaturesGroupsList
                    For Each Feature As Genome_Feature In FeaturesList.FeaturesList
                        If Feature.TAG.ToLower.Contains(Query) Or Feature.Name.ToLower.Contains(Query) Or Feature.Description.ToLower.Contains(Query) Or Feature.Orthology.ToLower.Contains(Query) Then
                            WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                        End If
                    Next
                Next FeaturesList

            Case "Name&Description"

                FeaturesGroupDataGridView.Rows.Clear()
                Dim Query As String = QueryTextBox.Text.ToLower

                Select Case SearchGroupComboBox.Text
                    Case "Current"
                        For Each FeaturesList As FeaturesAssembly In cntFeaturesGroupsList
                            If FeaturesList.AssemblyName = FeaturesGroupsListBox.SelectedItems(0).Text Then
                                For Each Feature As Genome_Feature In FeaturesList.FeaturesList
                                    If Feature.Name.ToLower.Contains(Query) Or Feature.Description.ToLower.Contains(Query) Then
                                        WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                                    End If
                                Next

                                Exit For
                            End If
                        Next
                    Case "All"
                        For Each FeaturesList As FeaturesAssembly In cntFeaturesGroupsList
                            For Each Feature As Genome_Feature In FeaturesList.FeaturesList
                                If Feature.Name.ToLower.Contains(Query) Or Feature.Description.ToLower.Contains(Query) Then
                                    WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                                End If
                            Next
                        Next
                    Case "Main"
                        For Each Feature As Genome_Feature In cntFeaturesGroupsList(0).FeaturesList
                            If Feature.Name.ToLower.Contains(Query) Or Feature.Description.ToLower.Contains(Query) Then
                                WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                            End If
                        Next
                End Select



            Case "TAG"



                FeaturesGroupDataGridView.Rows.Clear()
                Dim Query As String = QueryTextBox.Text.ToLower


                Select Case SearchGroupComboBox.Text
                    Case "Current"
                        For Each FeaturesList As FeaturesAssembly In cntFeaturesGroupsList
                            If FeaturesList.AssemblyName = FeaturesGroupsListBox.SelectedItems(0).Text Then
                                For Each Feature As Genome_Feature In FeaturesList.FeaturesList
                                    If Feature.TAG.ToLower.Contains(Query) Then
                                        WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                                    End If
                                Next

                                Exit For
                            End If

                        Next
                    Case "All"
                        For Each FeaturesList As FeaturesAssembly In cntFeaturesGroupsList
                            For Each Feature As Genome_Feature In FeaturesList.FeaturesList
                                If Feature.TAG.ToLower.Contains(Query) Then
                                    WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                                End If
                            Next
                        Next
                    Case "Main"

                        For Each Feature As Genome_Feature In cntFeaturesGroupsList(0).FeaturesList
                            If Feature.TAG.ToLower.Contains(Query) Then
                                WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                            End If

                        Next

                End Select


            Case "Orthology"

                FeaturesGroupDataGridView.Rows.Clear()
                Dim Query As String = QueryTextBox.Text.ToLower

                Select Case SearchGroupComboBox.Text
                    Case "Current"
                        For Each FeaturesList As FeaturesAssembly In cntFeaturesGroupsList
                            If FeaturesList.AssemblyName = FeaturesGroupsListBox.SelectedItems(0).Text Then
                                For Each Feature As Genome_Feature In FeaturesList.FeaturesList
                                    If Feature.Orthology.ToLower.Contains(Query) Then
                                        WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                                    End If
                                Next

                                Exit For
                            End If
                        Next
                    Case "All"
                        For Each FeaturesList As FeaturesAssembly In cntFeaturesGroupsList
                            For Each Feature As Genome_Feature In FeaturesList.FeaturesList
                                If Feature.Orthology.ToLower.Contains(Query) Then
                                    WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                                End If
                            Next
                        Next
                    Case "Main"

                        For Each Feature As Genome_Feature In cntFeaturesGroupsList(0).FeaturesList
                            If Feature.Orthology.ToLower.Contains(Query) Then
                                WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                            End If
                        Next

                End Select

            Case "Type"

                Dim TypeList As New List(Of Short)

                Select Case QueryTextBox.Text.ToLower
                    Case "orf"
                        TypeList.Add(1)
                    Case "cds"
                        TypeList.Add(1)
                    Case "rna"
                        TypeList.Add(2)
                        TypeList.Add(4)
                    Case "site"
                        TypeList.Add(3)
                        TypeList.Add(5)
                        TypeList.Add(6)
                    Case "repeat"
                        TypeList.Add(9)
                    Case "coding"
                        TypeList.Add(1)
                        TypeList.Add(2)
                        TypeList.Add(4)
                    Case "oligo"
                        TypeList.Add(10)
                    Case "primer"
                        TypeList.Add(10)
                End Select

                FeaturesGroupDataGridView.Rows.Clear()




                Select Case SearchGroupComboBox.Text
                    Case "Current"
                        For Each FeaturesList As FeaturesAssembly In cntFeaturesGroupsList
                            If FeaturesList.AssemblyName = FeaturesGroupsListBox.SelectedItems(0).Text Then
                                For Each Feature As Genome_Feature In FeaturesList.FeaturesList

                                    For Each Type As Short In TypeList
                                        If Feature.Type = Type Then
                                            WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                                            Exit For
                                        End If
                                    Next

                                Next

                                Exit For
                            End If

                        Next
                    Case "All"
                        For Each FeaturesList As FeaturesAssembly In cntFeaturesGroupsList
                            For Each Feature As Genome_Feature In FeaturesList.FeaturesList

                                For Each Type As Short In TypeList
                                    If Feature.Type = Type Then
                                        WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                                        Exit For
                                    End If
                                Next

                            Next
                        Next
                    Case "Main"
                        For Each Feature As Genome_Feature In cntFeaturesGroupsList(0).FeaturesList

                            For Each Type As Short In TypeList
                                If Feature.Type = Type Then
                                    WriteFeatureRow(Feature, FeaturesGroupDataGridView)
                                    Exit For
                                End If
                            Next

                        Next
                End Select


        End Select

        CountButton.Text = FeaturesGroupDataGridView.Rows.Count - 1

    End Sub

    Private Sub FeaturesGroupsListBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ShowFeaturesFromGroup(FeaturesGroupsListBox.SelectedItems(0).Text)

    End Sub

    Private Sub FeaturesGroupsListBox_ItemChecked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ItemCheckedEventArgs) Handles FeaturesGroupsListBox.ItemChecked
        If Not bGroupLock Then

            Dim CurrentGroup As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, e.Item.Text)
            CurrentGroup.Visible = e.Item.Checked

            DisplayFeatures()
        End If

    End Sub

    Private Sub AllFeaturesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AllFeaturesButton.Click
        Try
            For i = 0 To FeaturesGroupsListBox.SelectedItems.Count - 1
                ShowFeaturesFromGroup(FeaturesGroupsListBox.SelectedItems(i).Text)
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub SearchFeaturesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchFeaturesButton.Click
        SearchFeature()

    End Sub

    Private Sub QueryTextBox_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles QueryTextBox.KeyDown
        If e.KeyCode = Keys.Enter Then
            SearchFeature()
        End If
    End Sub

    Private Sub AddFButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddFButton.Click
        Try


            Select Case FeaturesGroupsListBox.SelectedIndices(0)

                Case -1
                    MsgBox("Select some group of features!")

                Case 0 'Add feature to main list

                    Dim ParentTabNameArray As String() = strFileName.Split("\")
                    Dim ParentTabName As String = ParentTabNameArray(ParentTabNameArray.GetUpperBound(0))
                    AddFeature.Text = ParentTabName & " - New feature"
                    AddFeature.MyParent = Me
                    AddFeature.Show()
                    AddFeature.Focus()

                Case 1 'Add user oligo

                    Dim Range As Integer = 0

                    If intRangeStart < intRangeEnd Then 'Normal position of projection window
                        Range = intRangeEnd - intRangeStart
                    Else
                        Range = strGenomeSequence.Length - intRangeStart + intRangeEnd
                    End If

                    Dim CurrentX As Integer = intRangeStart + Windows.Forms.Cursor.Position.X * Range / Me.Width
                    AddOligo(CurrentX - 10, CurrentX + 10)

                    DisplayFeatures()

                Case Else


            End Select

        Catch ex As Exception
            MsgBox("Select some group!" & vbNewLine & ex.Message)
        End Try

    End Sub

    Private Sub DelFButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DelFButton.Click
        Dim HistoryRecord As String = ""

        Dim CurrentGroup As FeaturesAssembly = Nothing

        For i = FeaturesGroupDataGridView.SelectedRows.Count - 1 To 0 Step -1

            CurrentGroup = DataIO.GetCurrentGroup(cntFeaturesGroupsList, FeaturesGroupDataGridView.SelectedRows(i).Cells(9).Value)

            If Not IsNothing(CurrentGroup) Then

                If CurrentGroup.AssemblyName = strMainFeaturesListName Then 'Save only main list
                    bSaveRequired = True
                End If


                For j = CurrentGroup.FeaturesList.Count - 1 To 0 Step -1
                    If CurrentGroup.FeaturesList(j).TAG = FeaturesGroupDataGridView.SelectedRows(i).Cells(0).Value Then
                        HistoryRecord = "Del:" & CurrentGroup.FeaturesList(j).TAG & "|Asm=" & CurrentGroup.AssemblyName
                        History.Add(HistoryRecord)
                        listUndo_Features.Add(CurrentGroup.FeaturesList(j))
                        CurrentGroup.FeaturesList.Remove(CurrentGroup.FeaturesList(j))
                    End If
                Next
                FeaturesGroupDataGridView.Rows.RemoveAt(FeaturesGroupDataGridView.SelectedRows(i).Index)


            End If

        Next

        'UndoButton.Enabled = True

        DisplayFeatures()
    End Sub

    Private Sub DeleteAllButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteAllButton.Click

        If MsgBox("Delete selected annotation?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Dim CurrentGroup As FeaturesAssembly = Nothing

            For i = FeaturesGroupsListBox.Items.Count - 1 To 0 Step -1

                If FeaturesGroupsListBox.Items(i).Selected Then

                    If FeaturesGroupsListBox.Items(i).Text = strMainFeaturesListName Or _
                    FeaturesGroupsListBox.Items(i).Text = strUserFeaturesListName Then

                        CurrentGroup = DataIO.GetCurrentGroup(cntFeaturesGroupsList, FeaturesGroupsListBox.Items(i).Text)
                        CurrentGroup.FeaturesList.Clear()

                        For j = FeaturesGroupDataGridView.Rows.Count - 2 To 0 Step -1
                            If FeaturesGroupDataGridView.Rows(j).Cells(9).Value = CurrentGroup.AssemblyName Then
                                FeaturesGroupDataGridView.Rows.RemoveAt(j)
                            End If
                        Next j

                    Else

                        CurrentGroup = DataIO.GetCurrentGroup(cntFeaturesGroupsList, FeaturesGroupsListBox.Items(i).Text)
                        cntFeaturesGroupsList.Remove(CurrentGroup)
                        For j = FeaturesGroupDataGridView.Rows.Count - 2 To 0 Step -1
                            If FeaturesGroupDataGridView.Rows(j).Cells(9).Value = CurrentGroup.AssemblyName Then
                                FeaturesGroupDataGridView.Rows.RemoveAt(j)
                            End If
                        Next j

                    End If

                End If

            Next

            RefreshAssemblyList()
            DisplayFeatures()

        End If

    End Sub

    Private Sub FeaturesGroupDataGridView_SelectionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FeaturesGroupDataGridView.SelectionChanged
        If FeaturesGroupDataGridView.SelectedRows.Count > 0 Then
            DelFButton.Enabled = True
        Else
            DelFButton.Enabled = False
        End If
    End Sub

    Private Sub FeaturesGroupDataGridView_CellBeginEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellCancelEventArgs) Handles FeaturesGroupDataGridView.CellBeginEdit
        EditMode = True
    End Sub

    Private Sub FeaturesGroupDataGridView_CellEndEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles FeaturesGroupDataGridView.CellEndEdit

        Dim HistoryRecord As String = ""

        If EditMode And Not CurrentTAG = "" Then


            Dim CurrentGroup As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, FeaturesGroupDataGridView.CurrentRow.Cells(9).Value)

            If IsNothing(CurrentGroup) Then
                MsgBox("No group found!")
                Exit Sub
            End If

            If CurrentGroup.AssemblyName = strMainFeaturesListName Then 'Save only main list
                bSaveRequired = True
            End If

            For Each Feature As Genome_Feature In CurrentGroup.FeaturesList
                If Feature.TAG = CurrentTAG Then
                    Select Case e.ColumnIndex
                        Case 0
                            Dim NewTag As String = FeaturesGroupDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value
                            Dim Found As Boolean = False
                            For Each Feature2 As Genome_Feature In CurrentGroup.FeaturesList
                                If Feature2.TAG = NewTag Then
                                    Found = True
                                    Exit For
                                End If
                            Next

                            If Found Then
                                MsgBox("Tag must be unique!")
                                FeaturesGroupDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = CurrentTAG
                            Else
                                HistoryRecord = "Edt:TG=" & NewTag & "|" & Feature.TAG & "|Asm=" & CurrentGroup.AssemblyName
                                History.Add(HistoryRecord)
                                Feature.TAG = NewTag
                            End If

                        Case 1
                            HistoryRecord = "Edt:NM=" & Feature.TAG & "|" & Feature.Name & "|Asm=" & CurrentGroup.AssemblyName
                            History.Add(HistoryRecord)
                            Feature.Name = FeaturesGroupDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value
                        Case 2
                            HistoryRecord = "Edt:DC=" & Feature.TAG & "|" & Feature.Description & "|Asm=" & CurrentGroup.AssemblyName
                            History.Add(HistoryRecord)
                            Feature.Description = FeaturesGroupDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value
                        Case 3
                            HistoryRecord = "Edt:ST=" & Feature.TAG & "|" & Feature.AbsoluteStart & "|Asm=" & CurrentGroup.AssemblyName
                            History.Add(HistoryRecord)
                            Feature.AbsoluteStart = FeaturesGroupDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value
                        Case 4
                            HistoryRecord = "Edt:ED=" & Feature.TAG & "|" & Feature.AbsoluteEnd & "|Asm=" & CurrentGroup.AssemblyName
                            History.Add(HistoryRecord)
                            Feature.AbsoluteEnd = FeaturesGroupDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value
                        Case 5
                            HistoryRecord = "Edt:DR=" & Feature.TAG & "|" & Feature.Direction & "|Asm=" & CurrentGroup.AssemblyName
                            History.Add(HistoryRecord)
                            Select Case FeaturesGroupDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value
                                Case "Plus"
                                    Feature.Direction = 1
                                Case "Minus"
                                    Feature.Direction = 2
                                Case "Symmetrical"
                                    Feature.Direction = 3
                                Case Else
                                    Feature.Direction = 0
                            End Select
                        Case 6
                            HistoryRecord = "Edt:TP=" & Feature.TAG & "|" & Feature.Type & "|Asm=" & CurrentGroup.AssemblyName
                            History.Add(HistoryRecord)


                            'Select Case FeaturesGroupDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value
                            'Case "ORF"
                            'Feature.Type = 1
                            'Case "Structural RNA"
                            'Feature.Type = 2
                            'Case "Antisense/Small RNA"
                            'Feature.Type = 4
                            'Case "Binding site/Regulatory sequence"
                            'Feature.Type = 3
                            'Case "Transcription start site"
                            'Feature.Type = 5
                            'Case "Transcription terminator"
                            'Feature.Type = 6
                            'Case "Repeat"
                            'Feature.Type = 9
                            'Case "User feature"
                            'Feature.Type = 10
                            'Case Else
                            'Feature.Type = 10
                            'End Select

                            Feature.Type = Genome_Feature.GetTypeFromDescription(FeaturesGroupDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value)


                        Case 7
                            HistoryRecord = "Edt:OT=" & Feature.TAG & "|" & Feature.Orthology & "|Asm=" & CurrentGroup.AssemblyName
                            History.Add(HistoryRecord)
                            Feature.Orthology = FeaturesGroupDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value
                        Case 8
                            If FeaturesGroupDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = "" Then
                                If Feature.ReadList.Count > 0 Then
                                    Dim ReadString As String = ""
                                    For Each RItem As ReadItem In Feature.ReadList
                                        ReadString = String.Concat(RItem.ReadAbsoluteStart, "-", RItem.ReadAbsoluteEnd, ",")
                                    Next
                                    ReadString = ReadString.Remove(ReadString.Length - 1, 1)
                                    HistoryRecord = "Edt:RD=" & Feature.TAG & "|" & ReadString & "|Asm=" & CurrentGroup.AssemblyName
                                    History.Add(HistoryRecord)
                                End If
                                FeaturesGroupDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = "Continous"
                                Feature.UseReadList = False
                                Feature.ReadList.Clear()
                            Else

                                If Feature.ReadList.Count > 0 Then
                                    Dim ReadString As String = ""
                                    For Each RItem As ReadItem In Feature.ReadList
                                        ReadString = String.Concat(RItem.ReadAbsoluteStart, "-", RItem.ReadAbsoluteEnd, ",")
                                    Next
                                    ReadString = ReadString.Remove(ReadString.Length - 1, 1)
                                    HistoryRecord = "Edt:RD=" & Feature.TAG & "|" & ReadString & "|Asm=" & CurrentGroup.AssemblyName
                                    History.Add(HistoryRecord)
                                Else
                                    HistoryRecord = "Edt:RD=" & Feature.TAG & "|" & "none" & "|Asm=" & CurrentGroup.AssemblyName
                                    History.Add(HistoryRecord)
                                End If

                                Feature.UseReadList = True
                                Feature.ReadList.Clear()
                                Dim RCItems As String() = FeaturesGroupDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value.Split(",")
                                Try
                                    For Each RCItem As String In RCItems
                                        Feature.ReadList.Add(New ReadItem(RCItem.Split("-")(0), RCItem.Split(".")(1)))
                                    Next
                                Catch ex As Exception
                                    MsgBox("Wrong format!")
                                    Feature.UseReadList = False
                                End Try


                            End If


                        Case 9
                            'Edit group


                    End Select

                    Exit For
                End If
            Next

            DisplayFeatures()
            EditMode = False
        End If

        If History.Count = 0 Then
            'UndoButton.Enabled = False
        Else
            'UndoButton.Enabled = True
        End If

    End Sub

    Private Sub FeaturesGroupDataGridView_CellEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles FeaturesGroupDataGridView.CellEnter
        CurrentTAG = FeaturesGroupDataGridView.CurrentRow.Cells(0).Value
        CurrentGroup = FeaturesGroupDataGridView.CurrentRow.Cells(9).Value

    End Sub

    Private Sub TabseparatedFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabseparatedFileToolStripMenuItem.Click
        ImportFeatures.MyGenomeViewer = Me
        ImportFeatures.Show()
        ImportFeatures.Focus()
    End Sub

    Private Sub AnnotationFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AnnotationFileToolStripMenuItem.Click
        If Master.OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            For Each File As String In Master.OpenFileDialog.FileNames
                Master.OpenAnnotation(File, Me)
            Next

        End If

    End Sub

    Private Sub SaveFeaturesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveFeaturesButton.Click

        For Each Item As ListViewItem In FeaturesGroupsListBox.Items
            If Item.Selected Then
                If Master.SaveFileDialog.ShowDialog = DialogResult.OK Then

                    Dim CurrentGroup As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, Item.Text)
                    DataIO.WriteAnnotation(CurrentGroup.FeaturesList, Master.SaveFileDialog.FileName, bGenomeTopology, shGenetic_Code, strComment)

                End If
            End If
        Next



    End Sub

    Private Sub MergeListsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MergeListsButton.Click
        MergeMaster.MergeList.Clear()
        MergeMaster.MergeTargetComboBox.Items.Clear()

        For Each Item As ListViewItem In FeaturesGroupsListBox.Items
            If Item.Selected Then
                MergeMaster.MergeList.Add(DataIO.GetCurrentGroup(cntFeaturesGroupsList, Item.Text))
                MergeMaster.MergeTargetComboBox.Items.Add(Item.Text)
            End If
        Next

        If MergeMaster.MergeList.Count > 0 Then
            MergeMaster.MyViewer = Me
            MergeMaster.Show()
            MergeMaster.Focus()
        End If


    End Sub

    Private Sub RenameAsmButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RenameAsmButton.Click

        Dim CurrentGroup As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, FeaturesGroupsListBox.SelectedItems(0).Text)

        If Not IsNothing(CurrentGroup) Then

            SystemTextBox.Text = "Rename group"
            SystemTextBox.InputTextBox.Text = CurrentGroup.AssemblyName
            Dim Dialog_Result As Short = SystemTextBox.DialogReturn

            If Dialog_Result = 1 Then
                If Not (CurrentGroup.AssemblyName = strMainFeaturesListName Or _
                CurrentGroup.AssemblyName = strUserFeaturesListName) Then
                    CurrentGroup.AssemblyName = SystemTextBox.InputTextBox.Text
                    FeaturesGroupsListBox.SelectedItems(0).Text = CurrentGroup.AssemblyName
                Else
                    MsgBox("Not possible to rename system groups!")
                End If
            End If


        End If


    End Sub

    Private Sub EraseTableButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EraseTableButton.Click
        FeaturesGroupDataGridView.Rows.Clear()

    End Sub

    Private Sub DisplayToTopologyToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisplayToTopologyToolStripButton.Click

        For Each Row As DataGridViewRow In FeaturesGroupDataGridView.Rows
            Dim CurrentGroup As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, Row.Cells(9).Value)

            If Not IsNothing(CurrentGroup) Then
                If Not Row.Cells(0).Value = "" Then

                    Dim CurrentFeature As Genome_Feature = Nothing
                    For Each Feature As Genome_Feature In CurrentGroup.FeaturesList
                        If Feature.TAG = Row.Cells(0).Value Then
                            CurrentFeature = Feature
                            Exit For
                        End If
                    Next Feature

                    ShowTopology(CurrentFeature)

                End If
            End If


        Next Row

    End Sub

#End Region

#Region "Quantitative values"

    Public Sub ShowIntervalsFromHolder(ByVal IntervalName As String)
        For Each Holder As QuantBlockHolder In listIntegratedValues
            If Holder.Name = IntervalName Then   'FeaturesGroupsListBox.SelectedItem

                IntervalsDataGridView.Rows.Clear()

                For Each Interval As QuantitationBlock In Holder.BlocksList
                    WriteBlockRow(Interval, IntervalsDataGridView)
                Next

                Exit For
            End If
        Next

        BlocksCountButton.Text = IntervalsDataGridView.Rows.Count - 1

    End Sub

    Private Sub LinearToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinearToolStripMenuItem.Click
        bIntegratedLog = False
        LogarithmToolStripMenuItem.Checked = bIntegratedLog
        LinearToolStripMenuItem.Checked = Not bIntegratedLog
        GraphPanel.Invalidate()
    End Sub

    Private Sub LogarithmToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogarithmToolStripMenuItem.Click
        bIntegratedLog = True
        LogarithmToolStripMenuItem.Checked = bIntegratedLog
        LinearToolStripMenuItem.Checked = Not bIntegratedLog
        GraphPanel.Invalidate()
    End Sub

    Private Sub FrameToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FrameToolStripMenuItem.Click
        bIntegratedFill = False
        FillToolStripMenuItem.Checked = bIntegratedFill
        FrameToolStripMenuItem.Checked = Not bIntegratedFill
        GraphPanel.Invalidate()
    End Sub

    Private Sub FillToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FillToolStripMenuItem.Click
        bIntegratedFill = True
        FillToolStripMenuItem.Checked = bIntegratedFill
        FrameToolStripMenuItem.Checked = Not bIntegratedFill
        GraphPanel.Invalidate()
    End Sub

    Private Sub DelValsToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DelValsToolStripButton.Click
        Dim SearchID As String = ""

        For i = IntervalsListView.SelectedItems.Count - 1 To 0 Step -1
            SearchID = IntervalsListView.SelectedItems(i).Text
            IntervalsListView.Items.RemoveAt(IntervalsListView.SelectedItems(i).Index)
            For Each QHolder As QuantBlockHolder In listIntegratedValues
                If QHolder.Name = SearchID Then
                    listIntegratedValues.Remove(QHolder)
                    Exit For
                End If
            Next
        Next

        DisplayFeatures()
    End Sub

    Private Sub AddValuesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddValuesButton.Click
        QuantControl.MyGenomeViewer = Me
        QuantControl.Show()
        QuantControl.Focus()
    End Sub

    Private Sub SaveBlocksButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBlocksButton.Click
        Dim SearchID As String = ""
        Dim SaveDialogHeader As String = Master.SaveFileDialog.Title

        For i = IntervalsListView.SelectedItems.Count - 1 To 0 Step -1
            SearchID = IntervalsListView.SelectedItems(i).Text
            For Each QHolder As QuantBlockHolder In listIntegratedValues
                If QHolder.Name = SearchID Then
                    Master.SaveFileDialog.Title = "Save blocks: " & QHolder.Name
                    If Master.SaveFileDialog.ShowDialog = DialogResult.OK Then
                        Dim SaveStream As New IO.FileStream(Master.SaveFileDialog.FileName & ".xls", IO.FileMode.Create)
                        Dim BlockWriter As New IO.StreamWriter(SaveStream)
                        BlockWriter.WriteLine("ID" & Chr(9) & "Start" & Chr(9) & "End" & Chr(9) & "Dir" & Chr(9) & "Value")
                        For Each Block As QuantitationBlock In QHolder.BlocksList
                            BlockWriter.WriteLine(Block.TAG & Chr(9) & Block.AbsoluteStart & Chr(9) & Block.AbsoluteEnd & Chr(9) & Block.Direction & Chr(9) & Block.Value)
                        Next


                        BlockWriter.Close()
                        SaveStream.Close()
                        BlockWriter.Dispose()
                        SaveStream.Dispose()
                    End If

                    Exit For
                End If
            Next

        Next

        Master.SaveFileDialog.Title = SaveDialogHeader
    End Sub

    Private Sub MultValuesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MultValuesButton.Click

    End Sub


    Private Sub IntervalsListView_ItemChecked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ItemCheckedEventArgs) Handles IntervalsListView.ItemChecked
        Dim SearchID As String = e.Item.Text

        For Each QHolder As QuantBlockHolder In listIntegratedValues
            If QHolder.Name = SearchID Then
                QHolder.SetVisibility(e.Item.Checked)
                Exit For
            End If
        Next

        DisplayFeatures()
    End Sub

    Private Sub ColorIntervalToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorIntervalToolStripMenuItem.Click
        If Master.ColorSelectDialog.ShowDialog = DialogResult.OK Then
            Dim SearchID As String = IntervalsListView.SelectedItems(0).Text

            For Each QHolder As QuantBlockHolder In listIntegratedValues
                If QHolder.Name = SearchID Then
                    QHolder.SetColor(Master.ColorSelectDialog.Color)
                    IntervalsListView.SelectedItems(0).ForeColor = Master.ColorSelectDialog.Color
                    Exit For
                End If
            Next

            DisplayFeatures()
        End If
    End Sub

    Private Sub RenameIntervalToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RenameIntervalToolStripMenuItem.Click
        Dim SearchID As String = IntervalsListView.SelectedItems(0).Text

        SystemTextBox.Text = "Rename interval"
        SystemTextBox.InputTextBox.Text = SearchID
        Dim Dialog_Result As Short = SystemTextBox.DialogReturn


        If Dialog_Result = 1 Then
            For Each QHolder As QuantBlockHolder In listIntegratedValues
                If QHolder.Name = SearchID Then
                    QHolder.Name = SystemTextBox.InputTextBox.Text
                    Exit For
                End If
            Next
        End If

        IntervalsListView.SelectedItems(0).Text = SystemTextBox.InputTextBox.Text

        DisplayFeatures()

    End Sub

    Private Sub IntervalsListView_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IntervalsListView.SelectedIndexChanged
        If IntervalsListView.SelectedItems.Count > 0 Then
            DelValsToolStripButton.Enabled = True
            SaveBlocksButton.Enabled = True
        Else
            DelValsToolStripButton.Enabled = False
            SaveBlocksButton.Enabled = False
        End If
    End Sub

    Private Sub ViewIntervalsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewIntervalsButton.Click
        For i = 0 To IntervalsListView.SelectedItems.Count - 1
            ShowIntervalsFromHolder(IntervalsListView.SelectedItems(i).Text)
        Next

    End Sub

    Private Sub IntervalsDataGridView_CellEndEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles IntervalsDataGridView.CellEndEdit
        Dim CurrentHolder As QuantBlockHolder = DataIO.GetCurrentBlockHolder(listIntegratedValues, CurrentHolderName)


        For Each Block As QuantitationBlock In CurrentHolder.BlocksList
            If Block.TAG = CurrentBlockName Then


                Select Case e.ColumnIndex
                    Case 0

                    Case 1
                        Block.AbsoluteStart = IntervalsDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value
                    Case 2
                        Block.AbsoluteEnd = IntervalsDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value
                    Case 3
                        Select Case IntervalsDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value
                            Case "Plus"
                                Block.Direction = 1
                            Case "Minus"
                                Block.Direction = 2
                            Case "Unknown"
                                Block.Direction = 0
                        End Select
                    Case 4
                        Block.Value = IntervalsDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value

                End Select
            End If

        Next

        DisplayFeatures()

    End Sub

    Private Sub IntervalsDataGridView_CellEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles IntervalsDataGridView.CellEnter
        CurrentHolderName = IntervalsDataGridView.CurrentRow.Cells(5).Value
        CurrentBlockName = IntervalsDataGridView.CurrentRow.Cells(0).Value

    End Sub

    Private Sub SplitBlockToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SplitBlockToolStripMenuItem.Click

        If Not IsNothing(cntrlSelected_Block) Then
            Dim CurrentHolder As QuantBlockHolder = DataIO.GetCurrentBlockHolder(listIntegratedValues, cntrlSelected_Block.Holder_Name)
            Dim CurrentX As Integer = MouseLocationGraph.X / Projection_K + intRangeStart
            Dim SplitBlocks As QuantitationBlock() = Bioinformatics.SplitBlock(cntrlSelected_Block, CurrentX)

            CurrentHolder.BlocksList.Add(SplitBlocks(0))
            CurrentHolder.BlocksList.Add(SplitBlocks(1))
            CurrentHolder.BlocksList.Remove(cntrlSelected_Block)
            Bioinformatics.SortCoverageBlocks(CurrentHolder)

            cntrlSelected_Block = Nothing

            DisplayFeatures()

        End If
    End Sub

    Private Sub MergeBlocksToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MergeBlocksToolStripMenuItem.Click
        If Not IsNothing(cntrlSelected_Block) And Not IsNothing(cntrlSelected_Block_Alt) Then
            Dim CurrentHolder As QuantBlockHolder = DataIO.GetCurrentBlockHolder(listIntegratedValues, cntrlSelected_Block.Holder_Name)
            CurrentHolder.BlocksList.Add(Bioinformatics.MergeBlocks(cntrlSelected_Block, cntrlSelected_Block_Alt))
            CurrentHolder.BlocksList.Remove(cntrlSelected_Block)
            CurrentHolder.BlocksList.Remove(cntrlSelected_Block_Alt)
            Bioinformatics.SortCoverageBlocks(CurrentHolder)

            cntrlSelected_Block = Nothing
            cntrlSelected_Block_Alt = Nothing

            Master.Ctrl_Pressed = False

            DisplayFeatures()

        End If

    End Sub

    Private Sub DeleteBlockToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteBlockToolStripMenuItem.Click
        If Not IsNothing(cntrlSelected_Block) Then
            Dim CurrentHolder As QuantBlockHolder = DataIO.GetCurrentBlockHolder(listIntegratedValues, cntrlSelected_Block.Holder_Name)

            CurrentHolder.BlocksList.Remove(cntrlSelected_Block)

            cntrlSelected_Block = Nothing

            DisplayFeatures()

        End If
    End Sub

    Private Sub FindBlockToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindBlockToolStripMenuItem.Click
        If Not IsNothing(cntrlSelected_Block) Then
            IntervalsDataGridView.Rows.Clear()
            WriteBlockRow(cntrlSelected_Block, IntervalsDataGridView)

        End If
    End Sub

#End Region

#Region "Translation lane"

    Private Sub FastaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FastaToolStripMenuItem.Click
        If list6FrameTranslation.Count = 6 Then
            If Master.SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
                Dim FS As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.Create)
                Dim Writer As New IO.StreamWriter(FS)

                Dim FrameF1 As String = list6FrameTranslation(0).Replace("-", "")
                Dim FrameF2 As String = list6FrameTranslation(1).Replace("-", "")
                Dim FrameF3 As String = list6FrameTranslation(2).Replace("-", "")
                Dim RevFrameR1 As String = Bioinformatics.ReverseStrand(list6FrameTranslation(3).Replace("-", ""))
                Dim RevFrameR2 As String = Bioinformatics.ReverseStrand(list6FrameTranslation(4).Replace("-", ""))
                Dim RevFrameR3 As String = Bioinformatics.ReverseStrand(list6FrameTranslation(5).Replace("-", ""))

                Writer.WriteLine(">+1")
                Writer.WriteLine(FrameF1)
                Writer.WriteLine(">+2")
                Writer.WriteLine(FrameF2)
                Writer.WriteLine(">+3")
                Writer.WriteLine(FrameF3)
                Writer.WriteLine(">-1")
                Writer.WriteLine(RevFrameR1)
                Writer.WriteLine(">-2")
                Writer.WriteLine(RevFrameR2)
                Writer.WriteLine(">-3")
                Writer.WriteLine(RevFrameR3)

                Writer.Close()
                FS.Close()
                Writer.Dispose()
                FS.Dispose()
            End If
        End If
    End Sub

    Private Sub WriteTranslation(ByVal Data As String(), ByVal Frame As String, ByVal Writer As IO.StreamWriter)
        For Each Seq As String In Data

            If Seq.Length > 1 Then

                Writer.WriteLine(Seq & Chr(9) & Frame)

            End If

        Next Seq
    End Sub

    Private Sub TableToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TableToolStripMenuItem.Click
        If list6FrameTranslation.Count = 6 Then
            Master.SaveFileDialog.Filter = "Text file|*.txt"

            If Master.SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
                Dim FS As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.Create)
                Dim Writer As New IO.StreamWriter(FS)

                Dim FrameF1 As String() = list6FrameTranslation(0).Replace("-", "").Split("*")
                Dim FrameF2 As String() = list6FrameTranslation(1).Replace("-", "").Split("*")
                Dim FrameF3 As String() = list6FrameTranslation(2).Replace("-", "").Split("*")
                Dim RevFrameR1 As String() = Bioinformatics.ReverseStrand(list6FrameTranslation(3).Replace("-", "")).Split("*")
                Dim RevFrameR2 As String() = Bioinformatics.ReverseStrand(list6FrameTranslation(4).Replace("-", "")).Split("*")
                Dim RevFrameR3 As String() = Bioinformatics.ReverseStrand(list6FrameTranslation(5).Replace("-", "")).Split("*")

                Writer.WriteLine("Seq" & Chr(9) & "Frame")
                WriteTranslation(FrameF1, "Frame+1", Writer)
                WriteTranslation(FrameF2, "Frame+2", Writer)
                WriteTranslation(FrameF3, "Frame+3", Writer)
                WriteTranslation(RevFrameR1, "Frame-1", Writer)
                WriteTranslation(RevFrameR2, "Frame-2", Writer)
                WriteTranslation(RevFrameR3, "Frame-3", Writer)

                Writer.Close()
                FS.Close()
                Writer.Dispose()
                FS.Dispose()
            End If

            Master.SaveFileDialog.Filter = ""

        End If
    End Sub

#End Region

    Public Sub SearchShortRepeatSequence()
        'Function searches for short repeats of variable length like GAAGAAGAA using a template.
        SearchSequenceTextBox.Text = SearchSequenceTextBox.Text.ToUpper

        Dim ForCoordList As List(Of CoordHit) = Nothing
        Dim RevCoordList As List(Of CoordHit) = Nothing

        Dim L As Integer = SearchSequenceTextBox.Text.Length

        ForCoordList = Bioinformatics.UngappedSequenceSearch(strGenomeSequence, SearchSequenceTextBox.Text, IdentityPercentTextBox.Text / 100)
        RevCoordList = Bioinformatics.UngappedSequenceSearch(strGenomeSequence, Bioinformatics.GetReverseComplement(SearchSequenceTextBox.Text), IdentityPercentTextBox.Text / 100)

        Dim CuratedList As New List(Of Genome_Feature)
        Dim NewFeature As Genome_Feature = Nothing
        Dim counter As Integer = 0

        For Each PotentialFeature As CoordHit In ForCoordList
            If Not PotentialFeature.Used Then
                NewFeature = New Genome_Feature
                NewFeature.TAG = "CF_" & counter
                NewFeature.Direction = 1
                NewFeature.Type = 7
                NewFeature.AbsoluteStart = PotentialFeature.Position
                NewFeature.AbsoluteEnd = PotentialFeature.Position + L - 1
                counter += 1
            End If

            For Each Hit As CoordHit In ForCoordList
                If Not Hit.Used Then
                    If NewFeature.AbsoluteEnd > Hit.Position And NewFeature.AbsoluteEnd < Hit.Position + L - 1 Then 'This feature overlaps downstream
                        'Extend downstream

                        NewFeature.AbsoluteEnd = Hit.Position + L - 1
                        Hit.Used = True

                    ElseIf NewFeature.AbsoluteStart > Hit.Position And NewFeature.AbsoluteStart < Hit.Position + L - 1 Then 'This feature overlaps upstream
                        'Extend upstream

                        NewFeature.AbsoluteStart = Hit.Position
                        Hit.Used = True
                    End If
                End If
            Next


            If Not PotentialFeature.Used Then
                CuratedList.Add(NewFeature)
            End If

        Next

        For Each Feature As Genome_Feature In CuratedList
            cntFeaturesGroupsList(1).FeaturesList.Add(Feature)
            'MyAccessoryBox.AccessoryGridView.Rows.Add(True, Feature.TAG, "", Feature.AbsoluteStart, Feature.AbsoluteEnd, "Plus", "User feature", "")
        Next



        CuratedList.Clear()
        NewFeature = Nothing

        For Each PotentialFeature As CoordHit In RevCoordList
            If Not PotentialFeature.Used Then
                NewFeature = New Genome_Feature
                NewFeature.TAG = "CF_" & counter
                NewFeature.Direction = 2
                NewFeature.Type = 7
                NewFeature.AbsoluteStart = PotentialFeature.Position
                NewFeature.AbsoluteEnd = PotentialFeature.Position + L - 1
                counter += 1
            End If

            For Each Hit As CoordHit In RevCoordList
                If Not Hit.Used Then
                    If NewFeature.AbsoluteEnd > Hit.Position And NewFeature.AbsoluteEnd < Hit.Position + L - 1 Then 'This feature overlaps downstream
                        'Extend downstream

                        NewFeature.AbsoluteEnd = Hit.Position + L - 1
                        Hit.Used = True

                    ElseIf NewFeature.AbsoluteStart > Hit.Position And NewFeature.AbsoluteStart < Hit.Position + L - 1 Then 'This feature overlaps upstream
                        'Extend upstream

                        NewFeature.AbsoluteStart = Hit.Position
                        Hit.Used = True
                    End If
                End If
            Next


            If Not PotentialFeature.Used Then
                CuratedList.Add(NewFeature)
            End If

        Next

        For Each Feature As Genome_Feature In CuratedList
            cntFeaturesGroupsList(1).FeaturesList.Add(Feature)
            'MyAccessoryBox.AccessoryGridView.Rows.Add(True, Feature.TAG, "", Feature.AbsoluteStart, Feature.AbsoluteEnd, "Minus", "User feature", "")
        Next
    End Sub


    Private Sub TestButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        If Master.SaveFileDialog.ShowDialog = DialogResult.OK Then
            Dim WriteStream As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.Create)
            Dim Writer As New IO.StreamWriter(WriteStream)

            Dim Width2 As Integer = 8
            Dim TargetSeq As String = ""
            For i = 1 To strGenomeSequence.Length
                TargetSeq = DataIO.RetrieveSeqFromCache(strGenomeSequence, i - Width2, i + Width2)
                Writer.WriteLine(-Bioinformatics.CalculateOligoDG(TargetSeq, 46, False))
            Next



            Writer.Close()
            WriteStream.Close()
            Writer.Dispose()
            WriteStream.Dispose()

        End If





        '\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\!Wordspace calculator!\\\\\\\\\\\\\\\\\\\\\\

        'If Master.SaveFileDialog.ShowDialog = DialogResult.OK Then
        'Dim WriteStream As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.Create)
        'Dim Writer As New IO.StreamWriter(WriteStream)

        'Dim WordspaceStat As DataTable = Bioinformatics.GetWordStatistics(strGenomeSequence, 4, 0.31, MyProgressBar)

        'For i = 0 To WordspaceStat.Rows.Count - 1
        'Writer.WriteLine(WordspaceStat.Rows(i).Item(0) & Chr(9) & WordspaceStat.Rows(i).Item(1) & Chr(9) & WordspaceStat.Rows(i).Item(2))
        'Next

        'Writer.Close()
        'WriteStream.Close()
        'Writer.Dispose()
        'WriteStream.Dispose()
        'End If



        '\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        'Function to calculate antisense RNAs from a list of transcripts (working)

        'If Master.SaveFileDialog.ShowDialog = DialogResult.OK Then

        'Dim WriteStream As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.Create)
        'Dim Writer As New IO.StreamWriter(WriteStream)
        'Dim AntisenseCoverage As Single = 0

        'For Each Feature As Genome_Feature In listGenome_Features
        'For Each QueryFeature As Genome_Feature In listUser_Features
        'If Bioinformatics.IsTrueAntisenseFeature(Feature, QueryFeature) Then
        'AntisenseCoverage = (QueryFeature.AbsoluteEnd - QueryFeature.AbsoluteStart + 1) / (Feature.AbsoluteEnd - Feature.AbsoluteStart + 1)
        'Writer.WriteLine(Feature.TAG & Chr(9) & Feature.Name & Chr(9) & Feature.Description & Chr(9) & QueryFeature.AbsoluteStart & Chr(9) & QueryFeature.AbsoluteEnd & Chr(9) & QueryFeature.Direction & Chr(9) & AntisenseCoverage)
        'End If
        'Next
        'Next

        'Writer.Close()
        'WriteStream.Close()
        'Writer.Dispose()
        'WriteStream.Dispose()

        'End If


        '\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        'Function to calculate corresponding TSS for genes (working)

        'Dim Operons As New List(Of Genome_Feature)
        'Dim TSSs As New List(Of Genome_Feature)

        'For Each Feature As Genome_Feature In listUser_Features
        'Select Case Feature.Type
        'Case 5
        'TSSs.Add(Feature)
        'Case 12
        'Operons.Add(Feature)
        'End Select
        'Next

        'Bioinformatics.FindTSSForGenes(strGenomeSequence, TSSs, Operons, 25, 25, Master.SaveFileDialog)

        '\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


        ' If Master.SaveFileDialog.ShowDialog = DialogResult.OK Then
        'Dim WriteStream As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.Create)
        'Dim Writer As New IO.StreamWriter(WriteStream)
        'Dim TotalCoverage As Integer = 0
        'Dim FeatureCoverage As Integer = 0

        'For i = 0 To listPositionalValues(0).Positional_Values.Count - 1
        'TotalCoverage += listPositionalValues(0).Positional_Values(i)
        'Next
        'For i = 0 To listPositionalValues(1).Positional_Values.Count - 1
        'TotalCoverage += listPositionalValues(1).Positional_Values(i)
        'Next

        'Writer.WriteLine("Total coverage" & Chr(9) & TotalCoverage)

        'For Each Feature As Genome_Feature In listGenome_Features
        'Select Case Feature.Direction
        'Case 1
        'FeatureCoverage = Bioinformatics.GetPileUpSum(Feature.AbsoluteStart, Feature.AbsoluteEnd, listPositionalValues(0).Positional_Values)
        'Case 2
        'FeatureCoverage = Bioinformatics.GetPileUpSum(Feature.AbsoluteStart, Feature.AbsoluteEnd, listPositionalValues(1).Positional_Values)
        'End Select
        'Writer.WriteLine(Feature.TAG & Chr(9) & Feature.Name & Chr(9) & Feature.Type & Chr(9) & FeatureCoverage)
        'Next
        'Writer.Close()
        'WriteStream.Close()
        'Writer.Dispose()
        'WriteStream.Dispose()

        'End If


        '\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

        'If Master.OpenFileDialog.ShowDialog = DialogResult.OK Then

        'Dim ReadStream As New IO.FileStream(Master.OpenFileDialog.FileName, IO.FileMode.Open)
        'Dim Reader As New IO.StreamReader(ReadStream)

        'Dim FileName As String = ""
        'Dim FileNameParts As String()

        'Dim FilePath As String() = Master.OpenFileDialog.FileName.Split(".")(0).Split("\")
        'Dim FileDir As String = ""
        'For i = 0 To FilePath.GetUpperBound(0) - 1
        'FileDir &= FilePath(i) & "\"
        'Next




        'Dim CurrentString As String = ""
        'Dim ForPileupFile As String = ""
        'Dim RevPileupFile As String = ""
        'Dim NormalizerCount As Long = 0

        'Dim ForPileupData As New List(Of Integer)
        'Dim RevPileupData As New List(Of Integer)

        'Dim StartNewPack As Boolean = False


        'While Reader.Peek > -1
        'CurrentString = Reader.ReadLine



        'If StartNewPack Then
        'Select Case CurrentString.Split("=")(0)
        'Case "ForPileup"
        'ForPileupFile = CurrentString.Split("=")(1)
        'Case "RevPileup"
        'RevPileupFile = CurrentString.Split("=")(1)
        'End Select
        'End If



        'If CurrentString = "</PilePack>" Then
        'Execute search

        'ForPileupData = DataIO.RetrievePositionalValuesIntoListOfInteger(ForPileupFile)
        'RevPileupData = DataIO.RetrievePositionalValuesIntoListOfInteger(RevPileupFile)

        'NormalizerCount = Bioinformatics.GetTotalCountOfCoding(ForPileupData, RevPileupData, listGenome_Features, True)

        'FileNameParts = ForPileupFile.Split("\")
        'FileName = FileDir & FileNameParts(FileNameParts.GetUpperBound(0)) & "-RPKM.txt"

        'Bioinformatics.GetNormalizedCoverage(NormalizerCount, listUser_Features, ForPileupData, RevPileupData, FileName, True)

        'StartNewPack = False
        'End If


        'If CurrentString = "<PilePack>" Then
        'StartNewPack = True
        'ForPileupData.Clear()
        'RevPileupData.Clear()
        'ForPileupFile = ""
        'RevPileupFile = ""
        'End If






        'End While


        'Reader.Close()
        'ReadStream.Close()
        'Reader.Dispose()
        'ReadStream.Dispose()

        'End If


        '\\\\\\\\\\\\\\\\\\\\\\
        'CODON USAGE

        'If Master.SaveFileDialog.ShowDialog = DialogResult.OK Then
        'Dim WriteStream As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.Create)
        'Dim Writer As New IO.StreamWriter(WriteStream)

        'Dim ResTable As DataTable = Bioinformatics.GetCodonUsage(Me)

        'Dim WriteString As String = ""
        'For Each row As DataRow In ResTable.Rows
        'WriteString = ""
        'For i = 0 To ResTable.Columns.Count - 1
        'WriteString &= row.Item(i) & Chr(9)
        'Next
        'Writer.WriteLine(WriteString)
        'Next




        'Writer.Close()
        'WriteStream.Close()
        'Writer.Dispose()
        'WriteStream.Dispose()
        'End If

        '\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


    End Sub




    Private Sub ClearIntegratedToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearIntegratedToolStripButton.Click
        listIntegratedValues.Clear()
        IntervalsListView.Items.Clear()

        If listPositionalValues.Count = 0 Then
            MyControlBox.SkewOffRadioButton.Checked = True
        End If

        DisplayFeatures()
    End Sub


    Public Sub CreateStepList(ByVal Coverage As List(Of Integer))
        If Master.SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

            Dim Smoothing As Integer = 100
            Dim Normalizer As Single = Smoothing + 1
            Dim StartPos As Integer = 0
            Dim EndPos As Integer = 0

            Dim PrevSum As Integer = 0
            Dim NextSum As Integer = 0

            Dim DerivativeList As New List(Of Integer) 'TSS only if Integer, second list for TTS is required

            Dim MaxIndex As Integer = Coverage.Count - 1

            For i = 0 To MaxIndex
                Try
                    PrevSum = 0
                    NextSum = 0

                    If i + Smoothing <= MaxIndex And i - Smoothing >= 0 Then

                        For SubIndex = i - Smoothing To i
                            PrevSum += Coverage(SubIndex)
                        Next

                        For SubIndex = i To i + Smoothing
                            NextSum += Coverage(SubIndex)
                        Next

                    ElseIf i + Smoothing <= MaxIndex And i - Smoothing < 0 Then

                        For SubIndex = 0 To i
                            PrevSum += Coverage(SubIndex)
                        Next

                        For SubIndex = MaxIndex - Smoothing + i + 1 To MaxIndex
                            PrevSum += Coverage(SubIndex)
                        Next

                        For SubIndex = i To i + Smoothing
                            NextSum += Coverage(SubIndex)
                        Next

                    ElseIf i + Smoothing > MaxIndex And i - Smoothing >= 0 Then

                        For SubIndex = i - Smoothing To i
                            PrevSum += Coverage(SubIndex)
                        Next

                        For SubIndex = i To MaxIndex
                            NextSum += Coverage(SubIndex)
                        Next

                        For SubIndex = 0 To Smoothing - MaxIndex + i - 1
                            NextSum += Coverage(SubIndex)
                        Next

                    End If

                    'If PrevSum = 0 Then
                    'PrevSum = 1
                    'End If

                    '   DerivativeList.Add(NextSum / PrevSum)


                    If NextSum = 0 Then
                        NextSum = 1
                    End If

                    DerivativeList.Add(PrevSum / NextSum)

                Catch ex As Exception

                    DerivativeList.Add(0)

                    MsgBox(ex.Message)
                End Try

            Next



            Dim ResultFile As New IO.FileStream(Master.SaveFileDialog.FileName & "-derivative.txt", IO.FileMode.Create)
            Dim SmoothedWriter As New IO.StreamWriter(ResultFile)

            For Each Derivative As Single In DerivativeList
                SmoothedWriter.WriteLine(Derivative)
            Next

            SmoothedWriter.Close()
            ResultFile.Close()
            SmoothedWriter.Dispose()
            ResultFile.Dispose()


        End If



    End Sub





    Private Sub ScanSlipperingToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScanSlipperingToolStripButton.Click
        Dim SlipperingBlocks As New List(Of QuantitationBlock)
        SlipperingBlocks = Bioinformatics.FindSlipperingIntervals(listIntegratedValues(0).BlocksList, listIntegratedValues(1).BlocksList, , )

        Dim SlipperingFeatures As New List(Of Genome_Feature)


        For Each Block As QuantitationBlock In SlipperingBlocks
            For Each MainFeature As Genome_Feature In cntFeaturesGroupsList(0).FeaturesList
                If MainFeature.Type = 1 And _
                Block.Direction = MainFeature.Direction And _
                Bioinformatics.IsFeatureInBlock(MainFeature, Block, ) Then
                    SlipperingFeatures.Add(MainFeature)
                End If
            Next
        Next

        Dim TotalOutputFile As New IO.FileStream(strFileName & "- slippering genes.txt", IO.FileMode.Create)
        Dim TotalWriter As New IO.StreamWriter(TotalOutputFile)
        For Each SFeature As Genome_Feature In SlipperingFeatures
            TotalWriter.WriteLine(SFeature.TAG & Chr(9) & SFeature.Name & Chr(9) & SFeature.Direction)
        Next

        TotalWriter.Close()
        TotalOutputFile.Close()
        TotalWriter.Dispose()
        TotalOutputFile.Dispose()

    End Sub

    Private Sub ScanSameIntervalToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScanSameIntervalToolStripButton.Click
        Dim IncreasingIntervals As New List(Of QuantitationBlock)
        IncreasingIntervals = Bioinformatics.FindDifExpressingIntervals(listIntegratedValues(0).BlocksList, listIntegratedValues(1).BlocksList, , )
        'Dim DecreasingIntervals As New List(Of QuantitationBlock)
        'DecreasingIntervals = Bioinformatics.FindDifExpressingIntervals(listIntegratedValues(0).BlocksList, listIntegratedValues(1).BlocksList, False, )


        Dim ResultTablePlus As New DataTable

        ResultTablePlus.Columns.Add("Block")
        ResultTablePlus.Columns.Add("Feature")
        ResultTablePlus.Columns.Add("Name")
        ResultTablePlus.Columns.Add("Dir")

        Dim ResultTableMinus As New DataTable

        ResultTableMinus.Columns.Add("Block")
        ResultTableMinus.Columns.Add("Feature")
        ResultTableMinus.Columns.Add("Name")
        ResultTableMinus.Columns.Add("Dir")


        For Each Block As QuantitationBlock In IncreasingIntervals

            For Each MainFeature As Genome_Feature In cntFeaturesGroupsList(0).FeaturesList
                If MainFeature.Type = 1 And _
                Block.Direction = MainFeature.Direction And _
                Bioinformatics.IsFeatureInBlock(MainFeature, Block, ) Then

                    Select Case Block.Direction
                        Case 1
                            ResultTablePlus.Rows.Add(Block.TAG, MainFeature.TAG, MainFeature.Name, MainFeature.Direction)
                        Case 2
                            ResultTableMinus.Rows.Add(Block.TAG, MainFeature.TAG, MainFeature.Name, MainFeature.Direction)
                    End Select
                End If
            Next
        Next

        Dim TotalOutputFile As New IO.FileStream(strFileName & "- total genes in intervals increased.txt", IO.FileMode.Create)
        Dim TotalWriter As New IO.StreamWriter(TotalOutputFile)

        For Each Row As DataRow In ResultTablePlus.Rows
            TotalWriter.WriteLine(Row.Item(0) & Chr(9) & Row.Item(1) & Chr(9) & Row.Item(2) & Chr(9) & Row.Item(3))
        Next

        For Each Row As DataRow In ResultTableMinus.Rows
            TotalWriter.WriteLine(Row.Item(0) & Chr(9) & Row.Item(1) & Chr(9) & Row.Item(2) & Chr(9) & Row.Item(3))
        Next

        TotalWriter.Close()
        TotalOutputFile.Close()
        TotalWriter.Dispose()
        TotalOutputFile.Dispose()

        Dim FilteredOutputFile As New IO.FileStream(strFileName & "- not first genes in intervals increased.txt", IO.FileMode.Create)
        Dim FilteredWriter As New IO.StreamWriter(FilteredOutputFile)


        For i = 1 To ResultTablePlus.Rows.Count - 1 'Now scan in plus direction
            If ResultTablePlus.Rows(i).Item(0) = ResultTablePlus.Rows(i - 1).Item(0) Then 'Interval continued
                FilteredWriter.WriteLine(ResultTablePlus.Rows(i).Item(0) & Chr(9) & ResultTablePlus.Rows(i).Item(1) & Chr(9) & ResultTablePlus.Rows(i).Item(2) & Chr(9) & ResultTablePlus.Rows(i).Item(3))
            End If
        Next

        For i = ResultTableMinus.Rows.Count - 2 To 0 Step -1 'Now scan in minus direction
            If ResultTableMinus.Rows(i).Item(0) = ResultTableMinus.Rows(i + 1).Item(0) Then
                FilteredWriter.WriteLine(ResultTableMinus.Rows(i).Item(0) & Chr(9) & ResultTableMinus.Rows(i).Item(1) & Chr(9) & ResultTableMinus.Rows(i).Item(2) & Chr(9) & ResultTableMinus.Rows(i).Item(3))
            End If
        Next

        FilteredWriter.Close()
        FilteredOutputFile.Close()
        FilteredWriter.Dispose()
        FilteredOutputFile.Dispose()


    End Sub

    Private Sub BlocksDifexpressionButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlocksDifexpressionButton.Click

        Dim GroupList As New List(Of String)
        Dim Found As Boolean = False
        For Each Holder As PositionalValuesHolder In listPositionalValues
            Found = False

            For Each Group As String In GroupList
                If Group = Holder.Group Then
                    Found = True
                    Exit For
                End If
            Next

            If Not Found Then
                GroupList.Add(Holder.Group)
            End If
        Next






        Dim Annotation As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, strMainFeaturesListName)


        Dim Steps_Plus As New List(Of CoverageStep)
        Dim Steps_Minus As New List(Of CoverageStep)


        Dim TotalValues As New List(Of Integer)
        Dim ScaleFactors As New List(Of Single)
        Dim LocalSum As Integer = 0


        For Each Group As String In GroupList
            LocalSum = 0

            For i = 0 To listPositionalValues.Count - 1
                If listPositionalValues(i).Group = Group Then
                    LocalSum += Bioinformatics.GetCodingCoverage_SingleStrand(listPositionalValues(i).Positional_Values, Annotation.FeaturesList)
                End If
            Next i

            TotalValues.Add(LocalSum)

        Next Group


        Dim MaxCov As Integer = 0
        For Each Value As Integer In TotalValues
            If Value > MaxCov Then
                MaxCov = Value
            End If
        Next


        For i = 0 To TotalValues.Count - 1
            ScaleFactors.Add(MaxCov / TotalValues(i))
        Next



        Dim GroupCounter As Integer = 0

        For Each Group As String In GroupList

            Dim PlusCount As Integer = 0
            Dim MinusCount As Integer = 0

            For i = 0 To listPositionalValues.Count - 1
                If listPositionalValues(i).Group = Group Then
                    Select Case listPositionalValues(i).Strand
                        Case 1
                            PlusCount += 1
                        Case 2
                            MinusCount += 1
                    End Select
                End If
            Next i

            Dim CovListArrayPlus(PlusCount - 1) As List(Of Integer)
            Dim CovListArrayMinus(MinusCount - 1) As List(Of Integer)

            PlusCount = 0
            MinusCount = 0

            For i = 0 To listPositionalValues.Count - 1
                If listPositionalValues(i).Group = Group Then
                    Select Case listPositionalValues(i).Strand
                        Case 1
                            CovListArrayPlus(PlusCount) = listPositionalValues(i).Positional_Values
                            PlusCount += 1
                        Case 2
                            'We reverse minus list
                            CovListArrayMinus(MinusCount) = listPositionalValues(i).Positional_Values
                            MinusCount += 1
                    End Select
                End If
            Next i



            Dim IntegratedCoveragePlus As List(Of Integer) = Nothing
            Dim IntegratedCoverageMinus As List(Of Integer) = Nothing

            IntegratedCoveragePlus = Bioinformatics.ScaleLibrary_Int(Bioinformatics.SumIntLists(CovListArrayPlus), ScaleFactors(GroupCounter))
            IntegratedCoverageMinus = Bioinformatics.ScaleLibrary_Int(Bioinformatics.SumIntLists(CovListArrayMinus), ScaleFactors(GroupCounter))

            Dim NewHolder As QuantBlockHolder = Bioinformatics.CalculateValuesForIntervals(listIntegratedValues(0), IntegratedCoveragePlus, IntegratedCoverageMinus, Group, 1000000000)
            listIntegratedValues.Add(NewHolder)

            IntervalsListView.Items.Add(NewHolder.Name)
            IntervalsListView.Items(IntervalsListView.Items.Count - 1).Checked = True
            IntervalsListView.Items(IntervalsListView.Items.Count - 1).ForeColor = listIntegratedValues(0).BlocksList(0).Draw_Color


            GroupCounter += 1
        Next Group



    End Sub

    Private Sub IntervalMarkTableButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IntervalMarkTableButton.Click
        Dim NormalizedCoverage As List(Of PositionalValuesHolder) = Bioinformatics.NormalizeCoverageByCDS(listPositionalValues, cntFeaturesGroupsList(0).FeaturesList)

        MsgBox(NormalizedCoverage.Count)

        For Each Holder As PositionalValuesHolder In NormalizedCoverage
            Dim NormStream As New IO.FileStream(strFileName & Holder.Holder_Name & "-norm", IO.FileMode.Create)
            Dim NormWriter As New IO.StreamWriter(NormStream)

            For Each pos As Single In Holder.Log_Values
                NormWriter.WriteLine(pos)
            Next


            NormWriter.Close()
            NormStream.Close()
            NormWriter.Dispose()
            NormStream.Dispose()
        Next

        MsgBox("Done!")

        Dim ResultTable As DataTable = Bioinformatics.CreateAnnotationTable(NormalizedCoverage, listIntegratedValues(0).BlocksList)

        Dim TableStream As New IO.FileStream(strFileName & "-interval summary", IO.FileMode.Create)
        Dim TableWriter As New IO.StreamWriter(TableStream)

        Dim ResultString As String = ""

        For i = 0 To ResultTable.Columns.Count - 1
            ResultString &= ResultTable.Columns(i).ColumnName & Chr(9)
        Next
        TableWriter.WriteLine(ResultString)

        For Each Row As DataRow In ResultTable.Rows
            ResultString = ""
            For i = 0 To ResultTable.Columns.Count - 1
                ResultString &= Row.Item(i) & Chr(9)
            Next
            TableWriter.WriteLine(ResultString)
        Next

        TableWriter.Close()
        TableStream.Close()
        TableWriter.Dispose()
        TableStream.Dispose()
    End Sub

    Public Sub GetTerminatorsStatistics()

        For Each BlockHolder As QuantBlockHolder In listIntegratedValues
            Dim TermTable As DataTable = Bioinformatics.GetTerminatorsEfficiency(BlockHolder, cntFeaturesGroupsList(0).FeaturesList)
            Dim FS As New IO.FileStream(strFileName & " - " & BlockHolder.Name & "-term report.txt", IO.FileMode.Create)
            Dim Writer As New IO.StreamWriter(FS)

            Dim WriteString As String = ""
            For Each Col As DataColumn In TermTable.Columns
                WriteString &= Col.ColumnName & Chr(9)
            Next
            Writer.WriteLine(WriteString)

            For Each Row As DataRow In TermTable.Rows
                WriteString = ""
                For i = 0 To TermTable.Columns.Count - 1
                    WriteString &= Row.Item(i) & Chr(9)
                Next
                Writer.WriteLine(WriteString)
            Next

            Writer.Close()
            FS.Close()
            Writer.Dispose()
            FS.Dispose()
        Next

    End Sub

    Public Sub GetTerminatorsPseudocounts()
        For i = 0 To listIntegratedValues.Count - 1
            Bioinformatics.SortCoverageBlocks(listIntegratedValues(i))

            Dim Blocks_Plus As New List(Of QuantitationBlock)
            Dim Blocks_Minus As New List(Of QuantitationBlock)

            For Each Block As QuantitationBlock In listIntegratedValues(i).BlocksList
                Select Case Block.Direction
                    Case 1
                        Blocks_Plus.Add(Block)
                    Case 2
                        Blocks_Minus.Add(Block)
                End Select
            Next

            Dim PseudoCountTable As New DataTable
            PseudoCountTable.Columns.Add("PrevBlock")
            PseudoCountTable.Columns.Add("NextBlock")
            PseudoCountTable.Columns.Add("PrevCount")
            PseudoCountTable.Columns.Add("NextCount")


            For BlockPos = 1 To Blocks_Plus.Count - 1
                PseudoCountTable.Rows.Add(Blocks_Plus(BlockPos - 1).TAG, _
                                          Blocks_Plus(BlockPos).TAG, _
                                          Blocks_Plus(BlockPos - 1).Value, _
                                          Blocks_Plus(BlockPos).Value _
                                          )
            Next

            For BlockPos = Blocks_Minus.Count - 2 To 0 Step -1
                PseudoCountTable.Rows.Add(Blocks_Minus(BlockPos + 1).TAG, _
                                              Blocks_Minus(BlockPos).TAG, _
                                              Blocks_Minus(BlockPos + 1).Value, _
                                              Blocks_Minus(BlockPos).Value _
                                              )

            Next


            Dim FS As New IO.FileStream(strFileName & " - " & listIntegratedValues(i).Name & "-pseudocount.txt", IO.FileMode.Create)
            Dim Writer As New IO.StreamWriter(FS)

            Dim WriteString As String = ""
            For Each Col As DataColumn In PseudoCountTable.Columns
                WriteString &= Col.ColumnName & Chr(9)
            Next
            Writer.WriteLine(WriteString)

            For Each Row As DataRow In PseudoCountTable.Rows
                WriteString = ""
                For j = 0 To PseudoCountTable.Columns.Count - 1
                    WriteString &= Row.Item(j) & Chr(9)
                Next j
                Writer.WriteLine(WriteString)
            Next

            Writer.Close()
            FS.Close()
            Writer.Dispose()
            FS.Dispose()


        Next i


    End Sub




    Public Sub GetExtraFeatures()
        If Master.OpenFileDialog.ShowDialog = DialogResult.OK Then
            Dim ImportedAnnotation As List(Of Genome_Feature) = DataIO.ParseGBAnnotation(Master.OpenFileDialog.FileName)
            Dim ExtraList As New List(Of Genome_Feature)



            Dim Found As Boolean = False

            For Each ImportedFeature As Genome_Feature In ImportedAnnotation

                Found = False

                For Each MainFeature As Genome_Feature In cntFeaturesGroupsList(0).FeaturesList
                    If ImportedFeature.TAG = MainFeature.TAG Then
                        Found = True
                        Exit For
                    End If
                Next


                If Not Found Then
                    ExtraList.Add(ImportedFeature)
                End If

            Next

            Dim NewGroup As New FeaturesAssembly
            NewGroup.Visible = True
            NewGroup.AssemblyName = "ExtraFeatures"
            NewGroup.FeaturesList = ExtraList
            cntFeaturesGroupsList.Add(NewGroup)

            RefreshAssemblyList()
            DisplayFeatures()

        End If
    End Sub


    Private Sub FindProbesForArrayToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindProbesForArrayToolStripMenuItem.Click
        If Not IsNothing(cntrlSelected_Feature) Then
            Dim CurrentGroup As FeaturesAssembly = DataIO.GetCurrentGroup(cntFeaturesGroupsList, cntrlSelected_Feature.Group)
            Bioinformatics.FindProbesForGene(strGenomeSequence, CurrentGroup.FeaturesList, cntrlSelected_Feature.TAG, 60, -65, 2, -3, , , 10, , )
        End If

    End Sub


End Class
