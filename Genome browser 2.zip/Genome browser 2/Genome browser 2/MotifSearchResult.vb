﻿Public Class MotifSearchResult
    Private ForHits As New List(Of K_Word_Weighted)
    Private RevHits As New List(Of K_Word_Weighted)
    Private MyPWM As New PWM
    Private strName As String

    Public Property For_Hits() As List(Of K_Word_Weighted)
        Get
            For_Hits = ForHits
        End Get
        Set(ByVal value As List(Of K_Word_Weighted))
            ForHits = value
        End Set
    End Property

    Public Property Rev_Hits() As List(Of K_Word_Weighted)
        Get
            Rev_Hits = RevHits
        End Get
        Set(ByVal value As List(Of K_Word_Weighted))
            RevHits = value
        End Set
    End Property

    Public Property Target_PWM() As PWM
        Get
            Target_PWM = MyPWM
        End Get
        Set(ByVal value As PWM)
            MyPWM = value
        End Set
    End Property

    Public Property Name() As String
        Get
            Name = strName
        End Get
        Set(ByVal value As String)
            strName = value
        End Set
    End Property

End Class
