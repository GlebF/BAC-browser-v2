﻿Public Class PromoterPowerScanData
    Private listForData As New List(Of K_Word_WW)
    Private listRevData As New List(Of K_Word_WW)

    Public Property ForData() As List(Of K_Word_WW)
        Get
            ForData = listForData
        End Get
        Set(ByVal value As List(Of K_Word_WW))
            listForData = value
        End Set
    End Property

    Public Property RevData() As List(Of K_Word_WW)
        Get
            RevData = listRevData
        End Get
        Set(ByVal value As List(Of K_Word_WW))
            listRevData = value
        End Set
    End Property



End Class
