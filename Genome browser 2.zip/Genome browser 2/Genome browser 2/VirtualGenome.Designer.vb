﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class VirtualGenome
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(VirtualGenome))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.ControlToolStrip = New System.Windows.Forms.ToolStrip
        Me.RefreshButton = New System.Windows.Forms.ToolStripButton
        Me.ZoomInButton = New System.Windows.Forms.ToolStripButton
        Me.ZoomOutButton = New System.Windows.Forms.ToolStripButton
        Me.GridButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSplitButton1 = New System.Windows.Forms.ToolStripSplitButton
        Me.SimplifiedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FullToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.CheckButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel
        Me.TextSizeComboBox = New System.Windows.Forms.ToolStripComboBox
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel
        Me.AxisComboBox = New System.Windows.Forms.ToolStripComboBox
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripLabel3 = New System.Windows.Forms.ToolStripLabel
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox
        Me.DrawImageButton = New System.Windows.Forms.ToolStripButton
        Me.FeaturesDataGridView = New System.Windows.Forms.DataGridView
        Me.ShowFeatureCol = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.ShowFeatureLabelCol = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.FeatureNameCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.FeatureIDCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.StartCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.EndCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DirCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TypeCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ColorCol = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.StyleCol = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.FeaturesTabPage = New System.Windows.Forms.TabPage
        Me.FeaturesTableToolStrip = New System.Windows.Forms.ToolStrip
        Me.DeleteSelectedRowsButton = New System.Windows.Forms.ToolStripButton
        Me.RestrictTabPage = New System.Windows.Forms.TabPage
        Me.DetectButton = New System.Windows.Forms.Button
        Me.ClearButton = New System.Windows.Forms.Button
        Me.DetectorListBox = New System.Windows.Forms.CheckedListBox
        Me.ViewPanel = New System.Windows.Forms.Panel
        Me.MinOverlapAngleTextBox = New System.Windows.Forms.ToolStripTextBox
        Me.ToolStripLabel4 = New System.Windows.Forms.ToolStripLabel
        Me.ControlToolStrip.SuspendLayout()
        CType(Me.FeaturesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.FeaturesTabPage.SuspendLayout()
        Me.FeaturesTableToolStrip.SuspendLayout()
        Me.RestrictTabPage.SuspendLayout()
        Me.SuspendLayout()
        '
        'ControlToolStrip
        '
        Me.ControlToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RefreshButton, Me.ZoomInButton, Me.ZoomOutButton, Me.GridButton, Me.ToolStripSplitButton1, Me.ToolStripSeparator1, Me.CheckButton, Me.ToolStripSeparator2, Me.ToolStripLabel4, Me.MinOverlapAngleTextBox, Me.ToolStripLabel1, Me.TextSizeComboBox, Me.ToolStripLabel2, Me.AxisComboBox, Me.ToolStripSeparator3, Me.ToolStripLabel3, Me.ToolStripTextBox1, Me.DrawImageButton})
        Me.ControlToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.ControlToolStrip.Name = "ControlToolStrip"
        Me.ControlToolStrip.Size = New System.Drawing.Size(1000, 25)
        Me.ControlToolStrip.TabIndex = 2
        Me.ControlToolStrip.Text = "ToolStrip1"
        '
        'RefreshButton
        '
        Me.RefreshButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.RefreshButton.Image = CType(resources.GetObject("RefreshButton.Image"), System.Drawing.Image)
        Me.RefreshButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.RefreshButton.Name = "RefreshButton"
        Me.RefreshButton.Size = New System.Drawing.Size(23, 22)
        Me.RefreshButton.Text = "Refresh"
        '
        'ZoomInButton
        '
        Me.ZoomInButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ZoomInButton.Image = CType(resources.GetObject("ZoomInButton.Image"), System.Drawing.Image)
        Me.ZoomInButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ZoomInButton.Name = "ZoomInButton"
        Me.ZoomInButton.Size = New System.Drawing.Size(23, 22)
        Me.ZoomInButton.Text = "Zoom in"
        '
        'ZoomOutButton
        '
        Me.ZoomOutButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ZoomOutButton.Image = CType(resources.GetObject("ZoomOutButton.Image"), System.Drawing.Image)
        Me.ZoomOutButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ZoomOutButton.Name = "ZoomOutButton"
        Me.ZoomOutButton.Size = New System.Drawing.Size(23, 22)
        Me.ZoomOutButton.Text = "Zoom out"
        '
        'GridButton
        '
        Me.GridButton.Checked = True
        Me.GridButton.CheckOnClick = True
        Me.GridButton.CheckState = System.Windows.Forms.CheckState.Checked
        Me.GridButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.GridButton.Image = CType(resources.GetObject("GridButton.Image"), System.Drawing.Image)
        Me.GridButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.GridButton.Name = "GridButton"
        Me.GridButton.Size = New System.Drawing.Size(23, 22)
        Me.GridButton.Text = "Grid"
        '
        'ToolStripSplitButton1
        '
        Me.ToolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripSplitButton1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SimplifiedToolStripMenuItem, Me.FullToolStripMenuItem})
        Me.ToolStripSplitButton1.Image = CType(resources.GetObject("ToolStripSplitButton1.Image"), System.Drawing.Image)
        Me.ToolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripSplitButton1.Name = "ToolStripSplitButton1"
        Me.ToolStripSplitButton1.Size = New System.Drawing.Size(32, 22)
        Me.ToolStripSplitButton1.Text = "View"
        '
        'SimplifiedToolStripMenuItem
        '
        Me.SimplifiedToolStripMenuItem.Checked = True
        Me.SimplifiedToolStripMenuItem.CheckOnClick = True
        Me.SimplifiedToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.SimplifiedToolStripMenuItem.Name = "SimplifiedToolStripMenuItem"
        Me.SimplifiedToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.SimplifiedToolStripMenuItem.Text = "Simplified"
        '
        'FullToolStripMenuItem
        '
        Me.FullToolStripMenuItem.CheckOnClick = True
        Me.FullToolStripMenuItem.Name = "FullToolStripMenuItem"
        Me.FullToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.FullToolStripMenuItem.Text = "Full"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'CheckButton
        '
        Me.CheckButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CheckButton.Image = CType(resources.GetObject("CheckButton.Image"), System.Drawing.Image)
        Me.CheckButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CheckButton.Name = "CheckButton"
        Me.CheckButton.Size = New System.Drawing.Size(23, 22)
        Me.CheckButton.Text = "Check all"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(60, 22)
        Me.ToolStripLabel1.Text = "Label text:"
        '
        'TextSizeComboBox
        '
        Me.TextSizeComboBox.Items.AddRange(New Object() {"8", "10", "12", "14", "16", "18", "20"})
        Me.TextSizeComboBox.Name = "TextSizeComboBox"
        Me.TextSizeComboBox.Size = New System.Drawing.Size(75, 25)
        Me.TextSizeComboBox.Text = "8"
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(53, 22)
        Me.ToolStripLabel2.Text = "Axis text:"
        '
        'AxisComboBox
        '
        Me.AxisComboBox.Items.AddRange(New Object() {"8", "10", "12", "14", "16", "18", "20"})
        Me.AxisComboBox.Name = "AxisComboBox"
        Me.AxisComboBox.Size = New System.Drawing.Size(75, 25)
        Me.AxisComboBox.Text = "8"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel3
        '
        Me.ToolStripLabel3.Name = "ToolStripLabel3"
        Me.ToolStripLabel3.Size = New System.Drawing.Size(82, 22)
        Me.ToolStripLabel3.Text = "Export quality:"
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(25, 25)
        Me.ToolStripTextBox1.Text = "4"
        '
        'DrawImageButton
        '
        Me.DrawImageButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DrawImageButton.Image = CType(resources.GetObject("DrawImageButton.Image"), System.Drawing.Image)
        Me.DrawImageButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DrawImageButton.Name = "DrawImageButton"
        Me.DrawImageButton.Size = New System.Drawing.Size(23, 22)
        Me.DrawImageButton.ToolTipText = "Export image"
        '
        'FeaturesDataGridView
        '
        Me.FeaturesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.FeaturesDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ShowFeatureCol, Me.ShowFeatureLabelCol, Me.FeatureNameCol, Me.FeatureIDCol, Me.StartCol, Me.EndCol, Me.DirCol, Me.TypeCol, Me.ColorCol, Me.StyleCol})
        Me.FeaturesDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FeaturesDataGridView.Location = New System.Drawing.Point(3, 28)
        Me.FeaturesDataGridView.Name = "FeaturesDataGridView"
        Me.FeaturesDataGridView.Size = New System.Drawing.Size(377, 318)
        Me.FeaturesDataGridView.TabIndex = 0
        '
        'ShowFeatureCol
        '
        Me.ShowFeatureCol.HeaderText = ""
        Me.ShowFeatureCol.Name = "ShowFeatureCol"
        Me.ShowFeatureCol.Width = 30
        '
        'ShowFeatureLabelCol
        '
        Me.ShowFeatureLabelCol.HeaderText = ""
        Me.ShowFeatureLabelCol.Name = "ShowFeatureLabelCol"
        Me.ShowFeatureLabelCol.Width = 30
        '
        'FeatureNameCol
        '
        Me.FeatureNameCol.HeaderText = "Name"
        Me.FeatureNameCol.Name = "FeatureNameCol"
        Me.FeatureNameCol.Width = 60
        '
        'FeatureIDCol
        '
        Me.FeatureIDCol.HeaderText = "Locus Tag"
        Me.FeatureIDCol.Name = "FeatureIDCol"
        Me.FeatureIDCol.Width = 60
        '
        'StartCol
        '
        Me.StartCol.HeaderText = "Start"
        Me.StartCol.Name = "StartCol"
        Me.StartCol.Width = 50
        '
        'EndCol
        '
        Me.EndCol.HeaderText = "End"
        Me.EndCol.Name = "EndCol"
        Me.EndCol.Width = 50
        '
        'DirCol
        '
        Me.DirCol.HeaderText = "Direction"
        Me.DirCol.Name = "DirCol"
        Me.DirCol.Width = 50
        '
        'TypeCol
        '
        Me.TypeCol.HeaderText = "Type"
        Me.TypeCol.Name = "TypeCol"
        Me.TypeCol.Width = 50
        '
        'ColorCol
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        Me.ColorCol.DefaultCellStyle = DataGridViewCellStyle1
        Me.ColorCol.HeaderText = "Color"
        Me.ColorCol.Name = "ColorCol"
        Me.ColorCol.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ColorCol.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ColorCol.Width = 50
        '
        'StyleCol
        '
        Me.StyleCol.HeaderText = "Style"
        Me.StyleCol.Items.AddRange(New Object() {"Locus", "TSS", "Terminator"})
        Me.StyleCol.Name = "StyleCol"
        Me.StyleCol.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.StyleCol.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.StyleCol.Width = 70
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 25)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.TabControl1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.AutoScroll = True
        Me.SplitContainer1.Panel2.Controls.Add(Me.ViewPanel)
        Me.SplitContainer1.Size = New System.Drawing.Size(1000, 375)
        Me.SplitContainer1.SplitterDistance = 391
        Me.SplitContainer1.TabIndex = 3
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.FeaturesTabPage)
        Me.TabControl1.Controls.Add(Me.RestrictTabPage)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(391, 375)
        Me.TabControl1.TabIndex = 1
        '
        'FeaturesTabPage
        '
        Me.FeaturesTabPage.Controls.Add(Me.FeaturesDataGridView)
        Me.FeaturesTabPage.Controls.Add(Me.FeaturesTableToolStrip)
        Me.FeaturesTabPage.Location = New System.Drawing.Point(4, 22)
        Me.FeaturesTabPage.Name = "FeaturesTabPage"
        Me.FeaturesTabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.FeaturesTabPage.Size = New System.Drawing.Size(383, 349)
        Me.FeaturesTabPage.TabIndex = 0
        Me.FeaturesTabPage.Text = "Features"
        Me.FeaturesTabPage.UseVisualStyleBackColor = True
        '
        'FeaturesTableToolStrip
        '
        Me.FeaturesTableToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DeleteSelectedRowsButton})
        Me.FeaturesTableToolStrip.Location = New System.Drawing.Point(3, 3)
        Me.FeaturesTableToolStrip.Name = "FeaturesTableToolStrip"
        Me.FeaturesTableToolStrip.Size = New System.Drawing.Size(377, 25)
        Me.FeaturesTableToolStrip.TabIndex = 1
        Me.FeaturesTableToolStrip.Text = "ToolStrip1"
        '
        'DeleteSelectedRowsButton
        '
        Me.DeleteSelectedRowsButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DeleteSelectedRowsButton.Enabled = False
        Me.DeleteSelectedRowsButton.Image = CType(resources.GetObject("DeleteSelectedRowsButton.Image"), System.Drawing.Image)
        Me.DeleteSelectedRowsButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DeleteSelectedRowsButton.Name = "DeleteSelectedRowsButton"
        Me.DeleteSelectedRowsButton.Size = New System.Drawing.Size(23, 22)
        Me.DeleteSelectedRowsButton.Text = "ToolStripButton1"
        Me.DeleteSelectedRowsButton.ToolTipText = "Delete selected rows"
        '
        'RestrictTabPage
        '
        Me.RestrictTabPage.Controls.Add(Me.DetectButton)
        Me.RestrictTabPage.Controls.Add(Me.ClearButton)
        Me.RestrictTabPage.Controls.Add(Me.DetectorListBox)
        Me.RestrictTabPage.Location = New System.Drawing.Point(4, 22)
        Me.RestrictTabPage.Name = "RestrictTabPage"
        Me.RestrictTabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.RestrictTabPage.Size = New System.Drawing.Size(383, 349)
        Me.RestrictTabPage.TabIndex = 1
        Me.RestrictTabPage.Text = "Restrictases"
        Me.RestrictTabPage.UseVisualStyleBackColor = True
        '
        'DetectButton
        '
        Me.DetectButton.Location = New System.Drawing.Point(125, 196)
        Me.DetectButton.Name = "DetectButton"
        Me.DetectButton.Size = New System.Drawing.Size(50, 23)
        Me.DetectButton.TabIndex = 8
        Me.DetectButton.Text = "Find"
        Me.DetectButton.UseVisualStyleBackColor = True
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(6, 196)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(50, 23)
        Me.ClearButton.TabIndex = 7
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'DetectorListBox
        '
        Me.DetectorListBox.CheckOnClick = True
        Me.DetectorListBox.FormattingEnabled = True
        Me.DetectorListBox.Location = New System.Drawing.Point(6, 6)
        Me.DetectorListBox.Name = "DetectorListBox"
        Me.DetectorListBox.Size = New System.Drawing.Size(169, 184)
        Me.DetectorListBox.TabIndex = 6
        '
        'ViewPanel
        '
        Me.ViewPanel.BackColor = System.Drawing.Color.White
        Me.ViewPanel.Location = New System.Drawing.Point(3, 3)
        Me.ViewPanel.Name = "ViewPanel"
        Me.ViewPanel.Size = New System.Drawing.Size(1000, 1000)
        Me.ViewPanel.TabIndex = 0
        '
        'MinOverlapAngleTextBox
        '
        Me.MinOverlapAngleTextBox.Name = "MinOverlapAngleTextBox"
        Me.MinOverlapAngleTextBox.Size = New System.Drawing.Size(50, 25)
        '
        'ToolStripLabel4
        '
        Me.ToolStripLabel4.Name = "ToolStripLabel4"
        Me.ToolStripLabel4.Size = New System.Drawing.Size(73, 22)
        Me.ToolStripLabel4.Text = "Min overlap:"
        '
        'VirtualGenome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.ControlToolStrip)
        Me.Name = "VirtualGenome"
        Me.Size = New System.Drawing.Size(1000, 400)
        Me.ControlToolStrip.ResumeLayout(False)
        Me.ControlToolStrip.PerformLayout()
        CType(Me.FeaturesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.FeaturesTabPage.ResumeLayout(False)
        Me.FeaturesTabPage.PerformLayout()
        Me.FeaturesTableToolStrip.ResumeLayout(False)
        Me.FeaturesTableToolStrip.PerformLayout()
        Me.RestrictTabPage.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ControlToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents RefreshButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ZoomInButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ZoomOutButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents GridButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CheckButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents FeaturesDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents ViewPanel As System.Windows.Forms.Panel
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DrawImageButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSplitButton1 As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents SimplifiedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FullToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents TextSizeComboBox As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripLabel2 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents AxisComboBox As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ShowFeatureCol As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents ShowFeatureLabelCol As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents FeatureNameCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FeatureIDCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StartCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EndCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DirCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TypeCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ColorCol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StyleCol As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel3 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripTextBox1 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents FeaturesTabPage As System.Windows.Forms.TabPage
    Friend WithEvents FeaturesTableToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents RestrictTabPage As System.Windows.Forms.TabPage
    Friend WithEvents DetectButton As System.Windows.Forms.Button
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents DetectorListBox As System.Windows.Forms.CheckedListBox
    Friend WithEvents DeleteSelectedRowsButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel4 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents MinOverlapAngleTextBox As System.Windows.Forms.ToolStripTextBox

End Class
