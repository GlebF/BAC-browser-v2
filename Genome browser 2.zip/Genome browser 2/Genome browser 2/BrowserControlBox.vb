﻿Public Class BrowserControlBox

    Private cMyParent As Genome_Viewer
    Private SearchSeqList As New DataTable

    Public Property MyParent() As Genome_Viewer
        Get
            MyParent = cMyParent
        End Get
        Set(ByVal value As Genome_Viewer)
            cMyParent = value
        End Set
    End Property

    Public Sub ClearCache()
        SearchSeqList.Clear()
    End Sub

    Private Sub GridCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GridCheckBox.CheckedChanged
        If Not IsNothing(cMyParent) Then
            cMyParent.DrawGrid = GridCheckBox.Checked
        End If

    End Sub


    Private Sub CodingCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CodingCheckBox.CheckedChanged, SiteCheckBox.CheckedChanged, NCCheckBox.CheckedChanged, RepCheckBox.CheckedChanged, TranscriptionCheckBox.CheckedChanged, UserCheckBox.CheckedChanged
        If Not IsNothing(cMyParent) Then
            cMyParent.AssignFeaturesVisibility()
            cMyParent.DisplayFeatures()
        End If

    End Sub

    Private Sub OperonsCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OperonsCheckBox.CheckedChanged
        If Not IsNothing(cMyParent) Then
            cMyParent.AssignFeaturesVisibility()
            cMyParent.DisplayFeatures()
        End If
    End Sub


    Private Sub TransComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TransComboBox.SelectedIndexChanged
        MyParent.Genetic_Code = TransComboBox.Text.Split("-")(0)

    End Sub

    Public Sub LoadDetectorItems()
        DetectorListBox.Items.Clear()
        For Each Row As DataRow In Master.SiteSeqList.Rows
            DetectorListBox.Items.Add(Row.Item(0))
        Next
    End Sub

    Private Sub BrowserControlBox_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SearchSeqList.Columns.Clear()
        SearchSeqList.Columns.Add("Name")
        SearchSeqList.Columns.Add("Seq")
        LoadDetectorItems()

    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        ClearCache()
        cMyParent.Site_Detector.Clear()
        LoadDetectorItems()

        If cMyParent.Sequence_Markers.Count = 0 Then
            MarckupOffRadioButton.Checked = True
        End If

        MyParent.DisplayFeatures()

    End Sub

    Public Sub DetectRestrictionSites()
        Dim CacheTable As New DataTable
        CacheTable.Columns.Add("Name")
        CacheTable.Columns.Add("Seq")
        Dim DeletedItems As New DataTable 'Items to be removed from detector
        DeletedItems = CacheTable.Clone
        Dim NewItems As New DataTable 'Items to be added to detector
        NewItems = CacheTable.Clone

        For Each Row As DataRow In Master.SiteSeqList.Rows
            For i = 0 To DetectorListBox.CheckedItems.Count - 1
                If Row.Item(0) = DetectorListBox.CheckedItems(i) Then
                    CacheTable.Rows.Add(Row.Item(0), Row.Item(1))
                End If
            Next
        Next

        Dim Found As Boolean = False
        For Each MasterRow As DataRow In SearchSeqList.Rows
            Found = False
            For Each Row As DataRow In CacheTable.Rows
                If Row.Item(0) = MasterRow.Item(0) Then
                    Found = True
                End If
            Next
            If Not Found Then
                DeletedItems.Rows.Add(MasterRow.Item(0), MasterRow.Item(1))
            End If
        Next

        For Each CachedRow As DataRow In CacheTable.Rows
            Found = False
            For Each Row As DataRow In SearchSeqList.Rows
                If Row.Item(0) = CachedRow.Item(0) Then
                    Found = True
                End If
            Next
            If Not Found Then
                NewItems.Rows.Add(CachedRow.Item(0), CachedRow.Item(1))
            End If
        Next

        'Remember new data
        SearchSeqList.Rows.Clear()
        For Each CachedRow As DataRow In CacheTable.Rows
            SearchSeqList.Rows.Add(CachedRow.Item(0), CachedRow.Item(1))
        Next

        For Each DeletedItem As DataRow In DeletedItems.Rows
            For i = cMyParent.Site_Detector.Count - 1 To 0 Step -1
                If cMyParent.Site_Detector(i).Name = DeletedItem.Item(0).ToString Then
                    cMyParent.Site_Detector.RemoveAt(i)
                End If
            Next
        Next

        Dim ForCoordList As List(Of CoordHit) = Nothing
        Dim RevCoordList As List(Of CoordHit) = Nothing


        Dim ClearedSequence As String = ""
        Dim FastSearch As Boolean = False
        Dim Counter As Integer = 0
        Dim CutPos As Integer = 0
        Dim UseCut As Boolean = False

        SystemProgressBarBox.Show()
        SystemProgressBarBox.Focus()
        SystemProgressBarBox.MasterProgressBar.Maximum = NewItems.Rows.Count
        SystemProgressBarBox.MasterProgressBar.Value = 0
        SystemProgressBarBox.StatusLabel.Text = "Searching restriction sites..."
        SystemProgressBarBox.StatusLabel.Refresh()

        For Each NewItem As DataRow In NewItems.Rows
            If NewItem.Item(1).ToString.Contains(Chr(94)) Then
                UseCut = True
                CutPos = NewItem.Item(1).ToString.IndexOf(Chr(94))
            Else
                UseCut = False
            End If

            ClearedSequence = NewItem.Item(1)
            ClearedSequence = ClearedSequence.Replace(Chr(94), vbNullString)
            ClearedSequence = ClearedSequence.Replace(Chr(42), vbNullString)

            ForCoordList = Bioinformatics.UngappedSequenceSearch(cMyParent.Genome_Sequence, ClearedSequence, 1)
            RevCoordList = Bioinformatics.UngappedSequenceSearch(cMyParent.Genome_Sequence, Bioinformatics.GetReverseComplement(ClearedSequence), 1)

            If Not IsNothing(ForCoordList) Then
                For Each Coord As CoordHit In ForCoordList
                    Dim NewSite As New Genome_Feature
                    NewSite.TAG = NewItem.Item(0) & "F" & Counter
                    NewSite.Name = NewItem.Item(0)
                    NewSite.AbsoluteStart = Coord.Position
                    NewSite.AbsoluteEnd = Coord.Position + ClearedSequence.Length - 1
                    NewSite.Direction = 1
                    NewSite.Type = 7
                    If UseCut Then
                        NewSite.UseReadList = True
                        NewSite.ReadList.Add(New ReadItem(CutPos, CutPos))
                    End If
                    MyParent.Site_Detector.Add(NewSite)
                Next
            End If

            If Not IsNothing(RevCoordList) Then
                For Each Coord As CoordHit In RevCoordList
                    Dim NewSite As New Genome_Feature
                    NewSite.TAG = NewItem.Item(0) & "R" & Counter
                    NewSite.Name = NewItem.Item(0)
                    NewSite.AbsoluteStart = Coord.Position
                    NewSite.AbsoluteEnd = Coord.Position + ClearedSequence.Length - 1
                    NewSite.Direction = 2
                    NewSite.Type = 7
                    If UseCut Then
                        NewSite.UseReadList = True
                        NewSite.ReadList.Add(New ReadItem(ClearedSequence.Length - CutPos, ClearedSequence.Length - CutPos))
                    End If
                    MyParent.Site_Detector.Add(NewSite)
                Next
            End If

            SystemProgressBarBox.MasterProgressBar.PerformStep()
            Counter += 1
        Next

        SystemProgressBarBox.Close()



        MyParent.DisplayFeatures()
    End Sub

    Private Sub DetectButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DetectButton.Click

        If DetectorListBox.CheckedItems.Count > 0 Then
            MyParent.SiteMarkupMode = True
            DetectRestrictionSites()
        Else
            MyParent.Site_Detector.Clear()

            If MyParent.Sequence_Markers.Count = 0 Then
                MarckupOffRadioButton.Checked = True
            End If

            MyParent.DisplayFeatures()
        End If

    End Sub


    Private Sub BackButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackButton.Click
        For i = 0 To DetectorListBox.Items.Count - 1
            DetectorListBox.SetItemChecked(i, False)
        Next

        For Each Row As DataRow In SearchSeqList.Rows
            For i = 0 To DetectorListBox.Items.Count - 1
                If DetectorListBox.Items(i).ToString = Row.Item(0) Then
                    DetectorListBox.SetItemChecked(i, True)
                End If
            Next
        Next

    End Sub

    Private Sub MarckupOffRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MarckupOffRadioButton.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.SiteMarkupMode = MarckupOnRadioButton.Checked
        End If
    End Sub

    Private Sub MarckupOnRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MarckupOnRadioButton.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.SiteMarkupMode = MarckupOnRadioButton.Checked
        End If
    End Sub

    Private Sub TopologyComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TopologyComboBox.SelectedIndexChanged
        Select Case TopologyComboBox.Text
            Case "Linear"
                MyParent.GenomeTopology = False
                MyParent.DisplayFeatures()
            Case "Circular"
                MyParent.GenomeTopology = True
                MyParent.DisplayFeatures()
        End Select



    End Sub

    Private Sub CommentTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommentTextBox.TextChanged
        cMyParent.Comment = CommentTextBox.Text
    End Sub

    Private Sub SkewOffRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SkewOffRadioButton.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.GraphPanel.Visible = SkewOnRadioButton.Checked
        End If
    End Sub

    Private Sub SkewOnRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SkewOnRadioButton.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.GraphPanel.Visible = SkewOnRadioButton.Checked
        End If
    End Sub

    Private Sub TranslationOffButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TranslationOffButton.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.TranslatePanel.Visible = TranslationOnButton.Checked
        End If
    End Sub

    Private Sub TranslationOnButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TranslationOnButton.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.TranslatePanel.Visible = TranslationOnButton.Checked
        End If
    End Sub

    Private Sub ColorCodeCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorCodeCheckBox.CheckedChanged
        MyParent.TranslationFullColor = ColorCodeCheckBox.Checked
        MyParent.DisplayFeatures()
    End Sub

    Private Sub F1CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F1CheckBox.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.DisplayFeatures()
        End If

    End Sub

    Private Sub F2CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F2CheckBox.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.DisplayFeatures()
        End If
    End Sub

    Private Sub F3CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F3CheckBox.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.DisplayFeatures()
        End If
    End Sub

    Private Sub R1CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles R1CheckBox.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.DisplayFeatures()
        End If
    End Sub

    Private Sub R2CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles R2CheckBox.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.DisplayFeatures()
        End If
    End Sub

    Private Sub R3CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles R3CheckBox.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.DisplayFeatures()
        End If
    End Sub

    Private Sub RefreshButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshButton.Click
        MyParent.UpdateSeqStat()
    End Sub

    Private Sub AuxOffButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AuxOffButton.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.GraphicsSplitContainer.Panel2Collapsed = AuxOffButton.Checked
        End If
    End Sub

    Private Sub AuxOnButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AuxOnButton.CheckedChanged
        If Not IsNothing(cMyParent) Then
            MyParent.GraphicsSplitContainer.Panel2Collapsed = AuxOffButton.Checked
        End If
    End Sub
End Class
