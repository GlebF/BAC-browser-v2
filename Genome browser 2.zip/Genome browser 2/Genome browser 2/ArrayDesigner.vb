﻿Public Class ArrayDesigner

    Public MyGenomeViewer As Genome_Viewer
   
    Private Sub GoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoButton.Click


        ' If Master.SaveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
        Dim DecimalFormat As System.Globalization.NumberFormatInfo = System.Globalization.CultureInfo.InstalledUICulture.NumberFormat.Clone
        'DecimalFormat.NumberDecimalSeparator = "."



        Dim FeaturesList As List(Of Genome_Feature) = Nothing

        For Each Group As FeaturesAssembly In MyGenomeViewer.Features_Groups_List
            If Group.AssemblyName = SourceComboBox.Text Then
                FeaturesList = Group.FeaturesList
            End If
        Next Group

        Dim ProbeLength As Integer = ProbeLengthTextBox.Text
        Dim ProbeDG As Single = Single.Parse(ProbeDGTextBox.Text, DecimalFormat)
        Dim ProbeDGSpan As Single = Single.Parse(ProbeDGRangeTextBox.Text, DecimalFormat)
        Dim MinSelfDG As Single = Single.Parse(ProbeSelfDGTextBox.Text, DecimalFormat)
        Dim XHybIdentity As Single = Single.Parse(XHybeTextBox.Text, DecimalFormat)
        Dim FinalProbesCount As Integer = FinalProbesNumberTextBox.Text
        Dim SearchProbesCount As Integer = SearchProbesNumberTextBox.Text
        Dim MinFeatureLength As Integer = MinFeatureLTextBox.Text
        Dim StructureT As Single = Single.Parse(StructureTTextBox.Text, DecimalFormat)


        Bioinformatics.FindProbesForGenome(MyGenomeViewer.Genome_Sequence, FeaturesList, ProbeLength, ProbeDG, ProbeDGSpan, MinSelfDG, XhybCheckBox.Checked, XHybIdentity, FinalProbesCount, SearchProbesCount, MinFeatureLength, StructureT, CDSOnlyCheckBox.Checked, ReportLabel)


        'Dim WriteStream As New IO.FileStream(Master.SaveFileDialog.FileName, IO.FileMode.Create)
        'Dim Writer As New IO.StreamWriter(WriteStream)

        'Writer.WriteLine("Probe" & Chr(9) & "Sequence")

        'For Each Probe As K_Word_Thermodynamics In ProbesList

        'Writer.WriteLine(Probe.SeqName & Chr(9) & Probe.Word_Text)

        'Next Probe



        'Writer.Close()
        'WriteStream.Close()
        'Writer.Dispose()
        'WriteStream.Dispose()

        ' End If


    End Sub

    Private Sub ArrayDesigner_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SourceComboBox.Items.Clear()
        For Each Group As FeaturesAssembly In MyGenomeViewer.Features_Groups_List
            SourceComboBox.Items.Add(Group.AssemblyName)
        Next Group
    End Sub
End Class