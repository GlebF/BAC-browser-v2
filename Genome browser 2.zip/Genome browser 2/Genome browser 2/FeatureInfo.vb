﻿Public Class FeatureInfo
    Private strFeatureName As String
    Private strFeatureID As String
    Private intFeatureStart As Integer
    Private intFeatureEnd As Integer
    Private sFeatureDirection As Short
    Private intFeatureType As Short
    Private strCol As String
    Private cFillColor As Color = Color.Red
    Private bShowFeature As Boolean = True
    Private bShowLabel As Boolean = True
    Private sDrawStyle As Short = 0

    Private sStartAngle As Single
    Private sEndAngle As Single
    Private intRadius As Integer



    Public Property StartAngle() As Single
        Get
            StartAngle = sStartAngle
        End Get
        Set(ByVal value As Single)
            sStartAngle = value
        End Set
    End Property

    Public Property EndAngle() As Single
        Get
            EndAngle = sEndAngle
        End Get
        Set(ByVal value As Single)
            sEndAngle = value
        End Set
    End Property

    Public Property Radius() As Integer
        Get
            Radius = intRadius
        End Get
        Set(ByVal value As Integer)
            intRadius = value
        End Set
    End Property

    Public Property FeatureDrawStyle() As Short
        Get
            FeatureDrawStyle = sDrawStyle
        End Get
        Set(ByVal value As Short)
            sDrawStyle = value
        End Set
    End Property

    Public Property ShowFeature() As Boolean
        Get
            ShowFeature = bShowFeature
        End Get
        Set(ByVal value As Boolean)
            bShowFeature = value
        End Set
    End Property

    Public Property ShowLabel() As Boolean
        Get
            ShowLabel = bShowLabel
        End Get
        Set(ByVal value As Boolean)
            bShowLabel = value
        End Set
    End Property

    Public Property FeatureID() As String
        Get
            FeatureID = strFeatureID
        End Get
        Set(ByVal value As String)
            strFeatureID = value
        End Set
    End Property

    Public Property FeatureStart() As Integer
        Get
            FeatureStart = intFeatureStart
        End Get
        Set(ByVal value As Integer)
            intFeatureStart = value
        End Set
    End Property

    Public Property FeatureEnd() As Integer
        Get
            FeatureEnd = intFeatureEnd
        End Get
        Set(ByVal value As Integer)
            intFeatureEnd = value
        End Set
    End Property

    Public Property FeatureType() As Integer
        Get
            FeatureType = intFeatureType
        End Get
        Set(ByVal value As Integer)
            intFeatureType = value
        End Set
    End Property

    Public Property FeatureName() As String
        Get
            FeatureName = strFeatureName
        End Get
        Set(ByVal value As String)
            strFeatureName = value
        End Set
    End Property

    Public Property FeatureOrientation() As Short
        Get
            FeatureOrientation = sFeatureDirection
        End Get
        Set(ByVal value As Short)
            sFeatureDirection = value
        End Set
    End Property

    Public Property FillColor() As Color
        Get
            FillColor = cFillColor
        End Get
        Set(ByVal value As Color)
            cFillColor = value
        End Set
    End Property

    Public Property FeatureColor() As String
        Get
            FeatureColor = strCol
        End Get
        Set(ByVal value As String)
            strCol = value
        End Set
    End Property


    Public Sub New(ByVal ShowMe As Boolean, ByVal ShowMyLabel As Boolean, ByVal FName As String, ByVal FID As String, _
                   ByVal FStart As Integer, ByVal FEnd As Integer, ByVal FDirection As Short, ByVal FType As Short, _
                   ByVal F_FillCol As Color, Optional ByVal F_DrawStyle As Short = 0)

        bShowFeature = ShowMe
        bShowLabel = ShowMyLabel
        strFeatureName = FName
        strFeatureID = FID
        intFeatureStart = FStart
        intFeatureEnd = FEnd
        sFeatureDirection = FDirection
        intFeatureType = FType
        cFillColor = F_FillCol
        sDrawStyle = F_DrawStyle

    End Sub
End Class
