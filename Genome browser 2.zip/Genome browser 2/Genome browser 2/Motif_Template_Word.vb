﻿Public Class Motif_Template_Word
    Private strWord As String
    Private intWordHitCount As Integer
    Private intSeqHitCount As Integer

    Public Property Word() As String
        Get
            Word = strWord
        End Get
        Set(ByVal value As String)
            strWord = value
        End Set
    End Property

    Public Property WordHitCount() As Integer
        Get
            WordHitCount = intWordHitCount
        End Get
        Set(ByVal value As Integer)
            intWordHitCount = value
        End Set
    End Property

    Public Property SeqHitCount() As Integer
        Get
            SeqHitCount = intSeqHitCount
        End Get
        Set(ByVal value As Integer)
            intSeqHitCount = value
        End Set
    End Property

End Class
