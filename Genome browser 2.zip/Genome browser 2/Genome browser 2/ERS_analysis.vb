﻿Public Class ERS_analysis
    Public MyViewer As Genome_Viewer
    Public SearchCount As Integer = 0


    Private Sub RefreshGroupsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshGroupsButton.Click
        AnalysisHolderListBox.Items.Clear()
        AllHoldersListBox.Items.Clear()

        Dim GroupList As New List(Of String)
        Dim Found As Boolean = False
        For Each Holder As PositionalValuesHolder In MyViewer.Positional_Values_Collection
            Found = False

            For Each Group As String In GroupList
                If Group = Holder.Group Then
                    Found = True
                    Exit For
                End If
            Next

            If Not Found Then
                GroupList.Add(Holder.Group)
            End If


        Next



        For Each Group As String In GroupList
            AllHoldersListBox.Items.Add(Group)
        Next
    End Sub

    Private Sub AllAddButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AllAddButton.Click
        For Each Item As String In AllHoldersListBox.Items
            AnalysisHolderListBox.Items.Add(Item)

        Next

        AllHoldersListBox.Items.Clear()
    End Sub

    Private Sub AllRemoveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AllRemoveButton.Click
        For Each Item As String In AnalysisHolderListBox.Items
            AllHoldersListBox.Items.Add(Item)

        Next

        AnalysisHolderListBox.Items.Clear()
    End Sub

    Private Sub AddItemButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddItemButton.Click
        If Not IsNothing(AllHoldersListBox.SelectedItem) Then
            AnalysisHolderListBox.Items.Add(AllHoldersListBox.SelectedItem)
            AllHoldersListBox.Items.Remove(AllHoldersListBox.SelectedItem)
        End If
    End Sub

    Private Sub RemoveItemButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveItemButton.Click
        If Not IsNothing(AnalysisHolderListBox.SelectedItem) Then
            AllHoldersListBox.Items.Add(AnalysisHolderListBox.SelectedItem)
            AnalysisHolderListBox.Items.Remove(AnalysisHolderListBox.SelectedItem)
        End If
    End Sub

    Private Sub GoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoButton.Click

        StatusLabelPlus.Text = "Ready"
        StatusLabelPlus.Refresh()
        StatusLabelMinus.Text = "Ready"
        StatusLabelMinus.Refresh()


        Dim Plus_Cov_Collection As New List(Of PositionalValuesHolder)
        Dim Minus_Cov_Collection As New List(Of PositionalValuesHolder)


        For Each Group As String In AnalysisHolderListBox.Items
            For i = 0 To MyViewer.Positional_Values_Collection.Count - 1
                If MyViewer.Positional_Values_Collection(i).Group = Group Then
                    Select Case MyViewer.Positional_Values_Collection(i).Strand
                        Case 1
                            Plus_Cov_Collection.Add(MyViewer.Positional_Values_Collection(i))
                        Case 2
                            Minus_Cov_Collection.Add(MyViewer.Positional_Values_Collection(i))
                    End Select
                End If
            Next i
        Next Group


        Dim Plus_TSS_List As New List(Of Integer)
        Dim Minus_TSS_List As New List(Of Integer)


        Dim PositiveCount As Integer = 0
        Dim SearchWindow As Integer = SearchWindowTextBox.Text
        Dim MinSignalToNoiseRatio As Single = SignalToNoiseTextBox.Text
        Dim MinTSSCoverage As Integer = TSSCovTextBox.Text
        Dim MinTSSPosMatch As Integer = TSSPosMatchTextBox.Text

        Dim MaxPos As Integer = Plus_Cov_Collection(0).Positional_Values.Count - SearchWindow
        Dim LocalBackground As Single = 0
        Dim CurrentSignalToNoiseRatio As Single = 0




        StatusLabelPlus.Text = "Searching TSS's on Plus strand"
        StatusLabelPlus.Refresh()


        For Pos = SearchWindow To MaxPos
            PositiveCount = 0

            For Each CoverageList As PositionalValuesHolder In Plus_Cov_Collection
                'Look here if TSS is present at i'th position

                If CoverageList.Positional_Values(Pos) >= MinTSSCoverage Then
                    LocalBackground = 0

                    'Collect coverage upstream
                    For j = 0 To SearchWindow - 1
                        LocalBackground += CoverageList.Positional_Values(Pos - 1 - j)
                    Next j

                    'Collect coverage downstream
                    For j = 0 To SearchWindow - 1
                        LocalBackground += CoverageList.Positional_Values(Pos + 1 + j)
                    Next j

                    If LocalBackground = 0 Then
                        LocalBackground = 1
                    End If

                    CurrentSignalToNoiseRatio = CoverageList.Positional_Values(Pos) / LocalBackground

                    If CurrentSignalToNoiseRatio >= MinSignalToNoiseRatio Then
                        PositiveCount += 1
                    End If

                    If PositiveCount >= MinTSSPosMatch Then
                        Plus_TSS_List.Add(Pos)
                        Exit For
                    End If

                End If 'CoverageList.Positional_Values(Pos) >= MinTSSCoverage

            Next CoverageList


        Next Pos


        StatusLabelPlus.Text = "Identified " & Plus_TSS_List.Count & " TSSs"
        StatusLabelPlus.Refresh()


        StatusLabelMinus.Text = "Searching TSS's on Minus strand"
        StatusLabelMinus.Refresh()


        For Pos = SearchWindow To MaxPos
            PositiveCount = 0

            For Each CoverageList As PositionalValuesHolder In Minus_Cov_Collection
                'Look here if TSS is present at i'th position

                If CoverageList.Positional_Values(Pos) >= MinTSSCoverage Then
                    LocalBackground = 0

                    'Collect coverage upstream
                    For j = 0 To SearchWindow - 1
                        LocalBackground += CoverageList.Positional_Values(Pos - 1 - j)
                    Next j

                    'Collect coverage downstream
                    For j = 0 To SearchWindow - 1
                        LocalBackground += CoverageList.Positional_Values(Pos + 1 + j)
                    Next j

                    If LocalBackground = 0 Then
                        LocalBackground = 1
                    End If

                    CurrentSignalToNoiseRatio = CoverageList.Positional_Values(Pos) / LocalBackground

                    If CurrentSignalToNoiseRatio >= MinSignalToNoiseRatio Then
                        PositiveCount += 1
                    End If

                    If PositiveCount >= MinTSSPosMatch Then
                        Minus_TSS_List.Add(Pos)
                        Exit For
                    End If

                End If 'CoverageList.Positional_Values(Pos) >= MinTSSCoverage

            Next CoverageList


        Next Pos


        StatusLabelMinus.Text = "Identified " & Minus_TSS_List.Count & " TSSs"
        StatusLabelMinus.Refresh()

        MyViewer.Features_Groups_List.Add(Bioinformatics.MakeTSSFromERS(Plus_TSS_List, Minus_TSS_List, "TSSs by ERS "))

        

        MyViewer.RefreshAssemblyList()

        MyViewer.DisplayFeatures()


        SearchCount += 1

    End Sub

End Class