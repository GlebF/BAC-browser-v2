﻿Public Class QuantitationBlock 'Coverage interval
    Private MyHolder As String = ""
    Private sglVal As Single = 0
    Private sglAuxVal As Single = 0
    Private strTAG As String = ""
    Private strDescription As String = ""
    Private intAbsoluteStart As Integer = 0
    Private intAbsoluteEnd As Integer = 0
    Private shDir As Short = 0
    Private intProjectionStart As Integer = 0
    Private intProjectionEnd As Integer = 0
    Private bVisible As Boolean = True
    Private colDrawColor As Color

    Public Property Holder_Name() As String
        Get
            Holder_Name = MyHolder
        End Get
        Set(ByVal value As String)
            MyHolder = value
        End Set
    End Property

    Public Property Draw_Color() As Color
        Get
            Draw_Color = colDrawColor
        End Get
        Set(ByVal value As Color)
            colDrawColor = value
        End Set
    End Property

    Public Property Value() As Single
        Get
            Value = sglVal
        End Get
        Set(ByVal value As Single)
            sglVal = value
        End Set
    End Property

    Public Property Aux_Value() As Single
        Get
            Aux_Value = sglAuxVal
        End Get
        Set(ByVal value As Single)
            sglAuxVal = value
        End Set
    End Property

    Public Property TAG() As String
        Get
            TAG = strTAG
        End Get
        Set(ByVal value As String)
            strTAG = value
        End Set
    End Property

    Public Property Description() As String
        Get
            Description = strDescription
        End Get
        Set(ByVal value As String)
            strDescription = value
        End Set
    End Property

    Public Property AbsoluteStart() As Integer
        Get
            AbsoluteStart = intAbsoluteStart
        End Get
        Set(ByVal value As Integer)
            intAbsoluteStart = value
        End Set
    End Property

    Public Property AbsoluteEnd() As Integer
        Get
            AbsoluteEnd = intAbsoluteEnd
        End Get
        Set(ByVal value As Integer)
            intAbsoluteEnd = value
        End Set
    End Property

    Public Property Direction() As Short
        Get
            Direction = shDir
        End Get
        Set(ByVal value As Short)
            shDir = value
        End Set
    End Property

    Public Property ProjectionStart() As Integer
        Get
            ProjectionStart = intProjectionStart
        End Get
        Set(ByVal value As Integer)
            intProjectionStart = value
        End Set
    End Property

    Public Property ProjectionEnd() As Integer
        Get
            ProjectionEnd = intProjectionEnd
        End Get
        Set(ByVal value As Integer)
            intProjectionEnd = value
        End Set
    End Property

    Public Property Visible() As Boolean
        Get
            Visible = bVisible
        End Get
        Set(ByVal value As Boolean)
            bVisible = value
        End Set
    End Property

    Public Function GetStrandDescription()
        Select Case Direction
            Case 1
                Return "Plus"
            Case 2
                Return "Minus"
            Case Else
                Return "Unknown"
        End Select
    End Function

End Class
