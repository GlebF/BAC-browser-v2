﻿Public Class HairpinFinder
    Public MyViewer As Genome_Viewer
    Public SearchCount As Integer = 0


   
   
    Private Sub GoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoButton.Click
        Dim Words As New List(Of K_Word)
        Words = Bioinformatics.Make_K_Word_List(MyViewer.Genome_Sequence, ScanWTextBox.Text)

        Dim StartPos As Integer = 0
        Dim EndPos As Integer = 0

        If StartComboBox.Text = "Sequence start" Then
            StartPos = 0
        Else
            StartPos = StartComboBox.Text - 1
        End If


        If EndComboBox.Text = "Sequence end" Then
            EndPos = Words.Count - 1
        Else
            EndPos = EndComboBox.Text - 1
        End If

        SystemProgressBarBox.MasterProgressBar.Maximum = EndPos - StartPos 'MyViewer.Genome_Sequence.Length - ScanWTextBox.Text
        SystemProgressBarBox.MasterProgressBar.Value = 0
        SystemProgressBarBox.Show()
        SystemProgressBarBox.Focus()
        SystemProgressBarBox.StatusLabel.Text = "Analyzing sequence"
        SystemProgressBarBox.StatusLabel.Refresh()



        Dim ForHairpins As List(Of OligoAlignment) = Nothing
        Dim min_dG As Single = MindGTextBox.Text

        Dim NewAsm As New FeaturesAssembly
        NewAsm.AssemblyName = "Hairpin search: " & SearchCount & " dG:" & min_dG
        NewAsm.Visible = True

        Dim FoundFeatures As New List(Of Genome_Feature)



        Dim counter As Integer = 0
        For i = StartPos To EndPos
            ForHairpins = Bioinformatics.CreateHairpinList(Words(i).Word_Text, TTextBox.Text, , True, min_dG)
            For Each Item As OligoAlignment In ForHairpins
                If Item.SumDG < min_dG Then
                    Dim NewFeature As New Genome_Feature
                    NewFeature.Type = 3
                    NewFeature.Direction = 1
                    NewFeature.TAG = "hairpin region-" & counter
                    NewFeature.Name = NewFeature.TAG
                    NewFeature.AbsoluteStart = Words(i).Relative_Position + 1
                    NewFeature.AbsoluteEnd = NewFeature.AbsoluteStart + Words(i).Word_Text.Length - 1

                    FoundFeatures.Add(NewFeature)

                    'NewAsm.FeaturesList.Add(NewFeature)
                    Exit For
                End If
            Next

            counter += 1

            SystemProgressBarBox.MasterProgressBar.PerformStep()


        Next

        Dim ClusterList As New List(Of Genome_Feature)
        For i = 0 To FoundFeatures.Count - 1




            If i < FoundFeatures.Count - 1 Then
                If FoundFeatures(i).AbsoluteEnd > FoundFeatures(i + 1).AbsoluteStart Then
                    'Put feature in combined list
                    ClusterList.Add(FoundFeatures(i))
                Else

                    If ClusterList.Count = 0 Then
                        NewAsm.FeaturesList.Add(FoundFeatures(i))
                    Else
                        ClusterList.Add(FoundFeatures(i))

                        Dim CombinedFeature As New Genome_Feature

                        CombinedFeature.Type = ClusterList(0).Type
                        CombinedFeature.Direction = ClusterList(0).Direction
                        CombinedFeature.TAG = ClusterList(0).TAG
                        CombinedFeature.Name = ClusterList(0).Name
                        CombinedFeature.AbsoluteStart = ClusterList(0).AbsoluteStart
                        CombinedFeature.AbsoluteEnd = ClusterList(ClusterList.Count - 1).AbsoluteEnd
                        NewAsm.FeaturesList.Add(CombinedFeature)

                        ClusterList.Clear()
                    End If

                End If

            Else
                If FoundFeatures(i - 1).AbsoluteEnd > FoundFeatures(i).AbsoluteStart Then
                    ClusterList.Add(FoundFeatures(i))
                    Dim CombinedFeature As New Genome_Feature

                    CombinedFeature.Type = ClusterList(0).Type
                    CombinedFeature.Direction = ClusterList(0).Direction
                    CombinedFeature.TAG = ClusterList(0).TAG
                    CombinedFeature.Name = ClusterList(0).Name
                    CombinedFeature.AbsoluteStart = ClusterList(0).AbsoluteStart
                    CombinedFeature.AbsoluteEnd = ClusterList(ClusterList.Count - 1).AbsoluteEnd
                    NewAsm.FeaturesList.Add(CombinedFeature)

                    ClusterList.Clear()
                Else
                    ClusterList.Add(FoundFeatures(i))
                End If


            End If

        Next


        If NewAsm.FeaturesList.Count > 0 Then
            MyViewer.Features_Groups_List.Add(NewAsm)
            MyViewer.RefreshAssemblyList()
            MyViewer.DisplayFeatures()
        End If

        SystemProgressBarBox.Close()

        SearchCount += 1
    End Sub


End Class