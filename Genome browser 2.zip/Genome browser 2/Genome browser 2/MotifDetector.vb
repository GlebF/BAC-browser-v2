﻿Public Class MotifDetector

    Public MotiffLOGO As New SequenceLOGO

    Public SearchResults As New List(Of MotifSearchResult)
    Public CurrentPWM As PWM
    Public CurrentGenome As Genome_Viewer


    Public Sub DrawPWM(ByVal SelectedPWM As PWM)
        PWMDataGridView.Columns.Clear()
        For i = 0 To SelectedPWM.PWM_Table.Count - 1
            PWMDataGridView.Columns.Add(i + 1, i + 1)
            PWMDataGridView.Columns(i).Width = 50
        Next


        PWMDataGridView.Rows.Add(4)
        PWMDataGridView.Rows(0).HeaderCell.Value = "A"
        PWMDataGridView.Rows(1).HeaderCell.Value = "T"
        PWMDataGridView.Rows(2).HeaderCell.Value = "G"
        PWMDataGridView.Rows(3).HeaderCell.Value = "C"

        For i = 0 To SelectedPWM.PWM_Table.Count - 1
            PWMDataGridView.Rows(0).Cells(i).Value = SelectedPWM.PWM_Table(i).A_Weight
            PWMDataGridView.Rows(1).Cells(i).Value = SelectedPWM.PWM_Table(i).T_Weight
            PWMDataGridView.Rows(2).Cells(i).Value = SelectedPWM.PWM_Table(i).G_Weight
            PWMDataGridView.Rows(3).Cells(i).Value = SelectedPWM.PWM_Table(i).C_Weight

        Next
    End Sub

    Private Sub AddButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddButton.Click
        If Master.OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then

            For Each File As String In Master.OpenFileDialog.FileNames
                FilesDataGridView.Rows.Add(File, "0")
            Next

        End If

    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        FilesDataGridView.Rows.Clear()

    End Sub

    Private Sub MotifDetector_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MotiffLOGO.Location = New Point(0, 0)
        MotiffLOGO.Dock = DockStyle.Fill
        LOGOPanel.Controls.Add(MotiffLOGO)

        CurrentPWM = Nothing
        SearchResults.Clear()

        SourceComboBox.Items.Clear()
        For Each Group As FeaturesAssembly In CurrentGenome.Features_Groups_List
            SourceComboBox.Items.Add(Group.AssemblyName)
        Next Group

    End Sub

    Private Sub ViewButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewButton.Click
        Dim NewPWM As New PWM

        NewPWM = DataIO.LoadPWM(FilesDataGridView.CurrentRow.Cells(0).Value)
        DrawPWM(NewPWM)

        MotiffLOGO.Motiff_PWM = NewPWM
        MotiffLOGO.ConvertPWMToLOGO(True)
        MotiffLOGO.Invalidate()

        MaxTextBox.Text = NewPWM.GetMaxWeight
        MinTextBox.Text = NewPWM.GetMinWeight

    End Sub

    Private Sub RemoveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveButton.Click
        For i = FilesDataGridView.Rows.Count - 2 To 0 Step -1
            If FilesDataGridView.Rows(i).Selected Then
                FilesDataGridView.Rows.RemoveAt(i)
            End If
        Next
    End Sub

    Private Sub UpButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpButton.Click
        Dim SelectedIndex As Integer = FilesDataGridView.CurrentRow.Index
        Dim SelectedItem As DataGridViewRow = FilesDataGridView.CurrentRow
        FilesDataGridView.Rows.RemoveAt(SelectedIndex)
        FilesDataGridView.Rows.Insert(SelectedIndex - 1, SelectedItem)
        FilesDataGridView.Rows(SelectedIndex - 1).Selected = True

    End Sub

    Private Sub DownButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DownButton.Click
        Dim SelectedIndex As Integer = FilesDataGridView.CurrentRow.Index
        Dim SelectedItem As DataGridViewRow = FilesDataGridView.CurrentRow
        FilesDataGridView.Rows.RemoveAt(SelectedIndex)
        FilesDataGridView.Rows.Insert(SelectedIndex + 1, SelectedItem)
        FilesDataGridView.Rows(SelectedIndex + 1).Selected = True

    End Sub

    Private Sub SearchButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchButton.Click
        ReportTextBox.Text = ""
        SearchResults.Clear()

        For i = 0 To FilesDataGridView.Rows.Count - 2
            Dim NewPWM As New PWM
            NewPWM = DataIO.LoadPWM(FilesDataGridView.Rows(i).Cells(0).Value)
            StatusLabel.Text = "For strand of: " & FilesDataGridView.Rows(i).Cells(0).Value
            StatusLabel.Refresh()
            Dim WordList_For As New List(Of K_Word_Weighted)
            WordList_For = Bioinformatics.SearchMotifWithPWM(CurrentGenome.Genome_Sequence, NewPWM)
            StatusLabel.Text = "Rev strand of: " & FilesDataGridView.Rows(i).Cells(0).Value
            StatusLabel.Refresh()
            Dim WordList_Rev As New List(Of K_Word_Weighted)
            WordList_Rev = Bioinformatics.SearchMotifWithPWM(CurrentGenome.Genome_Sequence, Bioinformatics.GetReverseComplementPWM(NewPWM))

            Dim ABSThreshold As Single = CType(FilesDataGridView.Rows(i).Cells(1).Value, Single)

            Dim counter As Integer = 0

            Dim For_Weight_Filtered_List As New List(Of K_Word_Weighted)
            Dim Rev_Weight_Filtered_List As New List(Of K_Word_Weighted)

            For Each Word As K_Word_Weighted In WordList_For
                If Word.Weight >= ABSThreshold Then
                    For_Weight_Filtered_List.Add(Word)
                    counter += 1
                End If
            Next

            For Each Word As K_Word_Weighted In WordList_Rev
                If Word.Weight >= ABSThreshold Then
                    Rev_Weight_Filtered_List.Add(Word)
                    counter += 1
                End If
            Next


            Dim NewResult As New MotifSearchResult
            NewResult.For_Hits = For_Weight_Filtered_List
            NewResult.Rev_Hits = Rev_Weight_Filtered_List
            NewResult.Target_PWM = NewPWM
            Dim NameArr As String() = FilesDataGridView.Rows(i).Cells(0).Value.Split("\")
            NewResult.Name = NameArr(NameArr.GetUpperBound(0)).Split(".")(0) & "_T=" & FilesDataGridView.Rows(i).Cells(1).Value
            SearchResults.Add(NewResult)

            ReportTextBox.Text &= NewResult.Name & vbNewLine
            ReportTextBox.Text &= "Max weight: " & NewPWM.GetMaxWeight & vbNewLine
            ReportTextBox.Text &= "Min weight: " & NewPWM.GetMinWeight & vbNewLine
            ReportTextBox.Text &= "Max threshold: " & ABSThreshold & vbNewLine
            ReportTextBox.Text &= "Total words found: " & counter & vbNewLine
            'ReportTextBox.Text &= vbNewLine

            If TSSCheckBox.Checked Then


                Dim FeaturesList As List(Of Genome_Feature) = Nothing

                For Each Group As FeaturesAssembly In CurrentGenome.Features_Groups_List
                    If Group.AssemblyName = SourceComboBox.Text Then
                        FeaturesList = Group.FeaturesList
                    End If
                Next Group

                Dim ProxDist As Integer = 0
                Dim MaxDistance As Integer = DistanceTextBox.Text

                For Each Feature As Genome_Feature In FeaturesList

                    If Feature.Type = 5 Then

                        For Each Result As MotifSearchResult In SearchResults
                            For Each Word As K_Word_Weighted In Result.For_Hits
                                ProxDist = Math.Min(Math.Abs(Feature.AbsoluteStart - Word.Relative_Position - 1), Math.Abs(Feature.AbsoluteStart - Word.Relative_Position - Word.Word_Text.Length))
                                If ProxDist <= MaxDistance Then
                                    Word.Bool_TAG = True
                                End If
                            Next Word


                            For Each Word As K_Word_Weighted In Result.Rev_Hits
                                ProxDist = Math.Min(Math.Abs(Feature.AbsoluteStart - Word.Relative_Position - 1), Math.Abs(Feature.AbsoluteStart - Word.Relative_Position - Word.Word_Text.Length))
                                If ProxDist <= MaxDistance Then
                                    Word.Bool_TAG = True
                                End If
                            Next Word


                        Next Result

                    End If 'Feature.Type = 5

                Next Feature


                For Each Result As MotifSearchResult In SearchResults
                    For k = Result.For_Hits.Count - 1 To 0 Step -1
                        If Result.For_Hits(k).Bool_TAG = False Then
                            Result.For_Hits.RemoveAt(k)
                            counter -= 1
                        End If
                    Next k

                    For k = Result.Rev_Hits.Count - 1 To 0 Step -1
                        If Result.Rev_Hits(k).Bool_TAG = False Then
                            Result.Rev_Hits.RemoveAt(k)
                            counter -= 1
                        End If
                    Next k

                Next


                ReportTextBox.Text &= "After filtration: " & counter & vbNewLine
            End If 'TSSCheckBox.Checked

            ReportTextBox.Text &= vbNewLine


        Next



    End Sub

    Private Sub DrawButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawButton.Click
        For Each Result As MotifSearchResult In SearchResults

            Dim NewGroup As New FeaturesAssembly
            NewGroup.AssemblyName = Result.Name
            NewGroup.Visible = True
            Dim counter As Integer = 0

            For Each Word As K_Word_Weighted In Result.For_Hits
                Dim NewFeature As New Genome_Feature
                NewFeature.AbsoluteStart = Word.Relative_Position + 1
                NewFeature.AbsoluteEnd = Word.Relative_Position + Word.Word_Text.Length
                NewFeature.Direction = 1
                NewFeature.Type = 3
                NewFeature.TAG = Result.Name & "-" & counter
                NewFeature.Name = NewFeature.TAG
                NewFeature.Group = Result.Name
                NewGroup.FeaturesList.Add(NewFeature)
                counter += 1
            Next

            For Each Word As K_Word_Weighted In Result.Rev_Hits
                Dim NewFeature As New Genome_Feature
                NewFeature.AbsoluteStart = Word.Relative_Position + 1
                NewFeature.AbsoluteEnd = Word.Relative_Position + Word.Word_Text.Length
                NewFeature.Direction = 2
                NewFeature.Type = 3
                NewFeature.TAG = Result.Name & "-" & counter
                NewFeature.Name = NewFeature.TAG
                NewFeature.Group = Result.Name
                NewGroup.FeaturesList.Add(NewFeature)
                counter += 1
            Next

            CurrentGenome.Features_Groups_List.Add(NewGroup)
        Next

        CurrentGenome.RefreshAssemblyList()
        CurrentGenome.DisplayFeatures()

    End Sub

    
End Class